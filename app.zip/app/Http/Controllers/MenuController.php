<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use App\Models\Role;
use App\Models\SubMenu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MenuController extends Controller
{
    public function __construct()
    {
        $this->middleware(['only.admin']);
    }

    public function pengaturanRole(Request $request)
    {
        if(count($request->all())) {
            $input = $request->validate([
                'role' => ['required'],
            ]);
            Role::create($input);
            return to_route('pengaturan_role')->with('success', 'Role baru berhasil ditambahkan!');
        } else {
            $data['title'] = 'Pengaturan Role';
            $data['roles'] = Role::all();
            return view('admin.pengaturan_role', $data);
        }
    }

    public function editRole(Request $request, $id)
    {
        $input = $request->validate([
            'role' => ['required'],
        ]);
        Role::find($id)->update($input);
        return to_route('pengaturan_role')->with('success', 'Role berhasil diubah!');
    }

    public function deleteRole($id)
    {
        Role::find($id)->delete($id);
        DB::table('user_access_menu')->where('role_id', $id)->delete();
        return to_route('pengaturan_role')->with('success', 'Role berhasil dihapus!');
    }

    public function aksesRole(Request $request, $id)
    {
        if(count($request->all())) {
            $menu_id = $request->menuId;
            $role_id = $request->roleId;

            $data = [
                'role_id' => $role_id,
                'menu_id' => $menu_id
            ];

            $result = DB::table('user_access_menu')->where($data)->get();
            if ($result->count() < 1) {
                DB::table('user_access_menu')->insert($data);
            } else {
                DB::table('user_access_menu')->where($data)->delete();
            }
            session()->flash('success', 'Role akses berhasil diubah!');
        }
        $data['title'] = 'Pengaturan Role Akses Menu';
        $data['menus'] = Menu::all();
        $data['role'] = Role::find($id);
        return view('admin.akses_role', $data);
    }

    public function menu(Request $request)
    {
        if(count($request->all())) {
            $input = $request->validate([
                'menu' => ['required'],
            ]);
            Menu::create($input);
            return to_route('menu')->with('success', 'Menu baru berhasil ditambahkan!');
        }
        $data['title'] = 'Pengaturan Menu';
        $data['menus'] = Menu::all();
        return view('admin.menu.menu', $data);
    }

    public function editMenu(Request $request, $id)
    {
        $input = $request->validate([
            'menu' => ['required'],
        ]);
        Menu::find($id)->update($input);
        return to_route('menu')->with('success', 'Menu berhasil diubah!');
    }

    public function deleteMenu($id)
    {
        Menu::find($id)->delete($id);
        SubMenu::where('menu_id', '=', $id)->delete();
        return to_route('menu')->with('success', 'Menu berhasil dihapus!');
    }

    public function subMenu(Request $request)
    {
        if(count($request->all())) {
            $input = $request->validate([
                'title' => ['required'],
                'menu_id' => ['required'],
                'icon' => ['required'],
                'url' => ['required'],
                'is_active' => ['required'],
            ]);
            SubMenu::create($input);
            return to_route('sub_menu')->with('success', 'Sub Menu baru berhasil ditambahkan!');
        } else {
            $data['title'] = 'Pengaturan Sub Menu';
            $data['sub_menu'] = SubMenu::getSubMenu();
            $data['menu'] = Menu::all();
            return view('admin.menu.sub_menu', $data);
        }
    }

    public function editSubMenu(Request $request, $id)
    {
        $input = $request->validate([
            'title' => ['required'],
            'menu_id' => ['required'],
            'icon' => ['required'],
            'url' => ['required'],
            'is_active' => ['required'],
        ]);
        SubMenu::find($id)->update($input);
        return to_route('sub_menu')->with('success', 'Sub Menu berhasil diubah!');
    }

    public function deleteSubMenu($id)
    {
        SubMenu::find($id)->delete($id);
        return to_route('sub_menu')->with('success', 'Sub Menu berhasil dihapus!');
    }
}
