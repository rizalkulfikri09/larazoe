<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\JamBooking;
use App\Models\SettingApp;
use App\Exports\UsersExport;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware(['only.admin']);
    }

    public function showKonsumen(Request $request)
    {
        $data['title'] = 'Daftar Konsumen';
        if ($request->ajax()) {
            $query = User::select(['id', 'nama', 'no_tlp', 'email', 'is_active'])->whereNot('role_id', '1')->latest()->get();
            return DataTables::of($query)->addIndexColumn()
            ->addColumn('ids', function ($row) {
                $check = '<input type="checkbox" class="sub_chk" data-ids="'. $row->id .'">';
                return $check;
            })
            ->addColumn('opsi', function ($row) {
                $btn = '<a href="javascript:void(0)" data-toggle="tooltip" data-id="'.$row->id.'" data-original-title="Edit" class="btn btn-success btn-sm tombol editKonsumen">Edit</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteKonsumen" data-toggle="tooltip" data-id="'.$row->id.'" data-original-title="Delete">Hapus</a>';
                return $btn;
            })
            ->editColumn('is_active', function ($row) {
                return $row->is_active == 1 ? 'Aktif' : 'Tidak Aktif';
            })
            ->rawColumns(['ids', 'opsi'])->toJson();
        }

        return view('admin.daftar_konsumen', $data);
    }

    public function createKonsumen(Request $request)
    {
        $request->validate([
            'nama' => ['required'],
            'no_tlp' => ['required', 'regex:/^0\d/', 'numeric', Rule::unique('users', 'no_tlp')->ignore($request->user_id, 'id')],
            'email' => ['required', 'email:rfc,dns', Rule::unique('users', 'email')->ignore($request->user_id, 'id')],
            'password' => [Rule::requiredIf($request->has('password')), 'min:8'],
        ], [
            'no_tlp.regex' => 'nomor WhatApp tidak sesuai format 08123XXXXXXX.',
        ]);

        if (!empty($request->user_id)) {
            $user = User::where('id', $request->user_id)->first();
            $user->update([
                'nama' => ucwords($request->nama),
                'no_tlp' => $request->no_tlp,
                'email' => $request->email,
                'is_active' => $request->status,
            ]);
            $status = 'diubah!';
        } else {
            User::create([
                'nama' => ucwords($request->nama),
                'no_tlp' => $request->no_tlp,
                'email' => $request->email,
                'password' => bcrypt($request->password),
                'image' => 'default.jpg',
                'role_id' => 2,
                'is_active' => 1,
            ]);
            $status = 'ditambah!';
        }

        return response()->json(['success' => true, 'message' => "Data konsumen berhasil $status"]);
    }

    public function editKonsumen($id)
    {
        $user = User::find($id);
        return response()->json($user);
    }

    public function deleteKonsumen($id)
    {
        $user = User::find($id);
        if ($user->image != 'default.jpg') {
            \Illuminate\Support\Facades\File::delete(public_path('/frontend/images/profile/' . $user->image));
        }
        $user->delete();
        return response()->json(['success' => true, 'message' => 'Data konsumen berhasil dihapus!']);
    }

    public function deleteAllKonsumen(Request $request)
    {
        $ids = $request->ids;
        $user = User::whereIn('id', explode(",", $ids));
        foreach ($user->get() as $row) {
            if ($row->image != 'default.jpg') {
                \Illuminate\Support\Facades\File::delete(public_path('/frontend/images/profile/' . $row->image));
            }
        }
        $user->delete();
        return response()->json(['success' => true, 'message' => 'Data konsumen berhasil dihapus!']);
    }

    public function resetPasswordAkun($id)
    {
        $user = User::where('id', '=', $id)->first();
        $user->update(['password' => bcrypt('password')]);
        return response()->json(['success' => true, 'message' => 'Password akun konsumen berhasil direset, default password = <b>password</b>']);
    }

    public function exportKonsumenExcel()
    {
        return UsersExport::export_excel();
    }

    public function exportKonsumenPdf()
    {
        return UsersExport::export_pdf();
    }

    public function pengaturanJam()
    {
        $data['title'] = 'Pengaturan Jam Booking';
        $data['jam_booking'] = JamBooking::select('id', 'jam', 'status')->get();
        $data['jml_konsumen'] = SettingApp::find(2);
        $data['tanggal_libur'] = DB::table('libur_studio')->orderBy('tanggal', 'asc')->get();
        return view('admin.pengaturan_jam', $data);
    }

    public function createJamBooking(Request $request)
    {
        $attr = $request->validate([
            'jam' => ['required'],
            'status' => ['required'],
        ]);

        JamBooking::create($attr);
        return to_route('pengaturan_jam')->with('success', 'Jam booking baru berhasil ditambahkan!');
    }

    public function editJamBooking($id)
    {
        $data['title'] = 'Edit Jam Booking';
        $data['jam_booking'] = JamBooking::findOrFail($id);
        $data['jml_hari'] = [7,1,2,3,4,5,6,0];
        return view('admin.edit_jam', $data);
    }

    public function updateJamBooking(Request $request, $id)
    {
        $attr = $request->validate([
            'jam' => ['required'],
            'status' => ['required'],
        ]);

        $jam_booking = JamBooking::where('id', $id)->first();
        $jam_booking->update($attr);
        return to_route('pengaturan_jam')->with('success', 'Jam booking berhasil diubah!');
    }

    public function deleteJamBooking($id)
    {
        JamBooking::find($id)->delete($id);
        return to_route('pengaturan_jam')->with('success', 'Jam booking berhasil dihapus!');
    }

    public function updateJmlKonsumen(Request $request)
    {
        $jml_konsumen = SettingApp::find(2);
        $jml_konsumen->update(['value_1' => $request->jml_konsumen]);
        return to_route('pengaturan_jam')->with('success', 'Jumlah konsumen per sesi berhasil diubah!');
    }

    public function createTglLibur(Request $request)
    {
        $attr = $request->validate([
            'tanggal' => ['required'],
        ]);

        DB::table('libur_studio')->insert($attr);
        return to_route('pengaturan_jam')->with('success', 'Tanggal libur studio berhasil ditambahkan!');
    }

    public function deleteLiburStudio($id)
    {
        DB::table('libur_studio')->delete($id);
        return to_route('pengaturan_jam')->with('success', 'Tanggal libur studio berhasil dihapus!');
    }

    public function pengaturanAplikasi()
    {
        $data['title'] = 'Pengaturan Aplikasi';
        $data['zona_waktu'] = ['7' => '+7 (WIB)','8' => '+8 (WITA)','9' => '+9 (WIT)'];
        $data['pengaturan_sistem'] = SettingApp::find(1);
        $data['pengaturan_pg'] = SettingApp::find(2);
        $data['bank_1'] = SettingApp::find(3);
        $data['bank_2'] = SettingApp::find(4);
        $data['pengaturan_umum'] = SettingApp::find(5);
        $data['portofolio'] = SettingApp::find(6);
        $data['header_website'] = SettingApp::find(7);
        $data['bagian_satu'] = SettingApp::find(8);
        $data['bagian_dua'] = SettingApp::find(9);
        $data['bagian_tiga'] = SettingApp::find(10);
        $data['pertanyaan'] = SettingApp::find(11);
        $data['footer_website'] = SettingApp::find(12);
        $data['logo_slider'] = SettingApp::find(13);
        $data['whatsapp'] = SettingApp::find(14);
        return view('admin.pengaturan_aplikasi', $data);
    }

    public function editWhatsapp(Request $request)
    {
        SettingApp::find(14)->update([
            'value_1' => $request->nomor_admin,
            'value_2' => $request->status_wg,
            'value_3' => $request->reminder,
        ]);
        $get_setting = SettingApp::find(1);
        if ($get_setting->value_2 != $request->verifikasi) {
            $get_setting->update(['value_2' => $request->verifikasi]);
        }
        if ($get_setting->value_10 != $request->verifikasi_email) {
            $get_setting->update(['value_10' => $request->verifikasi_email]);
        }
        return to_route('pengaturan_aplikasi')->with('success', 'Data WhatsApp Gateway berhasil diubah!');
    }

    public function editPaymentManual(Request $request)
    {
        SettingApp::find(3)->update([
            'value_5' => $request->is_active,
            'value_4' => $request->jml_dp,
        ]);
        return to_route('pengaturan_aplikasi')->with('success', 'Data pembayaran manual berhasil diubah!');
    }

    public function editBankSatu(Request $request)
    {
        $request->validate([
            'logo_bank_1' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
        ]);
        $bank_1 = SettingApp::find(3);
        $input = [
            'value_2' => $request->rekening_1,
            'value_3' => $request->nama_1,
        ];
        if ($file = $request->file('logo_bank_1')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/images/logo_bank'), $file_name);
            $input['value_1'] = $file_name;
        }
        $bank_1->update($input);
        return to_route('pengaturan_aplikasi')->with('success', 'Data bank satu berhasil diubah!');
    }

    public function editBankDua(Request $request)
    {
        $request->validate([
            'logo_bank_2' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
        ]);
        $bank_2 = SettingApp::find(4);
        $input = [
            'value_2' => $request->rekening_2,
            'value_3' => $request->nama_2,
        ];
        if ($file = $request->file('logo_bank_2')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/images/logo_bank'), $file_name);
            $input['value_1'] = $file_name;
        }
        $bank_2->update($input);
        return to_route('pengaturan_aplikasi')->with('success', 'Data bank dua berhasil diubah!');
    }

    public function editPengaturanUmum(Request $request)
    {
        $get_pengaturan_umum = SettingApp::find(5);
        $get_tutup_studio = SettingApp::find(2);
        $input = [
            "value_1" => $request->title_aplikasi,
            "value_2" => $request->nama_aplikasi,
            "value_3" => $request->copy_aplikasi,
            "value_5" => $request->zona_waktu,
            "value_6" => $request->pemilik,
            "value_7" => $request->kota_studio,
            "value_8" => $request->nama_studio,
            "value_9" => $request->alamat_studio,
            "value_10" => $request->note_studio,
        ];
        if ($file = $request->file('favicon_aplikasi')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/images/favicon'), $file_name);
            $input['value_4'] = $file_name;
        }
        if ($get_tutup_studio->value_4 != $request->tutup_studio) {
            $get_tutup_studio->update(['value_4' => $request->tutup_studio]);
        }
        $get_pengaturan_umum->update($input);
        return to_route('pengaturan_aplikasi')->with('success', 'Pengaturan umum berhasil diubah!');
    }

    public function editPengaturanSistem(Request $request)
    {
        $request->validate([
            'jam_expired' => [
                function ($attribute, $value, $fail) {
                    if ($value > 12) {
                        $fail('Jam expired booking harus kurang dari 12 jam!');
                    }
                }
            ]
        ]);
        $nama_cs = explode(",", $request->nama_cs);
        SettingApp::find(1)->update([
            'value_3' => $request->jam_expired,
            'value_4' => $request->registrasi,
            'value_5' => $request->jml_wedding,
            'value_6' => change_rupiah($request->transport),
            'value_7' => $request->hari_resc,
            'value_8' => $request->catatan_transport,
            'value_9' => $request->max_minggu,
            'items' => json_encode($nama_cs),
        ]);
        return to_route('pengaturan_aplikasi')->with('success', 'Pengaturan sistem berhasil diubah!');
    }

    public function editPortofolio(Request $request)
    {
        $request->validate([
            'portofolio_1' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'portofolio_2' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'portofolio_3' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'portofolio_4' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'portofolio_5' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'portofolio_6' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'portofolio_7' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'portofolio_8' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'portofolio_9' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
        ]);
        $get_portofolio = SettingApp::find(6);
        if ($file = $request->file('portofolio_1')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/gallery'), $file_name);
            $input['value_1'] = $file_name;
        }
        if ($file = $request->file('portofolio_2')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/gallery'), $file_name);
            $input['value_2'] = $file_name;
        }
        if ($file = $request->file('portofolio_3')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/gallery'), $file_name);
            $input['value_3'] = $file_name;
        }
        if ($file = $request->file('portofolio_4')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/gallery'), $file_name);
            $input['value_4'] = $file_name;
        }
        if ($file = $request->file('portofolio_5')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/gallery'), $file_name);
            $input['value_5'] = $file_name;
        }
        if ($file = $request->file('portofolio_6')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/gallery'), $file_name);
            $input['value_6'] = $file_name;
        }
        if ($file = $request->file('portofolio_7')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/gallery'), $file_name);
            $input['value_7'] = $file_name;
        }
        if ($file = $request->file('portofolio_8')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/gallery'), $file_name);
            $input['value_8'] = $file_name;
        }
        if ($file = $request->file('portofolio_9')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/gallery'), $file_name);
            $input['value_9'] = $file_name;
        }
        $get_portofolio->update($input);
        return to_route('pengaturan_aplikasi')->with('success', 'Portofolio berhasil diupdate!');
    }

    public function editHeaderWeb(Request $request)
    {
        $request->validate([
            'bg_utama' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
        ], [
            'bg_utama.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 2 MB.',
        ]);
        $input = [
            'value_1' => $request->title_website,
            'value_2' => $request->teks_logo,
            'value_3' => $request->teks_tengah,
            'value_4' => $request->tagline,
            'value_5' => $request->tombol_aplikasi,
        ];
        if ($file = $request->file('bg_utama')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img'), $file_name);
            $input['value_6'] = $file_name;
        }
        SettingApp::find(7)->update($input);
        return to_route('pengaturan_aplikasi')->with('success', 'Header website berhasil diubah!');
    }

    public function editBagianSatu(Request $request)
    {
        $request->validate([
            'bagian_1' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
        ], [
            'bagian_1.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 2 MB.',
        ]);
        $input = [
            'value_1' => $request->judul_1,
            'items' => $request->isi_1,
        ];
        if ($file = $request->file('bagian_1')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img'), $file_name);
            $input['value_2'] = $file_name;
        }
        SettingApp::find(8)->update($input);
        return to_route('pengaturan_aplikasi')->with('success', 'Tampilan website berhasil diubah!');
    }

    public function editBagianDua(Request $request)
    {
        $request->validate([
            'bagian_2' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
        ], [
            'bagian_2.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 2 MB.',
        ]);
        $input = [
            'value_1' => $request->judul_2,
            'value_3' => $request->title_1,
            'value_4' => $request->title_2,
            'value_5' => $request->title_3,
            'value_6' => $request->title_4,
            'value_7' => $request->keterangan_1,
            'value_8' => $request->keterangan_2,
            'value_9' => $request->keterangan_3,
            'value_10' => $request->keterangan_4,
        ];
        if ($file = $request->file('bagian_2')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img'), $file_name);
            $input['value_2'] = $file_name;
        }
        SettingApp::find(9)->update($input);
        return to_route('pengaturan_aplikasi')->with('success', 'Tampilan website berhasil diubah!');
    }

    public function editBagianTiga(Request $request)
    {
        $request->validate([
            'bagian_3' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
        ], [
            'bagian_3.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 2 MB.',
        ]);
        $input = [
            'value_2' => $request->keterangan,
            'value_3' => $request->is_active,
            'value_4' => $request->no_whatsapp,
            'value_5' => $request->pesan_wa,
            'value_6' => $request->chat,
            'items' => $request->link_youtube,
        ];
        if ($file = $request->file('bagian_3')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img'), $file_name);
            $input['value_1'] = $file_name;
        }
        SettingApp::find(10)->update($input);
        return to_route('pengaturan_aplikasi')->with('success', 'Tampilan website berhasil diubah!');
    }

    public function editPertanyaan(Request $request)
    {
        SettingApp::find(11)->update([
            'value_1' => $request->pertanyaan_1,
            'value_2' => $request->jawaban_1,
            'value_3' => $request->pertanyaan_2,
            'value_4' => $request->jawaban_2,
            'value_5' => $request->pertanyaan_3,
            'value_6' => $request->jawaban_3,
            'value_7' => $request->pertanyaan_4,
            'value_8' => $request->jawaban_4,
            'value_9' => $request->pertanyaan_5,
            'value_10' => $request->jawaban_5,
        ]);
        return to_route('pengaturan_aplikasi')->with('success', 'Pertanyaan/FAQ berhasil diubah!');
    }

    public function editFooterWeb(Request $request)
    {
        SettingApp::find(12)->update([
            'value_1' => $request->informasi,
            'value_2' => $request->instagram,
            'value_3' => $request->facebook,
            'value_4' => $request->youtube,
            'value_5' => $request->whatsapp,
            'value_6' => $request->alamat_studio,
            'value_7' => $request->email,
            'value_8' => $request->no_tlp,
            'items' => $request->google_maps,
        ]);
        return to_route('pengaturan_aplikasi')->with('success', 'Pertanyaan/FAQ berhasil diubah!');
    }

    public function editLogoSlide(Request $request)
    {
        $request->validate([
            'logo_1' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'logo_2' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'logo_3' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'logo_4' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'logo_5' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
            'logo_6' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
        ]);
        if ($file = $request->file('logo_1')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/clients'), $file_name);
            $input['value_1'] = $file_name;
        }
        if ($file = $request->file('logo_2')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/clients'), $file_name);
            $input['value_2'] = $file_name;
        }
        if ($file = $request->file('logo_3')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/clients'), $file_name);
            $input['value_3'] = $file_name;
        }
        if ($file = $request->file('logo_4')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/clients'), $file_name);
            $input['value_4'] = $file_name;
        }
        if ($file = $request->file('logo_5')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/clients'), $file_name);
            $input['value_5'] = $file_name;
        }
        if ($file = $request->file('logo_6')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/avilon/img/clients'), $file_name);
            $input['value_6'] = $file_name;
        }
        SettingApp::find(13)->update($input);
        return to_route('pengaturan_aplikasi')->with('success', 'Logo slide berhasil diupdate!');
    }

    public function editTripay(Request $request)
    {
        $status_xendit = SettingApp::find(2)->value_3;
        if ($status_xendit == 0) {
            SettingApp::find(2)->update([
                'value_2' => $request->is_active,
            ]);
            return to_route('pengaturan_aplikasi')->with('success', 'Status payment gateway Tripay berhasil diupdate!');
        }
        return to_route('pengaturan_aplikasi')->with('danger', 'Mohon nonaktifkan payment gateway Xendit terlebih dahulu!');
    }

    public function editXendit(Request $request)
    {
        $status_tripay = SettingApp::find(2)->value_2;
        if ($status_tripay == 0) {
            SettingApp::find(2)->update([
                'value_3' => $request->is_active,
            ]);
            return to_route('pengaturan_aplikasi')->with('success', 'Status payment gateway Xendit berhasil diupdate!');
        }
        return to_route('pengaturan_aplikasi')->with('danger', 'Mohon nonaktifkan payment gateway Tripay terlebih dahulu!');
    }

    public function daftarTransaksi(Request $request)
    {
        if ($request->ajax()) {
            $query = \App\Models\Transaksi::select(['kode_booking', 'kode_wedding', 'kode_undangan', 'kode_selfphoto', 'no_ref', 'link', 'status']);
            $data = empty($query) ? $query : $query->latest()->get();
            return DataTables::of($data)->addIndexColumn()
            ->editColumn('kode_booking', function ($row) {
                return isset($row->kode_booking) ? $row->kode_booking : "-";
            })
            ->editColumn('kode_wedding', function ($row) {
                return isset($row->kode_wedding) ? $row->kode_wedding : "-";
            })
            ->editColumn('kode_undangan', function ($row) {
                return isset($row->kode_undangan) ? $row->kode_undangan : "-";
            })
            ->editColumn('kode_selfphoto', function ($row) {
                return isset($row->kode_selfphoto) ? $row->kode_selfphoto : "-";
            })
            ->editColumn('no_ref', function ($row) {
                return isset($row->no_ref) ? $row->no_ref : "-";
            })
            ->rawColumns(['kode_booking'])->toJson();
        }
        $data['title'] = 'Daftar Transaksi';
        return view('admin.daftar_transaksi', $data);
    }
}
