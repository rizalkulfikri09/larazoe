<?php

namespace App\Http\Controllers;

use App\Models\Wedding;
use App\Models\Transaksi;
use App\Models\SettingApp;
use App\Models\SubWedding;
use App\Traits\TripayTrait;
use App\Traits\XenditTrait;
use App\Models\ExtraWedding;
use App\Models\PaketWedding;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Traits\NotifikasiTrait;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class WeddingController extends Controller
{
    public function bookingWedding(Request $request)
    {
        if (count($request->all())) {
            return redirect('pilih_paket_wedding/'.$request->id);
        } else {
            // Hapus Session Booking
            hapus_session();

            $data['title'] = 'Booking Wedding';
            $data['daftar_paket'] = PaketWedding::select('id', 'nama_paket', 'thumbnail')->where('is_active', '=', 1)->get();
            return view('fitur.wedding.paket', $data);
        }
    }

    public function pilihPaketWedding(Request $request, $id)
    {
        $data['title'] = 'Booking Wedding';
        $data['paket'] = PaketWedding::select('id', 'nama_paket', 'deskripsi')->where('id', '=', $id)->first();
        $data['sub_paket'] = SubWedding::where('id_paket', '=', $id)->where('is_active', '=', 1)->get();
        $data['paket_extra'] = ExtraWedding::select('id', 'extra_wedding', 'harga')->get();
        $data['get_catatan'] = SettingApp::find(1)->value_8;
        // Hapus Session Booking
        hapus_session();

        if (count($request->all())) {
            $request->validate([
                'sub_paket' => ['required'],
                'harga' => ['required'],
            ]);
            $get_sub_paket = SubWedding::where('id', '=', $request->sub_paket)->first();
            if ($get_sub_paket->id_paket == $id) {
                $input = [
                    'id_paket' => $id,
                    'id_sub_paket' => $get_sub_paket->id,
                    'id_extra_paket' => $request->paket_extra,
                    'transport' => $request->transport,
                ];
                session($input);
                return redirect('pilih_tanggal_wedding');
            }
            return redirect('booking_wedding');
        } else {
            $is_active = PaketWedding::select('is_active')->findOrFail($id)->is_active;
            if ($is_active) {
                return view('fitur.wedding.sub_paket', $data);
            } else {
                return to_route('booking_wedding');
            }
        }
    }

    public function totalPembayaran()
    {
        $get_sub_paket = SubWedding::where('id', '=', session()->get('id_sub_paket'))->first();
        if (session()->get('id_extra_paket')) {
            $get_extra_wedding = ExtraWedding::where('id', '=', session()->get('id_extra_paket'))->first();
            $harga_extra = $get_extra_wedding->harga;
        } else {
            $harga_extra = 0;
        }
        if (session()->get('transport')) {
            $transport = SettingApp::find(1)->value_6;
        } else {
            $transport = 0;
        }
        return $get_sub_paket->harga + $harga_extra + $transport;
    }

    public function pilihTanggalWedding(Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'tgl_wedding' => [
                    function ($attribute, $value, $fail) {
                        $set_sistem = SettingApp::find(1)->value_5;
                        $cek_wedding = Wedding::select('tgl_wedding')->where('tgl_wedding', '=', $value)->count();
                        if ($cek_wedding >= $set_sistem) {
                            $fail('Tanggal wedding yang anda pilih sudah penuh, pilih tanggal lain atau hubungi CS.');
                        }
                    }
                ]
            ]);
            session(['tgl_wedding' => $request->tgl_wedding]);
            return redirect('data_wedding');
        } else {
            if (!session()->get('id_sub_paket')) {
                return redirect('booking_wedding');
            }
            $data['title'] = 'Booking Wedding';
            $data['tgl_libur'] = DB::table('libur_studio')->where('tanggal', '>=', Carbon::now()->format('Y-m-d'))->pluck('tanggal');
            $data['max_date'] = SettingApp::find(1)->value_9;
            $data['total_pembayaran'] = format_rupiah(WeddingController::totalPembayaran());
            return view('fitur.wedding.pilih_tanggal_wedding', $data);
        }
    }

    public function dataWedding(Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'alamat' => ['required'],
            ]);
            session(['alamat' => $request->alamat]);
            return redirect('metode_pembayaran_wedding');
        } else {
            if (!session()->get('tgl_wedding')) {
                return redirect('booking_wedding');
            }
            $data['title'] = 'Booking Wedding';
            $data['total_pembayaran'] = format_rupiah(WeddingController::totalPembayaran());
            return view('fitur.wedding.data_wedding', $data);
        }
    }

    public function metodePembayaranWedding(Request $request)
    {
        $data['title'] = 'Pilih Metode Pembayaran';
        $data['status_tripay'] = SettingApp::find(2)->value_2;
        $data['status_xendit'] = SettingApp::find(2)->value_3;
        $data['bank_1'] = SettingApp::find(3);
        $data['bank_2'] = SettingApp::find(4);
        $data['daftar_pembayaran'] = TripayTrait::getChannelPembayaran();
        if (count($request->all())) {
            $request->validate([
                'pembayaran' => ['required'],
            ], [
                'pembayaran.required' => 'Pilih salah satu metode pembayaran terlebih dahulu.',
            ]);
            session(['code_pay' => $request->pembayaran]);
            return to_route('konfirmasi_wedding');
        } else {
            if (!session()->get('alamat')) {
                return redirect('booking_wedding');
            }
            $data['total_pembayaran'] = format_rupiah(WeddingController::totalPembayaran());
            return view('fitur.wedding.metode_pembayaran', $data);
        }
    }

    public function paketWedding()
    {
        $get_sub_paket = SubWedding::where('id', '=', session()->get('id_sub_paket'))->first();
        if (session()->get('id_extra_paket')) {
            $get_extra_wedding = ExtraWedding::where('id', '=', session()->get('id_extra_paket'))->first();
            $paket_extra = " + " . $get_extra_wedding->extra_wedding;
        } else {
            $paket_extra = "";
        }
        if (session()->get('transport')) {
            $transport = " + Transport";
        } else {
            $transport = "";
        }
        return $get_sub_paket->sub_paket . $paket_extra . $transport;
    }

    public function konfirmasiBookingWedding()
    {
        if (!session()->get('code_pay')) {
            return redirect('booking_wedding');
        }
        if (session()->get('code_pay') == 'bayar_manual') {
            $get_biaya_admin = 0;
        } else if (session()->get('code_pay') == 'bayar_otomatis') {
            $get_biaya_admin = 0;
        } else {
            $get_biaya_admin = TripayTrait::getBiayaTransaksi(session()->get('code_pay'), WeddingController::totalPembayaran());
        }

        $data['title'] = 'Konfirmasi Booking Wedding';
        $data['tgl_wedding'] = Carbon::parse(session()->get('tgl_wedding'))->translatedFormat('d F Y');
        $data['nama'] = auth()->user()->nama;
        $data['no_tlp'] = auth()->user()->no_tlp;
        $data['paket_wedding'] = WeddingController::paketWedding();
        $data['alamat'] = session()->get('alamat');
        $data['total'] = format_rupiah(WeddingController::totalPembayaran() + $get_biaya_admin);
        return view('fitur.wedding.konfirmasi_wedding', $data);
    }

    public function createBookingWedding()
    {
        if (!session()->get('id_paket')) {
            return redirect('booking_wedding');
        }
        $get_cs = SettingApp::find(1);

        $kode_wedding = kode_wedding();
        $nama_konsumen = auth()->user()->nama;
        $no_tlp = auth()->user()->no_tlp;
        $tgl_wedding = Carbon::parse(session()->get('tgl_wedding'))->translatedFormat('d F Y');
        $alamat = session()->get('alamat');
        $paket = WeddingController::paketWedding();
        $total = WeddingController::totalPembayaran();
        $total_rp = format_rupiah(WeddingController::totalPembayaran());

        $input_booking = [
            'kode' => $kode_wedding,
            'nama' => $nama_konsumen,
            'no_tlp' => $no_tlp,
            'alamat' => $alamat,
            'paket' => $paket,
            'status_booking' => 'Dipesan',
            'status_bayar' => 'Belum Dibayar',
            'total' => $total,
            'jml_dp' => 0,
            'tgl_wedding' => session()->get('tgl_wedding'),
            'cs' => $get_cs->value_1,
        ];

        /*
        | ---------------------------------------------------------------
        | Proses membuat transaksi pada payment gateway
        | ---------------------------------------------------------------
        */
        if (session()->get('code_pay') == 'bayar_manual') {
            $redirect = to_route('bayar_wedding', $kode_wedding)->with('success', 'Booking wedding anda berhasil dibuat.');
        } else if (session()->get('code_pay') == 'bayar_otomatis') {
            $xendit_transaksi = XenditTrait::createInvoiceWedding($kode_wedding, $paket, $total);
            $input_transaksi = [
                'kode_wedding' => $kode_wedding,
                'no_ref' => $xendit_transaksi['id'],
                'link' => $xendit_transaksi['invoice_url'],
                'status' => 'UNPAID',
            ];
            Transaksi::create($input_transaksi);
            $redirect = redirect($xendit_transaksi['invoice_url']);
        } else {
            $method = session()->get('code_pay');
            $tripay_transaksi = TripayTrait::createTransaksiWedding($kode_wedding, $method, $total, $paket);
            $input_transaksi = [
                'kode_wedding' => $kode_wedding,
                'no_ref' => $tripay_transaksi->reference,
                'link' => $tripay_transaksi->checkout_url,
                'status' => 'UNPAID',
            ];
            Transaksi::create($input_transaksi);
            $redirect = redirect($tripay_transaksi->checkout_url);
        }
        $text = "Informasi booking wedding\n\nKode Wedding : $kode_wedding\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $no_tlp\nPaket Dipesan : $paket\nTotal Pembayaran : $total_rp\nStatus Booking : Dipesan\nStatus Pembayaran : Belum Dibayar\nTanggal Wedding : $tgl_wedding\nAlamat : $alamat";
        NotifikasiTrait::sendNotify($text, $no_tlp);

        Wedding::create($input_booking);
        // Hapus Session Booking
        hapus_session();
        return $redirect;
    }

    public function riwayatWedding(Request $request)
    {
        if ($request->ajax()) {
            $query = Wedding::select(['kode', 'status_booking', 'status_bayar', 'jml_dp', 'tgl_wedding'])->where('no_tlp', '=', auth()->user()->no_tlp);
            $data = empty($query) ? $query : $query->latest()->get();
            return DataTables::of($data)->addIndexColumn()
            ->editColumn('status_bayar', function ($row) {
                $result = $row->status_bayar == 'DP' ? format_rupiah($row->jml_dp) : '';
                return $row->status_bayar.' <b style="color: red;">'.$result.'</b>';
            })
            ->editColumn('tgl_wedding', function ($row) {
                return Carbon::parse($row->tgl_wedding)->translatedFormat('d F Y');
            })
            ->addColumn('opsi', function ($row) {
                return button_wedding($row->status_booking, $row->status_bayar, $row->kode);
            })
            ->rawColumns(['status_bayar', 'opsi'])->toJson();
        }

        $data['title'] = 'Riwayat Booking Wedding';
        return view('fitur.wedding.riwayat_wedding', $data);
    }

    public function hasilBookingWedding($kode)
    {
        $get_booking = Wedding::where('kode', '=', $kode)->firstOrFail();
        $set_aplikasi = SettingApp::find(5);
        $set_sistem = SettingApp::find(1);
        $expired = strtotime($get_booking->created_at) + ($set_sistem->value_3 * 60 * 60); // expired 6 jam
        if ($get_booking->status_bayar == 'Belum Dibayar' && date('Y-m-d H:i:s', $expired) < gmdate('Y-m-d H:i:s', (time() + (60 * 60 * $set_aplikasi->value_5)))) {
            Wedding::where('kode', '=', $kode)->delete();
            return to_route('riwayat_wedding')->with('danger', 'Booking wedding anda sudah melewati batas pembayaran!');
        } else {
            $data['title'] = 'Hasil Booking Wedding';
            $data['booking'] = $get_booking;
            $data['transaksi'] = Transaksi::where('kode_wedding', '=', $kode)->first();
            $data['bank_1'] = SettingApp::find(3);
            $set_sistem = SettingApp::find(1);
            $get_created_at = strtotime($get_booking->created_at) + ($set_sistem->value_3 * 60 * 60);
            $data['waktu_expired'] = date('Y-m-d H:i:s', $get_created_at);
            return view('fitur.wedding.hasil_wedding', $data);
        }
    }

    public function hapusBookingWedding($kode)
    {
        $get_booking = Wedding::where('kode', '=', $kode)->firstOrFail();
        $get_transaksi = Transaksi::where('kode_wedding', '=', $kode)->first();
        switch ($get_booking->status_bayar) {
            case ("Belum Dibayar" && !isset($get_transaksi->link)):
                Wedding::where('kode', '=', $kode)->delete();
                return response()->json(['success' => true, 'message' => 'Booking wedding berhasil dihapus!']);
                break;
            case ("Lunas" && $get_booking->status_booking == 'Selesai'):
                Wedding::where('kode', '=', $kode)->delete();
                if ($get_transaksi) {
                    $get_transaksi->delete();
                    File::delete(public_path('/frontend/images/bukti_tf/' . $get_transaksi->link));
                }
                return response()->json(['success' => true, 'message' => 'Booking wedding berhasil dihapus!']);
                break;
            default:
                return to_route('riwayat_wedding');
                break;
        }
    }

    public function cetakBookingWedding($kode)
    {
        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('cetak.cetak_wedding', [
            'booking' => Wedding::where('kode', '=', $kode)->first(),
        ]);
        $pdf->setPaper(array(0, 0, 170, 360), 'portrait');
        return $pdf->download('booking_wedding_'.$kode.'.pdf');
    }

    public function bayarWedding($kode)
    {
        $data['title'] = 'Upload Bukti Transfer';
        $data['booking'] = Wedding::where('kode', '=', $kode)->firstOrFail();
        $data['transaksi'] = Transaksi::where('kode_wedding', '=', $kode)->first();
        $data['bank_1'] = SettingApp::find(3);
        $data['bank_2'] = SettingApp::find(4);
        if (!isset($data['transaksi']['no_ref']) && $data['bank_1']['value_5'] == '1') {
            return view('fitur.wedding.bayar_wedding', $data);
        } else {
            return to_route('hasil_wedding', $kode);
        }
    }

    public function _bayarWedding(Request $request, $kode)
    {
        $booking = Wedding::where('kode', '=', $kode)->first();
        $request->validate([
            'status_bayar' => ['required'],
            'jml_dp' => ['required'],
            'bukti_tf' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
        ], [
            'bukti_tf.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 2 MB.',
        ]);
        $status_bayar = $request->status_bayar;
        $jml_dp = change_rupiah($request->jml_dp);
        $min_dp = nominal_dp($booking->total);
        $nama_konsumen = auth()->user()->nama;
        $nomor_konsumen = auth()->user()->no_tlp;
        if ($jml_dp < $min_dp) {
            return to_route('bayar_wedding', $kode)->with('danger', 'Masukan nominal DP minimal 50% dari total pembayaran.');
        }

        // Upload foto bukti transfer
        if ($file = $request->file('bukti_tf')) {
            $file_name = $file->hashName();
            $file->move(public_path('/frontend/images/bukti_tf'), $file_name);
        }
        $link_bukti_tf = url('frontend/images/bukti_tf/' . $file_name);
        $transaksi = [
            'kode_wedding' => $kode,
            'link' => $file_name,
            'status' => 'UNPAID',
        ];
        // Insert bukti transfer ke tabel transaksi
        Transaksi::create($transaksi);
        // Update status pembayaran di tabel booking
        if($status_bayar == 'DP') {
            Wedding::where('kode', '=', $kode)->update([
                'jml_dp' => $jml_dp,
            ]);
        }
        $link_konfirmasi = url('daftar_wedding/' . $kode . '/edit');
        $text = "Konsumen Mengirim Bukti TF\n============================\nKode Wedding : $kode\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $nomor_konsumen\nPembayaran : $status_bayar\nFoto Bukti TF : $link_bukti_tf\n\nKonfirmasi Pembayaran : $link_konfirmasi\n============================";
        NotifikasiTrait::sendToAdmin($text);

        return to_route('bayar_wedding', $kode)->with('success', 'Bukti pembayaran booking wedding berhasil di upload. Silahkan tunggu sebentar, Admin sedang melakukan cek transaksi anda terlebih dahulu.');
    }

    public function tripayReturnWedding($kode_wedding)
    {
        $transaksi = Transaksi::where('kode_wedding', '=', $kode_wedding)->first();
        $cek_pembayaran = TripayTrait::getTransaksi($transaksi->no_ref);
        if ($transaksi->status == 'PAID') {
            return redirect('riwayat_wedding/' . $kode_wedding);
        } else {
            $get_wedding = Wedding::where('kode', '=', $kode_wedding)->first();
            switch ($cek_pembayaran) {
                case 'PAID':
                    $get_wedding->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_wedding', '=', $kode_wedding)->update(['status' => 'PAID']);
                    $text = "Informasi booking wedding\n\nKode Wedding : $kode_wedding\nNama Konsumen : $get_wedding->nama\nNomor WhatsApp : $get_wedding->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    return to_route('hasil_wedding', $kode_wedding)->with('success', 'Pembayaran booking wedding anda telah lunas.');
                    break;

                case 'EXPIRED':
                    $get_wedding->delete();
                    Transaksi::where('kode_wedding', '=', $kode_wedding)->update(['status' => 'EXPIRED']);
                    return to_route('riwayat_wedding')->with('danger', 'Pembayaran anda sudah melewati batas waktu.');
                    break;

                case 'FAILED':
                    $get_wedding->delete();
                    Transaksi::where('kode_wedding', '=', $kode_wedding)->update(['status' => 'FAILED']);
                    return to_route('riwayat_wedding')->with('danger', 'Pembayaran anda gagal.');
                    break;

                default:
                    return redirect('riwayat_wedding/' . $kode_wedding);
                    break;
            }
        }
    }

    public function xenditReturnWedding($kode)
    {
        $transaksi = Transaksi::where('kode_wedding', '=', $kode)->firstOrFail();
        $get_invoice = XenditTrait::getInvoice($transaksi->no_ref);
        $status = $get_invoice['status'];
        if ($transaksi->status == 'PAID') {
            return redirect('riwayat_wedding/' . $kode);
        } else {
            $get_wedding = Wedding::where('kode', '=', $kode)->first();
            switch ($status) {
                case "PENDING":
                    return redirect($get_invoice['invoice_url']);
                    break;
                case "PAID":
                    $get_wedding->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_wedding', '=', $kode)->update(['status' => 'PAID']);
                    $text = "Informasi booking wedding\n\nKode Wedding : $kode\nNama Konsumen : $get_wedding->nama\nNomor WhatsApp : $get_wedding->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    return to_route('hasil_wedding', $kode)->with('success', 'Pembayaran booking wedding anda telah lunas.');
                    break;

                case "SETTLED":
                    $get_wedding->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_wedding', '=', $kode)->update(['status' => 'SETTLED']);
                    $text = "Informasi booking wedding\n\nKode Wedding : $kode\nNama Konsumen : $get_wedding->nama\nNomor WhatsApp : $get_wedding->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    return to_route('hasil_wedding', $kode)->with('success', 'Pembayaran booking wedding anda telah lunas.');
                    break;

                case "EXPIRED":
                    $get_wedding->delete();
                    Transaksi::where('kode_wedding', '=', $kode)->update(['status' => 'EXPIRED']);
                    return to_route('riwayat_wedding')->with('danger', 'Pembayaran anda sudah melewati batas waktu.');
                    break;

                default:
                    return redirect('riwayat_wedding/' . $kode);
                    break;
            }
        }
    }
}
