<?php

namespace App\Http\Controllers;

use App\Models\Paket;
use App\Models\Studio;
use App\Models\SubPaket;
use App\Models\Testimoni;
use App\Models\Transaksi;
use App\Models\JamBooking;
use App\Models\SettingApp;
use App\Traits\TripayTrait;
use App\Traits\XenditTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Traits\NotifikasiTrait;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class StudioController extends Controller
{
    public function bookingStudio(Request $request)
    {
        if (count($request->all())) {
            return redirect('pilih_paket/'.$request->id);
        } else {
            // Hapus Session Booking
            hapus_session();

            $data['title'] = 'Booking Studio Foto';
            $data['daftar_paket'] = Paket::select('id', 'nama_paket', 'thumbnail')->where('is_active', '=', 1)->get();
            return view('fitur.studio.paket', $data);
        }
    }

    public function pilihPaket(Request $request, $id)
    {
        $data['title'] = 'Booking Studio Foto';
        $data['paket'] = Paket::select('id', 'nama_paket', 'deskripsi')->where('id', '=', $id)->first();
        $data['sub_paket'] = SubPaket::where('id_paket', '=', $id)->where('is_active', '=', 1)->get();
        // Hapus Session Booking
        hapus_session();

        if (count($request->all())) {
            $validator = \Illuminate\Support\Facades\Validator::make($request->all(), [
                'sub_paket' => ['required'],
                'harga' => ['required'],
                'jml_orang' => [
                    'required', 'numeric',
                    function($attribute, $value, $fail) use ($request) {
                        $sub_paket = SubPaket::where('id', $request->sub_paket)->first();
                        if (!empty($sub_paket->min_org) || !empty($sub_paket->max_org)) {
                            $min_orang = $sub_paket->min_org;
                            $max_orang = $sub_paket->max_org;
                            if ($value + 1 <= $min_orang) {
                                return $fail('Jumlah orang minimal ' . $min_orang);
                            }
                            if ($value - 1 >= $max_orang) {
                                return $fail('Jumlah orang maksimal ' . $max_orang);
                            }
                        }
                    },
                ],
            ]);
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }

            $get_sub_paket = SubPaket::where('id', '=', $request->sub_paket)->first();
            if ($get_sub_paket->id_paket == $id) {
                $input = [
                    'id_paket' => $id,
                    'id_sub_paket' => $get_sub_paket->id,
                    'jml_orang' => $request->jml_orang,
                ];
                session($input);
                return redirect('pilih_tanggal');
            }
            return redirect('booking_studio');
        } else {
            $is_active = Paket::select('is_active')->findOrFail($id)->is_active;
            if ($is_active) {
                return view('fitur.studio.sub_paket', $data);
            } else {
                return to_route('booking_studio');
            }
        }
    }

    public function pilihTanggal(Request $request)
    {
        if (count($request->all())) {
            session(['tgl_booking' => $request->tgl_booking]);
            return redirect('pilih_jam');
        } else {
            if (!session()->get('id_sub_paket')) {
                return redirect('booking_studio');
            }
            $get_sub_paket = SubPaket::where('id', '=', session()->get('id_sub_paket'))->first();
            $data['title'] = 'Booking Studio Foto';
            $data['tgl_libur'] = DB::table('libur_studio')->where('tanggal', '>=', Carbon::now()->format('Y-m-d'))->pluck('tanggal');
            $data['max_date'] = SettingApp::find(1)->value_9;
            $data['total_pembayaran'] = format_rupiah($get_sub_paket->harga);
            return view('fitur.studio.pilih_tanggal', $data);
        }
    }

    public function pilihJam(Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'jam_booking' => ['required']
            ], [
                'jam_booking.required' => 'Pilih salah satu jam booking terlebih dahulu.',
            ]);
            session(['id_jam' => $request->jam_booking]);
            return to_route('pilih_bayar');
        } else {
            if (!session()->get('tgl_booking')) {
                return redirect('booking_studio');
            }
            $get_sub_paket = SubPaket::where('id', '=', session()->get('id_sub_paket'))->first();
            $data['title'] = 'Booking Studio Foto';
            $data['jam_tersedia'] = JamBooking::ambilJam(session()->get('tgl_booking'));
            $data['tutup_studio'] = Carbon::createFromFormat('H:i', SettingApp::find(2)->value_4);
            $data['durasi'] = $get_sub_paket->durasi;
            $data['total_pembayaran'] = format_rupiah($get_sub_paket->harga);
            return view('fitur.studio.pilih_jam', $data);
        }
    }

    public function metodePembayaran(Request $request)
    {
        $data['title'] = 'Pilih Metode Pembayaran';
        $data['status_tripay'] = SettingApp::find(2)->value_2;
        $data['status_xendit'] = SettingApp::find(2)->value_3;
        $data['bank_1'] = SettingApp::find(3);
        $data['bank_2'] = SettingApp::find(4);
        $data['daftar_pembayaran'] = TripayTrait::getChannelPembayaran();
        $get_sub_paket = SubPaket::where('id', '=', session()->get('id_sub_paket'))->first();
        if (count($request->all())) {
            $request->validate([
                'pembayaran' => ['required'],
            ], [
                'pembayaran.required' => 'Pilih salah satu metode pembayaran terlebih dahulu.',
            ]);
            session(['code_pay' => $request->pembayaran]);
            return to_route('konfirmasi_booking');
        } else {
            if (!session()->get('id_jam')) {
                return redirect('booking_studio');
            }
            $data['total_pembayaran'] = format_rupiah($get_sub_paket->harga);
            return view('fitur.studio.metode_pembayaran', $data);
        }
    }

    public function konfirmasiBooking()
    {
        if (!session()->get('code_pay')) {
            return redirect('booking_studio');
        }
        $get_paket = Paket::where('id', '=', session()->get('id_paket'))->first();
        $get_sub_paket = SubPaket::where('id', '=', session()->get('id_sub_paket'))->first();
        $get_jam = JamBooking::where('id', '=', session()->get('id_jam'))->first();
        if (session()->get('code_pay') == 'bayar_manual') {
            $get_biaya_admin = 0;
        } else if (session()->get('code_pay') == 'bayar_otomatis') {
            $get_biaya_admin = 0;
        } else {
            $get_biaya_admin = TripayTrait::getBiayaTransaksi(session()->get('code_pay'), $get_sub_paket->harga);
        }

        $data['title'] = 'Konfirmasi Booking Studio Foto';
        $data['tgl_booking'] = Carbon::parse(session()->get('tgl_booking'))->translatedFormat('d F Y');
        $data['jam_booking'] = jam_pemotretan($get_jam->jam);
        $data['nama'] = auth()->user()->nama;
        $data['no_tlp'] = auth()->user()->no_tlp;
        $data['paket'] = $get_paket->nama_paket;
        $data['sub_paket'] = $get_sub_paket->sub_paket;
        $data['total'] = format_rupiah($get_sub_paket->harga + $get_biaya_admin);
        $data['jml_orang'] = session()->get('jml_orang');
        return view('fitur.studio.konfirmasi', $data);
    }

    public function createBookingStudio()
    {
        if (!session()->get('id_paket')) {
            return redirect('booking_studio');
        }
        $get_paket = Paket::where('id', '=', session()->get('id_paket'))->first();
        $get_sub_paket = SubPaket::where('id', '=', session()->get('id_sub_paket'))->first();
        $get_jam = JamBooking::where('id', '=', session()->get('id_jam'))->first();
        $get_cs = SettingApp::find(1);

        $kode_booking = kode_studio();
        $nama_konsumen = auth()->user()->nama;
        $no_tlp = auth()->user()->no_tlp;
        $tgl_booking = Carbon::parse(session()->get('tgl_booking'))->translatedFormat('d F Y');
        $jam_booking = jam_pemotretan($get_jam->jam);
        $paket = $get_paket->nama_paket . " - " . $get_sub_paket->sub_paket;
        $total = $get_sub_paket->harga;
        $total_rp = format_rupiah($get_sub_paket->harga);
        $jml_orang = session()->get('jml_orang');

        $input_booking = [
            'kode' => $kode_booking,
            'nama' => $nama_konsumen,
            'no_tlp' => $no_tlp,
            'paket' => $paket,
            'status_booking' => 'Dipesan',
            'status_bayar' => 'Belum Dibayar',
            'total' => $total,
            'jml_dp' => 0,
            'jml_orang' => $jml_orang,
            'tgl_booking' => session()->get('tgl_booking'),
            'jam_booking' => $jam_booking,
            'cs' => $get_cs->value_1,
            'id_sesi' => session()->get('id_jam'),
        ];

        /*
        | ---------------------------------------------------------------
        | Proses membuat transaksi pada payment gateway
        | ---------------------------------------------------------------
        */
        if (session()->get('code_pay') == 'bayar_manual') {
            $redirect = to_route('bayar_studio', $kode_booking)->with('success', 'Booking studio foto anda berhasil dibuat.');
        } else if (session()->get('code_pay') == 'bayar_otomatis') {
            $xendit_transaksi = XenditTrait::createInvoiceStudio($kode_booking, $paket, $total);
            $input_transaksi = [
                'kode_booking' => $kode_booking,
                'no_ref' => $xendit_transaksi['id'],
                'link' => $xendit_transaksi['invoice_url'],
                'status' => 'UNPAID',
            ];
            Transaksi::create($input_transaksi);
            $redirect = redirect($xendit_transaksi['invoice_url']);
        } else {
            $method = session()->get('code_pay');
            $tripay_transaksi = TripayTrait::createTransaksi($kode_booking, $method, $total, $paket);
            $input_transaksi = [
                'kode_booking' => $kode_booking,
                'no_ref' => $tripay_transaksi->reference,
                'link' => $tripay_transaksi->checkout_url,
                'status' => 'UNPAID',
            ];
            Transaksi::create($input_transaksi);
            $redirect = redirect($tripay_transaksi->checkout_url);
        }
        $text = "Informasi booking studio foto\n\nKode Booking : $kode_booking\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $no_tlp\nPaket Dipesan : $paket\nTotal Pembayaran : $total_rp\nStatus Booking : Dipesan\nStatus Pembayaran : Belum Dibayar\nTanggal Booking : $tgl_booking\nJam Booking : $jam_booking";
        NotifikasiTrait::sendNotify($text, $no_tlp);

        Studio::create($input_booking);
        // Hapus Session Booking
        hapus_session();
        return $redirect;
    }

    public function riwayatBooking(Request $request)
    {
        if ($request->ajax()) {
            $query = Studio::select(['kode', 'status_booking', 'status_bayar', 'jml_dp', 'tgl_booking', 'jam_booking'])->where('no_tlp', '=', auth()->user()->no_tlp);
            $data = empty($query) ? $query : $query->latest()->get();
            return DataTables::of($data)->addIndexColumn()
            ->editColumn('status_bayar', function ($row) {
                $result = $row->status_bayar == 'DP' ? format_rupiah($row->jml_dp) : '';
                return $row->status_bayar.' <b style="color: red;">'.$result.'</b>';
            })
            ->editColumn('tgl_booking', function ($row) {
                return Carbon::parse($row->tgl_booking)->translatedFormat('d F Y');
            })
            ->addColumn('opsi', function ($row) {
                return button_studio($row->status_booking, $row->status_bayar, $row->kode);
            })
            ->rawColumns(['status_bayar', 'opsi'])->toJson();
        }

        $data['title'] = 'Riwayat Booking Studio Foto';
        return view('fitur.studio.riwayat_booking', $data);
    }

    public function hasilBookingStudio($kode)
    {
        $get_booking = Studio::where('kode', '=', $kode)->firstOrFail();
        $set_aplikasi = SettingApp::find(5);
        $set_sistem = SettingApp::find(1);
        $nomor_admin = nomor_tlp(SettingApp::find(14)->value_1);
        $expired = strtotime($get_booking->created_at) + ($set_sistem->value_3 * 60 * 60);
        if ($get_booking->status_bayar == 'Belum Dibayar' && date('Y-m-d H:i:s', $expired) < gmdate('Y-m-d H:i:s', (time() + (60 * 60 * $set_aplikasi->value_5)))) {
            Studio::where('kode', '=', $kode)->delete();
            return to_route('riwayat_booking')->with('danger', 'Booking studio foto anda sudah melewati batas pembayaran!');
        } else {
            $data['title'] = 'Hasil Booking Studio Foto';
            $data['booking'] = $get_booking;
            $data['transaksi'] = Transaksi::where('kode_booking', '=', $kode)->first();
            $data['testimoni'] = Testimoni::where('kode', '=', $kode)->first();
            $data['bank_1'] = SettingApp::find(3);
            $set_sistem = SettingApp::find(1);
            $get_created_at = strtotime($get_booking->created_at) + ($set_sistem->value_3 * 60 * 60);
            $data['waktu_expired'] = date('Y-m-d H:i:s', $get_created_at);
            $data['qr_code'] = QrCode::format('svg')->size(200)->generate($kode);

            $text = "Kode Booking : $kode\nNama Konsumen : $get_booking->nama\nNomor WhatsApp : $get_booking->no_tlp\nPaket Dipesan : $get_booking->paket\nTotal Pembayaran : $get_booking->total\nStatus Booking : $get_booking->status_booking\nStatus Pembayaran : $get_booking->status_bayar\nTanggal Booking : $get_booking->tgl_booking\nJam Booking : $get_booking->jam_booking";
            $data['kirim_admin'] = "https://api.whatsapp.com/send?phone=$nomor_admin&text=".urlencode($text);
            return view('fitur.studio.hasil_booking', $data);
        }
    }

    public function hapusBookingStudio($kode)
    {
        $get_booking = Studio::where('kode', '=', $kode)->firstOrFail();
        $get_testimoni = Testimoni::where('kode', '=', $kode)->first();
        $get_transaksi = Transaksi::where('kode_booking', '=', $kode)->first();
        switch ($get_booking->status_bayar) {
            case ("Belum Dibayar" && !isset($get_transaksi->link)):
                Studio::where('kode', '=', $kode)->delete();
                return response()->json(['success' => true, 'message' => 'Booking studio foto berhasil dihapus!']);
                break;
            case ("Lunas" && $get_booking->status_booking == 'Selesai' && $get_testimoni):
                Studio::where('kode', '=', $kode)->delete();
                if ($get_transaksi) {
                    $get_transaksi->delete();
                    File::delete(public_path('/frontend/images/bukti_tf/' . $get_transaksi->link));
                }
                return response()->json(['success' => true, 'message' => 'Booking studio foto berhasil dihapus!']);
                break;
            default:
                return to_route('riwayat_booking');
                break;
        }
    }

    public function cetakBooking($kode)
    {
        $qr_code = base64_encode(QrCode::format('svg')->size(70)->generate($kode));
        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('cetak.cetak_booking', [
            'qr_code' => $qr_code,
            'booking' => Studio::where('kode', '=', $kode)->first(),
        ]);
        $pdf->setPaper(array(0, 0, 170, 360), 'portrait');
        return $pdf->download('booking_studio_'.$kode.'.pdf');
    }

    public function kalenderBooking()
    {
        $data['title'] = 'Kalender Booking Studio Foto';
        $data['kalender'] = (new Studio)->kalender();
        return view('fitur.studio.kalender_booking', $data);
    }

    public function bayarStudio($kode)
    {
        $data['title'] = 'Upload Bukti Transfer';
        $data['booking'] = Studio::where('kode', '=', $kode)->firstOrFail();
        $data['transaksi'] = Transaksi::where('kode_booking', '=', $kode)->first();
        $data['bank_1'] = SettingApp::find(3);
        $data['bank_2'] = SettingApp::find(4);
        if (!isset($data['transaksi']['no_ref']) && $data['bank_1']['value_5'] == '1') {
            return view('fitur.studio.bayar_studio', $data);
        } else {
            return to_route('hasil_booking', $kode);
        }
    }

    public function _bayarStudio(Request $request, $kode)
    {
        $booking = Studio::where('kode', '=', $kode)->first();
        $request->validate([
            'status_bayar' => ['required'],
            'jml_dp' => ['required'],
            'bukti_tf' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
        ], [
            'bukti_tf.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
        ]);
        $status_bayar = $request->status_bayar;
        $jml_dp = change_rupiah($request->jml_dp);
        $min_dp = nominal_dp($booking->total);
        $nama_konsumen = auth()->user()->nama;
        $nomor_konsumen = auth()->user()->no_tlp;
        if ($jml_dp < $min_dp) {
            return to_route('bayar_studio', $kode)->with('danger', 'Masukan nominal DP minimal 50% dari harga paket.');
        }

        // Upload foto bukti transfer
        if ($file = $request->file('bukti_tf')) {
            $file_name = $file->hashName();
            $file->move(public_path('frontend/images/bukti_tf'), $file_name);
        }
        $link_bukti_tf = url('frontend/images/bukti_tf/' . $file_name);
        $transaksi = [
            'kode_booking' => $kode,
            'link' => $file_name,
            'status' => 'UNPAID',
        ];
        // Insert bukti transfer ke tabel transaksi
        Transaksi::create($transaksi);
        // Update status pembayaran di tabel booking
        if($status_bayar == 'DP') {
            Studio::where('kode', '=', $kode)->update([
                'jml_dp' => $jml_dp,
            ]);
        }
        $link_konfirmasi = url('daftar_booking/' . $kode . '/edit');
        $text = "Konsumen Mengirim Bukti TF\n============================\nKode Booking : $kode\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $nomor_konsumen\nPembayaran : $status_bayar\nFoto Bukti TF : $link_bukti_tf\n\nKonfirmasi Pembayaran : $link_konfirmasi\n============================";
        NotifikasiTrait::sendToAdmin($text);

        return to_route('bayar_studio', $kode)->with('success', 'Bukti pembayaran booking studio foto berhasil di upload. Silahkan tunggu sebentar, Admin sedang melakukan cek transaksi anda terlebih dahulu.');
    }

    public function tripayReturnStudio($kode_booking)
    {
        $transaksi = Transaksi::where('kode_booking', '=', $kode_booking)->first();
        $cek_pembayaran = TripayTrait::getTransaksi($transaksi->no_ref);
        if ($transaksi->status == 'PAID') {
            return redirect('riwayat_booking/' . $kode_booking);
        } else {
            $get_studio = Studio::where('kode', '=', $kode_booking)->first();
            switch ($cek_pembayaran) {
                case 'PAID':
                    $get_studio->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_booking', '=', $kode_booking)->update(['status' => 'PAID']);
                    $text = "Informasi booking studio foto\n\nKode Booking : $kode_booking\nNama Konsumen : $get_studio->nama\nNomor WhatsApp : $get_studio->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    return to_route('hasil_booking', $kode_booking)->with('success', 'Pembayaran booking studio foto anda telah lunas.');
                    break;

                case 'EXPIRED':
                    $get_studio->delete();
                    Transaksi::where('kode_booking', '=', $kode_booking)->update(['status' => 'EXPIRED']);
                    return to_route('riwayat_booking')->with('danger', 'Pembayaran anda sudah melewati batas waktu.');
                    break;

                case 'FAILED':
                    $get_studio->delete();
                    Transaksi::where('kode_booking', '=', $kode_booking)->update(['status' => 'FAILED']);
                    return to_route('riwayat_booking')->with('danger', 'Pembayaran anda gagal.');
                    break;

                default:
                    return redirect('riwayat_booking/' . $kode_booking);
                    break;
            }
        }
    }

    public function testimoniStudio(Request $request, $kode)
    {
        if (count($request->all())) {
            $request->validate([
                'rating' => ['required'],
                'testimoni' => ['required'],
            ]);
            Testimoni::create([
                'kode' => $kode,
                'nama' => auth()->user()->nama,
                'rating' => $request->rating,
                'testimoni' => $request->testimoni
            ]);
            return to_route('hasil_booking', $kode)->with('success', 'Testimoni & rating berhasil disimpan.');
        } else {
            $get_booking = Studio::where('kode', '=', $kode)->first();
            $get_testimoni = Testimoni::where('kode', '=', $kode)->first();
            if (!isset($get_testimoni) && $get_booking->status_booking == 'Selesai') {
                $data['title'] = 'Testimoni & Rating';
                $data['kode_booking'] = $get_booking->kode;
                return view('fitur.studio.testimoni', $data);
            }
        }
    }

    public function rescheduleTanggal(Request $request, $kode)
    {
        if (count($request->all())) {
            session(['tgl_booking' => $request->tgl_booking]);
            return to_route('reschedule_jam', $kode);
        } else {
            session()->forget('tgl_booking');
            $data['title'] = 'Reschedule Booking Studio Foto';
            $data['tgl_libur'] = DB::table('libur_studio')->where('tanggal', '>=', Carbon::now()->format('Y-m-d'))->pluck('tanggal');
            $data['max_date'] = SettingApp::find(1)->value_9;
            $data['booking'] = Studio::where('kode', '=', $kode)->first();
            return view('fitur.studio.reschedule_tgl', $data);
        }
    }

    public function rescheduleJam(Request $request, $kode)
    {
        $get_booking = Studio::where('kode', '=', $kode)->first();
        if (count($request->all())) {
            $request->validate([
                'jam_booking' => ['required']
            ], [
                'jam_booking.required' => 'Pilih salah satu jam booking terlebih dahulu.',
            ]);
            $get_jam = JamBooking::find($request->jam_booking)->jam;
            $get_booking->update([
                'tgl_booking' => session()->get('tgl_booking'),
                'jam_booking' => jam_reschedule($get_jam, $kode),
                'id_sesi' => $request->jam_booking,
            ]);
            return to_route('hasil_booking', $kode)->with('success', 'Booking studio foto Anda berhasil di reschedule');
        } else {
            session()->forget('jam_booking');
            if (!session()->get('tgl_booking')) {
                return to_route('riwayat_booking');
            }
            $data['jam_tersedia'] = JamBooking::ambilJam(session()->get('tgl_booking'));
            $data['title'] = 'Reschedule Booking Studio Foto';
            $data['tutup_studio'] = Carbon::createFromFormat('H:i', SettingApp::find(2)->value_4);
            $jam_mulai = Carbon::createFromFormat('H:i', substr($get_booking->jam_booking, 0, 5));
            $jam_selesai = Carbon::createFromFormat('H:i', substr($get_booking->jam_booking, -5));
            $data['durasi'] = $jam_selesai->diffInMinutes($jam_mulai);
            $data['booking'] = $get_booking;
            return view('fitur.studio.reschedule_jam', $data);
        }
    }

    public function xenditReturnStudio($kode)
    {
        $transaksi = Transaksi::where('kode_booking', '=', $kode)->firstOrFail();
        $get_invoice = XenditTrait::getInvoice($transaksi->no_ref);
        $status = $get_invoice['status'];
        if ($transaksi->status == 'PAID') {
            return redirect('riwayat_booking/' . $kode);
        } else {
            $get_studio = Studio::where('kode', '=', $kode)->first();
            switch ($status) {
                case "PENDING":
                    return redirect($get_invoice['invoice_url']);
                    break;
                case "PAID":
                    $get_studio->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_booking', '=', $kode)->update(['status' => 'PAID']);
                    $text = "Informasi booking studio foto\n\nKode Booking : $kode\nNama Konsumen : $get_studio->nama\nNomor WhatsApp : $get_studio->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    return to_route('hasil_booking', $kode)->with('success', 'Pembayaran booking studio foto anda telah lunas.');
                    break;

                case "SETTLED":
                    $get_studio->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_booking', '=', $kode)->update(['status' => 'SETTLED']);
                    $text = "Informasi booking studio foto\n\nKode Booking : $kode\nNama Konsumen : $get_studio->nama\nNomor WhatsApp : $get_studio->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    return to_route('hasil_booking', $kode)->with('success', 'Pembayaran booking studio foto anda telah lunas.');
                    break;

                case "EXPIRED":
                    $get_studio->delete();
                    Transaksi::where('kode_booking', '=', $kode)->update(['status' => 'EXPIRED']);
                    return to_route('riwayat_booking')->with('danger', 'Pembayaran anda sudah melewati batas waktu.');
                    break;

                default:
                    return redirect('riwayat_booking/' . $kode);
                    break;
            }
        }
    }
}
