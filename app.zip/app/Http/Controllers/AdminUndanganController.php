<?php

namespace App\Http\Controllers;

use App\Models\Undangan;
use App\Models\Transaksi;
use App\Models\UndanganTema;
use Illuminate\Http\Request;
use App\Models\UndanganPaket;
use App\Exports\UndanganExport;
use App\Traits\NotifikasiTrait;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\File;

class AdminUndanganController extends Controller
{
    public function __construct()
    {
        $this->middleware(['only.admin']);
    }

    public function showUndangan(Request $request)
    {
        if ($request->ajax()) {
            if ($request->status_undangan) {
                session()->put('status_undangan', $request->status_undangan);
            }
            if ($request->id_paket) {
                session()->put('id_paket', $request->id_paket);
            }
            if ($request->status_bayar) {
                session()->put('status_bayar', $request->status_bayar);
            }
            if ($request->id_tema) {
                session()->put('id_tema', $request->id_tema);
            }
            $query = Undangan::with(['paket', 'user', 'transaksi', 'tema'])
            ->when(session()->get('status_undangan'), function ($query) {
                $query->where('status_undangan', '=', session()->get('status_undangan'));
            })
            ->when(session()->get('id_paket'), function ($query) {
                $query->where('id_paket', '=', session()->get('id_paket'));
            })
            ->when(session()->get('status_bayar'), function ($query) {
                $query->where('status_bayar', '=', session()->get('status_bayar'));
            })
            ->when(session()->get('id_tema'), function ($query) {
                $query->where('id_tema', '=', session()->get('id_tema'));
            });
            $data = empty($query) ? $query : $query->latest()->get();
            $total_transaksi = $data->sum('paket.harga');
            return DataTables::of($data)->addIndexColumn()
            ->addColumn('kodes', function ($row) {
                $check = '<input type="checkbox" class="sub_chk" data-kodes="'. $row->kode .'">';
                return $check;
            })
            ->editColumn('nama', function ($row) {
                return $row->user->nama;
            })
            ->editColumn('no_tlp', function ($row) {
                return $row->user->no_tlp;
            })
            ->editColumn('status_bayar', function ($row) {
                $bukti_tf = isset($row->transaksi->link) && is_null($row->transaksi->no_ref) ? '<b><a target="_blank" href="'.url('frontend/images/bukti_tf/' . $row->transaksi->link).'">Bukti TF</a></b>' : '';
                return $row->status_bayar.'<br>'.$bukti_tf;
            })
            ->editColumn('tema', function ($row) {
                return $row->tema->nama_tema;
            })
            ->editColumn('masa_aktif', function ($row) {
                return \Illuminate\Support\Carbon::parse($row->created_at)->addDays($row->paket->durasi)->translatedFormat('d F Y');
            })
            ->editColumn('total', function ($row) {
                return format_rupiah($row->paket->harga);
            })
            ->addColumn('opsi', function ($row) {
                $btn = 'Proses Isi Data';
                if (isset($row->transaksi->link)) {
                    $btn = '<a href="daftar_undangan/'.$row->kode.'/edit" class="btn btn-success btn-block btn-sm">Edit</a><a href="javascript:void(0)" class="btn btn-danger btn-block btn-sm deleteUndangan" data-kode="'.$row->kode.'" >Hapus</a>';
                }
                return $btn;
            })
            ->with('sum_total', function() use ($total_transaksi) {
                return format_rupiah($total_transaksi);
            })
            ->rawColumns(['kodes', 'status_bayar', 'opsi'])->make(true);
        }

        $data['title'] = 'Daftar Undangan Digital';
        $data['status_undangan'] = ['Aktif', 'Nonaktif'];
        $data['status_bayar'] = ['Belum Dibayar', 'Lunas'];
        $data['daftar_paket'] = UndanganPaket::select('id', 'durasi')->get();
        $data['daftar_tema'] = UndanganTema::select('id', 'nama_tema')->get();
        return view('admin.undangan.daftar_undangan', $data);
    }

    public function exportUndanganPdf()
    {
        return (new UndanganExport)->export_pdf();
    }

    public function exportUndanganExcel()
    {
        return (new UndanganExport)->export_excel();
    }

    public function hapusFotoUndangan($kode_undangan)
    {
        $data_pengantin = \App\Models\UndanganPengantin::where('kode_undangan', '=', $kode_undangan)->first();
        if ($data_pengantin) {
            File::delete(public_path('/frontend/undangan/foto_pengantin/' . $data_pengantin->foto_pria));
            File::delete(public_path('/frontend/undangan/foto_pengantin/' . $data_pengantin->foto_wanita));
        }
        $data_undangan = \App\Models\UndanganDetail::where('kode_undangan', '=', $kode_undangan)->first();
        if ($data_undangan) {
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_1));
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_2));
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_3));
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_4));
        }
        $data_galeri = \App\Models\UndanganGaleri::where('kode_undangan', '=', $kode_undangan)->get();
        if ($data_galeri) {
            foreach ($data_galeri as $galeri) {
                File::delete(public_path('/frontend/undangan/foto_galeri/' . $galeri->foto));
            }
        }
        $data_cerita = \App\Models\UndanganCerita::where('kode_undangan', '=', $kode_undangan)->get();
        if ($data_cerita) {
            foreach ($data_cerita as $foto) {
                File::delete(public_path('/frontend/undangan/foto_cerita/' . $foto->foto_cerita));
            }
        }
    }

    public function deleteUndangan($kode_undangan)
    {
        try {
            $this->hapusFotoUndangan($kode_undangan);
        } catch (\Exception $e) {
            return response()->json(['success' => true, 'message' => 'Terjadi kesalahan saat hapus foto.']);
        }
        Undangan::where('kode', '=', $kode_undangan)->delete();
        $get_transaksi = Transaksi::where('kode_undangan', '=', $kode_undangan)->first();
        if ($get_transaksi) {
            $get_transaksi->delete();
            File::delete(public_path('/frontend/images/bukti_tf/' . $get_transaksi->link));
        }
        return response()->json(['success' => true, 'message' => 'Data undangan digital berhasil dihapus!']);
    }

    public function deleteAllUndangan(Request $request)
    {
        $kodes = $request->kodes;
        $get_undangan = Undangan::whereIn('kode', explode(",", $kodes));
        foreach ($get_undangan->get() as $undangan) {
            $this->hapusFotoUndangan($undangan->kode);
        }
        $get_undangan->delete();

        $get_transaksi = Transaksi::whereIn('kode_undangan', explode(",", $kodes));
        foreach ($get_transaksi->get() as $row) {
            File::delete(public_path('/frontend/images/bukti_tf/' . $row->link));
        }
        $get_transaksi->delete();
        return response()->json(['success' => true, 'message' => 'Data undangan digital berhasil dihapus!']);
    }

    public function editUndangan($kode_undangan, Request $request)
    {
        if (count($request->all())) {
            $post_status_undangan = $request->status_undangan;
            $post_status_pembayaran = $request->status_bayar;
            $get_undangan = Undangan::where('kode', '=', $kode_undangan)->with('user')->firstOrFail();
            $nama_konsumen = $get_undangan->user->nama;
            $no_tlp = $get_undangan->user->no_tlp;

            // Script bagian ubah status undangan
            if ($post_status_undangan != $get_undangan->status_undangan) {
                $status = $request->status_undangan;
                $get_undangan->update([
                    'status_undangan' => $status
                ]);
                $text = "Undangan digital atas nama $nama_konsumen telah $status. Terima kasih telah menggunakan layanan kami.";
                NotifikasiTrait::sendToUser($text, $no_tlp);
            }

            // Script bagian ubah status pembayaran
            if ($post_status_pembayaran != $get_undangan->status_bayar) {
                $get_undangan->update([
                    'status_undangan' => $post_status_pembayaran == 'Lunas' ? 'Aktif' : 'Nonaktif',
                    'status_bayar' => $post_status_pembayaran,
                ]);
                Transaksi::where('kode_undangan','=',$kode_undangan)->where('status','=','UNPAID')->update(['status' => 'PAID']);
                $text = "Undangan digital atas nama $nama_konsumen status pembayarannya sekarang adalah *$post_status_pembayaran*.";
                NotifikasiTrait::sendToUser($text, $no_tlp);
            }
            return to_route('daftar_undangan')->with('success', 'Data undangan digital berhasil diubah!');
        } else {
            $data['title'] = 'Edit Data Undangan Digital';
            $data['undangan'] = Undangan::where('kode', '=', $kode_undangan)->firstOrFail();
            $data['status_undangan'] = ['Aktif', 'Nonaktif'];
            $data['status_bayar'] = ['Belum Dibayar', 'Lunas'];
            $data['transaksi'] = Transaksi::where('kode_undangan', '=', $kode_undangan)->first();
            return view('admin.undangan.edit_undangan', $data);
        }
    }

    public function paketUndangan(Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'durasi' => ['required', 'numeric'],
                'harga' => ['required'],
            ]);
            $input = [
                'durasi' => $request->durasi,
                'harga' => change_rupiah($request->harga),
                'is_active' => 1,
            ];
            UndanganPaket::create($input);
            return to_route('paket_undangan')->with('success', 'Paket undangan berhasil ditambahkan!');
        } else {
            $data['title'] = 'Pengaturan Paket Undangan';
            $data['data_paket'] = UndanganPaket::all();
            return view('admin.undangan.paket_undangan', $data);
        }
    }

    public function editPaketUndangan($id, Request $request)
    {
        $request->validate([
            'durasi' => ['required', 'numeric'],
            'harga' => ['required'],
        ]);
        $input = [
            'durasi' => $request->durasi,
            'harga' => change_rupiah($request->harga),
            'is_active' => $request->is_active,
        ];
        UndanganPaket::find($id)->update($input);
        return to_route('paket_undangan')->with('success', 'Paket undangan berhasil diubah!');
    }

    public function deletePaketUndangan($id)
    {
        UndanganPaket::find($id)->delete();
        return to_route('paket_undangan')->with('success', 'Paket undangan berhasil dihapus!');
    }

    public function temaUndangan(Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'nama_tema' => ['required'],
                'preview' => ['required'],
                'aspect_ratio' => ['required'],
                'width_slider' => ['required'],
                'height_slider' => ['required'],
                'thumbnail' => ['required', 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
            ]);
            $input = [
                'nama_tema' => $request->nama_tema,
                'preview' => $request->preview,
                'aspect_ratio' => $request->aspect_ratio,
                'width_slider' => $request->width_slider,
                'height_slider' => $request->height_slider,
                'is_active' => 1,
            ];
            if ($file = $request->file('thumbnail')) {
                $file_name = $file->getClientOriginalName();
                $file->move(public_path('/frontend/images/paket'), $file_name);
                $input['thumbnail'] = $file_name;
            }
            UndanganTema::create($input);
            return to_route('tema_undangan')->with('success', 'Tema undangan berhasil ditambahkan!');
        } else {
            $data['title'] = 'Pengaturan Tema Undangan';
            $data['data_tema'] = UndanganTema::all();
            return view('admin.undangan.tema_undangan', $data);
        }
    }

    public function editTemaUndangan($id, Request $request)
    {
        $request->validate([
            'nama_tema' => ['required'],
            'preview' => ['required'],
            'aspect_ratio' => ['required'],
            'width_slider' => ['required'],
            'height_slider' => ['required'],
            'thumbnail' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
        ]);
        $get_tema = UndanganTema::find($id);
        $input = [
            'nama_tema' => $request->nama_tema,
            'preview' => $request->preview,
            'aspect_ratio' => $request->aspect_ratio,
            'width_slider' => $request->width_slider,
            'height_slider' => $request->height_slider,
            'is_active' => $request->is_active,
        ];
        if ($file = $request->file('thumbnail')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/images/paket'), $file_name);
            if ($get_tema->thumbnail != 'coming_soon.jpg') {
                File::delete(public_path('/frontend/images/paket/' . $get_tema->thumbnail));
            }
            $input['thumbnail'] = $file_name;
        }
        $get_tema->update($input);

        return to_route('tema_undangan')->with('success', 'Tema undangan berhasil diubah!');
    }

    public function deleteTemaUndangan($id)
    {
        $get_tema = UndanganTema::find($id);
        File::delete(public_path('/frontend/images/paket/' . $get_tema->thumbnail));
        $get_tema->delete($id);
        return to_route('tema_undangan')->with('success', 'Tema undangan berhasil dihapus!');
    }
}
