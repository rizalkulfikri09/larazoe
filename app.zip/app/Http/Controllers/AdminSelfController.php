<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\AddOnSelf;
use App\Models\PaketSelf;
use App\Models\SelfPhoto;
use App\Models\Transaksi;
use App\Models\SettingApp;
use App\Models\JamSelfPhoto;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Traits\NotifikasiTrait;
use App\Exports\SelfPhotoExport;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\File;

class AdminSelfController extends Controller
{
    public function __construct()
    {
        $this->middleware(['only.admin']);
    }

    public function showSelfPhoto(Request $request)
    {
        if ($request->ajax()) {
            if ($request->session_sbo) {
                session()->put('session_sbo', $request->session_sbo);
            }
            if ($request->session_dp) {
                session()->put('session_dp', $request->session_dp);
            }
            if ($request->session_sba) {
                session()->put('session_sba', $request->session_sba);
            }
            if ($request->tanggal_1) {
                session()->put('tanggal_1', $request->tanggal_1);
                session()->put('tanggal_2', $request->tanggal_2);
            }
            $query = SelfPhoto::with(['user', 'transaksi'])
            ->when(session()->get('session_sbo'), function ($query) {
                $query->where('status_booking', '=', session()->get('session_sbo'));
            })
            ->when(session()->get('session_dp'), function ($query) {
                $query->where('id_paket', '=', session()->get('session_dp'));
            })
            ->when(session()->get('session_sba'), function ($query) {
                $query->where('status_bayar', '=', session()->get('session_sba'));
            })
            ->when(session()->get('tanggal_1'), function ($query) {
                $query->where('tgl_booking', '>=', session()->get('tanggal_1'))->where('tgl_booking', '<=', session()->get('tanggal_2'));
            });
            $data = empty($query) ? $query : $query->latest()->get();
            return DataTables::of($data)->addIndexColumn()
            ->addColumn('kodes', function ($row) {
                $check = '<input type="checkbox" class="sub_chk" data-kodes="'. $row->kode .'">';
                return $check;
            })
            ->editColumn('nama', function ($row) {
                return $row->user->nama;
            })
            ->editColumn('no_tlp', function ($row) {
                return $row->user->no_tlp;
            })
            ->editColumn('tgl_booking', function ($row) {
                return \Illuminate\Support\Carbon::parse($row->tgl_booking)->translatedFormat('d F Y');
            })
            ->editColumn('status_bayar', function ($row) {
                $result = $row->status_bayar == 'DP' ? format_rupiah($row->jml_dp) : '';
                $bukti_tf = isset($row->transaksi->link) && is_null($row->transaksi->no_ref) ? '<b><a target="_blank" href="'.url('frontend/images/bukti_tf/' . $row->transaksi->link).'">Bukti TF</a></b>' : '';
                return $row->status_bayar.' <b style="color: red;">'.$result.'</b><br>'.$bukti_tf;
            })
            ->editColumn('total', function ($row) {
                return format_rupiah($row->total);
            })
            ->addColumn('opsi', function ($row) {
                $btn = '<a href="daftar_self_photo/'.$row->kode.'/edit" class="btn btn-success btn-block btn-sm">Edit</a><a href="javascript:void(0)" class="btn btn-danger btn-block btn-sm deleteBooking" data-toggle="tooltip" data-kode="'.$row->kode.'" data-original-title="Delete">Hapus</a>';
                return $btn;
            })
            ->with('sum_total', function() use ($query) {
                return format_rupiah($query->sum('total'));
            })
            ->rawColumns(['kodes', 'status_bayar', 'opsi'])->toJson();
        }

        $data['title'] = 'Daftar Booking Self Photo';
        $data['daftar_konsumen'] = User::select(['id', 'nama'])->get();
        $data['daftar_sesi'] = JamSelfPhoto::select(['id', 'jam'])->get();
        $data['daftar_paket'] = PaketSelf::select(['id', 'nama_paket'])->where('is_active', 1)->get();
        $data['add_ons'] = AddOnSelf::select(['id', 'nama_addon'])->get();
        $getCS = SettingApp::find(1);
        $data['nama_cs'] = json_decode($getCS->items);
        $data['cs_now'] = $getCS;
        $data['session_sbo'] = ['Dipesan', 'Selesai'];
        $data['session_sba'] = ['Lunas', 'DP', 'Belum Dibayar'];
        $data['session_dp'] = PaketSelf::select('id', 'nama_paket')->get();
        return view('admin.selfphoto.daftar_selfphoto', $data);
    }

    public function createSelfPhoto(Request $request)
    {
        $request->validate([
            'user_id' => ['required'],
            'tgl_booking' => ['required'],
            'id_sesi' => ['required'],
            'paket' => ['required'],
            'jml_orang' => ['required'],
            'status_booking' => ['required'],
            'status_bayar' => ['required'],
            'jml_dp' => ['required'],
        ]);
        $query = SelfPhoto::where('tgl_booking', '=', $request->tgl_booking)->where('id_sesi', '=', $request->id_sesi)->get()->count();
        if ($query >= 1) {
            throw \Illuminate\Validation\ValidationException::withMessages([
            'id_sesi' => 'Jam booking yang dipilih sudah penuh, pilih jam booking yang lain.'
            ]);
        }

        $id_sesi = $request->id_sesi;
        $get_paket = PaketSelf::find($request->paket);
        $get_addon = AddOnSelf::whereIn('id', $request->add_ons ?? [])->get();
        $add_ons = $get_addon->pluck('nama_addon')->implode(', ');
        $paket = $get_paket->nama_paket . ($add_ons ? " - " . $add_ons : "");
        $total_pembayaran = ($get_addon->sum('harga') ?? 0) + $get_paket->harga;

        $get_jam = JamSelfPhoto::where('id', $id_sesi)->first();
        $jam_akhir = Carbon::createFromFormat('H:i', $get_jam->jam);
        $jam_akhir->addMinutes($get_paket->durasi);
        $jam_booking = $get_jam->jam.' - '.$jam_akhir->format('H:i');

        SelfPhoto::create([
            'kode' => kode_selfphoto(),
            'user_id' => $request->user_id,
            'paket' => $paket,
            'status_booking' => $request->status_booking,
            'status_bayar' => $request->status_bayar,
            'jml_dp' => $request->status_bayar != "DP" ? 0 : change_rupiah($request->jml_dp),
            'total' => $total_pembayaran,
            'jml_orang' => $request->jml_orang,
            'tgl_booking' => $request->tgl_booking,
            'jam_booking' => $jam_booking,
            'id_sesi' => $request->id_sesi,
            'id_paket' => $request->paket,
            'cs' => $request->nama_cs,
        ]);

        return response()->json(['success' => true, 'message' => "Booking self photo berhasil ditambah!"]);
    }

    public function editSelfPhoto(Request $request, $kode_selfphoto)
    {
        if (count($request->all())) {
            $post_status_booking = $request->status_booking;
            $post_status_pembayaran = $request->status_bayar;
            $post_jumlah_dp = change_rupiah($request->jml_dp);
            $get_booking = SelfPhoto::where('kode', '=', $kode_selfphoto)->with('user')->firstOrFail();

            // Script bagian ubah status booking self photo
            if ($post_status_booking != $get_booking->status_booking) {
                $nama_konsumen = $get_booking->user->nama;
                $no_tlp = $get_booking->user->no_tlp;
                $status = $request->status_booking;
                $get_booking->update([
                    'status_booking' => $status
                ]);
                $text = "Booking self photo atas nama $nama_konsumen telah $status. Terima kasih telah menggunakan layanan kami, jangan lupa berikan testimoni dan rating pada aplikasi.";
                NotifikasiTrait::sendToUser($text, $no_tlp);
            }

            // Script bagian ubah status pembayaran
            if ($post_status_pembayaran != $get_booking->status_bayar) {
                $nama_konsumen = $get_booking->user->nama;
                $no_tlp = $get_booking->user->no_tlp;
                $get_booking->update([
                    'status_booking' => $post_status_booking,
                    'status_bayar' => $post_status_pembayaran,
                    'jml_dp' => $post_jumlah_dp,
                ]);
                Transaksi::where('kode_selfphoto','=',$kode_selfphoto)->where('status','=','UNPAID')->update(['status' => 'PAID']);
                $link = url('cetak_selfphoto/' . $kode_selfphoto);
                $text = "Booking self photo atas nama $nama_konsumen status pembayarannya sekarang adalah $post_status_pembayaran.\n\nBerikut link untuk cetak nota : $link";
                NotifikasiTrait::sendToUser($text, $no_tlp);
            }
            return to_route('daftar_self_photo')->with('success', 'Data booking self photo berhasil diubah!');
        } else {
            $data['title'] = 'Edit Booking Self Photo';
            $getCS = SettingApp::find(1);
            $data['booking'] = SelfPhoto::where('kode', '=', $kode_selfphoto)->firstOrFail();
            $data['status_booking'] = ['Dipesan', 'Selesai'];
            $data['status_bayar'] = ['Belum Dibayar', 'DP', 'Lunas'];
            $data['nama_cs'] = json_decode($getCS->items);
            $data['jam_booking'] = JamSelfPhoto::select(['id', 'jam'])->get();
            $data['transaksi'] = Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->first();

            return view('admin.selfphoto.edit_selfphoto', $data);
        }
    }

    public function resSelfPhoto(Request $request ,$kode_selfphoto)
    {
        $request->validate([
            'jml_orang' => ['required'],
            'tgl_booking' => ['required'],
            'id_sesi' => ['required'],
        ]);

        $get_jam = JamSelfPhoto::where('id', $request->id_sesi)->first();
        $get_booking = SelfPhoto::where('kode', '=', $kode_selfphoto)->firstOrFail();
        $get_booking->update([
            "jml_orang" => $request->jml_orang,
            "tgl_booking" => $request->tgl_booking,
            "jam_booking" => resjam_selfphoto($get_jam->jam, $kode_selfphoto),
            "id_sesi" => $request->id_sesi,
            "cs" => $request->cs,
        ]);

        return to_route('daftar_self_photo')->with('success', 'Booking self photo berhasil di reschedule!');
    }

    public function deleteSelfPhoto($kode_selfphoto)
    {
        SelfPhoto::where('kode', '=', $kode_selfphoto)->delete();
        $get_transaksi = Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->first();
        if ($get_transaksi) {
            $get_transaksi->delete();
            File::delete(public_path('/frontend/images/bukti_tf/' . $get_transaksi->link));
        }
        return response()->json(['success' => true, 'message' => 'Booking self photo berhasil dihapus!']);
    }

    public function deleteAllSelfPhoto(Request $request)
    {
        $kodes = $request->kodes;
        SelfPhoto::whereIn('kode', explode(",", $kodes))->delete();
        $get_transaksi = Transaksi::whereIn('kode_selfphoto', explode(",", $kodes));
        foreach ($get_transaksi->get() as $row) {
            File::delete(public_path('/frontend/images/bukti_tf/' . $row->link));
        }
        $get_transaksi->delete();
        return response()->json(['success' => true, 'message' => 'Booking self photo berhasil dihapus!']);
    }

    public function exportSelfPdf()
    {
        return (new SelfPhotoExport)->export_pdf();
    }

    public function exportSelfExcel()
    {
        return (new SelfPhotoExport)->export_excel();
    }

    public function paketSelfPhoto(Request $request)
    {
        if(count($request->all())) {
            $input = $request->validate([
                'nama_paket' => ['required'],
                'thumbnail' => ['required', 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'deskripsi' => ['required'],
                'min_org' => ['required'],
                'max_org' => ['required'],
                'durasi' => ['required'],
                'harga' => ['required'],
                'is_active' => ['required'],
            ]);
            $input['harga'] = change_rupiah($request->harga);
            if ($file = $request->file('thumbnail')) {
                $file_name = $file->getClientOriginalName();
                $file->move(public_path('/frontend/images/paket'), $file_name);
                $input['thumbnail'] = $file_name;
            }
            PaketSelf::create($input);
            return to_route('paket_self_photo')->with('success', 'Paket baru berhasil ditambahkan!');
        } else {
            $data['title'] = 'Paket Self Photo';
            $data['data_paket'] = PaketSelf::all();
            return view('admin.selfphoto.paket_selfphoto', $data);
        }
    }

    public function editPaketSelfPhoto(Request $request, $id)
    {
        $get_paket = PaketSelf::where('id', $id)->first();
        $input = $request->validate([
            'nama_paket' => ['required'],
            'thumbnail' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'deskripsi' => ['required'],
            'min_org' => ['required'],
            'max_org' => ['required'],
            'durasi' => ['required'],
            'harga' => ['required'],
            'is_active' => ['required'],
        ]);
        $input['harga'] = change_rupiah($request->harga);
        if ($file = $request->file('thumbnail')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/images/paket'), $file_name);
            if ($get_paket->thumbnail != $file_name) {
                File::delete(public_path('/frontend/images/paket/' . $get_paket->thumbnail));
            }
            $input['thumbnail'] = $file_name;
        }
        $get_paket->update($input);

        return to_route('paket_self_photo')->with('success', 'Paket berhasil diubah!');
    }

    public function deletePaketSelfPhoto($id)
    {
        $get_paket = PaketSelf::find($id);
        File::delete(public_path('/frontend/images/paket/' . $get_paket->thumbnail));
        $get_paket->delete($id);
        return to_route('paket_self_photo')->with('success', 'Paket berhasil dihapus!');
    }

    public function addonsSelfPhoto(Request $request)
    {
        if (count($request->all())) {
            $input = $request->validate([
                'nama_addon' => ['required'],
                'harga' => ['required'],
            ]);
            $input['harga'] = change_rupiah($request->harga);
            AddOnSelf::create($input);
            return to_route('addons_self_photo')->with('success', 'Add on berhasil ditambahkan!');
        } else {
            $data['title'] = 'Add Ons Self Photo';
            $data['data_addons'] = AddOnSelf::all();
            return view('admin.selfphoto.add_ons', $data);
        }
    }

    public function editAddOnsSelf(Request $request, $id)
    {
        $get_addon = AddOnSelf::where('id', $id)->first();
        $input = $request->validate([
            'nama_addon' => ['required'],
            'harga' => ['required'],
        ]);
        $input['harga'] = change_rupiah($request->harga);
        $get_addon->update($input);

        return to_route('addons_self_photo')->with('success', 'Add ons berhasil diubah!');
    }

    public function deleteAddOns($id)
    {
        AddOnSelf::find($id)->delete($id);
        return to_route('addons_self_photo')->with('success', 'Add ons berhasil dihapus!');
    }

    public function jamSelfPhoto(Request $request)
    {
        if (count($request->all())) {
            $input = $request->validate([
                'jam' => ['required'],
                'status' => ['required'],
            ]);
            JamSelfPhoto::create($input);
            return to_route('jam_self_photo')->with('success', 'Jam booking baru berhasil ditambahkan!');
        } else {
            $data['title'] = 'Jam Booking Self Photo';
            $data['jam_booking'] = JamSelfPhoto::select('id', 'jam', 'status')->get();
            return view('admin.selfphoto.jam_selfphoto', $data);
        }
    }

    public function editJamSelf(Request $request, $id)
    {
        if (count($request->all())) {
            $input = $request->validate([
                'jam' => ['required'],
                'status' => ['required'],
            ]);
            JamSelfPhoto::where('id', $id)->update($input);
            return to_route('jam_self_photo')->with('success', 'Jam booking berhasil diubah!');
        } else {
            $data['title'] = 'Edit Jam Booking';
            $data['jam_booking'] = JamSelfPhoto::findOrFail($id);
            $data['jml_hari'] = [7,1,2,3,4,5,6,0];
            return view('admin.selfphoto.edit_jam_self', $data);
        }
    }

    public function deleteJamSelf($id)
    {
        JamSelfPhoto::find($id)->delete($id);
        return to_route('jam_self_photo')->with('success', 'Jam booking berhasil dihapus!');
    }
}
