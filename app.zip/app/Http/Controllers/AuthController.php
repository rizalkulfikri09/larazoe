<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Rules\ReCaptcha;
use App\Models\UserToken;
use App\Models\SettingApp;
use Illuminate\Http\Request;
use App\Traits\NotifikasiTrait;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function goToDefaultPage()
    {
        if (auth()->user()->role_id == 2) {
            return to_route('user');
        } else if (auth()->user()->role_id == 1) {
            return to_route('admin');
        } else {
            return to_route('/');
        }
    }

    public function getUserByPhone($no_tlp)
    {
        return User::where('no_tlp', $no_tlp)->first();
    }

    public function getUserToken($no_tlp)
    {
        return UserToken::where('no_tlp', $no_tlp)->orderBy('created_at', 'desc')->first();
    }

    public function send_aktivasi($no_tlp)
    {
        $otp = random_int(1000, 9999);
        $user_token = [
            'no_tlp' => $no_tlp,
            'token' => $otp,
        ];
        UserToken::create($user_token);

        /*
        | ---------------------------------------------------------------
        | Pesan Untuk OTP
        | ---------------------------------------------------------------
        */
        $link = url('aktivasi/'.$no_tlp).'/';
        $text = "Kode verifikasi Anda : *$otp*. Kode akan kedaluarsa dalam waktu 5 menit.\n\nHalaman Aktivasi : $link";
        NotifikasiTrait::sendToUser($text, $no_tlp);
    }

    public function send_reset($no_tlp)
    {
        $otp = random_int(1000, 9999);
        $user_token = [
            'no_tlp' => $no_tlp,
            'token' => $otp,
        ];
        UserToken::create($user_token);

        /*
        | ---------------------------------------------------------------
        | Pesan Untuk OTP
        | ---------------------------------------------------------------
        */
        $link = url('reset/'.$no_tlp).'/';
        $text = "Kode verifikasi Anda : *$otp*. Kode akan kedaluarsa dalam waktu 5 menit.\n\nHalaman Reset Password : $link";
        NotifikasiTrait::sendToUser($text, $no_tlp);
    }

    public function send_mail($no_tlp)
    {
        $user = User::where('no_tlp', '=', $no_tlp)->first();
        $otp = random_int(1000, 9999);
        $user_token = [
            'no_tlp' => $user->no_tlp,
            'token' => $otp,
        ];
        UserToken::create($user_token);

        $mailData = [
            'title' => "Kode OTP untuk reset password",
            'body' => "Kode verifikasi Anda : $otp. Kode akan kedaluarsa dalam waktu 5 menit. Klik link dibawah ini untuk reset password :",
            'link' => url('mail/'.$user->no_tlp),
        ];
        Mail::to($user->email)->send(new \App\Mail\SendMail($mailData));
    }

    public function showLogin()
    {
        $data['set_sistem'] = SettingApp::find(1);
        return view('auth.login', $data);
    }

    public function _login(Request $request)
    {
        $request->validate([
            'no_tlp' => ['required'],
            'password' => ['required', 'min:8'],
        ]);

        $user = User::where('no_tlp', $request->no_tlp)->orWhere('email', $request->no_tlp)->first();

        if ($user) {
            if ($user->is_active) {
                if (Hash::check($request->password, $user?->password)) {
                    $request->session()->regenerate();
                    auth()->login($user, $request->remember);
                    if ($user->role_id == 1) {
                        return redirect()->intended('admin');
                    } else {
                        return redirect()->intended('user');
                    }
                } else {
                    return back()->with('danger', 'Login gagal cek kembali nomor WhatsApp dan password Anda!');
                }
            } else {
                return back()->with('danger', 'Akun anda belum diaktivasi, silahkan cek WhatsApp Anda');
            }
        } else {
            return back()->with('danger', 'Anda belum terdaftar, silahkan buat akun terlebih dahulu.');
        }
    }

    public function logout(Request $request)
    {
        auth()->guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return to_route('login');
    }

    public function showRegistrasi(Request $request)
    {
        $set_sistem = SettingApp::find(1);
        if (count($request->all())) {
            $request->validate([
                'nama' => ['required'],
                'no_tlp' => ['required', Rule::unique('users', 'no_tlp'), 'regex:/^0\d/', 'numeric'],
                'email' => ['required', Rule::unique('users', 'email'), 'email:rfc,dns'],
                'password' => ['required', 'min:8', 'confirmed'],
                'g-recaptcha-response' => ['required', new ReCaptcha],
                'type_send' => ['required'],
            ], [
                'no_tlp.regex' => 'nomor WhatApp tidak sesuai format 08123XXXXXXX.',
                'g-recaptcha-response.required' => 'ReCaptcha wajib diisi, tidak boleh kosong.',
            ]);

            User::create([
                'nama' => ucwords($request->nama),
                'no_tlp' => $request->no_tlp,
                'email' => $request->email,
                'password' => bcrypt($request->password),
                'image' => 'default.jpg',
                'role_id' => '2',
                'is_active' => '0',
            ]);

            if ($set_sistem->value_2 && $request->type_send == "wa") {
                $this->send_aktivasi($request->no_tlp);
                return redirect('aktivasi/'.$request->no_tlp)->with('success', 'Kode OTP dikirim ke nomor WhatsApp Anda');
            } else if ($set_sistem->value_10 && $request->type_send == "mail") {
                try {
                    $otp = random_int(1000, 9999);
                    $user_token = [
                        'no_tlp' => $request->no_tlp,
                        'token' => $otp,
                    ];
                    UserToken::create($user_token);
                    $mailData = [
                        'title' => "Kode OTP untuk aktivasi akun",
                        'body' => "Kode verifikasi Anda : $otp. Kode akan kedaluarsa dalam waktu 5 menit. Klik link dibawah ini untuk aktivasi akun :",
                        'link' => url('aktivasi/'.$request->no_tlp),
                    ];
                    Mail::to($request->email)->send(new \App\Mail\SendMail($mailData));
                } catch (\Exception $e) {
                    throw ValidationException::withMessages(['Terjadi kesalahan disistem.']);
                }
                return redirect('aktivasi/'.$request->no_tlp)->with('success', 'Kode OTP berhasil dikirim, cek email Anda atau cek di folder Spam.');
            } else {
                return to_route('login');
            }
        } else {
            $data['set_sistem'] = $set_sistem;
            $data['captcha_key'] = config('tools.captcha_key');
            if ($data['set_sistem']['value_4']) {
                return view('auth.registrasi', $data);
            }
            return to_route('login');
        }
    }

    public function lupaPassword(Request $request)
    {
        $set_sistem = SettingApp::find(1);
        if (count($request->all())) {
            $request->validate([
                'no_tlp' => ['required'],
                'type_send' => ['required'],
                'g-recaptcha-response' => ['required', new ReCaptcha],
            ], [
                'g-recaptcha-response.required' => 'ReCaptcha wajib diisi, tidak boleh kosong.',
            ]);
            $user = User::where('no_tlp', $request->no_tlp)->orWhere('email', $request->no_tlp)->first();
            if ($user) {
                if ($set_sistem->value_2 && $request->type_send == "wa") {
                    $this->send_reset($request->no_tlp);
                    return redirect('reset/'.$request->no_tlp)->with('success', 'Kode OTP dikirim ke nomor WhatsApp Anda');
                } else if ($set_sistem->value_10 && $request->type_send == "mail") {
                    try {
                        $this->send_mail($user->no_tlp);
                    } catch (\Exception $e) {
                        throw ValidationException::withMessages(['Terjadi kesalahan disistem.']);
                    }
                    return redirect('mail/'.$user->no_tlp)->with('success', 'Kode OTP berhasil dikirim, cek email Anda atau cek di folder Spam.');
                } else {
                    return to_route('login');
                }
            } else {
                throw ValidationException::withMessages([
                    'no_tlp' => 'Nomor WhatsApp atau email tidak terdaftar.'
                ]);
            }
        } else {
            $data['set_sistem'] = $set_sistem;
            $data['captcha_key'] = config('tools.captcha_key');
            return view('auth.lupa_password', $data);
        }
    }

    public function verifikasi($type, $no_tlp, Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'kode_1' => ['required','numeric'],
                'kode_2' => ['required','numeric'],
                'kode_3' => ['required','numeric'],
                'kode_4' => ['required','numeric'],
            ]);
            $otp = $request->kode_1 . $request->kode_2 . $request->kode_3 . $request->kode_4;

            $user = $this->getUserByPhone($no_tlp);
            $user_token = $this->getUserToken($no_tlp);

            switch ($user_token) {
                // Bagian proses untuk aktivasi akun
                case ($user_token && $type == "aktivasi"):
                    if ($user_token->token == $otp) {
                        if ((time() - strtotime($user_token->created_at)) < 300) { // token expired 5 menit
                            User::where('no_tlp', $no_tlp)->update(['is_active' => 1]);
                            UserToken::where('no_tlp', $no_tlp)->delete();
                            return to_route('login')->with('success', 'Akun Anda berhasil diaktifkan, silahkan login.');
                        }
                        User::where('no_tlp', $no_tlp)->delete();
                        UserToken::where('no_tlp', $no_tlp)->delete();
                        return to_route('login')->with('danger', 'Aktivasi akun gagal! Kode OTP telah kedaluwarsa.');
                    } else {
                        return redirect('aktivasi/'.$request->no_tlp)->with('danger', 'Kode OTP yang dimasukan salah / masukan kode OTP yang baru.');
                    }
                    break;
                // Bagian proses untuk reset password
                case ($user_token && $type == "reset"):
                    if ($user_token->token == $otp) {
                        if ((time() - strtotime($user_token->created_at)) < 300) { // token expired 5 menit
                            session(['kode_reset' => $otp]);
                            return redirect('reset_password/'.$request->no_tlp);
                        } else {
                            UserToken::where('no_tlp', $no_tlp)->delete();
                            return to_route('login')->with('danger', 'Reset password gagal! Kode OTP telah kedaluwarsa.');
                        }
                    } else {
                        return redirect('reset/'.$request->no_tlp)->with('danger', 'Kode OTP yang dimasukan salah / masukan kode OTP yang baru.');
                    }
                    break;
                case ($user_token && $type == "mail"):
                    if ($user_token->token == $otp) {
                        if ((time() - strtotime($user_token->created_at)) < 300) { // token expired 5 menit
                            session(['kode_reset' => $otp]);
                            return redirect('reset_password/'.$request->no_tlp);
                        } else {
                            UserToken::where('no_tlp', $no_tlp)->delete();
                            return to_route('login')->with('danger', 'Reset password gagal! Kode OTP telah kedaluwarsa.');
                        }
                    } else {
                        return redirect('reset/'.$request->no_tlp)->with('danger', 'Kode OTP yang dimasukan salah / masukan kode OTP yang baru.');
                    }
                    break;
                default:
                    return to_route('login');
                    break;
            }
        // Bagian view aktivasi akun & reset password
        } else {
            $user = $this->getUserByPhone($no_tlp);
            $user_token = $this->getUserToken($no_tlp);
            if ($user && $user_token) {
                if ($type == 'aktivasi') {
                    $title = 'Aktivasi Akun';
                    $resend = "Tidak menerima kode? <a href=". route('send_aktivasi', $no_tlp) .">Kirim Ulang</a>";
                } else if ($type == 'reset') {
                    $title = 'Reset Password Akun';
                    $resend = "Tidak menerima kode? <a href=". route('send_reset', $no_tlp) .">Kirim Ulang</a>";
                } else if ($type == 'mail') {
                    $title = 'Reset Password Akun';
                    $resend = "Tidak menerima kode? <a href=". route('send_mail', $no_tlp) .">Kirim Ulang</a>";
                }
                return view('auth.verifikasi', [
                    'title' => $title,
                    'type' => $type,
                    'no_tlp' => $no_tlp,
                    'expired_time' => date('Y-m-d H:i:s', strtotime($user_token->created_at) + 300),
                    'resend' => $resend,
                ]);
            }
            return to_route('login');
        }
    }

    public function resetPassword($no_tlp, Request $request)
    {
        $user = $this->getUserByPhone($no_tlp);
        if ($user && !session()->get('kode_reset') == $user->token) {
            if (count($request->all())) {
                $request->validate([
                    'password' => ['required', 'min:8', 'confirmed'],
                ]);
                User::where('no_tlp', $no_tlp)->update(['password' => bcrypt($request->password)]);
                UserToken::where('no_tlp', $no_tlp)->delete();
                session()->forget('kode_reset');
                return to_route('login')->with('success', 'Password Anda berhasil direset! silahkan login');
            } else {
                $user_token = $this->getUserToken($no_tlp);
                if ($user_token && (time() - strtotime($user_token->created_at)) < 300) { // token expired 5 menit
                    return view('auth.reset_password', compact('no_tlp'));
                } else {
                    UserToken::where('no_tlp', $no_tlp)->delete();
                    session()->forget('kode_reset');
                    return to_route('login');
                }
            }
        } else {
            session()->forget('kode_reset');
            return to_route('login');
        }
    }

    public function resendAktivasi($no_tlp)
    {
        $user_token = $this->getUserToken($no_tlp);
        if ((time() - strtotime($user_token->created_at)) > 300) {
            $this->send_aktivasi($no_tlp);
            return redirect('aktivasi/'.$no_tlp)->with('success', 'Kode OTP dikirim ke nomor WhatsApp Anda');
        }
        return redirect('aktivasi/'.$no_tlp);
    }

    public function resendReset($no_tlp)
    {
        $user_token = $this->getUserToken($no_tlp);
        if ((time() - strtotime($user_token->created_at)) > 300) {
            $this->send_reset($no_tlp);
            return redirect('reset/'.$no_tlp)->with('success', 'Kode OTP dikirim ke nomor WhatsApp Anda');
        }
        return redirect('reset/'.$no_tlp);
    }

    public function resendMail($no_tlp)
    {
        $user_token = $this->getUserToken($no_tlp);
        if ((time() - strtotime($user_token->created_at)) > 300) {
            try {
                $this->send_mail($no_tlp);
            } catch (\Exception $e) {
                throw ValidationException::withMessages(['Terjadi kesalahan disistem.']);
            }
            return redirect('mail/'.$no_tlp)->with('success', 'Kode OTP berhasil dikirim, cek email Anda atau cek di folder Spam.');
        }
        return redirect('mail/'.$no_tlp);
    }
}
