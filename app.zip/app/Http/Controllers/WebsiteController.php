<?php

namespace App\Http\Controllers;

use App\Models\SettingApp;

class WebsiteController extends Controller
{
    public function __invoke()
    {
        $data['daftar_paket'] = \App\Models\Paket::select('id', 'nama_paket', 'thumbnail')->get();
        $data['paket_selfphoto'] = \App\Models\PaketSelf::select('id', 'nama_paket', 'thumbnail')->get();
        $data['tema_undangan'] = \App\Models\UndanganTema::select('nama_tema', 'thumbnail')->get();
        $data['kalender'] = (new \App\Models\Studio)->kalender();
        $data['logo_app'] = SettingApp::find(5);
        $data['set_portofolio'] = SettingApp::find(6);
        $data['header_website'] = SettingApp::find(7);
        $data['bagian_satu'] = SettingApp::find(8);
        $data['bagian_dua'] = SettingApp::find(9);
        $data['bagian_tiga'] = SettingApp::find(10);
        $data['pertanyaan'] = SettingApp::find(11);
        $data['footer_website'] = SettingApp::find(12);
        $data['logo_slider'] = SettingApp::find(13);
        $data['testimoni_konsumen'] = \App\Models\Testimoni::select('nama', 'rating', 'testimoni')->whereIn('rating', ['4','5'])->orderBy('id', 'DESC')->limit(3)->get();

        return view('website.index', $data);
    }
}
