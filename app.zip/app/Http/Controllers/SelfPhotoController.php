<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\AddOnSelf;
use App\Models\PaketSelf;
use App\Models\SelfPhoto;
use App\Models\Testimoni;
use App\Models\Transaksi;
use App\Models\SettingApp;
use App\Traits\TripayTrait;
use App\Traits\XenditTrait;
use App\Models\JamSelfPhoto;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Traits\NotifikasiTrait;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class SelfPhotoController extends Controller
{
    public function selfPhoto(Request $request)
    {
        if (count($request->all())) {
            return redirect('paket_self/'.$request->id);
        } else {
            hapus_session_self(); // Hapus Session Booking Self Photo
            $data['title'] = 'Booking Self Photo';
            $data['daftar_paket'] = PaketSelf::select('id', 'nama_paket', 'thumbnail')->where('is_active', '=', 1)->get();
            return view('fitur.selfphoto.index', $data);
        }
    }

    public function paketSelf(Request $request, $id)
    {
        $data['title'] = 'Booking Self Photo';
        $data['paket'] = PaketSelf::where('id', '=', $id)->first();
        $data['harga_paket'] = $data['paket']['harga'];
        $data['min_org'] = $data['paket']['min_org'];
        $data['max_org'] = $data['paket']['max_org'];
        $data['add_ons'] = AddOnSelf::get();
        hapus_session_self(); // Hapus Session Booking Self Photo

        if (count($request->all())) {
            $validator = \Illuminate\Support\Facades\Validator::make($request->all(), [
                'total' => ['required'],
                'jml_orang' => [
                    'required', 'numeric',
                    function($attribute, $value, $fail) use ($id) {
                        $paket_self = PaketSelf::where('id', '=', $id)->first();
                        if (!empty($paket_self->min_org) || !empty($paket_self->max_org)) {
                            $min_orang = $paket_self->min_org;
                            $max_orang = $paket_self->max_org;
                            if ($value + 1 <= $min_orang) {
                                return $fail('Jumlah orang minimal ' . $min_orang);
                            }
                            if ($value - 1 >= $max_orang) {
                                return $fail('Jumlah orang maksimal ' . $max_orang);
                            }
                        }
                    },
                ],
            ]);
            if ($validator->fails()) {
                return back()->withErrors($validator)->withInput();
            }
            $input = [
                'add_ons' => $request->add_ons,
                'id_paket' => $id,
                'jml_orang' => $request->jml_orang,
            ];
            session($input);
            return to_route('tanggal_self');
        } else {
            $is_active = PaketSelf::select('is_active')->findOrFail($id)->is_active;
            if ($is_active) {
                return view('fitur.selfphoto.paket_self', $data);
            } else {
                return back();
            }
        }
    }

    public function tanggalSelf(Request $request)
    {
        if (count($request->all())) {
            session(['tgl_booking' => $request->tgl_booking]);
            return to_route('jam_self');
        } else {
            if (!session()->get('id_paket')) {
                return to_route('self_photo');
            }
            $data['title'] = 'Booking Self Photo';
            $data['tgl_libur'] = DB::table('libur_studio')->where('tanggal', '>=', Carbon::now()->format('Y-m-d'))->pluck('tanggal');
            $data['max_date'] = SettingApp::find(1)->value_9;

            $harga_paket = PaketSelf::select('harga')->where('id', '=', session()->get('id_paket'))->first()->harga;
            $total_pembayaran = session()->get('add_ons') ? AddOnSelf::whereIn('id', session()->get('add_ons'))->sum('harga') : 0;
            $data['total_pembayaran'] = format_rupiah($total_pembayaran + $harga_paket);
            return view('fitur.selfphoto.tanggal_self', $data);
        }
    }

    public function jamSelf(Request $request)
    {
        $get_paket = PaketSelf::where('id', '=', session()->get('id_paket'))->first();
        if (count($request->all())) {
            $request->validate([
                'jam_booking' => ['required']
            ], [
                'jam_booking.required' => 'Pilih salah satu jam booking terlebih dahulu.',
            ]);
            session(['id_sesi' => $request->jam_booking]);
            return to_route('pembayaran_self');
        } else {
            if (!session()->get('tgl_booking')) {
                return to_route('self_photo');
            }
            $data['title'] = 'Booking Self Photo';
            $data['jam_selfphoto'] = JamSelfPhoto::ambilJam(session()->get('tgl_booking'));
            $data['tutup_studio'] = Carbon::createFromFormat('H:i', SettingApp::find(2)->value_4);
            $data['durasi'] = $get_paket->durasi;
            $total_pembayaran = session()->get('add_ons') ? AddOnSelf::whereIn('id', session()->get('add_ons'))->sum('harga') : 0;
            $data['total_pembayaran'] = format_rupiah($total_pembayaran + $get_paket->harga);
            return view('fitur.selfphoto.jam_self', $data);
        }
    }

    public function pembayaranSelf(Request $request)
    {
        $data['title'] = 'Pilih Metode Pembayaran';
        $data['status_tripay'] = SettingApp::find(2)->value_2;
        $data['status_xendit'] = SettingApp::find(2)->value_3;
        $data['bank_1'] = SettingApp::find(3);
        $data['bank_2'] = SettingApp::find(4);
        $data['daftar_pembayaran'] = TripayTrait::getChannelPembayaran();
        if (count($request->all())) {
            $request->validate([
                'pembayaran' => ['required'],
            ], [
                'pembayaran.required' => 'Pilih salah satu metode pembayaran terlebih dahulu.',
            ]);
            session(['code_pay' => $request->pembayaran]);
            return to_route('konfirmasi_selfphoto');
        } else {
            if (!session()->get('id_sesi')) {
                return to_route('self_photo');
            }
            $harga_paket = PaketSelf::select('harga')->where('id', '=', session()->get('id_paket'))->first()->harga;
            $total_pembayaran = session()->get('add_ons') ? AddOnSelf::whereIn('id', session()->get('add_ons'))->sum('harga') : 0;
            $data['total_pembayaran'] = format_rupiah($total_pembayaran + $harga_paket);
            return view('fitur.selfphoto.metode_pembayaran', $data);
        }
    }

    public function konfirmasiSelfPhoto()
    {
        if (!session()->get('code_pay')) {
            return to_route('self_photo');
        }
        $get_paket = PaketSelf::where('id', '=', session()->get('id_paket'))->first();
        $get_addon = AddOnSelf::whereIn('id', session()->get('add_ons') ?? [])->get();
        $add_ons = $get_addon->pluck('nama_addon')->implode(', ');
        $total_pembayaran = ($get_addon->sum('harga') ?? 0) + $get_paket->harga;
        $get_jam = JamSelfPhoto::where('id', '=', session()->get('id_sesi'))->first();
        if (session()->get('code_pay') == 'bayar_manual') {
            $get_biaya_admin = 0;
        } else if (session()->get('code_pay') == 'bayar_otomatis') {
            $get_biaya_admin = 0;
        } else {
            $get_biaya_admin = TripayTrait::getBiayaTransaksi(session()->get('code_pay'), $total_pembayaran);
        }

        $data['title'] = 'Konfirmasi Booking Self Photo';
        $data['tgl_booking'] = Carbon::parse(session()->get('tgl_booking'))->translatedFormat('d F Y');
        $data['jam_booking'] = jam_selfphoto($get_jam->jam);
        $data['nama'] = auth()->user()->nama;
        $data['no_tlp'] = auth()->user()->no_tlp;
        $data['paket'] = $get_paket->nama_paket . ($add_ons ? " - " . $add_ons : "");
        $data['total'] = format_rupiah($total_pembayaran + $get_biaya_admin);
        $data['jml_orang'] = session()->get('jml_orang');
        return view('fitur.selfphoto.konfirmasi', $data);
    }

    public function createBookingSelf()
    {
        if (!session()->get('id_paket')) {
            return to_route('self_photo');
        }
        $get_paket = PaketSelf::where('id', '=', session()->get('id_paket'))->first();
        $get_addon = AddOnSelf::whereIn('id', session()->get('add_ons') ?? [])->get();
        $add_ons = $get_addon->pluck('nama_addon')->implode(', ');
        $total_pembayaran = ($get_addon->sum('harga') ?? 0) + $get_paket->harga;
        $get_jam = JamSelfPhoto::where('id', '=', session()->get('id_sesi'))->first();
        $get_cs = SettingApp::find(1)->value_1;
        $get_user = User::select('nama', 'no_tlp')->findOrFail(auth()->user()->id);

        $kode_selfphoto = kode_selfphoto();
        $tgl_booking = Carbon::parse(session()->get('tgl_booking'))->translatedFormat('d F Y');
        $jam_booking = jam_selfphoto($get_jam->jam);
        $paket = $get_paket->nama_paket . ($add_ons ? " - " . $add_ons : "");
        $jml_orang = session()->get('jml_orang');
        $total_rp = format_rupiah($total_pembayaran);

        $input_booking = [
            'kode' => $kode_selfphoto,
            'user_id' => auth()->user()->id,
            'paket' => $paket,
            'status_booking' => 'Dipesan',
            'status_bayar' => 'Belum Dibayar',
            'jml_dp' => 0,
            'total' => $total_pembayaran,
            'jml_orang' => $jml_orang,
            'tgl_booking' => session()->get('tgl_booking'),
            'jam_booking' => $jam_booking,
            'cs' => $get_cs,
            'id_sesi' => session()->get('id_sesi'),
            'id_paket' => session()->get('id_paket'),
        ];

        /*
        | ---------------------------------------------------------------
        | Proses membuat transaksi pada payment gateway
        | ---------------------------------------------------------------
        */
        if (session()->get('code_pay') == 'bayar_manual') {
            $redirect = to_route('bayar_selfphoto', $kode_selfphoto)->with('success', 'Booking self photo anda berhasil dibuat.');
        } else if (session()->get('code_pay') == 'bayar_otomatis') {
            $xendit_transaksi = XenditTrait::createInvoiceSelfPhoto($kode_selfphoto, $paket, $total_pembayaran);
            $input_transaksi = [
                'kode_selfphoto' => $kode_selfphoto,
                'no_ref' => $xendit_transaksi['id'],
                'link' => $xendit_transaksi['invoice_url'],
                'status' => 'UNPAID',
            ];
            Transaksi::create($input_transaksi);
            $redirect = redirect($xendit_transaksi['invoice_url']);
        } else {
            $method = session()->get('code_pay');
            $tripay_transaksi = TripayTrait::createTransaksiSelfPhoto($kode_selfphoto, $method, $total_pembayaran, $paket);
            $input_transaksi = [
                'kode_selfphoto' => $kode_selfphoto,
                'no_ref' => $tripay_transaksi->reference,
                'link' => $tripay_transaksi->checkout_url,
                'status' => 'UNPAID',
            ];
            Transaksi::create($input_transaksi);
            $redirect = redirect($tripay_transaksi->checkout_url);
        }
        $text = "Informasi booking self photo\n\nKode Booking : $kode_selfphoto\nNama Konsumen : $get_user->nama\nNomor WhatsApp : $get_user->no_tlp\nPaket : $paket\nTotal Pembayaran : $total_rp\nStatus Booking : Dipesan\nStatus Pembayaran : Belum Dibayar\nTanggal Booking : $tgl_booking\nJam Booking : $jam_booking\nJumlah Orang : $jml_orang";
        NotifikasiTrait::sendNotify($text, $get_user->no_tlp);

        SelfPhoto::create($input_booking);
        hapus_session_self(); // Hapus Session Booking Self Photo
        return $redirect;
    }

    public function riwayatSelfPhoto(Request $request)
    {
        if ($request->ajax()) {
            $query = SelfPhoto::select(['kode', 'status_booking', 'status_bayar', 'jml_dp', 'tgl_booking', 'jam_booking'])->where('user_id', '=', auth()->user()->id);
            $data = empty($query) ? $query : $query->latest()->get();
            return DataTables::of($data)->addIndexColumn()
            ->editColumn('status_bayar', function ($row) {
                $result = $row->status_bayar == 'DP' ? format_rupiah($row->jml_dp) : '';
                return $row->status_bayar.' <b style="color: red;">'.$result.'</b>';
            })
            ->editColumn('tgl_booking', function ($row) {
                return Carbon::parse($row->tgl_booking)->translatedFormat('d F Y');
            })
            ->addColumn('opsi', function ($row) {
                return button_self($row->status_booking, $row->status_bayar, $row->kode);
            })
            ->rawColumns(['status_bayar', 'opsi'])->toJson();
        }

        $data['title'] = 'Riwayat Booking Self Photo';
        return view('fitur.selfphoto.riwayat_selfphoto', $data);
    }

    public function detailSelfPhoto($kode_selfphoto)
    {
        $get_booking = SelfPhoto::where('kode', '=', $kode_selfphoto)->with('user')->firstOrFail();
        $set_aplikasi = SettingApp::find(5);
        $set_sistem = SettingApp::find(1);
        $nomor_admin = nomor_tlp(SettingApp::find(14)->value_1);
        $expired = strtotime($get_booking->created_at) + ($set_sistem->value_3 * 60 * 60);
        if ($get_booking->status_bayar == 'Belum Dibayar' && date('Y-m-d H:i:s', $expired) < gmdate('Y-m-d H:i:s', (time() + (60 * 60 * $set_aplikasi->value_5)))) {
            SelfPhoto::where('kode', '=', $kode_selfphoto)->delete();
            return to_route('riwayat_selfphoto')->with('danger', 'Booking self photo anda sudah melewati batas pembayaran!');
        } else {
            $data['title'] = 'Detail Booking Self Photo';
            $data['booking'] = $get_booking;
            $data['transaksi'] = Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->first();
            $data['testimoni'] = Testimoni::where('kode', '=', $kode_selfphoto)->first();
            $data['bank_1'] = SettingApp::find(3);
            $get_created_at = strtotime($get_booking->created_at) + ($set_sistem->value_3 * 60 * 60);
            $data['waktu_expired'] = date('Y-m-d H:i:s', $get_created_at);

            $text = "Kode Booking : $kode_selfphoto\nNama Konsumen : ".$get_booking->user->nama."\nNomor WhatsApp : ".$get_booking->user->no_tlp."\nPaket : $get_booking->paket\nTotal Pembayaran : $get_booking->total\nStatus Booking : $get_booking->status_booking\nStatus Pembayaran : $get_booking->status_bayar\nTanggal Booking : $get_booking->tgl_booking\nJam Booking : $get_booking->jam_booking";
            $data['kirim_admin'] = "https://api.whatsapp.com/send?phone=$nomor_admin&text=".urlencode($text);
            return view('fitur.selfphoto.detail_selfphoto', $data);
        }
    }

    public function hapusSelfPhoto($kode_selfphoto)
    {
        $get_booking = SelfPhoto::where('kode', '=', $kode_selfphoto)->firstOrFail();
        $get_testimoni = Testimoni::where('kode', '=', $kode_selfphoto)->first();
        $get_transaksi = Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->first();
        switch ($get_booking->status_bayar) {
            case ("Belum Dibayar" && !isset($get_transaksi->link)):
                SelfPhoto::where('kode', '=', $kode_selfphoto)->delete();
                return response()->json(['success' => true, 'message' => 'Booking self photo berhasil dihapus!']);
                break;
            case ("Lunas" && $get_booking->status_booking == 'Selesai' && $get_testimoni):
                SelfPhoto::where('kode', '=', $kode_selfphoto)->delete();
                if ($get_transaksi) {
                    $get_transaksi->delete();
                    File::delete(public_path('/frontend/images/bukti_tf/' . $get_transaksi->link));
                }
                return response()->json(['success' => true, 'message' => 'Booking self photo berhasil dihapus!']);
                break;
            default:
                return response()->json(['success' => false, 'message' => 'Terjadi kesalahan pada sistem!']);
                break;
        }
    }

    public function cetakSelfPhoto($kode_selfphoto)
    {
        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('cetak.cetak_selfphoto', [
            'booking' => SelfPhoto::where('kode', '=', $kode_selfphoto)->with('user')->first(),
        ]);
        $pdf->setPaper(array(0, 0, 170, 360), 'portrait');
        return $pdf->download('booking_selfphoto_'.$kode_selfphoto.'.pdf');
    }

    public function bayarSelfPhoto(Request $request, $kode_selfphoto)
    {
        $data['title'] = 'Upload Bukti Transfer';
        $booking = SelfPhoto::where('kode', '=', $kode_selfphoto)->firstOrFail();
        $data['transaksi'] = Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->first();
        if (count($request->all())) {
            $request->validate([
                'status_bayar' => ['required'],
                'jml_dp' => ['required'],
                'bukti_tf' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            ], [
                'bukti_tf.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            ]);
            $status_bayar = $request->status_bayar;
            $jml_dp = change_rupiah($request->jml_dp);
            $min_dp = nominal_dp($booking->total);
            $nama_konsumen = $booking->user->nama;
            $nomor_konsumen = $booking->user->no_tlp;
            if ($jml_dp < $min_dp) {
                $nominal_dp = format_rupiah($min_dp);
                return to_route('bayar_selfphoto', $kode_selfphoto)->with('danger', "Minimal DP adalah $nominal_dp.");
            }
            // Upload foto bukti transfer
            if ($file = $request->file('bukti_tf')) {
                $file_name = $file->hashName();
                $file->move(public_path('frontend/images/bukti_tf'), $file_name);
            }
            $link_bukti_tf = url('frontend/images/bukti_tf/' . $file_name);
            $transaksi = [
                'kode_selfphoto' => $kode_selfphoto,
                'link' => $file_name,
                'status' => 'UNPAID',
            ];
            // Insert bukti transfer ke tabel transaksi
            Transaksi::create($transaksi);
            // Update status pembayaran di tabel booking
            if($status_bayar == 'DP') {
                SelfPhoto::where('kode', '=', $kode_selfphoto)->update([
                    'jml_dp' => $jml_dp,
                ]);
            }
            $link_konfirmasi = url('daftar_self_photo/' . $kode_selfphoto . '/edit');
            $text = "Konsumen Mengirim Bukti TF\n============================\nKode Booking : $kode_selfphoto\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $nomor_konsumen\nPembayaran : $status_bayar\nFoto Bukti TF : $link_bukti_tf\n\nKonfirmasi Pembayaran : $link_konfirmasi\n============================";
            NotifikasiTrait::sendToAdmin($text);
            return to_route('bayar_selfphoto', $kode_selfphoto)->with('success', 'Bukti pembayaran booking self photo berhasil di upload. Silahkan tunggu sebentar, Admin sedang melakukan cek transaksi anda terlebih dahulu.');
        } else {
            $data['booking'] = $booking;
            $data['bank_1'] = SettingApp::find(3);
            $data['bank_2'] = SettingApp::find(4);
            if (!isset($data['transaksi']['no_ref']) && $data['bank_1']['value_5'] == '1') {
                return view('fitur.selfphoto.bayar_selfphoto', $data);
            } else {
                return to_route('detail_selfphoto', $kode_selfphoto);
            }
        }
    }

    public function tripayReturnSelfPhoto($kode_selfphoto)
    {
        $transaksi = Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->first();
        $cek_pembayaran = TripayTrait::getTransaksi($transaksi->no_ref);
        if ($transaksi->status == 'PAID') {
            return to_route('detail_selfphoto', $kode_selfphoto);
        } else {
            $get_booking = SelfPhoto::where('kode', '=', $kode_selfphoto)->with('user')->first();
            switch ($cek_pembayaran) {
                case 'PAID':
                    $nama_konsumen = $get_booking->user->nama;
                    $nomor_konsumen = $get_booking->user->no_tlp;
                    $get_booking->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->update(['status' => 'PAID']);
                    $text = "Informasi booking self photo\n\nKode Booking : $kode_selfphoto\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $nomor_konsumen\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    return to_route('detail_selfphoto', $kode_selfphoto)->with('success', 'Pembayaran booking self photo anda telah lunas.');
                    break;

                case 'EXPIRED':
                    $get_booking->delete();
                    Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->update(['status' => 'EXPIRED']);
                    return to_route('riwayat_selfphoto')->with('danger', 'Pembayaran anda sudah melewati batas waktu.');
                    break;

                case 'FAILED':
                    $get_booking->delete();
                    Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->update(['status' => 'FAILED']);
                    return to_route('riwayat_selfphoto')->with('danger', 'Pembayaran anda gagal.');
                    break;

                default:
                    return to_route('detail_selfphoto', $kode_selfphoto);
                    break;
            }
        }
    }

    public function xenditReturnSelfPhoto($kode_selfphoto)
    {
        $transaksi = Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->firstOrFail();
        $get_invoice = XenditTrait::getInvoice($transaksi->no_ref);
        $status = $get_invoice['status'];
        if ($transaksi->status == 'PAID') {
            return to_route('riwayat_selfphoto', $kode_selfphoto);
        } else {
            $get_booking = SelfPhoto::where('kode', '=', $kode_selfphoto)->with('user')->first();
            $nama_konsumen = $get_booking->user->nama;
            $nomor_konsumen = $get_booking->user->no_tlp;
            switch ($status) {
                case "PENDING":
                    return redirect($get_invoice['invoice_url']);
                    break;
                case "PAID":
                    $get_booking->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->update(['status' => 'PAID']);
                    $text = "Informasi booking self photo\n\nKode Booking : $kode_selfphoto\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $nomor_konsumen\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    return to_route('detail_selfphoto', $kode_selfphoto)->with('success', 'Pembayaran booking self photo anda telah lunas.');
                    break;

                case "SETTLED":
                    $get_booking->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->update(['status' => 'SETTLED']);
                    $text = "Informasi booking self photo\n\nKode Booking : $kode_selfphoto\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $nomor_konsumen\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    return to_route('detail_selfphoto', $kode_selfphoto)->with('success', 'Pembayaran booking self photo anda telah lunas.');
                    break;

                case "EXPIRED":
                    $get_booking->delete();
                    Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->update(['status' => 'EXPIRED']);
                    return to_route('riwayat_selfphoto')->with('danger', 'Pembayaran anda sudah melewati batas waktu.');
                    break;

                default:
                    return to_route('riwayat_selfphoto', $kode_selfphoto);
                    break;
            }
        }
    }

    public function resTanggalSelfPhoto(Request $request, $kode_selfphoto)
    {
        if (count($request->all())) {
            session(['tgl_booking' => $request->tgl_booking]);
            return to_route('resjam_selfphoto', $kode_selfphoto);
        } else {
            session()->forget('tgl_booking');
            $data['title'] = 'Reschedule Booking Self Photo';
            $data['tgl_libur'] = DB::table('libur_studio')->where('tanggal', '>=', Carbon::now()->format('Y-m-d'))->pluck('tanggal');
            $data['max_date'] = SettingApp::find(1)->value_9;
            $data['booking'] = SelfPhoto::where('kode', '=', $kode_selfphoto)->first();
            return view('fitur.selfphoto.reschedule_tgl', $data);
        }
    }

    public function resJamSelfPhoto(Request $request, $kode_selfphoto)
    {
        $get_booking = SelfPhoto::where('kode', '=', $kode_selfphoto)->first();
        $get_paket = PaketSelf::find($get_booking->id_paket);
        if (count($request->all())) {
            $request->validate([
                'jam_booking' => ['required']
            ], [
                'jam_booking.required' => 'Pilih salah satu jam booking terlebih dahulu.',
            ]);
            $get_jam = JamSelfPhoto::find($request->jam_booking)->jam;
            $get_booking->update([
                'tgl_booking' => session()->get('tgl_booking'),
                'jam_booking' => resjam_selfphoto($get_jam, $kode_selfphoto),
                'id_sesi' => $request->jam_booking,
            ]);
            return to_route('detail_selfphoto', $kode_selfphoto)->with('success', 'Booking self photo Anda berhasil di reschedule');
        } else {
            session()->forget('jam_booking');
            if (!session()->get('tgl_booking')) {
                return to_route('riwayat_booking');
            }
            $data['jam_selfphoto'] = JamSelfPhoto::ambilJam(session()->get('tgl_booking'));
            $data['title'] = 'Reschedule Booking Self Photo';
            $data['tutup_studio'] = Carbon::createFromFormat('H:i', SettingApp::find(2)->value_4);
            $data['durasi'] = $get_paket->durasi;
            $data['booking'] = $get_booking;
            return view('fitur.selfphoto.reschedule_jam', $data);
        }
    }

    public function testimoniSelfPhoto(Request $request, $kode_selfphoto)
    {
        if (count($request->all())) {
            $request->validate([
                'rating' => ['required'],
                'testimoni' => ['required'],
            ]);
            Testimoni::create([
                'kode' => $kode_selfphoto,
                'nama' => auth()->user()->nama,
                'rating' => $request->rating,
                'testimoni' => $request->testimoni
            ]);
            return to_route('detail_selfphoto', $kode_selfphoto)->with('success', 'Testimoni & rating berhasil disimpan.');
        } else {
            $get_booking = SelfPhoto::where('kode', '=', $kode_selfphoto)->first();
            $get_testimoni = Testimoni::where('kode', '=', $kode_selfphoto)->first();
            if (!isset($get_testimoni) && $get_booking->status_booking == 'Selesai') {
                $data['title'] = 'Testimoni & Rating';
                $data['kode_selfphoto'] = $get_booking->kode;
                return view('fitur.selfphoto.testimoni', $data);
            }
        }
    }
}
