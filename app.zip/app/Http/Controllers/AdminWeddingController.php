<?php

namespace App\Http\Controllers;

use App\Models\Wedding;
use App\Models\Transaksi;
use App\Models\SettingApp;
use App\Models\SubWedding;
use App\Models\ExtraWedding;
use App\Models\PaketWedding;
use Illuminate\Http\Request;
use App\Exports\WeddingExport;
use Illuminate\Support\Carbon;
use App\Traits\NotifikasiTrait;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\File;

class AdminWeddingController extends Controller
{
    public function __construct()
    {
        $this->middleware(['only.admin']);
    }

    public function showWedding(Request $request)
    {
        if ($request->ajax()) {
            if ($request->session_sbo) {
                session()->put('session_sbo', $request->session_sbo);
            }
            if ($request->session_dp) {
                session()->put('session_dp', $request->session_dp);
            }
            if ($request->session_sba) {
                session()->put('session_sba', $request->session_sba);
            }
            if ($request->tanggal_1) {
                session()->put('tanggal_1', $request->tanggal_1);
                session()->put('tanggal_2', $request->tanggal_2);
            }
            $query = Wedding::select(['booking_wedding.*', 'transaksi.kode_wedding', 'transaksi.link', 'transaksi.no_ref'])->leftJoin('transaksi', 'booking_wedding.kode', '=', 'transaksi.kode_wedding')
            ->when(session()->get('session_sbo'), function ($query) {
                $query->where('status_booking', '=', session()->get('session_sbo'));
            })
            ->when(session()->get('session_dp'), function ($query) {
                $query->where('paket', '=', session()->get('session_dp'));
            })
            ->when(session()->get('session_sba'), function ($query) {
                $query->where('status_bayar', '=', session()->get('session_sba'));
            })
            ->when(session()->get('tanggal_1'), function ($query) {
                $query->where('tgl_wedding', '>=', session()->get('tanggal_1'))->where('tgl_wedding', '<=', session()->get('tanggal_2'));
            });
            $data = empty($query) ? $query : $query->latest()->get();
            return DataTables::of($data)->addIndexColumn()
            ->addColumn('kodes', function ($row) {
                $check = '<input type="checkbox" class="sub_chk" data-kodes="'. $row->kode .'">';
                return $check;
            })
            ->editColumn('tgl_wedding', function ($row) {
                return Carbon::parse($row->tgl_wedding)->translatedFormat('d F Y');
            })
            ->editColumn('status_bayar', function ($row) {
                $result = $row->status_bayar == 'DP' ? format_rupiah($row->jml_dp) : '';
                $bukti_tf = isset($row->link) && is_null($row->no_ref) ? '<b><a target="_blank" href="'.url('frontend/images/bukti_tf/' . $row->link).'">Bukti TF</a></b>' : '';
                return $row->status_bayar.' <b style="color: red;">'.$result.'</b><br>'.$bukti_tf;
            })
            ->editColumn('total', function ($row) {
                return format_rupiah($row->total);
            })
            ->addColumn('opsi', function ($row) {
                $btn = '<a href="daftar_wedding/'.$row->kode.'/edit" class="btn btn-success btn-block btn-sm">Edit</a><a href="javascript:void(0)" class="btn btn-danger btn-block btn-sm deleteBooking" data-toggle="tooltip" data-kode="'.$row->kode.'" data-original-title="Delete">Hapus</a>';
                return $btn;
            })
            ->with('sum_total', function() use ($query) {
                return format_rupiah($query->sum('total'));
            })
            ->rawColumns(['kodes', 'status_bayar', 'opsi'])->toJson();
        }

        $data['title'] = 'Daftar Booking Wedding';
        $data['sub_wedding'] = SubWedding::select(['id', 'sub_paket'])->get();
        $data['extra_wedding'] = ExtraWedding::select(['id', 'extra_wedding'])->get();
        $getCS = SettingApp::find(1);
        $data['nama_cs'] = json_decode($getCS->items);
        $data['cs_now'] = $getCS;
        $data['session_sbo'] = ['Dipesan', 'Selesai'];
        $data['session_sba'] = ['Lunas', 'DP', 'Belum Dibayar'];
        $data['session_dp'] = Wedding::select('paket')->distinct()->pluck('paket');
        return view('admin.wedding.daftar_wedding', $data);
    }

    public function createWedding(Request $request)
    {
        $request->validate([
            'nama' => ['required'],
            'no_tlp' => ['required', 'regex:/^0\d/', 'numeric'],
            'alamat' => ['required'],
            'tgl_wedding' => ['required'],
            'paket' => ['required'],
            'extra_wedding' => ['required'],
            'jml_dp' => ['required'],
            'status_booking' => ['required'],
            'status_bayar' => ['required'],
        ], [
            'no_tlp.regex' => 'nomor WhatApp tidak sesuai format 08123XXXXXXX.',
        ]);

        $get_sub_wedding = SubWedding::where('id', '=', $request->paket)->first();
        $get_extra = ExtraWedding::where('id', '=', $request->extra_wedding)->first();
        $get_transport = SettingApp::find(1);

        if (!empty($request->extra_wedding)) {
            $paket_extra = " + " . $get_extra->extra_wedding;
            $total_extra = $get_extra->harga;
        } else {
            $paket_extra = "";
            $total_extra = 0;
        }
        if (!empty($request->transport)) {
            $transport = " + Transport";
            $total_transport = (int)$get_transport->value_6;
        } else {
            $transport = "";
            $total_transport = 0;
        }

        Wedding::create([
            'kode' => kode_wedding(),
            'nama' => $request->nama,
            'no_tlp' => format_tlp($request->no_tlp),
            'alamat' => $request->alamat,
            'paket' => $get_sub_wedding->sub_paket . $paket_extra . $transport,
            'status_booking' => $request->status_booking,
            'status_bayar' => $request->status_bayar,
            'jml_dp' => $request->status_bayar != "DP" ? 0 : change_rupiah($request->jml_dp),
            'total' => $get_sub_wedding->harga + $total_extra + $total_transport,
            'tgl_wedding' => $request->tgl_wedding,
            'cs' => $request->nama_cs,
        ]);

        return response()->json(['success' => true, 'message' => "Booking wedding berhasil ditambahkan!"]);
    }

    public function editWedding(Request $request, $kode)
    {
        if (count($request->all())) {
            $post_status_booking = $request->status_booking;
            $post_status_pembayaran = $request->status_bayar;
            $post_jumlah_dp = change_rupiah($request->jml_dp);
            $get_booking = Wedding::where('kode', '=', $kode)->firstOrFail();

            // Script bagian ubah status booking studio foto
            if ($post_status_booking != $get_booking->status_booking) {
                $nama_konsumen = $get_booking->nama;
                $no_tlp = $get_booking->no_tlp;
                $status = $request->status_booking;
                $get_booking->update([
                    'status_booking' => $status
                ]);
                $text = "Booking wedding atas nama $nama_konsumen telah $status. Terima kasih telah menggunakan layanan kami.";
                NotifikasiTrait::sendToUser($text, $no_tlp);
            }

            // Script bagian ubah status pembayaran
            if ($post_status_pembayaran != $get_booking->status_bayar) {
                $nama_konsumen = $get_booking->nama;
                $no_tlp = $get_booking->no_tlp;
                $get_booking->update([
                    'status_booking' => $post_status_booking,
                    'status_bayar' => $post_status_pembayaran,
                    'jml_dp' => $post_jumlah_dp,
                ]);
                Transaksi::where('kode_wedding','=',$kode)->where('status','=','UNPAID')->update(['status' => 'PAID']);
                $link = url('cetak_booking_wedding/' . $kode);
                $text = "Booking wedding atas nama $nama_konsumen status pembayarannya sekarang adalah $post_status_pembayaran.\n\nBerikut link untuk cetak nota : $link";
                NotifikasiTrait::sendToUser($text, $no_tlp);
            }
            return to_route('daftar_wedding')->with('success', 'Data booking wedding berhasil diubah!');
        } else {
            $data['title'] = 'Edit Booking Wedding';
            $getCS = SettingApp::find(1);
            $data['booking'] = Wedding::where('kode', '=', $kode)->firstOrFail();
            $data['status_booking'] = ['Dipesan', 'Selesai'];
            $data['status_bayar'] = ['Belum Dibayar', 'DP', 'Lunas'];
            $data['nama_cs'] = json_decode($getCS->items);
            $data['transaksi'] = Transaksi::where('kode_wedding', '=', $kode)->first();

            return view('admin.wedding.edit_wedding', $data);
        }
    }

    public function rescheduleWedding(Request $request ,$kode)
    {
        $request->validate([
            'nama' => ['required'],
            'no_tlp' => ['required', 'regex:/^0\d/', 'numeric'],
            'tgl_wedding' => ['required'],
        ], [
            'no_tlp.regex' => 'nomor WhatApp tidak sesuai format 08123XXXXXXX.',
        ]);

        $get_booking = Wedding::where('kode', '=', $kode)->firstOrFail();
        $get_booking->update([
            "nama" => $request->nama,
            "no_tlp" => format_tlp($request->no_tlp),
            "tgl_wedding" => $request->tgl_wedding,
            "alamat" => $request->alamat,
            "cs" => $request->cs,
        ]);

        return to_route('daftar_wedding')->with('success', 'Data booking wedding berhasil di reschedule!');
    }

    public function deleteWedding($kode)
    {
        Wedding::where('kode', '=', $kode)->delete($kode);
        $get_transaksi = Transaksi::where('kode_wedding', '=', $kode)->first();
        if ($get_transaksi) {
            $get_transaksi->delete();
            File::delete(public_path('/frontend/images/bukti_tf/' . $get_transaksi->link));
        }
        return response()->json(['success' => true, 'message' => 'Data booking wedding berhasil dihapus!']);
    }

    public function deleteAllWedding(Request $request)
    {
        $kodes = $request->kodes;
        Wedding::whereIn('kode', explode(",", $kodes))->delete();
        $get_transaksi = Transaksi::whereIn('kode_wedding', explode(",", $kodes));
        foreach ($get_transaksi->get() as $row) {
            File::delete(public_path('/frontend/images/bukti_tf/' . $row->link));
        }
        $get_transaksi->delete();
        return response()->json(['success' => true, 'message' => 'Data booking wedding berhasil dihapus!']);
    }

    public function exportWeddingPdf()
    {
        return (new WeddingExport)->export_pdf();
    }

    public function exportWeddingExcel()
    {
        return (new WeddingExport)->export_excel();
    }

    public function paketWedding(Request $request)
    {
        if(count($request->all())) {
            $request->validate([
                'nama_paket' => ['required'],
                'deskripsi' => ['required'],
                'thumbnail' => ['required', 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
            ]);
            $input = [
                'nama_paket' => $request->nama_paket,
                'deskripsi' => $request->deskripsi,
                'is_active' => 1,
            ];
            if ($file = $request->file('thumbnail')) {
                $file_name = $file->getClientOriginalName();
                $file->move(public_path('/frontend/images/paket'), $file_name);
                $input['thumbnail'] = $file_name;
            }
            PaketWedding::create($input);
            return to_route('paket_wedding')->with('success', 'Paket wedding berhasil ditambahkan!');
        } else {
            $data['title'] = 'Pengaturan Paket Wedding';
            $data['data_paket'] = PaketWedding::all();
            return view('admin.wedding.paket_wedding', $data);
        }
    }
    
    public function editPaketWedding(Request $request, $id)
    {
        $request->validate([
            'nama_paket' => ['required'],
            'deskripsi' => ['required'],
            'thumbnail' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
        ]);
        $get_paket = PaketWedding::where('id', $id)->first();
        $input = [
            'nama_paket' => $request->nama_paket,
            'deskripsi' => $request->deskripsi,
            'is_active' => $request->is_active,
        ];
        if ($file = $request->file('thumbnail')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/images/paket'), $file_name);
            if ($get_paket->thumbnail != $file_name) {
                File::delete(public_path('/frontend/images/paket/' . $get_paket->thumbnail));
            }
            $input['thumbnail'] = $file_name;
        }
        $get_paket->update($input);

        return to_route('paket_wedding')->with('success', 'Paket wedding berhasil diubah!');
    }

    public function deletePaketWedding($id)
    {
        $get_paket = PaketWedding::find($id);
        File::delete(public_path('/frontend/images/paket/' . $get_paket->thumbnail));
        $get_paket->delete($id);
        return to_route('paket_wedding')->with('success', 'Paket wedding berhasil dihapus!');
    }

    public function subPaketWedding(Request $request)
    {
        if(count($request->all())) {
            $input = $request->validate([
                'sub_paket' => ['required'],
                'id_paket' => ['required'],
                'harga' => ['required'],
                'is_active' => ['required'],
            ]);
            $input['harga'] = change_rupiah($request->harga);
            SubWedding::create($input);
            return to_route('sub_wedding')->with('success', 'Sub paket wedding berhasil ditambahkan!');
        } else {
            $data['title'] = 'Pengaturan Sub Paket Wedding';
            $data['sub_paket'] = SubWedding::getSubPaketWedding();
            $data['daftar_paket'] = PaketWedding::select('id', 'nama_paket')->get();
            $data['extra_paket'] = ExtraWedding::select('id', 'extra_wedding', 'harga')->get();
            return view('admin.wedding.sub_wedding', $data);
        }
    }

    public function extraWedding(Request $request)
    {
        $input = $request->validate([
            'extra_wedding' => ['required'],
            'harga_extra' => ['required'],
        ]);
        $input['harga'] = change_rupiah($request->harga_extra);
        ExtraWedding::create($input);
        return to_route('sub_wedding')->with('success', 'Extra paket wedding berhasil ditambahkan!');
    }

    public function editExtraWedding(Request $request, $id)
    {
        $get_sub_paket = ExtraWedding::where('id', $id)->first();
        $input = $request->validate([
            'extra_wedding' => ['required'],
            'harga_extra' => ['required'],
        ]);
        $input['harga'] = change_rupiah($request->harga_extra);
        $get_sub_paket->update($input);

        return to_route('sub_wedding')->with('success', 'Extra paket wedding berhasil diubah!');
    }

    public function deleteExtraWedding($id)
    {
        ExtraWedding::find($id)->delete();
        return to_route('sub_wedding')->with('success', 'Extra paket wedding berhasil dihapus!');
    }

    public function editSubWedding(Request $request, $id)
    {
        $get_sub_paket = SubWedding::where('id', $id)->first();
        $input = $request->validate([
            'sub_paket' => ['required'],
            'id_paket' => ['required'],
            'harga' => ['required'],
            'is_active' => ['required'],
        ]);
        $input['harga'] = change_rupiah($request->harga);
        $get_sub_paket->update($input);

        return to_route('sub_wedding')->with('success', 'Sub paket wedding berhasil diubah!');
    }

    public function deleteSubWedding($id)
    {
        SubWedding::find($id)->delete($id);
        return to_route('sub_wedding')->with('success', 'Sub paket wedding berhasil dihapus!');
    }
}
