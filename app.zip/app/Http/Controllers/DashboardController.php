<?php

namespace App\Http\Controllers;

use App\Models\Studio;
use App\Models\Wedding;
use App\Models\SelfPhoto;
use App\Models\Testimoni;
use App\Models\SettingApp;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Traits\NotifikasiTrait;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware(['only.admin']);
    }

    public function index(Request $request)
    {
        if (count($request->all())) {
            return to_route('cari_booking', $request->kode);
        } else {
            $get_cs = SettingApp::find(1);
            $data = [
                'title' => 'Dashboard Admin',
                'konsumen' => \App\Models\User::count(),
                'booking_studio' => Studio::count(),
                'booking_selfphoto' => SelfPhoto::count(),
                'undangan_digital' => \App\Models\Undangan::count(),
                'dipesan_studio' => Studio::select('id')->where('status_booking', '=', 'Dipesan')->count(),
                'selesai_studio' => Studio::select('id')->where('status_booking', '=', 'Selesai')->count(),
                'lunas_studio' => Studio::select('id')->where('status_bayar', '=', 'Lunas')->count(),
                'dp_studio' => Studio::select('id')->where('status_bayar', '=', 'DP')->count(),
                'belum_dibayar_studio' => Studio::select('id')->where('status_bayar', '=', 'Belum Dibayar')->count(),
                'lunas_wedding' => Wedding::select('id')->where('status_bayar', '=', 'Lunas')->count(),
                'dp_wedding' => Wedding::select('id')->where('status_bayar', '=', 'DP')->count(),
                'belum_dibayar_wedding' => Wedding::select('id')->where('status_bayar', '=', 'Belum Dibayar')->count(),
                'dipesan_wedding' => Wedding::select('id')->where('status_booking', '=', 'Dipesan')->count(),
                'selesai_wedding' => Wedding::select('id')->where('status_booking', '=', 'Selesai')->count(),
                'lunas_self' => SelfPhoto::select('id')->where('status_bayar', '=', 'Lunas')->count(),
                'dp_self' => SelfPhoto::select('id')->where('status_bayar', '=', 'DP')->count(),
                'belum_dibayar_self' => SelfPhoto::select('id')->where('status_bayar', '=', 'Belum Dibayar')->count(),
                'dipesan_self' => SelfPhoto::select('id')->where('status_booking', '=', 'Dipesan')->count(),
                'selesai_self' => SelfPhoto::select('id')->where('status_booking', '=', 'Selesai')->count(),
                'rating_5' => Testimoni::select('rating')->where('rating', '=', '5')->groupBy('rating')->count(),
                'rating_4' => Testimoni::select('rating')->where('rating', '=', '4')->groupBy('rating')->count(),
                'rating_3' => Testimoni::select('rating')->where('rating', '=', '3')->groupBy('rating')->count(),
                'rating_2' => Testimoni::select('rating')->where('rating', '=', '2')->groupBy('rating')->count(),
                'rating_1' => Testimoni::select('rating')->where('rating', '=', '1')->groupBy('rating')->count(),
                'nama_cs' => json_decode($get_cs->items),
                'cs_now' => $get_cs->value_1,
            ];
            return view('admin.dashboard.index', $data);
        }
    }

    public function gantiCs(Request $request)
    {
        SettingApp::find(1)->update([
            'value_1' => $request->nama_cs,
        ]);
        return to_route('admin')->with('flash', 'Customer service berhasil diubah!');
    }

    public function studioPerbulan($month)
    {
        $get_data = Studio::selectRaw("COUNT(id) as total")->whereRaw("MONTH(tgl_booking) = '$month'")->whereYear('created_at', Carbon::now()->year)->get();
        foreach ($get_data as $row) {
            return $row->total;
        }
    }

    public function weddingPerbulan($month)
    {
        $get_data = Wedding::selectRaw("COUNT(id) as total")->whereRaw("MONTH(tgl_wedding) = '$month'")->whereYear('created_at', Carbon::now()->year)->get();
        foreach ($get_data as $row) {
            return $row->total;
        }
    }

    public function selfPhotoPerbulan($month)
    {
        $get_data = SelfPhoto::selectRaw("COUNT(id) as total")->whereRaw("MONTH(tgl_booking) = '$month'")->whereYear('created_at', Carbon::now()->year)->get();
        foreach ($get_data as $row) {
            return $row->total;
        }
    }

    public function studioPerMinggu($day)
    {
        $get_data = Studio::selectRaw("COUNT(id) as total")->where("tgl_booking", $day)->get();
        foreach ($get_data as $row) {
            return $row->total;
        }
    }

    public function grafikLaporan()
    {
        $data = [
            'title' => 'Dashboard Admin',
            // Booking studio
            'studio_januari' => DashboardController::studioPerbulan(1),
            'studio_februari' => DashboardController::studioPerbulan(2),
            'studio_maret' => DashboardController::studioPerbulan(3),
            'studio_april' => DashboardController::studioPerbulan(4),
            'studio_mei' => DashboardController::studioPerbulan(5),
            'studio_juni' => DashboardController::studioPerbulan(6),
            'studio_juli' => DashboardController::studioPerbulan(7),
            'studio_agustus' => DashboardController::studioPerbulan(8),
            'studio_september' => DashboardController::studioPerbulan(9),
            'studio_oktober' => DashboardController::studioPerbulan(10),
            'studio_november' => DashboardController::studioPerbulan(11),
            'studio_desember' => DashboardController::studioPerbulan(12),
            // Booking Studio Per Hari
            'studio_senin' => DashboardController::studioPerMinggu(date('Y-m-d', strtotime('monday this week'))),
            'studio_selasa' => DashboardController::studioPerMinggu(date('Y-m-d', strtotime('tuesday this week'))),
            'studio_rabu' => DashboardController::studioPerMinggu(date('Y-m-d', strtotime('wednesday this week'))),
            'studio_kamis' => DashboardController::studioPerMinggu(date('Y-m-d', strtotime('thursday this week'))),
            'studio_jumat' => DashboardController::studioPerMinggu(date('Y-m-d', strtotime('friday this week'))),
            'studio_sabtu' => DashboardController::studioPerMinggu(date('Y-m-d', strtotime('saturday this week'))),
            'studio_minggu' => DashboardController::studioPerMinggu(date('Y-m-d', strtotime('sunday this week'))),
            // Booking wedding
            'wedding_januari' => DashboardController::weddingPerbulan(1),
            'wedding_februari' => DashboardController::weddingPerbulan(2),
            'wedding_maret' => DashboardController::weddingPerbulan(3),
            'wedding_april' => DashboardController::weddingPerbulan(4),
            'wedding_mei' => DashboardController::weddingPerbulan(5),
            'wedding_juni' => DashboardController::weddingPerbulan(6),
            'wedding_juli' => DashboardController::weddingPerbulan(7),
            'wedding_agustus' => DashboardController::weddingPerbulan(8),
            'wedding_september' => DashboardController::weddingPerbulan(9),
            'wedding_oktober' => DashboardController::weddingPerbulan(10),
            'wedding_november' => DashboardController::weddingPerbulan(11),
            'wedding_desember' => DashboardController::weddingPerbulan(12),
            // Booking self photo
            'self_januari' => DashboardController::selfPhotoPerbulan(1),
            'self_februari' => DashboardController::selfPhotoPerbulan(2),
            'self_maret' => DashboardController::selfPhotoPerbulan(3),
            'self_april' => DashboardController::selfPhotoPerbulan(4),
            'self_mei' => DashboardController::selfPhotoPerbulan(5),
            'self_juni' => DashboardController::selfPhotoPerbulan(6),
            'self_juli' => DashboardController::selfPhotoPerbulan(7),
            'self_agustus' => DashboardController::selfPhotoPerbulan(8),
            'self_september' => DashboardController::selfPhotoPerbulan(9),
            'self_oktober' => DashboardController::selfPhotoPerbulan(10),
            'self_november' => DashboardController::selfPhotoPerbulan(11),
            'self_desember' => DashboardController::selfPhotoPerbulan(12),
        ];
        return view('admin.dashboard.grafik', $data);
    }

    public function cariKode(Request $request)
    {
        $res = Studio::select("kode as value")->where('kode', 'LIKE', '%'.$request->search.'%')->limit(10)->get();
        return response()->json($res);
    }

    public function cariBooking(Request $request, $kode)
    {
        if (count($request->all())) {
            $post_status_booking = $request->status_booking;
            $post_status_pembayaran = $request->status_bayar;
            $post_jumlah_dp = change_rupiah($request->jml_dp);
            $get_booking = Studio::where('kode', '=', $kode)->firstOrFail();

            // Script bagian ubah status booking studio foto
            if ($post_status_booking != $get_booking->status_booking) {
                $nama_konsumen = $get_booking->nama;
                $no_tlp = $get_booking->no_tlp;
                $status = $request->status_booking;
                $get_booking->update([
                    'status_booking' => $status
                ]);
                $text = "Booking studio foto atas nama $nama_konsumen telah $status. Terima kasih telah menggunakan layanan kami.";
                NotifikasiTrait::sendToUser($text, $no_tlp);
            }

            // Script bagian ubah status pembayaran
            if ($post_status_pembayaran != $get_booking->status_bayar) {
                $nama_konsumen = $get_booking->nama;
                $no_tlp = $get_booking->no_tlp;
                $get_booking->update([
                    'status_booking' => $post_status_booking,
                    'status_bayar' => $post_status_pembayaran,
                    'jml_dp' => $post_jumlah_dp,
                ]);
                \App\Models\Transaksi::where('kode_booking','=',$kode)->where('status','=','UNPAID')->update(['status' => 'PAID']);
                $link = url('cetak_booking/' . $kode);
                $text = "Booking studio foto atas nama $nama_konsumen status pembayarannya sekarang adalah $post_status_pembayaran.\n\nBerikut link untuk cetak nota : $link";
                NotifikasiTrait::sendToUser($text, $no_tlp);
            }
            return to_route('cari_booking', $kode)->with('success', 'Data booking studio foto berhasil diubah!');
        } else {
            $data['title'] = 'Dashboard Admin';
            $data['booking'] = Studio::where('kode', '=', $kode)->first();
            $data['transaksi'] = \App\Models\Transaksi::where('kode_booking', '=', $kode)->first();
            $data['status_booking'] = ['Dipesan', 'Selesai'];
            $data['status_bayar'] = ['Belum Dibayar', 'DP', 'Lunas'];

            if (!is_null($data['booking'])) {
                return view('admin.dashboard.cari_booking', $data);
            } else {
                return to_route('admin')->with('danger', 'Kode booking tidak ditemukan!');
            }
        }
    }

    public function printBooking($kode)
    {
        return (new StudioController)->cetakBooking($kode);
    }

    public function scanKode(Request $request)
    {
        if (count($request->all())) {
            $cek_booking = Studio::select('kode', 'status_bayar')->where('kode', '=', $request->kode)->first();
            if (!is_null($cek_booking)) {
                if ($cek_booking->status_bayar == 'Belum Dibayar') {
                    return response()->json(['status' => 403, 'message' => 'Anda belum menyelesaikan pembayaran']);
                }
                return response()->json(['status' => 200, "redirect"=> url('data_booking/'.$cek_booking->kode)]);
            } else {
                return response()->json(['status' => 404]);
            }
        } else {
            $data['title'] = 'Scan Kode Booking Studio Foto';
            return view('admin.dashboard.scan_kode', $data);
        }
    }

    public function dataBooking($kode)
    {
        $get_booking = Studio::where('kode', '=', $kode)->first();
        if ($get_booking->status_bayar == 'Lunas' && $get_booking->status_booking == 'Dipesan') {
            $get_booking->update(['status_booking' => 'Selesai']);
        } else if ($get_booking->status_bayar == 'DP' && $get_booking->status_booking == 'Dipesan') {
            $get_booking->update(['status_booking' => 'Selesai', 'status_bayar' => 'Lunas']);
        }

        $data = [
            'title' => 'Hasil Booking Studio Foto',
            'booking' => $get_booking,
        ];
        return view('admin.dashboard.data_booking', $data);
    }
}
