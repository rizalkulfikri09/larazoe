<?php

namespace App\Http\Controllers;

use App\Models\Undangan;
use App\Models\Transaksi;
use App\Models\SettingApp;
use App\Traits\TripayTrait;
use App\Traits\XenditTrait;
use App\Models\UndanganTema;
use Illuminate\Http\Request;
use App\Models\UndanganPaket;
use App\Models\UndanganCerita;
use App\Models\UndanganDetail;
use App\Models\UndanganGaleri;
use App\Models\UndanganTempat;
use App\Models\UndanganUcapan;
use Illuminate\Support\Carbon;
use App\Traits\NotifikasiTrait;
use Illuminate\Validation\Rule;
use Yajra\DataTables\DataTables;
use App\Models\UndanganPengantin;
use Illuminate\Support\Facades\File;
use Illuminate\Validation\ValidationException;

class UndanganController extends Controller
{
    public function getMusik() {
        $get_musik = scandir(public_path('frontend/undangan/musik'));
        $daftar_musik = [];
        foreach ($get_musik as $file) {
            if ($file == '.' || $file == '..') {
                continue;
            }
            $daftar_musik[$file] = str_replace('.mp3', '', $file);
        }
        return $daftar_musik;
    }

    public function pilihTema(Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'id_tema' => ['required'],
            ]);
            session(['id_tema' => $request->id_tema]);
            return redirect('data_pengantin');
        } else {
            hapus_session_undangan();
            $data['title'] = 'Pilih Tema Undangan';
            $data['daftar_tema'] = UndanganTema::where('is_active', '=', 1)->get();
            return view('fitur.undangan.pilih_tema', $data);
        }
    }

    public function dataPengantin(Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'link' => ['required', 'unique:undangan,link', 'max:128'],
                'foto_pria' => ['required', 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'base64_foto_pria' => ['required'],
                'full_nama_pria' => ['required', 'max:128'],
                'nama_pria' => ['required', 'max:128'],
                'anak_of_pria' => ['required', 'max:128'],
                'ortu_pria' => ['required', 'max:255'],
                'foto_wanita' => ['required', 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'base64_foto_wanita' => ['required'],
                'full_nama_wanita' => ['required', 'max:128'],
                'nama_wanita' => ['required', 'max:128'],
                'anak_of_wanita' => ['required', 'max:128'],
                'ortu_wanita' => ['required', 'max:255'],
                'id_paket' => ['required'],
                'warna_undangan' => ['required'],
                'ig_pria' => [Rule::requiredIf($request->status_ig_pria == 1), 'max:128'],
                'twitter_pria' => [Rule::requiredIf($request->status_twitter_pria == 1), 'max:128'],
                'fb_pria' => [Rule::requiredIf($request->status_fb_pria == 1), 'max:128'],
                'ig_wanita' => [Rule::requiredIf($request->status_ig_wanita == 1), 'max:128'],
                'twitter_wanita' => [Rule::requiredIf($request->status_twitter_wanita == 1), 'max:128'],
                'fb_wanita' => [Rule::requiredIf($request->status_fb_wanita == 1), 'max:128'],
            ], [
                'foto_pria.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_wanita.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'link.unique' => 'Link undangan sudah ada yang menggunakan, coba ganti yang lain.'
            ]);

            $pria_image_parts = explode(";base64,", $request->base64_foto_pria);
            $pria_ext = explode("image/", $pria_image_parts[0]);
            $pria_file_name = $request->file('foto_pria')->hashName().'.'.$pria_ext[1];
            $pria_file = public_path('frontend/undangan/foto_pengantin/').$pria_file_name;
            File::put($pria_file, base64_decode($pria_image_parts[1]));

            $wanita_image_parts = explode(";base64,", $request->base64_foto_wanita);
            $wanita_ext = explode("image/", $wanita_image_parts[0]);
            $wanita_file_name = $request->file('foto_wanita')->hashName().'.'.$wanita_ext[1];
            $wanita_file = public_path('frontend/undangan/foto_pengantin/').$wanita_file_name;
            File::put($wanita_file, base64_decode($wanita_image_parts[1]));

            $kode_undangan = kode_undangan();
            $undangan = [
                'kode' => $kode_undangan,
                'user_id' => auth()->user()->id,
                'nama_pria' => ucwords($request->nama_pria),
                'full_nama_pria' => ucwords($request->full_nama_pria),
                'nama_wanita' => ucwords($request->nama_wanita),
                'full_nama_wanita' => ucwords($request->full_nama_wanita),
                'link' => strtolower($request->link),
                'status_undangan' => 'Nonaktif',
                'status_bayar' => 'Belum Dibayar',
                'warna_undangan' => $request->warna_undangan,
                'id_tema' => session()->get('id_tema'),
                'id_paket' => $request->id_paket,
            ];
            $undangan_pengantin = [
                'kode_undangan' => $kode_undangan,
                'foto_pria' => $pria_file_name,
                'foto_wanita' => $wanita_file_name,
                'ortu_pria' => ucwords($request->ortu_pria),
                'anak_of_pria' => ucfirst($request->anak_of_pria),
                'ortu_wanita' => ucwords($request->ortu_wanita),
                'anak_of_wanita' => ucfirst($request->anak_of_wanita),
                'ig_pria' => $request->status_ig_pria ? $request->ig_pria : NULL,
                'twitter_pria' => $request->status_twitter_pria ? $request->twitter_pria : NULL,
                'fb_pria' => $request->status_fb_pria ? $request->fb_pria : NULL,
                'ig_wanita' => $request->status_ig_wanita ? $request->ig_wanita : NULL,
                'twitter_wanita' => $request->status_twitter_wanita ? $request->twitter_wanita : NULL,
                'fb_wanita' => $request->status_fb_wanita ? $request->fb_wanita : NULL,
            ];
            Undangan::create($undangan);
            UndanganPengantin::create($undangan_pengantin);
            return to_route('data_undangan', $kode_undangan);
        } else {
            if (!session()->get('id_tema')) {
                return redirect('pilih_tema');
            }
            $data['title'] = 'Isi Data Pengantin';
            $data['daftar_paket'] = UndanganPaket::where('is_active', '=', 1)->get();
            return view('fitur.undangan.data_pengantin', $data);
        }
    }

    public function dataUndangan($kode_undangan, Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'nama_acara_1' => ['required', 'max:128'],
                'tanggal_acara_1' => ['required', 'max:128'],
                'tempat_acara_1' => ['required', 'max:128'],
                'alamat_acara_1' => ['required', 'max:255'],
                'link_maps_1' => ['required', 'max:255'],
                'nama_acara_2' => [Rule::requiredIf($request->status_acara_2 == 1), 'max:128'],
                'tanggal_acara_2' => [Rule::requiredIf($request->status_acara_2 == 1), 'max:128'],
                'tempat_acara_2' => [Rule::requiredIf($request->status_acara_2 == 1), 'max:128'],
                'alamat_acara_2' => [Rule::requiredIf($request->status_acara_2 == 1), 'max:255'],
                'link_maps_2' => [Rule::requiredIf($request->status_acara_2 == 1), 'max:255'],
                'tanggal_nikah' => ['required'],
                'kalimat_pembuka' => ['required'],
                'foto_slider_1' => [Rule::requiredIf($request->status_slider == 1), 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_slider_2' => [Rule::requiredIf($request->status_slider == 1), 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_slider_3' => [Rule::requiredIf($request->status_slider == 1), 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_slider_4' => [Rule::requiredIf($request->status_slider == 1), 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'link_youtube' => [Rule::requiredIf($request->status_link_youtube == 1), 'max:255'],
                'nama_bank_1' => [Rule::requiredIf($request->status_bank_1 == 1), 'max:128'],
                'nomor_rekening_1' => [Rule::requiredIf($request->status_bank_1 == 1), 'max:128'],
                'pemilik_rekening_1' => [Rule::requiredIf($request->status_bank_1 == 1), 'max:128'],
                'nama_bank_2' => [Rule::requiredIf($request->status_bank_2 == 1), 'max:128'],
                'nomor_rekening_2' => [Rule::requiredIf($request->status_bank_2 == 1), 'max:128'],
                'pemilik_rekening_2' => [Rule::requiredIf($request->status_bank_2 == 1), 'max:128'],
                'musik' => [Rule::requiredIf($request->status_musik == 1), 'max:128'],
            ], [
                'foto_slider_1.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_slider_2.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_slider_3.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_slider_4.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            ]);

            if ($request->status_slider == 1) {
                // Slider 1
                $image_parts_1 = explode(";base64,", $request->base64_slider_1);
                $image_ext_1 = explode("image/", $image_parts_1[0]);
                $file_name_1 = $request->file('foto_slider_1')->hashName().'.'.$image_ext_1[1];
                $file_1 = public_path('frontend/undangan/foto_slider/').$file_name_1;
                File::put($file_1, base64_decode($image_parts_1[1]));
                // Slider 2
                $image_parts_2 = explode(";base64,", $request->base64_slider_2);
                $image_ext_2 = explode("image/", $image_parts_2[0]);
                $file_name_2 = $request->file('foto_slider_2')->hashName().'.'.$image_ext_2[1];
                $file_2 = public_path('frontend/undangan/foto_slider/').$file_name_2;
                File::put($file_2, base64_decode($image_parts_2[1]));
                // Slider 3
                $image_parts_3 = explode(";base64,", $request->base64_slider_3);
                $image_ext_3 = explode("image/", $image_parts_3[0]);
                $file_name_3 = $request->file('foto_slider_3')->hashName().'.'.$image_ext_3[1];
                $file_3 = public_path('frontend/undangan/foto_slider/').$file_name_3;
                File::put($file_3, base64_decode($image_parts_3[1]));
                // Slider 4
                $image_parts_4 = explode(";base64,", $request->base64_slider_4);
                $image_ext_4 = explode("image/", $image_parts_4[0]);
                $file_name_4 = $request->file('foto_slider_4')->hashName().'.'.$image_ext_4[1];
                $file_4 = public_path('frontend/undangan/foto_slider/').$file_name_4;
                File::put($file_4, base64_decode($image_parts_4[1]));
            }

            $undangan_detail = [
                'kode_undangan' => $kode_undangan,
                'tanggal_nikah' => $request->tanggal_nikah,
                'kalimat_pembuka' => $request->kalimat_pembuka,
                'status_slider' => $request->status_slider,
                'foto_slider_1' => $request->status_slider ? $file_name_1 : NULL,
                'title_slider_1' => empty($request->title_slider_1) ? NULL : ucfirst($request->title_slider_1),
                'foto_slider_2' => $request->status_slider ? $file_name_2 : NULL,
                'title_slider_2' => empty($request->title_slider_2) ? NULL : ucfirst($request->title_slider_2),
                'foto_slider_3' => $request->status_slider ? $file_name_3 : NULL,
                'title_slider_3' => empty($request->title_slider_3) ? NULL : ucfirst($request->title_slider_3),
                'foto_slider_4' => $request->status_slider ? $file_name_4 : NULL,
                'title_slider_4' => empty($request->title_slider_4) ? NULL : ucfirst($request->title_slider_4),
                'link_youtube' => $request->status_link_youtube ? convert_ytb($request->link_youtube) : NULL,
                'musik' => $request->status_musik ? $request->musik : NULL,
            ];
            UndanganDetail::create($undangan_detail);

            $undangan_tempat = [
                [
                    'kode_undangan' => $kode_undangan,
                    'nama_acara' => ucwords($request->nama_acara_1),
                    'tanggal_acara' => $request->tanggal_acara_1,
                    'tempat_acara' => ucwords($request->tempat_acara_1),
                    'alamat_acara' => $request->alamat_acara_1,
                    'link_maps' => convert_maps($request->link_maps_1),
                    'nama_bank' => $request->status_bank_1 ? $request->nama_bank_1 : NULL,
                    'nomor_rekening' => $request->status_bank_1 ? $request->nomor_rekening_1 : NULL,
                    'pemilik_rekening' => $request->status_bank_1 ? $request->pemilik_rekening_1 : NULL,
                ],
                [
                    'kode_undangan' => $kode_undangan,
                    'nama_acara' => $request->status_acara_2 ? ucwords($request->nama_acara_2) : NULL,
                    'tanggal_acara' => $request->status_acara_2 ? $request->tanggal_acara_2 : NULL,
                    'tempat_acara' => $request->status_acara_2 ? ucwords($request->tempat_acara_2) : NULL,
                    'alamat_acara' => $request->status_acara_2 ? $request->alamat_acara_2 : NULL,
                    'link_maps' => $request->status_acara_2 ? convert_maps($request->link_maps_2) : NULL,
                    'nama_bank' => $request->status_bank_2 ? $request->nama_bank_2 : NULL,
                    'nomor_rekening' => $request->status_bank_2 ? $request->nomor_rekening_2 : NULL,
                    'pemilik_rekening' => $request->status_bank_2 ? $request->pemilik_rekening_2 : NULL,
                ],
            ];
            foreach ($undangan_tempat as $ut) {
                UndanganTempat::create($ut);
            }

            return to_route('data_galeri', $kode_undangan);
        } else {
            $get_undangan = Undangan::where('kode', '=', $kode_undangan)->where('user_id', '=', auth()->user()->id)->firstOrFail();
            $data_undangan = UndanganDetail::where('kode_undangan', '=', $kode_undangan)->first();
            if ($get_undangan && !isset($data_undangan)) {
                $data['title'] = 'Isi Data Undangan';
                $data['kode'] = $kode_undangan;
                $data['daftar_musik'] = $this->getMusik();
                $data_slider = UndanganTema::select('aspect_ratio', 'width_slider', 'height_slider')->where('id', $get_undangan->id_tema)->first();
                $data['aspect_ratio'] = $data_slider->aspect_ratio;
                $data['width_slider'] = $data_slider->width_slider;
                $data['height_slider'] = $data_slider->height_slider;
                return view('fitur.undangan.data_undangan', $data);
            }
            return to_route('riwayat_undangan');
        }
    }

    public function dataGaleri($kode_undangan, Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'foto_1' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_2' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_3' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_4' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_5' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_6' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_7' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_8' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_9' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'foto_10' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            ], [
                'foto_1.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_2.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_3.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_4.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_5.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_6.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_7.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_8.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_9.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_10.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            ]);

            function createGaleriFoto($kode_undangan, $request, $fileKey, $base64Key) {
                if ($request->file($fileKey)) {
                    $image_parts = explode(";base64,", $request->$base64Key);
                    $image_ext = explode("image/", $image_parts[0]);
                    $file_name = $request->file($fileKey)->hashName().'.'.$image_ext[1];
                    $file = public_path('frontend/undangan/foto_galeri/').$file_name;
                    File::put($file, base64_decode($image_parts[1]));
                    UndanganGaleri::create([
                        'kode_undangan' => $kode_undangan,
                        'foto' => $file_name
                    ]);
                }
            }
            createGaleriFoto($kode_undangan, $request, 'foto_1', 'base64_foto_1');
            createGaleriFoto($kode_undangan, $request, 'foto_2', 'base64_foto_2');
            createGaleriFoto($kode_undangan, $request, 'foto_3', 'base64_foto_3');
            createGaleriFoto($kode_undangan, $request, 'foto_4', 'base64_foto_4');
            createGaleriFoto($kode_undangan, $request, 'foto_5', 'base64_foto_5');
            createGaleriFoto($kode_undangan, $request, 'foto_6', 'base64_foto_6');
            createGaleriFoto($kode_undangan, $request, 'foto_7', 'base64_foto_7');
            createGaleriFoto($kode_undangan, $request, 'foto_8', 'base64_foto_8');
            createGaleriFoto($kode_undangan, $request, 'foto_9', 'base64_foto_9');
            createGaleriFoto($kode_undangan, $request, 'foto_10', 'base64_foto_10');

            return to_route('data_cerita', $kode_undangan);
        } else {
            $get_undangan = Undangan::where('kode', '=', $kode_undangan)->where('user_id', '=', auth()->user()->id)->firstOrFail();
            $data_galeri = UndanganGaleri::where('kode_undangan', '=', $kode_undangan)->first();
            if ($get_undangan && !isset($data_galeri)) {
                $data['title'] = 'Upload Galeri Pengantin';
                $data['kode'] = $kode_undangan;
                return view('fitur.undangan.data_galeri', $data);
            }
            return to_route('riwayat_undangan');
        }
    }

    public function dataCerita($kode_undangan, Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'judul_cerita_1' => [Rule::requiredIf($request->status_cerita == 1), 'max:128'],
                'isi_cerita_1' => [Rule::requiredIf($request->status_cerita == 1)],
                'waktu_cerita_1' => [Rule::requiredIf($request->status_cerita == 1), 'max:128'],
                'foto_cerita_1' => [Rule::requiredIf($request->status_cerita == 1), 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'judul_cerita_2' => [Rule::requiredIf($request->status_cerita == 1), 'max:128'],
                'isi_cerita_2' => [Rule::requiredIf($request->status_cerita == 1)],
                'waktu_cerita_2' => [Rule::requiredIf($request->status_cerita == 1), 'max:128'],
                'foto_cerita_2' => [Rule::requiredIf($request->status_cerita == 1), 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
                'judul_cerita_3' => [Rule::requiredIf($request->status_cerita == 1), 'max:128'],
                'isi_cerita_3' => [Rule::requiredIf($request->status_cerita == 1)],
                'waktu_cerita_3' => [Rule::requiredIf($request->status_cerita == 1), 'max:128'],
                'foto_cerita_3' => [Rule::requiredIf($request->status_cerita == 1), 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
            ], [
                'foto_cerita_1.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_cerita_2.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
                'foto_cerita_3.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            ]);

            if ($request->status_cerita == 1) {
                // Cerita 1
                $image_parts_1 = explode(";base64,", $request->base64_cerita_1);
                $image_ext_1 = explode("image/", $image_parts_1[0]);
                $file_name_1 = $request->file('foto_cerita_1')->hashName().'.'.$image_ext_1[1];
                $file_1 = public_path('frontend/undangan/foto_cerita/').$file_name_1;
                File::put($file_1, base64_decode($image_parts_1[1]));
                // Cerita 2
                $image_parts_2 = explode(";base64,", $request->base64_cerita_2);
                $image_ext_2 = explode("image/", $image_parts_2[0]);
                $file_name_2 = $request->file('foto_cerita_2')->hashName().'.'.$image_ext_2[1];
                $file_2 = public_path('frontend/undangan/foto_cerita/').$file_name_2;
                File::put($file_2, base64_decode($image_parts_2[1]));
                // Cerita 3
                $image_parts_3 = explode(";base64,", $request->base64_cerita_3);
                $image_ext_3 = explode("image/", $image_parts_3[0]);
                $file_name_3 = $request->file('foto_cerita_3')->hashName().'.'.$image_ext_3[1];
                $file_3 = public_path('frontend/undangan/foto_cerita/').$file_name_3;
                File::put($file_3, base64_decode($image_parts_3[1]));
                $undangan_cerita = [
                    [
                        'kode_undangan' => $kode_undangan,
                        'foto_cerita' => $file_name_1,
                        'judul_cerita' => ucfirst($request->judul_cerita_1),
                        'waktu_cerita' => $request->waktu_cerita_1,
                        'isi_cerita' => $request->isi_cerita_1,
                    ],
                    [
                        'kode_undangan' => $kode_undangan,
                        'foto_cerita' => $file_name_2,
                        'judul_cerita' => ucfirst($request->judul_cerita_2),
                        'waktu_cerita' => $request->waktu_cerita_2,
                        'isi_cerita' => $request->isi_cerita_2,
                    ],
                    [
                        'kode_undangan' => $kode_undangan,
                        'foto_cerita' => $file_name_3,
                        'judul_cerita' => ucfirst($request->judul_cerita_3),
                        'waktu_cerita' => $request->waktu_cerita_3,
                        'isi_cerita' => $request->isi_cerita_3,
                    ],
                ];
                foreach ($undangan_cerita as $uc) {
                    UndanganCerita::create($uc);
                }
            }

            return to_route('bayar_undangan', $kode_undangan);
        } else {
            $get_undangan = Undangan::where('kode', '=', $kode_undangan)->where('user_id', '=', auth()->user()->id)->firstOrFail();
            $data_cerita = UndanganCerita::where('kode_undangan', '=', $kode_undangan)->first();
            if ($get_undangan && !isset($data_cerita)) {
                $data['title'] = 'Cerita Cinta Pengantin';
                $data['kode'] = $kode_undangan;
                return view('fitur.undangan.data_cerita', $data);
            }
            return to_route('riwayat_undangan');
        }
    }

    public function bayarUndangan($kode_undangan, Request $request)
    {
        $get_undangan = Undangan::where('kode', '=', $kode_undangan)->where('user_id', '=', auth()->user()->id)->firstOrFail();
        $get_transaksi = Transaksi::where('kode_undangan', '=', $kode_undangan)->first();
        $get_paket = UndanganPaket::select('harga')->where('id', '=', $get_undangan->id_paket)->first();
        if (count($request->all())) {
            $paket = 'Undangan Digital';
            $total = $get_paket->harga;
            /*
            | ---------------------------------------------------------------
            | Proses membuat transaksi pada payment gateway
            | ---------------------------------------------------------------
            */
            if ($request->pembayaran == 'bayar_manual') {
                $redirect = to_route('transfer_undangan', $kode_undangan);
            } else if ($request->pembayaran == 'bayar_otomatis') {
                $xendit_transaksi = XenditTrait::createInvoiceUndangan($kode_undangan, $paket, $total);
                $input_transaksi = [
                    'kode_undangan' => $kode_undangan,
                    'no_ref' => $xendit_transaksi['id'],
                    'link' => $xendit_transaksi['invoice_url'],
                    'status' => 'UNPAID',
                ];
                Transaksi::create($input_transaksi);
                $redirect = redirect($xendit_transaksi['invoice_url']);
            } else {
                $method = $request->pembayaran;
                $tripay_transaksi = TripayTrait::createTransaksiUndangan($kode_undangan, $method, $total, $paket);
                $input_transaksi = [
                    'kode_undangan' => $kode_undangan,
                    'no_ref' => $tripay_transaksi->reference,
                    'link' => $tripay_transaksi->checkout_url,
                    'status' => 'UNPAID',
                ];
                Transaksi::create($input_transaksi);
                $redirect = redirect($tripay_transaksi->checkout_url);
            }
            $user = $get_undangan->user;
            $total_rp = format_rupiah($get_paket->harga);
            $text = "Informasi undangan digital\n\nKode Undangan : $kode_undangan\nNama Konsumen : $user->nama\nNomor WhatsApp : $user->no_tlp\nTotal Pembayaran : $total_rp\n";
            NotifikasiTrait::sendToAdmin($text);

            return $redirect;
        } else {
            if ($get_undangan && !isset($get_transaksi)) {
                $data['title'] = 'Pilih Metode Pembayaran';
                $data['kode'] = $kode_undangan;
                $data['status_tripay'] = SettingApp::find(2)->value_2;
                $data['status_xendit'] = SettingApp::find(2)->value_3;
                $data['bank_1'] = SettingApp::find(3);
                $data['bank_2'] = SettingApp::find(4);
                $data['daftar_pembayaran'] = TripayTrait::getChannelPembayaran();
                $data['total_pembayaran'] = format_rupiah($get_paket->harga);
                return view('fitur.undangan.metode_pembayaran', $data);
            }
            return to_route('riwayat_undangan');
        }
    }

    public function riwayatUndangan(Request $request)
    {
        if ($request->ajax()) {
            $query = Undangan::select(['kode', 'status_undangan', 'status_bayar', 'link', 'id_paket', 'created_at'])->with('paket')->where('user_id', '=', auth()->user()->id);
            $data = empty($query) ? $query : $query->latest()->get();
            return DataTables::of($data)->addIndexColumn()
            ->editColumn('durasi', function ($row) {
                return Carbon::parse($row->created_at)->addDays($row->paket->durasi)->translatedFormat('d F Y');
            })
            ->addColumn('opsi', function ($row) {
                return button_undangan($row->status_bayar, $row->kode);
            })
            ->rawColumns(['link', 'opsi'])->make(true);
        }

        $data['title'] = 'Riwayat Undangan Digital Anda';
        return view('fitur.undangan.riwayat_undangan', $data);
    }

    public function hapusFotoUndangan($kode_undangan)
    {
        $data_pengantin = UndanganPengantin::where('kode_undangan', '=', $kode_undangan)->first();
        if ($data_pengantin) {
            File::delete(public_path('/frontend/undangan/foto_pengantin/' . $data_pengantin->foto_pria));
            File::delete(public_path('/frontend/undangan/foto_pengantin/' . $data_pengantin->foto_wanita));
        }
        $data_undangan = UndanganDetail::where('kode_undangan', '=', $kode_undangan)->first();
        if ($data_undangan) {
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_1));
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_2));
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_3));
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_4));
        }
        $data_galeri = UndanganGaleri::where('kode_undangan', '=', $kode_undangan)->get();
        if ($data_galeri) {
            foreach ($data_galeri as $galeri) {
                File::delete(public_path('/frontend/undangan/foto_galeri/' . $galeri->foto));
            }
        }
        $data_cerita = UndanganCerita::where('kode_undangan', '=', $kode_undangan)->get();
        if ($data_cerita) {
            foreach ($data_cerita as $foto) {
                File::delete(public_path('/frontend/undangan/foto_cerita/' . $foto->foto_cerita));
            }
        }
    }

    public function hapusUndangan($kode_undangan)
    {
        $get_undangan = Undangan::where('kode', '=', $kode_undangan)->firstOrFail();
        $get_transaksi = Transaksi::where('kode_undangan', '=', $kode_undangan)->first();
        try {
            $this->hapusFotoUndangan($kode_undangan);
        } catch (\Exception $e) {
            return response()->json(['success' => true, 'message' => 'Terjadi kesalahan saat hapus foto.']);
        }
        switch ($get_undangan->status_bayar) {
            case ("Belum Dibayar" && !isset($get_transaksi->link)):
                Undangan::where('kode', '=', $kode_undangan)->delete();
                return response()->json(['success' => true, 'message' => 'Undangan digital anda berhasil dihapus!']);
                break;
            case ("Lunas" && isset($get_transaksi->link)):
                Undangan::where('kode', '=', $kode_undangan)->delete();
                if ($get_transaksi) {
                    $get_transaksi->delete();
                    File::delete(public_path('/frontend/images/bukti_tf/' . $get_transaksi->link));
                }
                return response()->json(['success' => true, 'message' => 'Undangan digital anda berhasil dihapus!']);
                break;
            default:
                return to_route('riwayat_undangan');
                break;
        }
    }

    public function detailUndangan($kode_undangan, Request $request)
    {
        $get_undangan = Undangan::where('kode', '=', $kode_undangan)->with('pengantin', 'slider', 'tempat', 'galeri', 'cerita')->firstOrFail();
        $set_aplikasi = (int) SettingApp::find(5)->value_5;
        $set_sistem = (int) SettingApp::find(1)->value_3;
        $expired = strtotime($get_undangan->created_at) + ($set_sistem * 60 * 60);
        if ($get_undangan->status_bayar == 'Belum Dibayar' && date('Y-m-d H:i:s', $expired) < gmdate('Y-m-d H:i:s', (time() + (60 * 60 * $set_aplikasi)))) {
            try {
                $this->hapusFotoUndangan($kode_undangan);
            } catch (\Exception $e) {
                throw ValidationException::withMessages(['Terjadi kesalahan saat hapus foto.']);
            }
            Undangan::where('kode', '=', $kode_undangan)->delete();
            return to_route('riwayat_undangan')->with('danger', 'Undangan digital anda sudah melewati batas pembayaran!');
        } else {
            if ($request->ajax()) {
                $query = UndanganUcapan::where('kode_undangan', '=', $kode_undangan);
                $data = empty($query) ? $query : $query->latest()->get();
                return DataTables::of($data)->addIndexColumn()->make(true);
            }

            $data['title'] = 'Undangan Digital Anda';
            $data['tamu_hadir'] = UndanganUcapan::select('id')->where('kode_undangan', $kode_undangan)->where('kehadiran', '=', 'Hadir')->count();
            $data['tamu_tidak_hadir'] = UndanganUcapan::select('id')->where('kode_undangan', $kode_undangan)->where('kehadiran', '=', 'Tidak Hadir')->count();
            $data['tamu_belum_yakin'] = UndanganUcapan::select('id')->where('kode_undangan', $kode_undangan)->where('kehadiran', '=', 'Belum Yakin')->count();
            $data['undangan'] = $get_undangan;
            $data['transaksi'] = Transaksi::where('kode_undangan', '=', $kode_undangan)->first();
            $data['bank_1'] = (int) SettingApp::find(3)->value_5;
            $get_created_at = strtotime($get_undangan->created_at) + ($set_sistem * 60 * 60);
            $data['waktu_expired'] = date('Y-m-d H:i:s', $get_created_at);
            $data['status_undangan'] = $get_undangan->status_undangan == "Nonaktif" ? 'Nonaktif' : 'Aktif';
            $data['btn_status_undangan'] = $get_undangan->status_undangan == "Nonaktif" ? 'btn-danger' : 'btn-success';
            $data['daftar_musik'] = $this->getMusik();
            $data_slider = UndanganTema::select('aspect_ratio', 'width_slider', 'height_slider')->where('id', $get_undangan->id_tema)->first();
            $data['aspect_ratio'] = $data_slider->aspect_ratio;
            $data['width_slider'] = $data_slider->width_slider;
            $data['height_slider'] = $data_slider->height_slider;
            return view('fitur.undangan.detail_undangan', $data);
        }
    }

    public function transferUndangan($kode_undangan)
    {
        $data['title'] = 'Upload Bukti Transfer';
        $data['undangan'] = Undangan::where('kode', '=', $kode_undangan)->where('user_id', '=', auth()->user()->id)->firstOrFail();
        $data['data_paket'] = Undangan::where('kode', '=', $kode_undangan)->with('paket')->first();
        $data['transaksi'] = Transaksi::where('kode_undangan', '=', $kode_undangan)->first();
        $data['bank_1'] = SettingApp::find(3);
        $data['bank_2'] = SettingApp::find(4);
        if (!isset($data['transaksi']['no_ref']) && $data['bank_1']['value_5'] == '1') {
            return view('fitur.undangan.bayar_undangan', $data);
        } else {
            return to_route('riwayat_undangan');
        }
    }

    public function _transferUndangan($kode_undangan, Request $request)
    {
        $request->validate([
            'bukti_tf' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
        ], [
            'bukti_tf.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
        ]);
        $nama_konsumen = auth()->user()->nama;
        $nomor_konsumen = auth()->user()->no_tlp;

        // Upload foto bukti transfer
        if ($file = $request->file('bukti_tf')) {
            $file_name = $file->hashName();
            $file->move(public_path('frontend/images/bukti_tf'), $file_name);
        }
        $link_bukti_tf = url('frontend/images/bukti_tf/' . $file_name);
        $transaksi = [
            'kode_undangan' => $kode_undangan,
            'link' => $file_name,
            'status' => 'UNPAID',
        ];
        // Insert bukti transfer ke tabel transaksi
        Transaksi::create($transaksi);

        /*
        | ---------------------------------------------------------------
        | Kirim pesan ke Admin
        | ---------------------------------------------------------------
        */
        $link_konfirmasi = url('daftar_undangan/' . $kode_undangan . '/edit');
        $text = "Konsumen Mengirim Bukti TF\n============================\nKode Undangan : $kode_undangan\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $nomor_konsumen\nPembayaran : Lunas\nFoto Bukti TF : $link_bukti_tf\n\nKonfirmasi Pembayaran : $link_konfirmasi\n============================";
        NotifikasiTrait::sendToAdmin($text);

        return to_route('transfer_undangan', $kode_undangan)->with('success', 'Bukti pembayaran berhasil di upload. Silahkan tunggu sebentar, Admin sedang melakukan cek transaksi anda terlebih dahulu.');
    }

    public function xenditReturnUndangan($kode_undangan)
    {
        $transaksi = Transaksi::where('kode_undangan', '=', $kode_undangan)->firstOrFail();
        $get_invoice = XenditTrait::getInvoice($transaksi->no_ref);
        $status = $get_invoice['status'];
        if ($transaksi->status == 'PAID') {
            return redirect('detail_undangan/' . $kode_undangan);
        } else {
            $get_undangan = Undangan::where('kode', '=', $kode_undangan)->first();
            $user = $get_undangan->user;
            switch ($status) {
                case "PENDING":
                    return redirect($get_invoice['invoice_url']);
                    break;
                case "PAID":
                    $get_undangan->update([
                        'status_bayar' => 'Lunas',
                        'status_undangan' => 'Aktif',
                    ]);
                    Transaksi::where('kode_undangan', '=', $kode_undangan)->update(['status' => 'PAID']);
                    return to_route('detail_undangan', $kode_undangan)->with('success', 'Pembayaran anda telah lunas.');
                    $text = "Informasi undangan digital\n\nKode Undangan : $kode_undangan\nNama Konsumen : $user->nama\nNomor WhatsApp : $user->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    break;

                case "SETTLED":
                    $get_undangan->update([
                        'status_bayar' => 'Lunas',
                        'status_undangan' => 'Aktif',
                    ]);
                    Transaksi::where('kode_undangan', '=', $kode_undangan)->update(['status' => 'SETTLED']);
                    return to_route('detail_undangan', $kode_undangan)->with('success', 'Pembayaran anda telah lunas.');
                    $text = "Informasi undangan digital\n\nKode Undangan : $kode_undangan\nNama Konsumen : $user->nama\nNomor WhatsApp : $user->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    break;

                case "EXPIRED":
                    $get_undangan->delete();
                    Transaksi::where('kode_undangan', '=', $kode_undangan)->update(['status' => 'EXPIRED']);
                    return to_route('riwayat_undangan')->with('danger', 'Pembayaran anda sudah melewati batas waktu.');
                    break;

                default:
                    return redirect('detail_undangan/' . $kode_undangan);
                    break;
            }
        }
    }

    public function tripayReturnUndangan($kode_undangan)
    {
        $transaksi = Transaksi::where('kode_undangan', '=', $kode_undangan)->first();
        $cek_pembayaran = TripayTrait::getTransaksi($transaksi->no_ref);
        if ($transaksi->status == 'PAID') {
            return redirect('detail_undangan/' . $kode_undangan);
        } else {
            $get_undangan = Undangan::where('kode', '=', $kode_undangan)->first();
            $user = $get_undangan->user;
            switch ($cek_pembayaran) {
                case 'PAID':
                    $get_undangan->update([
                        'status_bayar' => 'Lunas',
                        'status_undangan' => 'Aktif',
                    ]);
                    Transaksi::where('kode_undangan', '=', $kode_undangan)->update(['status' => 'PAID']);
                    return to_route('detail_undangan', $kode_undangan)->with('success', 'Pembayaran anda telah lunas.');
                    $text = "Informasi undangan digital\n\nKode Undangan : $kode_undangan\nNama Konsumen : $user->nama\nNomor WhatsApp : $user->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendToAdmin($text);
                    break;

                case 'EXPIRED':
                    $get_undangan->delete();
                    Transaksi::where('kode_undangan', '=', $kode_undangan)->update(['status' => 'EXPIRED']);
                    return to_route('riwayat_undangan')->with('danger', 'Pembayaran anda sudah melewati batas waktu.');
                    break;

                case 'FAILED':
                    $get_undangan->delete();
                    Transaksi::where('kode_undangan', '=', $kode_undangan)->update(['status' => 'FAILED']);
                    return to_route('riwayat_undangan')->with('danger', 'Pembayaran anda gagal.');
                    break;

                default:
                    return redirect('detail_undangan/' . $kode_undangan);
                    break;
            }
        }
    }

    public function updateStatusUndangan($kode_undangan)
    {
        $get_undangan = Undangan::where('kode', '=', $kode_undangan)->firstOrFail();
        $status_undangan = $get_undangan->status_undangan == 'Aktif' ? 'Nonaktif' : 'Aktif';
        $get_undangan->update(['status_undangan' => $status_undangan]);
        return to_route('detail_undangan', $kode_undangan)->with('success', 'Status undangan digital berhasil diubah!');
    }

    public function showUndangan($link, $guest = null)
    {
        $get_undangan = Undangan::where('link', '=', $link)->with('slider', 'pengantin', 'cerita', 'galeri', 'tempat')->firstOrFail();
        if ($get_undangan) {
            if ($get_undangan->status_undangan == "Aktif" & $get_undangan->status_bayar == "Lunas") {
                $nama_acara = "Pernikahan ".$get_undangan->nama_pria." & ".$get_undangan->nama_wanita;
                $tanggal_mulai = date("Ymd\THis", strtotime($get_undangan->slider->tanggal_nikah));
                $tanggal_selesai = date("Ymd\T230000", strtotime($get_undangan->slider->tanggal_nikah));
                $lokasi = $get_undangan->tempat[0]->tempat_acara;
                $keterangan = "Kami sangat berharap anda dapat hadir di momen bahagia ini.";
                $google_calendar = "https://www.google.com/calendar/render?action=TEMPLATE&text=" . urlencode($nama_acara) . "&dates=" . $tanggal_mulai . "/" . $tanggal_selesai . "&location=" . urlencode($lokasi) . "&details=" . urlencode($keterangan);

                $guest = preg_replace_callback('/_+/', function ($matches) {
                    return str_repeat(' ', strlen($matches[0]));
                }, $guest);
                $data = [
                    'tamu' => !$guest ? 'Tamu Undangan' : $guest,
                    'undangan' => $get_undangan,
                    'tanggal_nikah' => Carbon::parse($get_undangan->slider->tanggal_nikah)->translatedFormat('Y/m/d H:i:s'),
                    'google_calendar' => $google_calendar,
                    'bg_image' => isset($get_undangan->galeri[0]->foto) ? asset('frontend/undangan/foto_galeri/'.$get_undangan->galeri[0]->foto) : asset('frontend/undangan/lovelove/images/default_img.jpg'),
                ];
                $get_tema = UndanganTema::where('id', $get_undangan->id_tema)->first();
                return view('fitur.undangan.' . $get_tema->preview, $data);
            }
            abort(404);
        }
    }

    public function ucapanTamu($kode_undangan, Request $request)
    {
        $get_undangan = Undangan::select('kode')->where('kode', '=', $kode_undangan)->firstOrFail();
        $cek_ip = UndanganUcapan::select('ip_address','kode_undangan')->where('kode_undangan', $kode_undangan)->where('ip_address', $request->ip())->first();
        $request->validate([
            'nama' => ['required', 'max:128', 'string', 'unique:undangan_ucapan,nama_tamu'],
            'ucapan' => ['required', 'max:255', 'string'],
            'kehadiran' => ['required', 'max:20', 'string'],
        ]);
        if ($cek_ip) {
            return throw ValidationException::withMessages(['Ucapan hanya dapat diisi satu kali']);
        } else {
            $ucapan_tamu = [
                'kode_undangan' => $get_undangan->kode,
                'nama_tamu' => $request->nama,
                'ucapan' => $request->ucapan,
                'kehadiran' => $request->kehadiran,
                'ip_address' => $request->ip(),
            ];
            UndanganUcapan::create($ucapan_tamu);
            return response()->json(['success' => true, 'message' => "Ucapan dan kehadiran berhasil dikirim"]);
        }
    }

    public function dataUcapan($kode_undangan, Request $request)
    {
        if ($request->ajax()) {
            $query = UndanganUcapan::select('nama_tamu', 'ucapan')->where('kode_undangan', '=', $kode_undangan);
            $data = empty($query) ? $query : $query->latest()->get();
            return DataTables::of($data)->make(true);
        }
    }

    public function editDataPengantin($kode_undangan, Request $request)
    {
        $get_undangan = Undangan::where('kode', $kode_undangan)->first();
        $get_pengantin = UndanganPengantin::where('kode_undangan', $kode_undangan)->first();
        $request->validate([
            'foto_pria' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'full_nama_pria' => ['required', 'max:128'],
            'nama_pria' => ['required', 'max:128'],
            'anak_of_pria' => ['required', 'max:128'],
            'ortu_pria' => ['required', 'max:255'],
            'foto_wanita' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'full_nama_wanita' => ['required', 'max:128'],
            'nama_wanita' => ['required', 'max:128'],
            'anak_of_wanita' => ['required', 'max:128'],
            'ortu_wanita' => ['required', 'max:255'],
            'ig_pria' => [Rule::requiredIf($request->status_ig_pria == 1), 'max:128'],
            'twitter_pria' => [Rule::requiredIf($request->status_twitter_pria == 1), 'max:128'],
            'fb_pria' => [Rule::requiredIf($request->status_fb_pria == 1), 'max:128'],
            'ig_wanita' => [Rule::requiredIf($request->status_ig_wanita == 1), 'max:128'],
            'twitter_wanita' => [Rule::requiredIf($request->status_twitter_wanita == 1), 'max:128'],
            'fb_wanita' => [Rule::requiredIf($request->status_fb_wanita == 1), 'max:128'],
        ], [
            'foto_pria.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_wanita.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'link.unique' => 'Link undangan sudah ada yang menggunakan, coba ganti yang lain.'
        ]);

        $undangan = [
            'nama_pria' => ucwords($request->nama_pria),
            'full_nama_pria' => ucwords($request->full_nama_pria),
            'nama_wanita' => ucwords($request->nama_wanita),
            'full_nama_wanita' => ucwords($request->full_nama_wanita),
        ];
        $undangan_pengantin = [
            'ortu_pria' => ucwords($request->ortu_pria),
            'anak_of_pria' => ucfirst($request->anak_of_pria),
            'ortu_wanita' => ucwords($request->ortu_wanita),
            'anak_of_wanita' => ucfirst($request->anak_of_wanita),
            'ig_pria' => $request->status_ig_pria ? $request->ig_pria : NULL,
            'twitter_pria' => $request->status_twitter_pria ? $request->twitter_pria : NULL,
            'fb_pria' => $request->status_fb_pria ? $request->fb_pria : NULL,
            'ig_wanita' => $request->status_ig_wanita ? $request->ig_wanita : NULL,
            'twitter_wanita' => $request->status_twitter_wanita ? $request->twitter_wanita : NULL,
            'fb_wanita' => $request->status_fb_wanita ? $request->fb_wanita : NULL,
        ];

        if ($request->file('foto_pria')) {
            File::delete(public_path('/frontend/undangan/foto_pengantin/' . $get_pengantin->foto_pria));
            $pria_image_parts = explode(";base64,", $request->base64_foto_pria);
            $pria_ext = explode("image/", $pria_image_parts[0]);
            $pria_file_name = $request->file('foto_pria')->hashName().'.'.$pria_ext[1];
            $pria_file = public_path('frontend/undangan/foto_pengantin/').$pria_file_name;
            File::put($pria_file, base64_decode($pria_image_parts[1]));
            $undangan_pengantin['foto_pria'] = $pria_file_name;
        }
        if ($request->file('foto_wanita')) {
            File::delete(public_path('/frontend/undangan/foto_pengantin/' . $get_pengantin->foto_wanita));
            $wanita_image_parts = explode(";base64,", $request->base64_foto_wanita);
            $wanita_ext = explode("image/", $pria_image_parts[0]);
            $wanita_file_name = $request->file('foto_wanita')->hashName().'.'.$wanita_ext[1];
            $wanita_file = public_path('frontend/undangan/foto_pengantin/').$wanita_file_name;
            File::put($wanita_file, base64_decode($wanita_image_parts[1]));
            $undangan_pengantin['foto_wanita'] = $wanita_file_name;
        }

        $get_undangan->update($undangan);
        $get_pengantin->update($undangan_pengantin);
        return to_route('detail_undangan', $kode_undangan)->with('success', 'Data pengantin berhasil diubah!');
    }

    public function editDataUndangan($kode_undangan, Request $request)
    {
        $get_detail = UndanganDetail::where('kode_undangan', $kode_undangan)->first();
        $request->validate([
            'nama_acara_1' => ['required', 'max:128'],
            'tanggal_acara_1' => ['required', 'max:128'],
            'tempat_acara_1' => ['required', 'max:128'],
            'alamat_acara_1' => ['required', 'max:255'],
            'link_maps_1' => ['required', 'max:255'],
            'nama_acara_2' => ['max:128'],
            'tanggal_acara_2' => ['max:128'],
            'tempat_acara_2' => ['max:128'],
            'alamat_acara_2' => ['max:255'],
            'link_maps_2' => ['max:255'],
            'tanggal_nikah' => ['required'],
            'kalimat_pembuka' => ['required'],
            'foto_slider_1' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_slider_2' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_slider_3' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_slider_4' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'link_youtube' => [Rule::requiredIf($request->status_link_youtube == 1), 'max:255'],
            'nama_bank_1' => [Rule::requiredIf($request->status_bank_1 == 1), 'max:128'],
            'nomor_rekening_1' => [Rule::requiredIf($request->status_bank_1 == 1), 'max:128'],
            'pemilik_rekening_1' => [Rule::requiredIf($request->status_bank_1 == 1), 'max:128'],
            'nama_bank_2' => [Rule::requiredIf($request->status_bank_2 == 1), 'max:128'],
            'nomor_rekening_2' => [Rule::requiredIf($request->status_bank_2 == 1), 'max:128'],
            'pemilik_rekening_2' => [Rule::requiredIf($request->status_bank_2 == 1), 'max:128'],
            'musik' => [Rule::requiredIf($request->status_musik == 1), 'max:128'],
        ], [
            'foto_slider_1.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_slider_2.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_slider_3.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_slider_4.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
        ]);

        $undangan_tempat_1 = [
            'nama_acara' => ucwords($request->nama_acara_1),
            'tanggal_acara' => $request->tanggal_acara_1,
            'tempat_acara' => ucwords($request->tempat_acara_1),
            'alamat_acara' => $request->alamat_acara_1,
            'link_maps' => convert_maps($request->link_maps_1),
            'nama_bank' => $request->status_bank_1 ? $request->nama_bank_1 : NULL,
            'nomor_rekening' => $request->status_bank_1 ? $request->nomor_rekening_1 : NULL,
            'pemilik_rekening' => $request->status_bank_1 ? $request->pemilik_rekening_1 : NULL,
        ];
        UndanganTempat::where('id', $request->tempat_1)->update($undangan_tempat_1);

        if ($request->nama_acara_2) {
            $undangan_tempat_2 = [
                'nama_acara' => ucwords($request->nama_acara_2),
                'tanggal_acara' => $request->tanggal_acara_2,
                'tempat_acara' => ucwords($request->tempat_acara_2),
                'alamat_acara' => $request->alamat_acara_2,
                'link_maps' => convert_maps($request->link_maps_2),
                'nama_bank' => $request->status_bank_2 ? $request->nama_bank_2 : NULL,
                'nomor_rekening' => $request->status_bank_2 ? $request->nomor_rekening_2 : NULL,
                'pemilik_rekening' => $request->status_bank_2 ? $request->pemilik_rekening_2 : NULL,
            ];
            UndanganTempat::where('id', $request->tempat_2)->update($undangan_tempat_2);
        }

        $undangan_detail = [
            'tanggal_nikah' => $request->tanggal_nikah,
            'kalimat_pembuka' => $request->kalimat_pembuka,
            'status_slider' => $request->status_slider,
            'title_slider_1' => empty($request->title_slider_1) ? NULL : $request->title_slider_1,
            'title_slider_2' => empty($request->title_slider_2) ? NULL : $request->title_slider_2,
            'title_slider_3' => empty($request->title_slider_3) ? NULL : $request->title_slider_3,
            'title_slider_4' => empty($request->title_slider_4) ? NULL : $request->title_slider_4,
            'link_youtube' => $request->status_link_youtube ? convert_ytb($request->link_youtube) : NULL,
            'musik' => $request->status_musik ? $request->musik : NULL,
        ];

        if ($request->status_slider == 1) {
            if ($request->file('foto_slider_1')) {
                File::delete(public_path('/frontend/undangan/foto_slider/' . $get_detail->foto_slider_1));
                $image_parts_1 = explode(";base64,", $request->base64_slider_1);
                $image_ext_1 = explode("image/", $image_parts_1[0]);
                $file_name_1 = $request->file('foto_slider_1')->hashName().'.'.$image_ext_1[1];
                $file_1 = public_path('frontend/undangan/foto_slider/').$file_name_1;
                File::put($file_1, base64_decode($image_parts_1[1]));
                $undangan_detail['foto_slider_1'] = $file_name_1;
            }
            if ($request->file('foto_slider_2')) {
                File::delete(public_path('/frontend/undangan/foto_slider/' . $get_detail->foto_slider_2));
                $image_parts_2 = explode(";base64,", $request->base64_slider_2);
                $image_ext_2 = explode("image/", $image_parts_2[0]);
                $file_name_2 = $request->file('foto_slider_2')->hashName().'.'.$image_ext_2[1];
                $file_2 = public_path('frontend/undangan/foto_slider/').$file_name_2;
                File::put($file_2, base64_decode($image_parts_2[1]));
                $undangan_detail['foto_slider_2'] = $file_name_2;
            }
            if ($request->file('foto_slider_3')) {
                File::delete(public_path('/frontend/undangan/foto_slider/' . $get_detail->foto_slider_3));
                $image_parts_3 = explode(";base64,", $request->base64_slider_3);
                $image_ext_3 = explode("image/", $image_parts_3[0]);
                $file_name_3 = $request->file('foto_slider_3')->hashName().'.'.$image_ext_3[1];
                $file_3 = public_path('frontend/undangan/foto_slider/').$file_name_3;
                File::put($file_3, base64_decode($image_parts_3[1]));
                $undangan_detail['foto_slider_3'] = $file_name_3;
            }
            if ($request->file('foto_slider_4')) {
                File::delete(public_path('/frontend/undangan/foto_slider/' . $get_detail->foto_slider_4));
                $image_parts_4 = explode(";base64,", $request->base64_slider_4);
                $image_ext_4 = explode("image/", $image_parts_4[0]);
                $file_name_4 = $request->file('foto_slider_4')->hashName().'.'.$image_ext_4[1];
                $file_4 = public_path('frontend/undangan/foto_slider/').$file_name_4;
                File::put($file_4, base64_decode($image_parts_4[1]));
                $undangan_detail['foto_slider_4'] = $file_name_4;
            }
        }
        $get_detail->update($undangan_detail);

        return to_route('detail_undangan', $kode_undangan)->with('success', 'Data undangan berhasil diubah!');
    }

    public function editDataGaleri($kode_undangan, Request $request)
    {
        $request->validate([
            'foto_1' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_2' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_3' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_4' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_5' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_6' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_7' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_8' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_9' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'foto_10' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
        ], [
            'foto_1.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_2.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_3.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_4.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_5.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_6.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_7.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_8.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_9.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_10.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
        ]);

        function updateOrCreateImage($kode_undangan, $request, $fileKey, $base64Key, $idKey) {
            if (!$request->$idKey) {
                if ($request->file($fileKey)) {
                    $image_parts = explode(";base64,", $request->$base64Key);
                    $image_ext = explode("image/", $image_parts[0]);
                    $file_name = $request->file($fileKey)->hashName().'.'.$image_ext[1];
                    $file = public_path('frontend/undangan/foto_galeri/').$file_name;
                    File::put($file, base64_decode($image_parts[1]));
                    UndanganGaleri::create([
                        'kode_undangan' => $kode_undangan,
                        'foto' => $file_name
                    ]);
                }
            } else {
                $get_foto = UndanganGaleri::where('kode_undangan', $kode_undangan)->where('id', $request->$idKey)->firstOrFail();
                if ($request->file($fileKey)) {
                    if (isset($get_foto->foto)) {
                        File::delete(public_path('/frontend/undangan/foto_galeri/' . $get_foto->foto));
                    }
                    $image_parts = explode(";base64,", $request->$base64Key);
                    $image_ext = explode("image/", $image_parts[0]);
                    $file_name = $request->file($fileKey)->hashName().'.'.$image_ext[1];
                    $file = public_path('frontend/undangan/foto_galeri/').$file_name;
                    File::put($file, base64_decode($image_parts[1]));
                    UndanganGaleri::updateOrCreate(
                        ['kode_undangan' => $kode_undangan, 'id' => $request->$idKey],
                        ['foto' => $file_name]
                    );
                }
            }
        }
        updateOrCreateImage($kode_undangan, $request, 'foto_1', 'base64_foto_1', 'id_foto_1');
        updateOrCreateImage($kode_undangan, $request, 'foto_2', 'base64_foto_2', 'id_foto_2');
        updateOrCreateImage($kode_undangan, $request, 'foto_3', 'base64_foto_3', 'id_foto_3');
        updateOrCreateImage($kode_undangan, $request, 'foto_4', 'base64_foto_4', 'id_foto_4');
        updateOrCreateImage($kode_undangan, $request, 'foto_5', 'base64_foto_5', 'id_foto_5');
        updateOrCreateImage($kode_undangan, $request, 'foto_6', 'base64_foto_6', 'id_foto_6');
        updateOrCreateImage($kode_undangan, $request, 'foto_7', 'base64_foto_7', 'id_foto_7');
        updateOrCreateImage($kode_undangan, $request, 'foto_8', 'base64_foto_8', 'id_foto_8');
        updateOrCreateImage($kode_undangan, $request, 'foto_9', 'base64_foto_9', 'id_foto_9');
        updateOrCreateImage($kode_undangan, $request, 'foto_10', 'base64_foto_10', 'id_foto_10');

        return to_route('detail_undangan', $kode_undangan)->with('success', 'Foto galeri berhasil diubah!');
    }

    public function editDataCerita($kode_undangan, Request $request)
    {
        $request->validate([
            'judul_cerita_1' => ['required', 'max:128'],
            'isi_cerita_1' => ['required'],
            'waktu_cerita_1' => ['required', 'max:128'],
            'foto_cerita_1' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'judul_cerita_2' => ['required', 'max:128'],
            'isi_cerita_2' => ['required'],
            'waktu_cerita_2' => ['required', 'max:128'],
            'foto_cerita_2' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
            'judul_cerita_3' => ['required', 'max:128'],
            'isi_cerita_3' => ['required'],
            'waktu_cerita_3' => ['required', 'max:128'],
            'foto_cerita_3' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
        ], [
            'foto_cerita_1.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_cerita_2.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
            'foto_cerita_3.*' => 'Foto harus berformat png,jpg,jpeg dan berukuran maksimal 4 MB.',
        ]);

        function updateOrCreateCerita($kode_undangan, $request, $fotoKey, $base64Key, $idKey, $judulKey, $waktuKey, $isiKey) {
            if (!$request->$idKey) {
                if ($request->file($fotoKey)) {
                    $image_parts = explode(";base64,", $request->$base64Key);
                    $image_ext = explode("image/", $image_parts[0]);
                    $file_name = $request->file($fotoKey)->hashName().'.'.$image_ext[1];
                    $file = public_path('frontend/undangan/foto_cerita/').$file_name;
                    File::put($file, base64_decode($image_parts[1]));
                    UndanganCerita::create([
                        'kode_undangan' => $kode_undangan,
                        'foto_cerita' => $file_name,
                        'judul_cerita' => ucfirst($request->$judulKey),
                        'waktu_cerita' => $request->$waktuKey,
                        'isi_cerita' => $request->$isiKey,
                    ]);
                }
            } else {
                $get_cerita = UndanganCerita::where('kode_undangan', $kode_undangan)->where('id', $request->$idKey)->firstOrFail();
                if ($request->file($fotoKey)) {
                    if (isset($get_cerita->foto_cerita)) {
                        File::delete(public_path('/frontend/undangan/foto_cerita/' . $get_cerita->foto_cerita));
                    }
                    $image_parts = explode(";base64,", $request->$base64Key);
                    $image_ext = explode("image/", $image_parts[0]);
                    $file_name = $request->file($fotoKey)->hashName().'.'.$image_ext[1];
                    $file = public_path('frontend/undangan/foto_cerita/').$file_name;
                    File::put($file, base64_decode($image_parts[1]));
                }
                UndanganCerita::updateOrCreate(
                    ['kode_undangan' => $kode_undangan, 'id' => $request->$idKey],
                    [
                        'foto_cerita' => $file_name ?? $get_cerita->foto_cerita,
                        'judul_cerita' => ucfirst($request->$judulKey),
                        'waktu_cerita' => $request->$waktuKey,
                        'isi_cerita' => $request->$isiKey,
                    ],
                );
            }
        }
        updateOrCreateCerita($kode_undangan, $request, 'foto_cerita_1', 'base64_cerita_1', 'id_cerita_1', 'judul_cerita_1', 'waktu_cerita_1', 'isi_cerita_1');
        updateOrCreateCerita($kode_undangan, $request, 'foto_cerita_2', 'base64_cerita_2', 'id_cerita_2', 'judul_cerita_2', 'waktu_cerita_2', 'isi_cerita_2');
        updateOrCreateCerita($kode_undangan, $request, 'foto_cerita_3', 'base64_cerita_3', 'id_cerita_3', 'judul_cerita_3', 'waktu_cerita_3', 'isi_cerita_3');

        return to_route('detail_undangan', $kode_undangan)->with('success', 'Data cerita berhasil diubah!');
    }

    public function previewUndangan($tema)
    {
        $get_tema = UndanganTema::where('preview', $tema)->first();
        if ($get_tema) {
            return view('fitur.undangan.preview.' . $get_tema->preview);
        }
        abort(404);
    }

    public function deleteGaleri($kode_undangan, $id)
    {
        $get_data = UndanganGaleri::where('kode_undangan', $kode_undangan)->where('id', $id)->firstOrFail();
        File::delete(public_path('/frontend/undangan/foto_galeri/' . $get_data->foto));
        $get_data->delete();
        return response()->json(['success' => true, 'message' => 'Foto berhasil dihapus!']);
    }

    public function deleteCerita($kode_undangan, $id)
    {
        $get_data = UndanganCerita::where('kode_undangan', $kode_undangan)->where('id', $id)->firstOrFail();
        if ($get_data->foto_cerita) {
            File::delete(public_path('/frontend/undangan/foto_cerita/' . $get_data->foto_cerita));
        }
        $get_data->delete();
        return response()->json(['success' => true, 'message' => 'Cerita berhasil dihapus!']);
    }
}
