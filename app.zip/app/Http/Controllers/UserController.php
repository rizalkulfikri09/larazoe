<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserToken;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        $data['title'] = 'Halaman Profil';
        hapus_session();
        hapus_session_self();
        hapus_session_undangan();
        return view('user.index', $data);
    }

    public function userEdit()
    {
        $data['title'] = 'Halaman Edit Profil';
        $data['set_sistem'] = \App\Models\SettingApp::find(1);
        $data['captcha_key'] = config('tools.captcha_key');
        return view('user.edit_profil', $data);
    }

    public function userUpdate(Request $request)
    {
        $user = User::findOrFail(auth()->user()->id);
        $input = $request->validate([
            'nama' => ['required', 'string'],
            'email' => ['required', 'unique:users,email,' . $user->id . ',id', 'email:rfc,dns'],
            'image' => ['image', 'mimes:png,jpg,jpeg', 'max:2048'],
        ]);
        if ($file = $request->file('image')) {
            $file_name = $file->hashName();
            $file->move(public_path('/frontend/images/profile'), $file_name);
            if ($user->image != 'default.jpg') {
                \Illuminate\Support\Facades\File::delete(public_path('/frontend/images/profile/' . $user->image));
            }
            $input['image'] = $file_name;
        }
        $user->update($input);
        return to_route('user_edit')->with('success', 'Profil anda berhasil diubah!');
    }

    public function userGantiNomor(Request $request)
    {
        $request->validate([
            'no_tlp' => ['required', 'regex:/^0\d/', 'numeric', 'unique:users,no_tlp'],
            'g-recaptcha-response' => ['required', new \App\Rules\ReCaptcha],
        ], [
            'no_tlp.regex' => 'nomor WhatApp tidak sesuai format 08123XXXXXXX.',
            'g-recaptcha-response.required' => 'ReCaptcha wajib diisi, tidak boleh kosong.',
        ]);
        $no_tlp = format_tlp($request->no_tlp);
        $user = User::where('id', '=', auth()->user()->id)->first();
        $set_sistem = \App\Models\SettingApp::find(1);
        $link = url('aktivasi/'.$no_tlp).'/';
        if ($set_sistem->value_2 && $request->type_send == "wa") {
            $otp = random_int(1000, 9999);
            $user_token = [
                'no_tlp' => $no_tlp,
                'token' => $otp,
            ];
            $text = "Kode verifikasi Anda : *$otp*. Kode akan kedaluarsa dalam waktu 5 menit.\n\nHalaman Verifikasi : $link";
            \App\Traits\NotifikasiTrait::sendToUser($text, $no_tlp);

            $user->update(['is_active' => 0, 'no_tlp' => $no_tlp]);
            UserToken::create($user_token);
            $request->session()->invalidate();
            return redirect('aktivasi/' . $no_tlp)->with('success', 'Kode OTP dikirim ke nomor WhatsApp Anda');
        } else if ($set_sistem->value_10 && $request->type_send == "mail") {
            try {
                $otp = random_int(1000, 9999);
                $user_token = [
                    'no_tlp' => $no_tlp,
                    'token' => $otp,
                ];
                $mailData = [
                    'title' => "Kode OTP untuk aktivasi akun",
                    'body' => "Kode verifikasi Anda : $otp. Kode akan kedaluarsa dalam waktu 5 menit. Klik link dibawah ini untuk aktivasi akun :",
                    'link' => $link,
                ];
                \Illuminate\Support\Facades\Mail::to($user->email)->send(new \App\Mail\SendMail($mailData));

                $user->update(['is_active' => 0, 'no_tlp' => $no_tlp]);
                UserToken::create($user_token);
                $request->session()->invalidate();
                return redirect('aktivasi/' . $no_tlp)->with('success', 'Kode OTP berhasil dikirim, cek email Anda atau cek di folder Spam.');
            } catch (\Exception $e) {
                throw \Illuminate\Validation\ValidationException::withMessages(['Terjadi kesalahan disistem.']);
            }
        } else {
            return to_route('user');
        }
    }

    public function gantiPassword(Request $request)
    {
        if (count($request->all())) {
            $request->validate([
                'current_password' => ['required', 'min:8', function ($attribute, $value, $fail) {
                    if (!Hash::check($value, auth()->user()->password)) {
                        return $fail('Password lama anda salah!');
                    }
                }],
                'password' => ['required', 'min:8', 'confirmed', function ($attribute, $value, $fail) {
                    if (Hash::check($value, auth()->user()->password)) {
                        return $fail('Password baru tidak boleh sama dengan password lama!');
                    }
                }],
            ]);
            User::where('no_tlp', '=', auth()->user()->no_tlp)->update(['password' => bcrypt($request->password)]);
            return to_route('ganti_password')->with('success', 'Password Anda berhasil diganti!');
        } else {
            $data['title'] = 'Halaman Ganti Password';
            return view('user.ganti_password', $data);
        }
    }

    public function hapusAkun(Request $request)
    {
        $request->validate([
            'password' => ['required', function ($attribute, $value, $fail) {
                if (!Hash::check($value, auth()->user()->password)) {
                    return $fail('Password yang anda masukan salah!');
                }
            }]
        ]);
        User::where('no_tlp', '=', auth()->user()->no_tlp)->delete();
        return to_route('logout');
    }
}
