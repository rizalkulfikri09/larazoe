<?php

namespace App\Http\Controllers;

use App\Models\Studio;
use App\Models\Wedding;
use App\Models\Undangan;
use App\Models\SelfPhoto;
use App\Models\Transaksi;
use Illuminate\Http\Request;
use App\Traits\NotifikasiTrait;
use Illuminate\Support\Facades\Response;

class PaymentController extends Controller
{
    public function studioCallback(Request $request)
    {
        $privateKey = config('payment.tripay_private');
        $callbackSignature = $request->server('HTTP_X_CALLBACK_SIGNATURE');
        $json = $request->getContent();
        $signature = hash_hmac('sha256', $json, $privateKey);

        if ($signature !== (string) $callbackSignature) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid signature',
            ]);
        }

        if ('payment_status' !== (string) $request->server('HTTP_X_CALLBACK_EVENT')) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid callback event, no action was taken',
            ]);
        }

        $data = json_decode($json);

        if (JSON_ERROR_NONE !== json_last_error()) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid data sent by tripay',
            ]);
        }

        $kode_booking = $data->merchant_ref;
        $status = strtoupper((string) $data->status);

        /*
        |--------------------------------------------------------------------------
        | Proses callback untuk closed payment
        |--------------------------------------------------------------------------
        */
        if (1 === (int) $data->is_closed_payment) {
            $get_studio = Studio::where('kode', '=', $kode_booking)->first();
            switch ($status) {
                case 'UNPAID':
                    $get_studio->update(['status_bayar' => 'Belum Dibayar']);
                    Transaksi::where('kode_booking', '=', $kode_booking)->update(['status' => 'UNPAID']);
                    break;

                case 'PAID':
                    $get_studio->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_booking', '=', $kode_booking)->update(['status' => 'PAID']);
                    $text = "Informasi booking studio foto\n\nKode Booking : $kode_booking\nNama Konsumen : $get_studio->nama\nNomor WhatsApp : $get_studio->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendNotify($text, $get_studio->no_tlp);
                    break;

                case 'EXPIRED':
                    $get_studio->delete();
                    Transaksi::where('kode_booking', '=', $kode_booking)->update(['status' => 'EXPIRED']);
                    break;

                case 'FAILED':
                    $get_studio->delete();
                    Transaksi::where('kode_booking', '=', $kode_booking)->update(['status' => 'FAILED']);
            }

            return Response::json(['success' => true]);
        }
    }

    public function weddingCallback(Request $request)
    {
        $privateKey = config('payment.tripay_private');
        $callbackSignature = $request->server('HTTP_X_CALLBACK_SIGNATURE');
        $json = $request->getContent();
        $signature = hash_hmac('sha256', $json, $privateKey);

        if ($signature !== (string) $callbackSignature) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid signature',
            ]);
        }

        if ('payment_status' !== (string) $request->server('HTTP_X_CALLBACK_EVENT')) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid callback event, no action was taken',
            ]);
        }

        $data = json_decode($json);

        if (JSON_ERROR_NONE !== json_last_error()) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid data sent by tripay',
            ]);
        }

        $kode_wedding = $data->merchant_ref;
        $status = strtoupper((string) $data->status);

        /*
        |--------------------------------------------------------------------------
        | Proses callback untuk closed payment
        |--------------------------------------------------------------------------
        */
        if (1 === (int) $data->is_closed_payment) {
            $get_wedding = Wedding::where('kode', '=', $kode_wedding)->first();
            switch ($status) {
                case 'UNPAID':
                    $get_wedding->update(['status_bayar' => 'Belum Dibayar']);
                    Transaksi::where('kode_wedding', '=', $kode_wedding)->update(['status' => 'UNPAID']);
                    break;

                case 'PAID':
                    $get_wedding->update(['status_bayar' => 'Lunas']);
                    Transaksi::where('kode_wedding', '=', $kode_wedding)->update(['status' => 'PAID']);
                    $text = "Informasi booking wedding\n\nKode Wedding : $kode_wedding\nNama Konsumen : $get_wedding->nama\nNomor WhatsApp : $get_wedding->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendNotify($text, $get_wedding->no_tlp);
                    break;

                case 'EXPIRED':
                    $get_wedding->delete();
                    Transaksi::where('kode_wedding', '=', $kode_wedding)->update(['status' => 'EXPIRED']);
                    break;

                case 'FAILED':
                    $get_wedding->delete();
                    Transaksi::where('kode_wedding', '=', $kode_wedding)->update(['status' => 'FAILED']);
            }

            return Response::json(['success' => true]);
        }
    }

    public function undanganCallback(Request $request)
    {
        $privateKey = config('payment.tripay_private');
        $callbackSignature = $request->server('HTTP_X_CALLBACK_SIGNATURE');
        $json = $request->getContent();
        $signature = hash_hmac('sha256', $json, $privateKey);

        if ($signature !== (string) $callbackSignature) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid signature',
            ]);
        }

        if ('payment_status' !== (string) $request->server('HTTP_X_CALLBACK_EVENT')) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid callback event, no action was taken',
            ]);
        }

        $data = json_decode($json);

        if (JSON_ERROR_NONE !== json_last_error()) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid data sent by tripay',
            ]);
        }

        $kode_undangan = $data->merchant_ref;
        $status = strtoupper((string) $data->status);

        /*
        |--------------------------------------------------------------------------
        | Proses callback untuk closed payment
        |--------------------------------------------------------------------------
        */
        if (1 === (int) $data->is_closed_payment) {
            $get_undangan = Undangan::where('kode', '=', $kode_undangan)->first();
            switch ($status) {
                case 'UNPAID':
                    $get_undangan->update(['status_bayar' => 'Belum Dibayar']);
                    Transaksi::where('kode_undangan', '=', $kode_undangan)->update(['status' => 'UNPAID']);
                    break;

                case 'PAID':
                    $get_undangan->update([
                        'status_bayar' => 'Lunas',
                        'status_undangan' => 'Aktif',
                    ]);
                    Transaksi::where('kode_undangan', '=', $kode_undangan)->update(['status' => 'PAID']);
                    $user = $get_undangan->user;
                    $text = "Informasi undangan digital\n\nKode Undangan : $kode_undangan\nNama Konsumen : $user->nama\nNomor WhatsApp : $user->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendNotify($text, $user->no_tlp);
                    break;

                case 'EXPIRED':
                    $get_undangan->delete();
                    Transaksi::where('kode_undangan', '=', $kode_undangan)->update(['status' => 'EXPIRED']);
                    break;

                case 'FAILED':
                    $get_undangan->delete();
                    Transaksi::where('kode_undangan', '=', $kode_undangan)->update(['status' => 'FAILED']);
            }
            return Response::json(['success' => true]);
        }
    }

    public function selfPhotoCallback(Request $request)
    {
        $privateKey = config('payment.tripay_private');
        $callbackSignature = $request->server('HTTP_X_CALLBACK_SIGNATURE');
        $json = $request->getContent();
        $signature = hash_hmac('sha256', $json, $privateKey);

        if ($signature !== (string) $callbackSignature) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid signature',
            ]);
        }

        if ('payment_status' !== (string) $request->server('HTTP_X_CALLBACK_EVENT')) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid callback event, no action was taken',
            ]);
        }

        $data = json_decode($json);

        if (JSON_ERROR_NONE !== json_last_error()) {
            return Response::json([
                'success' => false,
                'message' => 'Invalid data sent by tripay',
            ]);
        }

        $kode_selfphoto = $data->merchant_ref;
        $status = strtoupper((string) $data->status);

        /*
        |--------------------------------------------------------------------------
        | Proses callback untuk closed payment
        |--------------------------------------------------------------------------
        */
        if (1 === (int) $data->is_closed_payment) {
            $get_booking = SelfPhoto::where('kode', '=', $kode_selfphoto)->first();
            switch ($status) {
                case 'UNPAID':
                    $get_booking->update(['status_bayar' => 'Belum Dibayar']);
                    Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->update(['status' => 'UNPAID']);
                    break;

                case 'PAID':
                    $get_booking->update([
                        'status_bayar' => 'Lunas',
                        'status_undangan' => 'Aktif',
                    ]);
                    Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->update(['status' => 'PAID']);
                    $user = $get_booking->user;
                    $text = "Informasi booking self photo\n\nKode Booking : $kode_selfphoto\nNama Konsumen : $user->nama\nNomor WhatsApp : $user->no_tlp\nPembayaran : Lunas\n";
                    NotifikasiTrait::sendNotify($text, $user->no_tlp);
                    break;

                case 'EXPIRED':
                    $get_booking->delete();
                    Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->update(['status' => 'EXPIRED']);
                    break;

                case 'FAILED':
                    $get_booking->delete();
                    Transaksi::where('kode_selfphoto', '=', $kode_selfphoto)->update(['status' => 'FAILED']);
            }
            return Response::json(['success' => true]);
        }
    }

    public function callbackXendit(Request $request)
    {
        $xenditXCallbackToken = config('payment.xendit_token');
        $getHeaders = getallheaders();
        $getCallbackToken = isset($getHeaders['X-CALLBACK-TOKEN']) ? $getHeaders['X-CALLBACK-TOKEN'] : $getHeaders['X-Callback-Token'];
        $data = $request->getContent();

        $xIncomingCallbackTokenHeader = isset($getCallbackToken) ? $getCallbackToken : "";

        if($xIncomingCallbackTokenHeader === $xenditXCallbackToken) {
            $arrRequestInput = json_decode($data, true);
            $id = $arrRequestInput['id'];
            $kode = $arrRequestInput['external_id'];
            $status = $arrRequestInput['status'];

            switch ($status) {
                case "PAID":
                    $get_transaksi = Transaksi::where('no_ref', '=', $id)->first();
                    if ($get_transaksi->kode_booking) {
                        $get_studio = Studio::where('kode', '=', $kode)->first();
                        $get_studio->update(['status_bayar' => 'Lunas']);
                        Transaksi::where('kode_booking', '=', $kode)->update(['status' => 'PAID']);
                        $text = "Informasi booking studio foto\n\nKode Booking : $kode\nNama Konsumen : $get_studio->nama\nNomor WhatsApp : $get_studio->no_tlp\nPembayaran : Lunas\n";
                        NotifikasiTrait::sendNotify($text, $get_studio->no_tlp);

                    } else if ($get_transaksi->kode_selfphoto) {
                        $get_booking = SelfPhoto::where('kode', '=', $kode)->with('user')->first();
                        $nama_konsumen = $get_booking->user->nama;
                        $nomor_konsumen = $get_booking->user->no_tlp;
                        $get_booking->update(['status_bayar' => 'Lunas']);
                        Transaksi::where('kode_selfphoto', '=', $kode)->update(['status' => 'PAID']);
                        $text = "Informasi booking self photo\n\nKode Booking : $kode\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $nomor_konsumen\nPembayaran : Lunas\n";
                        NotifikasiTrait::sendNotify($text, $nomor_konsumen);

                    } else if ($get_transaksi->kode_wedding) {
                        $get_wedding = Wedding::where('kode', '=', $kode)->first();
                        $get_wedding->update(['status_bayar' => 'Lunas']);
                        Transaksi::where('kode_wedding', '=', $kode)->update(['status' => 'PAID']);
                        $text = "Informasi booking wedding\n\nKode Wedding : $kode\nNama Konsumen : $get_wedding->nama\nNomor WhatsApp : $get_wedding->no_tlp\nPembayaran : Lunas\n";
                        NotifikasiTrait::sendNotify($text, $get_wedding->no_tlp);

                    } else if ($get_transaksi->kode_undangan) {
                        $get_undangan = Undangan::where('kode', '=', $kode)->first();
                        $get_undangan->update([
                            'status_bayar' => 'Lunas',
                            'status_undangan' => 'Aktif',
                        ]);
                        Transaksi::where('kode_undangan', '=', $kode)->update(['status' => 'PAID']);
                        $user = $get_undangan->user;
                        $text = "Informasi undangan digital\n\nKode Undangan : $kode\nNama Konsumen : $user->nama\nNomor WhatsApp : $user->no_tlp\nPembayaran : Lunas\n";
                        NotifikasiTrait::sendNotify($text, $user->no_tlp);
                    }
                    break;
                case "SETTLED":
                    $get_transaksi = Transaksi::where('no_ref', '=', $id)->first();
                    if ($get_transaksi->kode_booking) {
                        $get_studio = Studio::where('kode', '=', $kode)->first();
                        $get_studio->update(['status_bayar' => 'Lunas']);
                        Transaksi::where('kode_booking', '=', $kode)->update(['status' => 'SETTLED']);
                        $text = "Informasi booking studio foto\n\nKode Booking : $kode\nNama Konsumen : $get_studio->nama\nNomor WhatsApp : $get_studio->no_tlp\nPembayaran : Lunas\n";
                        NotifikasiTrait::sendNotify($text, $get_studio->no_tlp);

                    } else if ($get_transaksi->kode_selfphoto) {
                        $get_booking = SelfPhoto::where('kode', '=', $kode)->with('user')->first();
                        $nama_konsumen = $get_booking->user->nama;
                        $nomor_konsumen = $get_booking->user->no_tlp;
                        $get_booking->update(['status_bayar' => 'Lunas']);
                        Transaksi::where('kode_selfphoto', '=', $kode)->update(['status' => 'SETTLED']);
                        $text = "Informasi booking self photo\n\nKode Booking : $kode\nNama Konsumen : $nama_konsumen\nNomor WhatsApp : $nomor_konsumen\nPembayaran : Lunas\n";
                        NotifikasiTrait::sendNotify($text, $nomor_konsumen);

                    } else if ($get_transaksi->kode_wedding) {
                        $get_wedding = Wedding::where('kode', '=', $kode)->first();
                        $get_wedding->update(['status_bayar' => 'Lunas']);
                        Transaksi::where('kode_wedding', '=', $kode)->update(['status' => 'SETTLED']);
                        $text = "Informasi booking wedding\n\nKode Wedding : $kode\nNama Konsumen : $get_wedding->nama\nNomor WhatsApp : $get_wedding->no_tlp\nPembayaran : Lunas\n";
                        NotifikasiTrait::sendNotify($text, $get_wedding->no_tlp);

                    } else if ($get_transaksi->kode_undangan) {
                        $get_undangan = Undangan::where('kode', '=', $kode)->first();
                        $get_undangan->update([
                            'status_bayar' => 'Lunas',
                            'status_undangan' => 'Aktif',
                        ]);
                        Transaksi::where('kode_undangan', '=', $kode)->update(['status' => 'SETTLED']);
                        $user = $get_undangan->user;
                        $text = "Informasi undangan digital\n\nKode Undangan : $kode\nNama Konsumen : $user->nama\nNomor WhatsApp : $user->no_tlp\nPembayaran : Lunas\n";
                        NotifikasiTrait::sendNotify($text, $user->no_tlp);
                    }
                    break;
                case "EXPIRED":
                    $get_transaksi = Transaksi::where('no_ref', '=', $id)->first();
                    if ($get_transaksi->kode_booking) {
                        Studio::where('kode', '=', $kode)->delete();
                        Transaksi::where('kode_booking', '=', $kode)->update(['status' => 'EXPIRED']);
                    } else if ($get_transaksi->kode_selfphoto) {
                        SelfPhoto::where('kode', '=', $kode)->delete();
                        Transaksi::where('kode_selfphoto', '=', $kode)->update(['status' => 'EXPIRED']);
                    } else if ($get_transaksi->kode_wedding) {
                        Wedding::where('kode', '=', $kode)->delete();
                        Transaksi::where('kode_wedding', '=', $kode)->update(['status' => 'EXPIRED']);
                    } else if ($get_transaksi->kode_undangan) {
                        Undangan::where('kode', '=', $kode)->delete();
                        Transaksi::where('kode_undangan', '=', $kode)->update(['status' => 'EXPIRED']);
                    }
                    break;
                default:
                    print_r(false);
                    break;
            }
        } else {
            http_response_code(403);
        }
    }
}
