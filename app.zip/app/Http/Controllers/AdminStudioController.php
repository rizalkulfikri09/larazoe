<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Paket;
use App\Models\Studio;
use App\Models\SubPaket;
use App\Models\Transaksi;
use App\Models\JamBooking;
use App\Models\SettingApp;
use Illuminate\Http\Request;
use App\Exports\StudioExport;
use Illuminate\Support\Carbon;
use App\Traits\NotifikasiTrait;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\File;

class AdminStudioController extends Controller
{
    public function __construct()
    {
        $this->middleware(['only.admin']);
    }

    public function showBooking(Request $request)
    {
        if ($request->ajax()) {
            if ($request->session_sbo) {
                session()->put('session_sbo', $request->session_sbo);
            }
            if ($request->session_dp) {
                session()->put('session_dp', $request->session_dp);
            }
            if ($request->session_sba) {
                session()->put('session_sba', $request->session_sba);
            }
            if ($request->tanggal_1) {
                session()->put('tanggal_1', $request->tanggal_1);
                session()->put('tanggal_2', $request->tanggal_2);
            }
            $query = Studio::select(['booking_studio.*', 'transaksi.kode_booking', 'transaksi.link', 'transaksi.no_ref'])->leftJoin('transaksi', 'booking_studio.kode', '=', 'transaksi.kode_booking')
            ->when(session()->get('session_sbo'), function ($query) {
                $query->where('status_booking', '=', session()->get('session_sbo'));
            })
            ->when(session()->get('session_dp'), function ($query) {
                $query->where('paket', '=', session()->get('session_dp'));
            })
            ->when(session()->get('session_sba'), function ($query) {
                $query->where('status_bayar', '=', session()->get('session_sba'));
            })
            ->when(session()->get('tanggal_1'), function ($query) {
                $query->where('tgl_booking', '>=', session()->get('tanggal_1'))->where('tgl_booking', '<=', session()->get('tanggal_2'));
            });
            $data = empty($query) ? $query : $query->latest()->get();
            return DataTables::of($data)->addIndexColumn()
            ->addColumn('kodes', function ($row) {
                $check = '<input type="checkbox" class="sub_chk" data-kodes="'. $row->kode .'">';
                return $check;
            })
            ->editColumn('tgl_booking', function ($row) {
                return Carbon::parse($row->tgl_booking)->translatedFormat('d F Y');
            })
            ->editColumn('status_bayar', function ($row) {
                $result = $row->status_bayar == 'DP' ? format_rupiah($row->jml_dp) : '';
                $bukti_tf = isset($row->link) && is_null($row->no_ref) ? '<b><a target="_blank" href="'.url('frontend/images/bukti_tf/' . $row->link).'">Bukti TF</a></b>' : '';
                return $row->status_bayar.' <b style="color: red;">'.$result.'</b><br>'.$bukti_tf;
            })
            ->editColumn('total', function ($row) {
                return format_rupiah($row->total);
            })
            ->addColumn('opsi', function ($row) {
                $btn = '<a href="daftar_booking/'.$row->kode.'/edit" class="btn btn-success btn-block btn-sm">Edit</a><a href="javascript:void(0)" class="btn btn-danger btn-block btn-sm deleteBooking" data-toggle="tooltip" data-kode="'.$row->kode.'" data-original-title="Delete">Hapus</a>';
                return $btn;
            })
            ->with('sum_total', function() use ($query) {
                return format_rupiah($query->sum('total'));
            })
            ->rawColumns(['kodes', 'status_bayar', 'opsi'])->toJson();
        }

        $data['title'] = 'Daftar Booking Studio Foto';
        $data['daftar_konsumen'] = User::select(['id', 'nama'])->get();
        $data['daftar_sesi'] = JamBooking::select(['id', 'jam'])->get();
        $data['daftar_paket'] = SubPaket::select(['id', 'sub_paket', 'min_org', 'max_org', 'durasi', 'harga'])->where('is_active', 1)->get();
        $getCS = SettingApp::find(1);
        $data['nama_cs'] = json_decode($getCS->items);
        $data['cs_now'] = $getCS;
        $data['session_sbo'] = ['Dipesan', 'Selesai'];
        $data['session_sba'] = ['Lunas', 'DP', 'Belum Dibayar'];
        $data['session_dp'] = Studio::select('paket')->distinct()->pluck('paket');
        return view('admin.studio.daftar_booking', $data);
    }

    public function createBooking(Request $request)
    {
        $request->validate([
            'nama' => ['required'],
            'no_tlp' => ['required', 'regex:/^0\d/', 'numeric'],
            'tgl_booking' => ['required'],
            'id_sesi' => ['required'],
            'paket' => ['required'],
            'jml_dp' => ['required'],
            'jml_orang' => ['required'],
            'status_booking' => ['required'],
            'status_bayar' => ['required'],
        ], [
            'no_tlp.regex' => 'nomor WhatApp tidak sesuai format 08123XXXXXXX.',
        ]);
        $jml_konsumen = SettingApp::find(2)->value_1;
        $query = Studio::where('tgl_booking', '=', $request->tgl_booking)->where('id_sesi', '=', $request->id_sesi)->get()->count();
        if ($query >= (int)$jml_konsumen) {
            throw \Illuminate\Validation\ValidationException::withMessages([
            'id_sesi' => 'Jam booking yang dipilih sudah penuh, pilih jam booking yang lain.'
            ]);
        }

        $id_konsumen = $request->nama;
        if(is_numeric($id_konsumen)) {
            $get_user = User::where('id', $id_konsumen)->first();
            $nama = $get_user->nama;
        } else {
            $nama = $request->nama;
        }

        $id_paket = $request->paket;
        $id_sesi = $request->id_sesi;
        $paket = SubPaket::getSubPaketById($id_paket);
        $get_paket = $paket->nama_paket . " - " . $paket->sub_paket;
        $total = $paket->harga;

        $get_jam = JamBooking::where('id', $id_sesi)->first();
        $get_sub_paket = SubPaket::where('id', $id_paket)->first();
        $jam_akhir = Carbon::createFromFormat('H:i', $get_jam->jam);
        $jam_akhir->addMinutes($get_sub_paket->durasi);
        $jam_booking = $get_jam->jam.' - '.$jam_akhir->format('H:i');

        Studio::create([
            'kode' => kode_studio(),
            'nama' => $nama,
            'no_tlp' => format_tlp($request->no_tlp),
            'paket' => $get_paket,
            'status_booking' => $request->status_booking,
            'status_bayar' => $request->status_bayar,
            'jml_dp' => $request->status_bayar != "DP" ? 0 : change_rupiah($request->jml_dp),
            'total' => $total,
            'jml_orang' => $request->jml_orang,
            'tgl_booking' => $request->tgl_booking,
            'jam_booking' => $jam_booking,
            'id_sesi' => $request->id_sesi,
            'cs' => $request->nama_cs,
        ]);

        return response()->json(['success' => true, 'message' => "Booking studio foto berhasil ditambah!"]);
    }

    public function editBooking(Request $request, $kode)
    {
        if (count($request->all())) {
            $post_status_booking = $request->status_booking;
            $post_status_pembayaran = $request->status_bayar;
            $post_jumlah_dp = change_rupiah($request->jml_dp);
            $get_booking = Studio::where('kode', '=', $kode)->firstOrFail();

            // Script bagian ubah status booking studio foto
            if ($post_status_booking != $get_booking->status_booking) {
                $nama_konsumen = $get_booking->nama;
                $no_tlp = $get_booking->no_tlp;
                $status = $request->status_booking;
                $get_booking->update([
                    'status_booking' => $status
                ]);
                $text = "Booking studio foto atas nama $nama_konsumen telah $status. Terima kasih telah menggunakan layanan kami, jangan lupa berikan testimoni dan rating pada aplikasi.";
                NotifikasiTrait::sendToUser($text, $no_tlp);
            }

            // Script bagian ubah status pembayaran
            if ($post_status_pembayaran != $get_booking->status_bayar) {
                $nama_konsumen = $get_booking->nama;
                $no_tlp = $get_booking->no_tlp;
                $get_booking->update([
                    'status_booking' => $post_status_booking,
                    'status_bayar' => $post_status_pembayaran,
                    'jml_dp' => $post_jumlah_dp,
                ]);
                Transaksi::where('kode_booking','=',$kode)->where('status','=','UNPAID')->update(['status' => 'PAID']);
                $link = url('cetak_booking/' . $kode);
                $text = "Booking studio foto atas nama $nama_konsumen status pembayarannya sekarang adalah $post_status_pembayaran.\n\nBerikut link untuk cetak nota : $link";
                NotifikasiTrait::sendToUser($text, $no_tlp);
            }
            return to_route('daftar_booking')->with('success', 'Data booking studio foto berhasil diubah!');
        } else {
            $data['title'] = 'Edit Booking Studio Foto';
            $getCS = SettingApp::find(1);
            $data['booking'] = Studio::where('kode', '=', $kode)->firstOrFail();
            $data['status_booking'] = ['Dipesan', 'Selesai'];
            $data['status_bayar'] = ['Belum Dibayar', 'DP', 'Lunas'];
            $data['nama_cs'] = json_decode($getCS->items);
            $data['jam_booking'] = JamBooking::select(['id', 'jam'])->get();
            $data['transaksi'] = Transaksi::where('kode_booking', '=', $kode)->first();

            return view('admin.studio.edit_booking', $data);
        }
    }

    public function rescheduleStudio(Request $request ,$kode)
    {
        $request->validate([
            'nama' => ['required'],
            'no_tlp' => ['required', 'regex:/^0\d/', 'numeric'],
            'tgl_booking' => ['required'],
            'id_sesi' => ['required'],
        ], [
            'no_tlp.regex' => 'nomor WhatApp tidak sesuai format 08123XXXXXXX.',
        ]);

        $get_jam = JamBooking::where('id', $request->id_sesi)->first();
        $get_booking = Studio::where('kode', '=', $kode)->firstOrFail();
        $get_booking->update([
            "nama" => $request->nama,
            "no_tlp" => format_tlp($request->no_tlp),
            "tgl_booking" => $request->tgl_booking,
            "jam_booking" => jam_reschedule($get_jam->jam, $kode),
            "id_sesi" => $request->id_sesi,
            "cs" => $request->cs,
        ]);

        return to_route('daftar_booking')->with('success', 'Booking studio foto berhasil di reschedule!');
    }

    public function deleteBooking($kode)
    {
        Studio::where('kode', '=', $kode)->delete();
        $get_transaksi = Transaksi::where('kode_booking', '=', $kode)->first();
        if ($get_transaksi) {
            $get_transaksi->delete();
            File::delete(public_path('/frontend/images/bukti_tf/' . $get_transaksi->link));
        }
        return response()->json(['success' => true, 'message' => 'Booking studio foto berhasil dihapus!']);
    }

    public function deleteAllBooking(Request $request)
    {
        $kodes = $request->kodes;
        Studio::whereIn('kode', explode(",", $kodes))->delete();
        $get_transaksi = Transaksi::whereIn('kode_booking', explode(",", $kodes));
        foreach ($get_transaksi->get() as $row) {
            File::delete(public_path('/frontend/images/bukti_tf/' . $row->link));
        }
        $get_transaksi->delete();
        return response()->json(['success' => true, 'message' => 'Booking studio foto berhasil dihapus!']);
    }

    public function exportStudioPdf()
    {
        return (new StudioExport)->export_pdf();
    }

    public function exportStudioExcel()
    {
        return (new StudioExport)->export_excel();
    }

    public function pengaturanPaket(Request $request)
    {
        if(count($request->all())) {
            $request->validate([
                'nama_paket' => ['required'],
                'deskripsi' => ['required'],
                'thumbnail' => ['required', 'image', 'mimes:png,jpg,jpeg', 'max:4048'],
            ]);
            $input = [
                'nama_paket' => $request->nama_paket,
                'deskripsi' => $request->deskripsi,
                'is_active' => 1,
            ];
            if ($file = $request->file('thumbnail')) {
                $file_name = $file->getClientOriginalName();
                $file->move(public_path('/frontend/images/paket'), $file_name);
                $input['thumbnail'] = $file_name;
            }
            Paket::create($input);
            return to_route('pengaturan_paket')->with('success', 'Paket baru berhasil ditambahkan!');
        } else {
            $data['title'] = 'Pengaturan Paket';
            $data['data_paket'] = Paket::all();
            return view('admin.studio.pengaturan_paket', $data);
        }
    }

    public function editPaket(Request $request, $id)
    {
        $request->validate([
            'nama_paket' => ['required'],
            'deskripsi' => ['required'],
            'thumbnail' => ['image', 'mimes:png,jpg,jpeg', 'max:4048'],
        ]);
        $get_paket = Paket::where('id', $id)->first();
        $input = [
            'nama_paket' => $request->nama_paket,
            'deskripsi' => $request->deskripsi,
            'is_active' => $request->is_active,
        ];
        if ($file = $request->file('thumbnail')) {
            $file_name = $file->getClientOriginalName();
            $file->move(public_path('/frontend/images/paket'), $file_name);
            if ($get_paket->thumbnail != $file_name) {
                File::delete(public_path('/frontend/images/paket/' . $get_paket->thumbnail));
            }
            $input['thumbnail'] = $file_name;
        }
        $get_paket->update($input);

        return to_route('pengaturan_paket')->with('success', 'Paket berhasil diubah!');
    }

    public function deletePaket($id)
    {
        $get_paket = Paket::find($id);
        File::delete(public_path('/frontend/images/paket/' . $get_paket->thumbnail));
        $get_paket->delete($id);
        return to_route('pengaturan_paket')->with('success', 'Paket berhasil dihapus!');
    }

    public function pengaturanSubPaket(Request $request)
    {
        if(count($request->all())) {
            $input = $request->validate([
                'sub_paket' => ['required'],
                'id_paket' => ['required'],
                'durasi' => ['required'],
                'harga' => ['required'],
                'min_org' => ['required'],
                'max_org' => ['required'],
                'is_active' => ['required'],
            ]);
            $input['harga'] = change_rupiah($request->harga);
            SubPaket::create($input);
            return to_route('pengaturan_sub_paket')->with('success', 'Sub Paket baru berhasil ditambahkan!');
        } else {
            $data['title'] = 'Pengaturan Sub Paket';
            $data['sub_paket'] = SubPaket::getSubPaket();
            $data['daftar_paket'] = Paket::select('id', 'nama_paket')->get();
            return view('admin.studio.pengaturan_sub_paket', $data);
        }
    }

    public function editSubPaket(Request $request, $id)
    {
        $get_sub_paket = SubPaket::where('id', $id)->first();
        $input = $request->validate([
            'sub_paket' => ['required'],
            'id_paket' => ['required'],
            'durasi' => ['required'],
            'harga' => ['required'],
            'min_org' => ['required'],
            'max_org' => ['required'],
            'is_active' => ['required'],
        ]);
        $input['harga'] = change_rupiah($request->harga);
        $get_sub_paket->update($input);

        return to_route('pengaturan_sub_paket')->with('success', 'Sub Paket berhasil diubah!');
    }

    public function deleteSubPaket($id)
    {
        SubPaket::find($id)->delete($id);
        return to_route('pengaturan_sub_paket')->with('success', 'Sub Paket berhasil dihapus!');
    }

    public function testimoniStudio()
    {
        $data['title'] = 'Daftar Testimoni';
        $data['daftar_testimoni'] = \App\Models\Testimoni::all();

        return view('admin.studio.testimoni_studio', $data);
    }

    public function deleteTestimoniStudio($id)
    {
        \App\Models\Testimoni::find($id)->delete($id);
        return to_route('testimoni_studio')->with('success', 'Data testimoni berhasil dihapus!');
    }
}
