<?php

namespace App\Traits;

use Xendit\Xendit;
use App\Models\SettingApp;

/**
 * 
 */
trait XenditTrait
{
    public static function createInvoiceStudio($kode_booking, $paket, $total)
    {
        $set_sistem = SettingApp::find(1);
        Xendit::setApiKey(config('payment.xendit_secret'));

        $params = [ 
            'external_id' => $kode_booking,
            'amount' => $total,
            'description' => 'Invoice Booking Studio Foto',
            'invoice_duration' => ($set_sistem->value_3 * 60 * 60),
            'customer' => [
                'given_names' => auth()->user()->nama,
                'email' => auth()->user()->email,
                'mobile_number' => nomor_tlp(auth()->user()->no_tlp),
            ],
            'customer_notification_preference' => [
                'invoice_created' => [
                ],
                'invoice_reminder' => [
                    'whatsapp',
                    'email',
                ],
                'invoice_paid' => [
                ],
                'invoice_expired' => [
                    'whatsapp',
                    'email',
                ]
            ],
            'success_redirect_url' => url('xendit_studio/' . $kode_booking),
            'failure_redirect_url' => url('xendit_studio/' . $kode_booking),
            'currency' => 'IDR',
            'items' => [
                [
                    'name' => $paket,
                    'quantity' => 1,
                    'price' => $total,
                ]
            ],
            'locale' => 'id',
        ];

        $createInvoice = \Xendit\Invoice::create($params);
        return $createInvoice;
    }

    public static function createInvoiceWedding($kode_wedding, $paket, $total)
    {
        $set_sistem = SettingApp::find(1);
        Xendit::setApiKey(config('payment.xendit_secret'));

        $params = [ 
            'external_id' => $kode_wedding,
            'amount' => $total,
            'description' => 'Invoice Booking Wedding',
            'invoice_duration' => ($set_sistem->value_3 * 60 * 60),
            'customer' => [
                'given_names' => auth()->user()->nama,
                'email' => auth()->user()->email,
                'mobile_number' => nomor_tlp(auth()->user()->no_tlp),
            ],
            'customer_notification_preference' => [
                'invoice_created' => [
                ],
                'invoice_reminder' => [
                    'whatsapp',
                    'email',
                ],
                'invoice_paid' => [
                ],
                'invoice_expired' => [
                    'whatsapp',
                    'email',
                ]
            ],
            'success_redirect_url' => url('xendit_wedding/' . $kode_wedding),
            'failure_redirect_url' => url('xendit_wedding/' . $kode_wedding),
            'currency' => 'IDR',
            'items' => [
                [
                    'name' => $paket,
                    'quantity' => 1,
                    'price' => $total,
                ]
            ],
            'locale' => 'id',
        ];

        $createInvoice = \Xendit\Invoice::create($params);
        return $createInvoice;
    }

    public static function createInvoiceUndangan($kode_undangan, $paket, $total)
    {
        $set_sistem = SettingApp::find(1);
        Xendit::setApiKey(config('payment.xendit_secret'));

        $params = [ 
            'external_id' => $kode_undangan,
            'amount' => $total,
            'description' => 'Invoice Undangan Digital',
            'invoice_duration' => ($set_sistem->value_3 * 60 * 60),
            'customer' => [
                'given_names' => auth()->user()->nama,
                'email' => auth()->user()->email,
                'mobile_number' => nomor_tlp(auth()->user()->no_tlp),
            ],
            'customer_notification_preference' => [
                'invoice_created' => [
                ],
                'invoice_reminder' => [
                    'whatsapp',
                    'email',
                ],
                'invoice_paid' => [
                ],
                'invoice_expired' => [
                    'whatsapp',
                    'email',
                ]
            ],
            'success_redirect_url' => url('xendit_undangan/' . $kode_undangan),
            'failure_redirect_url' => url('xendit_undangan/' . $kode_undangan),
            'currency' => 'IDR',
            'items' => [
                [
                    'name' => $paket,
                    'quantity' => 1,
                    'price' => $total,
                ]
            ],
            'locale' => 'id',
        ];

        $createInvoice = \Xendit\Invoice::create($params);
        return $createInvoice;
    }

    public static function createInvoiceSelfPhoto($kode_selfphoto, $paket, $total)
    {
        $set_sistem = SettingApp::find(1);
        Xendit::setApiKey(config('payment.xendit_secret'));

        $params = [ 
            'external_id' => $kode_selfphoto,
            'amount' => $total,
            'description' => 'Invoice Booking Self Photo',
            'invoice_duration' => ($set_sistem->value_3 * 60 * 60),
            'customer' => [
                'given_names' => auth()->user()->nama,
                'email' => auth()->user()->email,
                'mobile_number' => nomor_tlp(auth()->user()->no_tlp),
            ],
            'customer_notification_preference' => [
                'invoice_created' => [
                ],
                'invoice_reminder' => [
                    'whatsapp',
                    'email',
                ],
                'invoice_paid' => [
                ],
                'invoice_expired' => [
                    'whatsapp',
                    'email',
                ]
            ],
            'success_redirect_url' => url('xendit_selfphoto/' . $kode_selfphoto),
            'failure_redirect_url' => url('xendit_selfphoto/' . $kode_selfphoto),
            'currency' => 'IDR',
            'items' => [
                [
                    'name' => $paket,
                    'quantity' => 1,
                    'price' => $total,
                ]
            ],
            'locale' => 'id',
        ];

        $createInvoice = \Xendit\Invoice::create($params);
        return $createInvoice;
    }

    public static function getInvoice($id)
    {
        Xendit::setApiKey(config('payment.xendit_secret'));

        $getInvoice = \Xendit\Invoice::retrieve($id);
        return $getInvoice;
    }
}
