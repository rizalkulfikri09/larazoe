<?php

namespace App\Traits;

use App\Models\SettingApp;

/**
 * 
 */
trait NotifikasiTrait
{
    public static function sendNotify($text, $no_tlp)
    {
        $get_wa = SettingApp::find(14);
        if ($get_wa->value_2 == 1) {
            $token = config('tools.wg_token');
            $domain_api = config('tools.wg_domain');
            // API by Wablas
            $curl = curl_init();
            $data = [
                'phone' => $get_wa->value_1.','.$no_tlp,
                'message' => $text,
                'secret' => true,
                'priority' => true,
            ];
            curl_setopt($curl, CURLOPT_HTTPHEADER,
                array(
                    "Authorization: $token",
                )
            );
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($curl, CURLOPT_URL, "$domain_api");
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            $result = curl_exec($curl);
            curl_close($curl);
        }
    }

    public static function sendToAdmin($text)
    {
        $get_wa = SettingApp::find(14);
        if ($get_wa->value_2 == 1) {
            $token = config('tools.wg_token');
            $domain_api = config('tools.wg_domain');
            // API by Wablas
            $curl = curl_init();
            $data = [
                'phone' => $get_wa->value_1,
                'message' => $text,
                'secret' => true,
                'priority' => true,
            ];
            curl_setopt($curl, CURLOPT_HTTPHEADER,
                array(
                    "Authorization: $token",
                )
            );
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($curl, CURLOPT_URL, "$domain_api");
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            $result = curl_exec($curl);
            curl_close($curl);
        }
    }

    public static function sendToUser($text, $no_tlp)
    {
        $get_wa = SettingApp::find(14);
        if ($get_wa->value_2 == 1) {
            $token = config('tools.wg_token');
            $domain_api = config('tools.wg_domain');
            // API by Wablas
            $curl = curl_init();
            $data = [
                'phone' => $no_tlp,
                'message' => $text,
                'secret' => true,
                'priority' => true,
            ];
            curl_setopt($curl, CURLOPT_HTTPHEADER,
                array(
                    "Authorization: $token",
                )
            );
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($curl, CURLOPT_URL, "$domain_api");
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            $result = curl_exec($curl);
            curl_close($curl);
        }
    }

    public static function sendReminder()
    {
        $token = config('tools.wg_token');
        $domain_api = config('tools.wg_domain');
        $zona_waktu = SettingApp::find(5)->value_5;
        $time_now = gmdate('Y-m-d', (time() + (60 * 60 * $zona_waktu)));
        $get_booking = \App\Models\Studio::select('nama', 'no_tlp', 'tgl_booking', 'jam_booking', 'status_bayar')->whereIn('status_bayar', ['Lunas', 'DP'])->whereRaw("DATE(DATE_ADD(tgl_booking, INTERVAL -1 DAY)) = '$time_now'")->get();
        $get_wa = SettingApp::find(14);
        if ($get_wa->value_3 == 1) {
            if ($get_wa->value_2 == 1) {
                foreach ($get_booking as $row) {
                    $tgl_booking = \Illuminate\Support\Carbon::parse($row->tgl_booking)->translatedFormat('d F Y');
                    // API by Wablas
                    $curl = curl_init();
                    $data = [
                        'phone' => $row->no_tlp,
                        'message' => "*Reminder booking studio foto*\nNama Konsumen : $row->nama\nTanggal Pemotretan : $tgl_booking\nJam Pemotretan : $row->jam_booking\n\nDimohon untuk konsumen datang 15 menit sebelum jam pemotretan, harus sudah siap dan berada di studio foto.",
                        'secret' => true,
                        'priority' => true,
                    ];
                    curl_setopt($curl, CURLOPT_HTTPHEADER,
                        array(
                            "Authorization: $token",
                        )
                    );
                    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                    curl_setopt($curl, CURLOPT_URL, "$domain_api");
                    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
                    $result = curl_exec($curl);
                    curl_close($curl);
                }
            }
        }
    }
}
