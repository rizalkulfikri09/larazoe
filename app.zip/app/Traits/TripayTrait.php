<?php

namespace App\Traits;

use App\Models\SettingApp;

/**
 * 
 */
trait TripayTrait
{
    public static function getChannelPembayaran()
    {
        $status_tripay = SettingApp::find(2)->value_2;
        if ($status_tripay == 1) {
            $apiKey = config('payment.tripay_api');
            $mode = config('payment.tripay_mode');
            $curl = curl_init();
            curl_setopt_array($curl, array(
            CURLOPT_FRESH_CONNECT  => true,
            CURLOPT_URL            => "https://tripay.co.id/$mode/merchant/payment-channel",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$apiKey],
            CURLOPT_FAILONERROR    => false,
            CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4
            ));
            $response = curl_exec($curl);
            $error = curl_error($curl);
            curl_close($curl);
            $response = json_decode($response);
            if ($response->success == false) {
                $response = null;
            }
        } else {
            $response = null;
            $error = null;
        }
        return $response ? $response->data : $error;
    }

    public static function getBiayaTransaksi($code_pay, $total)
    {
        $apiKey = config('payment.tripay_api');
        $mode = config('payment.tripay_mode');
        $payload = [
            'code' => $code_pay,
            'amount' => $total,
        ];
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_FRESH_CONNECT  => true,
            CURLOPT_URL            => "https://tripay.co.id/$mode/merchant/fee-calculator?".http_build_query($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$apiKey],
            CURLOPT_FAILONERROR    => false,
            CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4
        ]);
        $response = curl_exec($curl);
        $error = curl_error($curl);
        curl_close($curl);
        $response = json_decode($response)->data;
        $total_biaya =  array_sum((array)$response[0]->total_fee);
        return $total_biaya ? $total_biaya : $error;
    }

    public static function createTransaksi($kode_booking, $method, $total, $paket)
    {
        $set_sistem = SettingApp::find(1);
        $mode         = config('payment.tripay_mode');
        $apiKey       = config('payment.tripay_api');
        $privateKey   = config('payment.tripay_private');
        $merchantCode = config('payment.tripay_kode');
        $merchantRef  = $kode_booking;
        $amount       = $total;
        $data = [
            'method'         => $method,
            'merchant_ref'   => $merchantRef,
            'amount'         => $amount,
            'customer_name'  => auth()->user()->nama,
            'customer_email' => auth()->user()->email,
            'customer_phone' => auth()->user()->no_tlp,
            'order_items'    => [
                [
                    'sku'         => $kode_booking,
                    'name'        => $paket,
                    'price'       => $total,
                    'quantity'    => 1,
                ]
            ],
            'callback_url'      => url('studio_callback'),
            'return_url'        => url('studio_return', $kode_booking),
            'expired_time' => (time() + ($set_sistem->value_3 * 60 * 60)),
            'signature'    => hash_hmac('sha256', $merchantCode.$merchantRef.$amount, $privateKey)
        ];
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_FRESH_CONNECT  => true,
            CURLOPT_URL            => "https://tripay.co.id/$mode/transaction/create",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$apiKey],
            CURLOPT_FAILONERROR    => false,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($data),
            CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4
        ]);
        $response = json_decode(curl_exec($curl));
        $error = curl_error($curl);
        curl_close($curl);
        if ($response->success == false) {
            throw \Illuminate\Validation\ValidationException::withMessages([$response->message . ', atau pilih metode pembayaran manual.']);
        } else {
            $response = $response->data;
            return $response ? $response : $error;
        }
    }

    public static function createTransaksiWedding($kode_booking, $method, $total, $paket)
    {
        $set_sistem = SettingApp::find(1);
        $mode = config('payment.tripay_mode');
        $apiKey       = config('payment.tripay_api');
        $privateKey   = config('payment.tripay_private');
        $merchantCode = config('payment.tripay_kode');
        $merchantRef  = $kode_booking;
        $amount       = $total;
        $data = [
            'method'         => $method,
            'merchant_ref'   => $merchantRef,
            'amount'         => $amount,
            'customer_name'  => auth()->user()->nama,
            'customer_email' => auth()->user()->email,
            'customer_phone' => auth()->user()->no_tlp,
            'order_items'    => [
                [
                    'sku'         => $kode_booking,
                    'name'        => $paket,
                    'price'       => $total,
                    'quantity'    => 1,
                ]
            ],
            'callback_url'      => url('wedding_callback'),
            'return_url'        => url('wedding_return', $kode_booking),
            'expired_time' => (time() + ($set_sistem->value_3 * 60 * 60)), // 6 jam
            'signature'    => hash_hmac('sha256', $merchantCode.$merchantRef.$amount, $privateKey)
        ];
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_FRESH_CONNECT  => true,
            CURLOPT_URL            => "https://tripay.co.id/$mode/transaction/create",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$apiKey],
            CURLOPT_FAILONERROR    => false,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($data),
            CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4
        ]);
        $response = json_decode(curl_exec($curl));
        $error = curl_error($curl);
        curl_close($curl);
        if ($response->success == false) {
            throw \Illuminate\Validation\ValidationException::withMessages([$response->message . ', atau pilih metode pembayaran manual.']);
        } else {
            $response = $response->data;
            return $response ? $response : $error;
        }
    }

    public static function createTransaksiUndangan($kode_undangan, $method, $total, $paket)
    {
        $set_sistem = SettingApp::find(1);
        $mode         = config('payment.tripay_mode');
        $apiKey       = config('payment.tripay_api');
        $privateKey   = config('payment.tripay_private');
        $merchantCode = config('payment.tripay_kode');
        $merchantRef  = $kode_undangan;
        $amount       = $total;
        $data = [
            'method'         => $method,
            'merchant_ref'   => $merchantRef,
            'amount'         => $amount,
            'customer_name'  => auth()->user()->nama,
            'customer_email' => auth()->user()->email,
            'customer_phone' => auth()->user()->no_tlp,
            'order_items'    => [
                [
                    'sku'         => $kode_undangan,
                    'name'        => $paket,
                    'price'       => $total,
                    'quantity'    => 1,
                ]
            ],
            'callback_url'      => url('undangan_callback'),
            'return_url'        => url('undangan_return', $kode_undangan),
            'expired_time' => (time() + ($set_sistem->value_3 * 60 * 60)),
            'signature'    => hash_hmac('sha256', $merchantCode.$merchantRef.$amount, $privateKey)
        ];
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_FRESH_CONNECT  => true,
            CURLOPT_URL            => "https://tripay.co.id/$mode/transaction/create",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$apiKey],
            CURLOPT_FAILONERROR    => false,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($data),
            CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4
        ]);
        $response = json_decode(curl_exec($curl));
        $error = curl_error($curl);
        curl_close($curl);
        if ($response->success == false) {
            throw \Illuminate\Validation\ValidationException::withMessages([$response->message . ', atau pilih metode pembayaran manual.']);
        } else {
            $response = $response->data;
            return $response ? $response : $error;
        }
    }

    public static function createTransaksiSelfPhoto($kode_selfphoto, $method, $total, $paket)
    {
        $set_sistem = SettingApp::find(1);
        $mode         = config('payment.tripay_mode');
        $apiKey       = config('payment.tripay_api');
        $privateKey   = config('payment.tripay_private');
        $merchantCode = config('payment.tripay_kode');
        $merchantRef  = $kode_selfphoto;
        $amount       = $total;
        $data = [
            'method'         => $method,
            'merchant_ref'   => $merchantRef,
            'amount'         => $amount,
            'customer_name'  => auth()->user()->nama,
            'customer_email' => auth()->user()->email,
            'customer_phone' => auth()->user()->no_tlp,
            'order_items'    => [
                [
                    'sku'         => $kode_selfphoto,
                    'name'        => $paket,
                    'price'       => $total,
                    'quantity'    => 1,
                ]
            ],
            'callback_url'      => url('selfphoto_callback'),
            'return_url'        => url('selfphoto_return', $kode_selfphoto),
            'expired_time' => (time() + ($set_sistem->value_3 * 60 * 60)),
            'signature'    => hash_hmac('sha256', $merchantCode.$merchantRef.$amount, $privateKey)
        ];
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_FRESH_CONNECT  => true,
            CURLOPT_URL            => "https://tripay.co.id/$mode/transaction/create",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$apiKey],
            CURLOPT_FAILONERROR    => false,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($data),
            CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4
        ]);
        $response = json_decode(curl_exec($curl));
        $error = curl_error($curl);
        curl_close($curl);
        if ($response->success == false) {
            throw \Illuminate\Validation\ValidationException::withMessages([$response->message . ', atau pilih metode pembayaran manual.']);
        } else {
            $response = $response->data;
            return $response ? $response : $error;
        }
    }

    public static function getTransaksi($no_ref)
    {
        $mode = config('payment.tripay_mode');
        $apiKey = config('payment.tripay_api');
        $payload = ['reference'	=> $no_ref];
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_FRESH_CONNECT  => true,
            CURLOPT_URL            => "https://tripay.co.id/$mode/transaction/detail?".http_build_query($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$apiKey],
            CURLOPT_FAILONERROR    => false,
            CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4
        ]);
        $response = curl_exec($curl);
        $error = curl_error($curl);
        curl_close($curl);
        $response = json_decode($response)->data->status;
        return $response ? $response : $error;
    }
}
