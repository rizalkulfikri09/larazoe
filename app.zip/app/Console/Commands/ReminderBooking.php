<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class ReminderBooking extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'booking:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Kirim pesan pengingat booking studio foto H-1 kepada konsumen';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        return \App\Traits\NotifikasiTrait::sendReminder();
    }
}
