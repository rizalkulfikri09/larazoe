<?php

namespace App\Console\Commands;

use App\Models\Studio;
use App\Models\Undangan;
use App\Models\SelfPhoto;
use App\Models\SettingApp;
use Illuminate\Support\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class UpdateBooking extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'booking:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update dan delete booking studio';

    public function hapusFotoUndangan($kode_undangan)
    {
        $data_pengantin = \App\Models\UndanganPengantin::where('kode_undangan', '=', $kode_undangan)->first();
        if ($data_pengantin) {
            File::delete(public_path('/frontend/undangan/foto_pengantin/' . $data_pengantin->foto_pria));
            File::delete(public_path('/frontend/undangan/foto_pengantin/' . $data_pengantin->foto_wanita));
        }
        $data_undangan = \App\Models\UndanganDetail::where('kode_undangan', '=', $kode_undangan)->first();
        if ($data_undangan) {
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_1));
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_2));
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_3));
            File::delete(public_path('/frontend/undangan/foto_slider/' . $data_undangan->foto_slider_4));
        }
        $data_galeri = \App\Models\UndanganGaleri::where('kode_undangan', '=', $kode_undangan)->get();
        if ($data_galeri) {
            foreach ($data_galeri as $galeri) {
                File::delete(public_path('/frontend/undangan/foto_galeri/' . $galeri->foto));
            }
        }
        $data_cerita = \App\Models\UndanganCerita::where('kode_undangan', '=', $kode_undangan)->get();
        if ($data_cerita) {
            foreach ($data_cerita as $foto) {
                File::delete(public_path('/frontend/undangan/foto_cerita/' . $foto->foto_cerita));
            }
        }
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $jam_expired = (int) SettingApp::find(1)->value_3;
        $zona_waktu = (int) SettingApp::find(5)->value_5;
        $time_now = gmdate('Y-m-d H:i:s', (time() + (60 * 60 * $zona_waktu)));

        DB::transaction(function () use ($jam_expired, $time_now, $zona_waktu) {
            Studio::select('status_booking', 'status_bayar', 'tgl_booking')->where('tgl_booking', '<=', gmdate('Y-m-d', time() + (60 * 60 * $zona_waktu)))->whereIn('status_bayar', ['Lunas', 'DP'])->update(['status_booking' => 'Selesai']);
            Studio::select('status_bayar', 'created_at')->whereRaw("DATE_ADD(created_at, INTERVAL $jam_expired HOUR) < '$time_now'")->where('status_bayar', '=', 'Belum Dibayar')->delete();
        });

        DB::transaction(function () use ($jam_expired, $time_now, $zona_waktu) {
            SelfPhoto::select('status_booking', 'status_bayar', 'tgl_booking')->where('tgl_booking', '<=', gmdate('Y-m-d', time() + (60 * 60 * $zona_waktu)))->whereIn('status_bayar', ['Lunas', 'DP'])->update(['status_booking' => 'Selesai']);
            SelfPhoto::select('status_bayar', 'created_at')->whereRaw("DATE_ADD(created_at, INTERVAL $jam_expired HOUR) < '$time_now'")->where('status_bayar', '=', 'Belum Dibayar')->delete();
        });

        DB::transaction(function () use ($jam_expired, $time_now) {
            $get_undangan = Undangan::select('kode', 'status_bayar', 'id_paket', 'created_at')->where('status_bayar', '=', 'Lunas')->get();
            foreach ($get_undangan as $row) {
                $masa_aktif = Carbon::parse($row->created_at)->addDays($row->paket->durasi)->translatedFormat('Y-m-d H:i:s');
                if ($masa_aktif < $time_now) {
                    try {
                        $this->hapusFotoUndangan($row->kode);
                    } catch (\Exception $e) { }
                    Undangan::select('kode')->where('kode', $row->kode)->delete();
                }
            }
            Undangan::select('status_bayar', 'created_at')->whereRaw("DATE_ADD(created_at, INTERVAL $jam_expired HOUR) < '$time_now'")->where('status_bayar', '=', 'Belum Dibayar')->delete();
        });
    }
}
