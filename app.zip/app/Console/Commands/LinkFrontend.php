<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class LinkFrontend extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'link:frontend {folder_tujuan}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $folder_tujuan = $this->argument('folder_tujuan');
        $src = base_path("public/frontend");
        $dst = dirname(base_path())."/{$folder_tujuan}";
        $src_public = base_path("public");
        exec("mv {$src_public}/.htaccess {$dst}/");
        exec("mv {$src_public}/favicon.ico {$dst}/");
        exec("mv {$src_public}/index.php {$dst}/");
        exec("mv {$src_public}/robots.txt {$dst}/");
        exec("ln -s {$src} {$dst}");
        $this->info("Linked {$src} to {$dst}");
    }
}
