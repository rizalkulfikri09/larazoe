<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $settingApp = null;
        try {
            $settingApp = \App\Models\SettingApp::find(5);
        } catch (\Throwable $th) { }
        \Carbon\Carbon::setLocale('id');
        config(['app.locale' => 'id']);
        $timezone_map = [
            '7' => 'Asia/Jakarta',
            '8' => 'Asia/Makassar',
            '9' => 'Asia/Jayapura',
        ];
        if ($settingApp) {
            date_default_timezone_set($timezone_map[$settingApp->value_5]);
            \Illuminate\Support\Facades\View::share('set_umum', $settingApp);
        }
    }
}
