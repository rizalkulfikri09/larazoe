<?php

namespace App\Exports;

use App\Models\Wedding;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromView;

class WeddingExport implements FromView
{
    public function __construct()
    {
        $this->query = Wedding::select(['kode', 'nama', 'no_tlp', 'alamat', 'paket', 'status_booking', 'status_bayar', 'tgl_wedding', 'jml_dp', 'cs', 'total'])
        ->when(session()->get('session_sbo'), function ($query) {
            $query->where('status_booking', '=', session()->get('session_sbo'));
        })
        ->when(session()->get('session_dp'), function ($query) {
            $query->where('paket', '=', session()->get('session_dp'));
        })
        ->when(session()->get('session_sba'), function ($query) {
            $query->where('status_bayar', '=', session()->get('session_sba'));
        })
        ->when(session()->get('tanggal_1'), function ($query) {
            $query->where('tgl_wedding', '>=', session()->get('tanggal_1'))->where('tgl_wedding', '<=', session()->get('tanggal_2'));
        })->get();
        $this->sum_total = $this->query->sum('total');
    }

    public function view(): View
    {
        return view('cetak.wedding_excel', [
            'data_booking' => $this->query,
            'sum_total' => $this->sum_total,
        ]);
    }

    public function export_excel()
    {
        return Excel::download(new WeddingExport, 'daftar_wedding_'.date("dmy").'.xlsx');
    }

    public function export_pdf()
    {
        $pdf = PDF::loadView('cetak.wedding_pdf', [
            'data_booking' => $this->query,
            'sum_total' => $this->sum_total,
        ]);
        $pdf->setPaper('A4', 'landscape');
        return $pdf->download('daftar_wedding_'.date("dmy").'.pdf');
    }
}
