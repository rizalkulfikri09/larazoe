<?php

namespace App\Exports;

use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromView;

class UsersExport implements FromView
{
    public function view(): View
    {
        return view('cetak.konsumen_excel', [
            'users' => User::select(['nama', 'no_tlp', 'email', 'role_id', 'is_active'])->whereNot('role_id', '1')->get(),
        ]);
    }

    public static function export_excel()
    {
        return Excel::download(new UsersExport, 'daftar_konsumen_'.date("dmy").'.xlsx');
    }

    public static function export_pdf()
    {
        $pdf = PDF::loadView('cetak.konsumen_pdf', [
            'users' => User::select(['nama', 'no_tlp', 'email', 'role_id', 'is_active'])->whereNot('role_id', '1')->get(),
        ]);

        return $pdf->download('daftar_konsumen_'.date("dmy").'.pdf');
    }
}
