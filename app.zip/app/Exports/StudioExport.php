<?php

namespace App\Exports;

use App\Models\Studio;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromView;

class StudioExport implements FromView
{
    public function __construct()
    {
        $this->query = Studio::select(['kode', 'nama', 'no_tlp', 'paket', 'status_booking', 'status_bayar', 'jml_orang', 'jml_dp', 'tgl_booking', 'jam_booking', 'cs', 'total'])
        ->when(session()->get('session_sbo'), function ($query) {
            $query->where('status_booking', '=', session()->get('session_sbo'));
        })
        ->when(session()->get('session_dp'), function ($query) {
            $query->where('paket', '=', session()->get('session_dp'));
        })
        ->when(session()->get('session_sba'), function ($query) {
            $query->where('status_bayar', '=', session()->get('session_sba'));
        })
        ->when(session()->get('tanggal_1'), function ($query) {
            $query->where('tgl_booking', '>=', session()->get('tanggal_1'))->where('tgl_booking', '<=', session()->get('tanggal_2'));
        })->get();
        $this->sum_total = $this->query->sum('total');
    }

    public function view(): View
    {
        return view('cetak.studio_excel', [
            'data_booking' => $this->query,
            'sum_total' => $this->sum_total,
        ]);
    }

    public function export_excel()
    {
        return Excel::download(new StudioExport, 'daftar_booking_'.date("dmy").'.xlsx');
    }

    public function export_pdf()
    {
        $pdf = PDF::loadView('cetak.studio_pdf', [
            'data_booking' => $this->query,
            'sum_total' => $this->sum_total,
        ]);
        $pdf->setPaper('A4', 'landscape');
        return $pdf->download('daftar_booking_'.date("dmy").'.pdf');
    }
}
