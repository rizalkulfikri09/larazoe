<?php

namespace App\Exports;

use App\Models\Undangan;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromView;

class UndanganExport implements FromView
{
    public function __construct()
    {
        $this->query = Undangan::with(['paket', 'user', 'transaksi', 'tema'])
        ->when(session()->get('status_undangan'), function ($query) {
            $query->where('status_undangan', '=', session()->get('status_undangan'));
        })
        ->when(session()->get('id_paket'), function ($query) {
            $query->where('id_paket', '=', session()->get('id_paket'));
        })
        ->when(session()->get('status_bayar'), function ($query) {
            $query->where('status_bayar', '=', session()->get('status_bayar'));
        })
        ->when(session()->get('id_tema'), function ($query) {
            $query->where('id_tema', '=', session()->get('id_tema'));
        })->get();
        $this->sum_total = $this->query->sum('paket.harga');
    }

    public function view(): View
    {
        return view('cetak.undangan_excel', [
            'data_undangan' => $this->query,
            'sum_total' => $this->sum_total,
        ]);
    }

    public function export_excel()
    {
        return Excel::download(new UndanganExport, 'daftar_undangan_'.date("dmy").'.xlsx');
    }

    public function export_pdf()
    {
        $pdf = PDF::loadView('cetak.undangan_pdf', [
            'data_undangan' => $this->query,
            'sum_total' => $this->sum_total,
        ]);
        $pdf->setPaper('A4', 'landscape');
        return $pdf->download('daftar_undangan_'.date("dmy").'.pdf');
    }
}
