<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UndanganGaleri extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'undangan_galeri';
    protected $fillable = ['kode_undangan', 'foto'];

    public function undangan()
    {
        return $this->belongsTo(Undangan::class);
    }
}
