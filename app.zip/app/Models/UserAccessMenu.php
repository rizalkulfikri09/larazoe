<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserAccessMenu extends Model
{
    public $timestamps = false;
    protected $table = 'user_access_menu';
    protected $guarded = ['id'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function menu()
    {
        return $this->belongsTo(Menu::class);
    }
}
