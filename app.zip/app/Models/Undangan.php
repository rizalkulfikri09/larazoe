<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Undangan extends Model
{
    use HasFactory;

    protected $table = 'undangan';
    protected $fillable = ['kode', 'user_id', 'nama_pria', 'full_nama_pria', 'nama_wanita', 'full_nama_wanita', 'link', 'status_undangan', 'status_bayar', 'warna_undangan', 'id_tema', 'id_paket'];

    public function paket()
    {
        return $this->belongsTo(UndanganPaket::class, 'id_paket');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function transaksi()
    {
        return $this->hasOne(Transaksi::class, 'kode_undangan', 'kode');
    }

    public function tema()
    {
        return $this->belongsTo(UndanganTema::class, 'id_tema');
    }

    public function slider()
    {
        return $this->hasOne(UndanganDetail::class, 'kode_undangan', 'kode');
    }

    public function pengantin()
    {
        return $this->hasOne(UndanganPengantin::class, 'kode_undangan', 'kode');
    }

    public function cerita()
    {
        return $this->hasMany(UndanganCerita::class, 'kode_undangan', 'kode');
    }

    public function galeri()
    {
        return $this->hasMany(UndanganGaleri::class, 'kode_undangan', 'kode');
    }

    public function tempat()
    {
        return $this->hasMany(UndanganTempat::class, 'kode_undangan', 'kode');
    }

    public function ucapan()
    {
        return $this->hasMany(UndanganUcapan::class, 'kode_undangan', 'kode');
    }
}
