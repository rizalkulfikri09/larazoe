<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UndanganPengantin extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'undangan_pengantin';
    protected $fillable = ['kode_undangan', 'foto_pria', 'foto_wanita', 'ortu_pria', 'anak_of_pria', 'ortu_wanita', 'anak_of_wanita', 'ig_pria', 'twitter_pria', 'fb_pria', 'ig_wanita', 'twitter_wanita', 'fb_wanita'];

    public function undangan()
    {
        return $this->belongsTo(Undangan::class);
    }
}
