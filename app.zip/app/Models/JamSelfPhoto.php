<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class JamSelfPhoto extends Model
{
    protected $table = 'jam_selfphoto';
    protected $fillable = ['jam', 'status'];

    public static function ambilJam($tgl_booking)
    {
        $tgl = strip_tags($tgl_booking);
        return JamSelfPhoto::select('id', 'jam')
            ->whereNotExists(function ($query) use ($tgl) {
                $query->select(DB::raw(1))
                    ->from('booking_self')
                    ->whereRaw('booking_self.id_sesi = jam_selfphoto.id')
                    ->where('tgl_booking', $tgl)
                    ->groupBy('id_sesi')
                    ->having(DB::raw('COUNT(id_sesi)'), '=', 1);
            })
            ->where('status', '!=', date('w', strtotime($tgl_booking)))
            ->orderBy('jam', 'ASC')
            ->get();
    }
}
