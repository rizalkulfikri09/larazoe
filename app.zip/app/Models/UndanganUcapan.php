<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UndanganUcapan extends Model
{
    use HasFactory;

    protected $table = 'undangan_ucapan';
    protected $fillable = ['kode_undangan', 'nama_tamu', 'ucapan', 'kehadiran', 'ip_address'];

    public function undangan()
    {
        return $this->belongsTo(Undangan::class);
    }
}
