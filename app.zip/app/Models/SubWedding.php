<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class SubWedding extends Model
{
    protected $table = 'sub_wedding';
    protected $guarded = ['id'];

    public static function getSubPaketWedding()
    {
        return DB::table('sub_wedding')->select('sub_wedding.*', 'paket_wedding.nama_paket')->join('paket_wedding', 'paket_wedding.id', '=', 'sub_wedding.id_paket')->get();
    }
}
