<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UndanganTema extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'undangan_tema';
    protected $fillable = ['nama_tema', 'thumbnail', 'preview', 'aspect_ratio', 'width_slider', 'height_slider', 'is_active'];

    public function undangan()
    {
        return $this->hasOne(Undangan::class);
    }
}
