<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubMenu extends Model
{
    public $timestamps = false;
    protected $table = 'sub_menu';
    protected $guarded = ['id'];

    public function menu()
    {
        return $this->belongsTo(Menu::class);
    }

    public static function getSubMenu()
    {
        return SubMenu::select('sub_menu.*', 'menu.menu')->join('menu', 'menu.id', '=', 'sub_menu.menu_id')->get();
    }
}
