<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UndanganCerita extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'undangan_cerita';
    protected $fillable = ['kode_undangan', 'foto_cerita', 'judul_cerita', 'waktu_cerita', 'isi_cerita'];

    public function undangan()
    {
        return $this->belongsTo(Undangan::class);
    }
}
