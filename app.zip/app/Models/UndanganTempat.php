<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UndanganTempat extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'undangan_tempat';
    protected $fillable = ['kode_undangan', 'nama_acara', 'tanggal_acara', 'tempat_acara', 'alamat_acara', 'link_maps', 'nama_bank', 'nomor_rekening', 'pemilik_rekening'];

    public function undangan()
    {
        return $this->belongsTo(Undangan::class);
    }
}
