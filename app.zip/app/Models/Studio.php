<?php

namespace App\Models;

use Illuminate\Support\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Studio extends Model
{
    use HasFactory;

    protected $table = 'booking_studio';

    protected $fillable = [
        'kode',
        'nama',
        'no_tlp',
        'paket',
        'status_booking',
        'status_bayar',
        'jml_dp',
        'total',
        'jml_orang',
        'tgl_booking',
        'jam_booking',
        'cs',
        'id_sesi',
    ];

    public function kalender()
    {
        return Studio::select('nama', 'status_booking', 'tgl_booking', 'jam_booking')->whereBetween('tgl_booking', [Carbon::now()->startOfMonth()->subDays(30)->format('Y-m-d'), Carbon::now()->endOfMonth()->addDays(30)->format('Y-m-d')])->whereIn('status_bayar', ['DP', 'Lunas'])->get();
    }
}
