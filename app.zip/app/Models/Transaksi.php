<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaksi extends Model
{
    protected $table = 'transaksi';
    protected $fillable = ['kode_booking', 'kode_wedding', 'kode_undangan', 'kode_selfphoto', 'no_ref', 'link', 'status'];

    public function undangan()
    {
        return $this->belongsTo(Undangan::class);
    }

    public function selfphoto()
    {
        return $this->belongsTo(SelfPhoto::class);
    }
}
