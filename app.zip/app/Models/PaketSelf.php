<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PaketSelf extends Model
{
    use HasFactory;

    protected $table = 'paket_self';
    protected $guarded = ['id'];
}
