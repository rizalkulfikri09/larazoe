<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class SubPaket extends Model
{
    protected $table = 'sub_paket';
    protected $guarded = ['id'];

    public static function getSubPaket()
    {
        return DB::table('sub_paket')->select('sub_paket.*', 'paket.nama_paket')->join('paket', 'paket.id', '=', 'sub_paket.id_paket')->get();
    }

    public static function getSubPaketById($id)
    {
        return DB::table('sub_paket')->select('sub_paket.*', 'paket.*')->join('paket', 'paket.id', '=', 'sub_paket.id_paket')->where('sub_paket.id', '=', $id)->first();
    }
}
