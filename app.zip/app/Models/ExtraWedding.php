<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExtraWedding extends Model
{
    protected $table = 'extra_wedding';
    protected $guarded = ['id'];
}
