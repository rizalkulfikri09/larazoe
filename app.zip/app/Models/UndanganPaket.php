<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UndanganPaket extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'undangan_paket';
    protected $fillable = ['durasi', 'harga', 'is_active'];

    public function undangan()
    {
        return $this->hasOne(Undangan::class);
    }
}
