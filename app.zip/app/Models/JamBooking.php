<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class JamBooking extends Model
{
    protected $table = 'jam_booking';
    protected $fillable = ['jam', 'status'];

    public static function ambilJam($tgl_booking)
    {
        $tgl = strip_tags($tgl_booking);
        $jml_konsumen = SettingApp::find(2);
        return JamBooking::select('id', 'jam')
            ->whereNotExists(function ($query) use ($tgl, $jml_konsumen) {
                $query->select(DB::raw(1))
                    ->from('booking_studio')
                    ->whereRaw('booking_studio.id_sesi = jam_booking.id')
                    ->where('tgl_booking', $tgl)
                    ->groupBy('id_sesi')
                    ->having(DB::raw('COUNT(id_sesi)'), '=', $jml_konsumen->value_1);
            })
            ->where('status', '!=', date('w', strtotime($tgl_booking)))
            ->orderBy('jam', 'ASC')
            ->get();
    }
}
