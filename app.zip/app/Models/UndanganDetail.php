<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UndanganDetail extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'undangan_detail';
    protected $fillable = ['kode_undangan', 'tanggal_nikah', 'foto_wanita', 'kalimat_pembuka', 'status_slider', 'foto_slider_1', 'title_slider_1', 'foto_slider_2', 'title_slider_2', 'foto_slider_3', 'title_slider_3', 'foto_slider_4', 'title_slider_4', 'link_youtube', 'musik'];

    public function undangan()
    {
        return $this->belongsTo(Undangan::class, 'kode');
    }
}
