<?php

use App\Models\Menu;
use App\Models\Studio;
use App\Models\SubPaket;
use App\Models\SettingApp;
use Illuminate\Support\Carbon;

function getMenu() {
    return auth()->user()->accessMenus()->with('menu')->get();
}

function getSubMenu($menu_id) {
    $_menu_id = strip_tags($menu_id);
    return Menu::find($_menu_id)->submenus()->where('is_active', 1)->get();
}

if (! function_exists('statusJam')) {
    function statusJam($value) {
        switch ($value) {
            case '7':
                echo 'Buka Setiap Hari';
            break;
            case '1':
                echo 'Tutup Senin';
            break;
            case '2':
                echo 'Tutup Selasa';
            break;
            case '3':
                echo 'Tutup Rabu';
            break;
            case '4':
                echo 'Tutup Kamis';
            break;
            case '5':
                echo 'Tutup Jumat';
            break;
            case '6':
                echo 'Tutup Sabtu';
            break;
            case '0':
                echo 'Tutup Minggu';
            break;
        }
    }
}

if (! function_exists('kode_studio')) {
    function kode_studio() {
        $idTerakhir = \App\Models\Studio::max('id');
        $id = $idTerakhir == NULL ? 0 : $idTerakhir;
        $karakter = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $panjangKarakter = strlen($karakter);
        $kode_studio = '';
        for ($i = 0; $i < 5; $i++) {
            $kode_studio .= $karakter[rand(0, $panjangKarakter - 1)];
        }
        return substr($id,-1,1).$kode_studio;
    }
}

if (! function_exists('kode_wedding')) {
    function kode_wedding() {
        $idTerakhir = \App\Models\Wedding::max('id');
        $id = $idTerakhir == NULL ? 0 : $idTerakhir;
        $karakter = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $panjangKarakter = strlen($karakter);
        $kode_wedding = '';
        for ($i = 0; $i < 5; $i++) {
            $kode_wedding .= $karakter[rand(0, $panjangKarakter - 1)];
        }
        return substr($id,-1,1).$kode_wedding;
    }
}

if (! function_exists('kode_undangan')) {
    function kode_undangan() {
        $idTerakhir = \App\Models\Undangan::max('id');
        $id = $idTerakhir == NULL ? 0 : $idTerakhir;
        $karakter = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $panjangKarakter = strlen($karakter);
        $kode_undangan = '';
        for ($i = 0; $i < 5; $i++) {
            $kode_undangan .= $karakter[rand(0, $panjangKarakter - 1)];
        }
        return substr($id,-1,1).$kode_undangan;
    }
}

if (! function_exists('kode_selfphoto')) {
    function kode_selfphoto() {
        $idTerakhir = \App\Models\SelfPhoto::max('id');
        $id = $idTerakhir == NULL ? 0 : $idTerakhir;
        $karakter = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $panjangKarakter = strlen($karakter);
        $kode_selfphoto = '';
        for ($i = 0; $i < 5; $i++) {
            $kode_selfphoto .= $karakter[rand(0, $panjangKarakter - 1)];
        }
        return substr($id,-1,1).$kode_selfphoto;
    }
}

if (! function_exists('format_rupiah')) {
    function format_rupiah($str) {
        return "Rp " . number_format($str,0,',','.');
    }
}

if (! function_exists('change_rupiah')) {
    function change_rupiah($str) {
        switch ($str) {
            case (substr($str,0,2) == "Rp"):
                $result = str_replace(".", "", substr($str, 3));
                break;
            default:
                $result = $str;
                break;
        }
        return $result;
    }
}

if (! function_exists('jam_reschedule')) {
    function jam_reschedule($jam_booking, $kode) {
        $get_jam_booking = Studio::where('kode', '=', $kode)->first()->jam_booking;
        $jam_mulai = Carbon::createFromFormat('H:i', substr($get_jam_booking, 0, 5));
        $jam_selesai = Carbon::createFromFormat('H:i', substr($get_jam_booking, -5));
        $durasi = $jam_selesai->diffInMinutes($jam_mulai);
        $jam_akhir = Carbon::createFromFormat('H:i', $jam_booking);
        $jam_akhir->addMinutes($durasi);
        return $jam_booking.' - '.$jam_akhir->format('H:i');
    }
}

if (! function_exists('jam_pemotretan')) {
    function jam_pemotretan($jam_booking) {
        $get_sub_paket = SubPaket::where('id', '=', session()->get('id_sub_paket'))->first();
        $jam_akhir = Carbon::createFromFormat('H:i', $jam_booking);
        $jam_akhir->addMinutes($get_sub_paket->durasi);
        return $jam_booking.' - '.$jam_akhir->format('H:i');
    }
}

if (! function_exists('jam_selfphoto')) {
    function jam_selfphoto($jam_booking) {
        $get_paket = \App\Models\PaketSelf::where('id', '=', session()->get('id_paket'))->first();
        $jam_akhir = Carbon::createFromFormat('H:i', $jam_booking);
        $jam_akhir->addMinutes($get_paket->durasi);
        return $jam_booking.' - '.$jam_akhir->format('H:i');
    }
}

if (! function_exists('resjam_selfphoto')) {
    function resjam_selfphoto($jam_booking, $kode) {
        $get_jam_booking = \App\Models\SelfPhoto::where('kode', '=', $kode)->first()->jam_booking;
        $jam_mulai = Carbon::createFromFormat('H:i', substr($get_jam_booking, 0, 5));
        $jam_selesai = Carbon::createFromFormat('H:i', substr($get_jam_booking, -5));
        $durasi = $jam_selesai->diffInMinutes($jam_mulai);
        $jam_akhir = Carbon::createFromFormat('H:i', $jam_booking);
        $jam_akhir->addMinutes($durasi);
        return $jam_booking.' - '.$jam_akhir->format('H:i');
    }
}

if (! function_exists('color_status')) {
    function color_status($value) {
        switch ($value) {
            case ($value != 'Selesai'):
                $color = "#C80303";
                break;
            default:
                $color = "#01AA41";
                break;
        }
        return $color;
    }
}

if (! function_exists('rating')) {
    function rating($value) {
        $star_1 = $value >= 1 ? '<i class="bi bi-star-fill"></i>' : '<i class="bi bi-star"></i>';
        $star_2 = $value >= 2 ? '<i class="bi bi-star-fill"></i>' : '<i class="bi bi-star"></i>';
        $star_3 = $value >= 3 ? '<i class="bi bi-star-fill"></i>' : '<i class="bi bi-star"></i>';
        $star_4 = $value >= 4 ? '<i class="bi bi-star-fill"></i>' : '<i class="bi bi-star"></i>';
        $star_5 = $value >= 5 ? '<i class="bi bi-star-fill"></i>' : '<i class="bi bi-star"></i>';
        return $star_1 . $star_2 . $star_3 . $star_4 . $star_5;
    }
}

if (! function_exists('nominal_dp')) {
    function nominal_dp($value) {
        $data = SettingApp::find(3);
        return ($data->value_4/100)*$value;
    }
}

if (! function_exists('convert_durasi')) {
    function convert_durasi($value) {
        if ($value < 360) {
            $_bulan = ($value % 365) / 30.5;
            $bulan = round($_bulan);
            return $bulan . ' Bulan';
        } else if ($value >= 360 && $value < 395) {
            return '1 Tahun';
        } else {
            $_tahun = ($value / 365);
            $tahun = round($_tahun);
            $_bulan = ($value % 365) / 30.5;
            $bulan = round($_bulan);
            return $tahun . ' Tahun ' . $bulan . ' Bulan';
        }
    }
}
