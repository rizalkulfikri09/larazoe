<?php

use App\Models\Testimoni;
use App\Models\Transaksi;
use App\Models\SettingApp;
use Illuminate\Support\Facades\DB;

if (! function_exists('check_access')) {
    function check_access($role_id, $menu_id) {
        $result = DB::table('user_access_menu')->where('role_id', '=', $role_id)->where('menu_id', '=', $menu_id)->get();

        if ($result->count() > 0) {
            return "checked='checked'";
        }
    }
}

if (! function_exists('hapus_session')) {
    function hapus_session() {
        session()->forget(['id_paket', 'id_sub_paket', 'jml_orang', 'tgl_booking', 'id_jam', 'id_extra_paket', 'transport', 'tgl_wedding', 'alamat', 'code_pay']);
    }
}

if (! function_exists('hapus_session_undangan')) {
    function hapus_session_undangan() {
        session()->forget(['id_paket', 'id_tema']);
    }
}

if (! function_exists('hapus_session_self')) {
    function hapus_session_self() {
        session()->forget(['add_ons', 'id_paket', 'jml_orang', 'tgl_booking', 'id_sesi', 'code_pay']);
    }
}

if (! function_exists('button_studio')) {
    function button_studio($status_booking, $status_bayar, $kode) {
        $get_transaksi = Transaksi::where('kode_booking', '=', $kode)->first();
        $get_testimoni = Testimoni::where('kode', '=', $kode)->first();
        switch ($status_booking) {
            case ($status_booking != 'Selesai' && isset($get_transaksi->kode_booking)):
                return '<a href="riwayat_booking/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a>';
                break;
            case ($status_booking == 'Dipesan' && $status_bayar == 'Lunas'):
                return '<a href="riwayat_booking/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a>';
                break;
            case ($status_booking == 'Dipesan' && $status_bayar == 'DP'):
                return '<a href="riwayat_booking/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a>';
                break;
            case ($status_booking == 'Selesai' && !isset($get_testimoni)):
                return '<a href="riwayat_booking/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a><a href="testimoni/'.$kode.'" class="btn btn-warning btn-sm tombol">Rating</a>';
                break;
            case ($status_booking == 'Selesai'):
                return '<a href="riwayat_booking/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteBooking" data-kode="'.$kode.'">Hapus</a>';
                break;
            default:
                return '<a href="riwayat_booking/'.$kode.'" class="btn btn-success btn-sm tombol">Bayar</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteBooking" data-kode="'.$kode.'">Batal</a>';
                break;
        }
    }
}

if (! function_exists('button_wedding')) {
    function button_wedding($status_booking, $status_bayar, $kode) {
        $get_transaksi = Transaksi::where('kode_wedding', '=', $kode)->first();
        switch ($status_booking) {
            case ($status_booking != 'Selesai' && isset($get_transaksi->kode_wedding)):
                return '<a href="riwayat_wedding/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a>';
                break;
            case ($status_booking == 'Dipesan' && $status_bayar == 'Lunas'):
                return '<a href="riwayat_wedding/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a>';
                break;
            case ($status_booking == 'Dipesan' && $status_bayar == 'DP'):
                return '<a href="riwayat_wedding/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a>';
                break;
            case ($status_booking == 'Selesai'):
                return '<a href="riwayat_wedding/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteBooking" data-kode="'.$kode.'">Hapus</a>';
                break;
            default:
                return '<a href="riwayat_wedding/'.$kode.'" class="btn btn-success btn-sm tombol">Bayar</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteBooking" data-kode="'.$kode.'">Batal</a>';
                break;
        }
    }
}

if (! function_exists('button_undangan')) {
    function button_undangan($status_bayar, $kode) {
        $get_transaksi = Transaksi::select('kode_undangan')->where('kode_undangan', '=', $kode)->first();
        $data_undangan = \App\Models\UndanganDetail::select('kode_undangan')->where('kode_undangan', '=', $kode)->first();
        $data_galeri = \App\Models\UndanganGaleri::select('kode_undangan')->where('kode_undangan', '=', $kode)->first();
        $data_cerita = \App\Models\UndanganCerita::select('kode_undangan')->where('kode_undangan', '=', $kode)->first();
        switch ($status_bayar) {
            case ("Lunas"):
                return '<a href="detail_undangan/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteUndangan" data-kode="'.$kode.'">Hapus</a>';
                break;
            case ("Belum Dibayar" && isset($get_transaksi)):
                return '<a href="detail_undangan/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a>';
                break;
            case ("Belum Dibayar" && !isset($data_undangan)):
                return '<a href="data_undangan/'.$kode.'" class="btn btn-success btn-sm tombol">Isi Data</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteUndangan" data-kode="'.$kode.'">Batal</a>';
                break;
            case ("Belum Dibayar" && !isset($data_galeri)):
                return '<a href="data_galeri/'.$kode.'" class="btn btn-success btn-sm tombol">Isi Data</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteUndangan" data-kode="'.$kode.'">Batal</a>';
                break;
            case ("Belum Dibayar" && !isset($data_cerita)):
                return '<a href="data_cerita/'.$kode.'" class="btn btn-success btn-sm tombol">Isi Data</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteUndangan" data-kode="'.$kode.'">Batal</a>';
                break;
            default:
            return '<a href="detail_undangan/'.$kode.'" class="btn btn-success btn-sm tombol">Bayar</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteUndangan" data-kode="'.$kode.'">Batal</a>';
                break;
        }
    }
}

if (! function_exists('button_self')) {
    function button_self($status_booking, $status_bayar, $kode) {
        $get_transaksi = Transaksi::where('kode_selfphoto', '=', $kode)->first();
        $get_testimoni = Testimoni::where('kode', '=', $kode)->first();
        switch ($status_booking) {
            case ($status_booking != 'Selesai' && isset($get_transaksi->kode_selfphoto)):
                return '<a href="riwayat_selfphoto/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a>';
                break;
            case ($status_booking == 'Dipesan' && $status_bayar == 'Lunas'):
                return '<a href="riwayat_selfphoto/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a>';
                break;
            case ($status_booking == 'Dipesan' && $status_bayar == 'DP'):
                return '<a href="riwayat_selfphoto/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a>';
                break;
            case ($status_booking == 'Selesai' && !isset($get_testimoni)):
                return '<a href="riwayat_selfphoto/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a><a href="testimoni_selfphoto/'.$kode.'" class="btn btn-warning btn-sm tombol">Rating</a>';
                break;
            case ($status_booking == 'Selesai'):
                return '<a href="riwayat_selfphoto/'.$kode.'" class="btn btn-success btn-sm tombol">Detail</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteBooking" data-kode="'.$kode.'">Hapus</a>';
                break;
            default:
                return '<a href="riwayat_selfphoto/'.$kode.'" class="btn btn-success btn-sm tombol">Bayar</a><a href="javascript:void(0)" class="btn btn-danger btn-sm tombol deleteBooking" data-kode="'.$kode.'">Batal</a>';
                break;
        }
    }
}

if (! function_exists('tgl_reschedule')) {
    function tgl_reschedule($tgl_booking) {
        $set_sistem = SettingApp::find(1);
        $set_aplikasi = SettingApp::find(5);
        $tgl_sekarang = gmdate('Y-m-d', (time() + (60 * 60 * $set_aplikasi->value_5)));
        $tgl_min = date('Y-m-d', strtotime($tgl_booking) - ($set_sistem->value_7 * 24 * 60 * 60));
        if ($tgl_min >= $tgl_sekarang) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
}

if (! function_exists('nomor_tlp')) {
    function nomor_tlp($str) {
        return substr_replace($str,'+62',0,1);
    }
}

if (! function_exists('format_tlp')) {
    function format_tlp($str) {
        return str_replace(array("+62","62"), "0", preg_replace("/[^0-9]/", "", $str));
    }
}

if (! function_exists('notif_bayar')) {
    function notif_bayar() {
        return Transaksi::select('kode_booking', 'kode_wedding', 'kode_undangan', 'kode_selfphoto')->where([['status', '=', 'UNPAID'], ['no_ref', '=', NULL]])->orderBy('created_at', 'desc')->limit(4)->get()->toArray();
    }
}

if (! function_exists('convert_ytb')) {
    function convert_ytb($value) {
        if (preg_match("#(?<=v=)[a-zA-Z0-9-]+(?=&)|(?<=v\/)[^&\n]+|(?<=v=)[^&\n]+|(?<=youtu.be/)[^&\n]+#", $value, $matches)) {
            $youtube_id = $matches[0];
        } else {
            $youtube_id = null;
        }
        return "https://www.youtube.com/embed/" . $youtube_id;
    }
}

if (! function_exists('convert_maps')) {
    function convert_maps($value) {
        preg_match("/https:\/\/.*maps.*/", $value, $matches);
        if (count($matches) > 0) {
            return $matches[0];
        } else {
            return "Link Google Maps tidak ditemukan.";
        }
    }
}
