<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class PaketSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $paket_foto = [
            [
                'nama_paket' => 'Baby & Kid Studio',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>Baby Kiddie Tiny 1</b><br><ul><li>Maks 1 kostum - 15 Menit</li><li>5 foto edit + cetak 5R</li><li>Semua file mentah</li><li><b>Harga : Rp 125.000</b></li></ul><hr><b>Baby Kiddie Tiny 2</b><br><ul><li>Maks 1 kostum - 15 Menit</li><li>4 foto edit + cetak 5R</li><li>Semua file mentah</li><li><b>Harga : Rp 110.000</b></li></ul>',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Foto Identitas',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => 'Tidak ada',
                'is_active' => '0',
            ],
            [
                'nama_paket' => 'Grup Studio',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>Grup 2-10 Orang</b><br><ul><li>1 Kostum - 15 Menit</li><li>3 foto edit + cetak 5R Master</li><li>Semua file mentah</li></ul><hr><b>Grup 11-20 Orang</b><br><ul><li>1 Kostum - 15 Menit</li><li>3 foto edit + cetak 5R Master</li><li>Semua file mentah</li></ul><hr><b>Grup 21-30 Orang</b><br><ul><li>1 Kostum - 15 Menit</li><li>3 foto edit + cetak 5R / orang</li><li>Semua file mentah</li></ul><hr><b>Grup 31-40 Orang</b><br><ul><li>1 Kostum - 15 Menit</li><li>3 foto edit + cetak 5R / orang</li><li>Semua file mentah</li></ul><hr><b>Grup 41-50 Orang</b><br><ul><li>1 Kostum - 15 Menit</li><li>3 foto edit + cetak 5R / orang</li><li>Semua file mentah</li></ul><hr><b>Grup 51-60 Orang</b><br><ul><li>1 Kostum - 15 Menit</li><li>3 foto edit + cetak 5R / orang</li><li>Semua file mentah</li></ul><hr><b>Grup 61-70 Orang</b><br><ul><li>1 Kostum - 15 Menit</li><li>3 foto edit + cetak 5R / orang</li><li>Semua file mentah</li></ul><hr><b>Grup 71-80 Orang</b><br><ul><li>1 Kostum - 15 Menit</li><li>3 foto edit + cetak 5R / orang</li><li>Semua file mentah</li></ul>',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Maternity Studio',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>Maternity Moment 1</b><br><ul><li>Maks 2 Kostum - 15 Menit</li><li>2 foto edit + cetak 8RJ + figura random</li><li>3 foto edit + cetak 5R</li><li>Semua file mentah</li><li><b>Harga : Rp 330.000</b></li></ul><hr><b>Maternity Moment 2</b><br><ul><li>Maks 1 Kostum - 10 Menit</li><li>2 foto edit + cetak 8RJ + figura random</li><li>3 foto edit + cetak 5R</li><li>Semua file mentah</li><li><b>Harga : Rp 210.000</b></li></ul>',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Wisuda Studio B',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>Graduation 3</b><br><ul><li>Maks 1 Kostum - 15 Menit</li><li>1 foto edit + cetak 16RJ - tanpa figura</li><li>1 foto edit + cetak 14RJ - tanpa figura</li><li>2 foto edit + cetak 8 RJ - tanpa figura</li><li>Semua file mentah</li><li><b>Harga : 279.500</b></li></ul>',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Wisuda Studio A',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>Graduation 1</b><br><ul><li>Maks 2 Kostum - 15 Menit</li><li>1 foto edit + cetak 20RJ - tanpa figura</li><li>1 foto edit + cetak 14RJ - tanpa figura</li><li>2 foto edit + cetak 8RJ - tanpa figura</li><li>2 foto edit + cetak 5R - tanpa figura</li><li>Semua file mentah</li><li>CD Drive</li><li><b>Harga : Rp 440.000</b></li></ul><hr><b>Graduation 2</b><br><ul><li>Maks 2 Kostum - 15 Menit</li><li>1 foto edit + cetak 16RJ - tanpa figura</li><li>1 foto edit + cetak 14RJ - tanpa figura</li><li>1 foto edit + cetak 8RJ - tanpa figura</li><li>2 foto edit + cetak 5R - tanpa figura</li><li>Semua file mentah</li><li><b>Harga : Rp 330.000</b></li></ul>',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Keluarga Studio A',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>Family Portrait 1</b><br><ul><li>Maks 2 Kostum - 20 Menit</li><li>1 foto edit + cetak 20RJ + figura random</li><li>2 foto edit + cetak 14RJ + figura random</li><li>3 foto edit + cetak 8RJ + figura random</li><li>Semua file mentah</li><li><b>Harga : Rp 931.700</b></li></ul><hr><b>Family Portrait 2</b><br><ul><li>Maks 2 Kostum - 15 Menit</li><li>1 foto edit + cetak 16RJ + figura random</li><li>1 foto edit + cetak 14RJ + figura random</li><li>3 foto edit + cetak 8RJ + figura random</li><li>Semua file mentah</li><li><b>Harga : 615.800</b></li></ul>',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Keluarga Studio B',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>Family Portrait 3</b><br><ul><li>Maks 1 Kostum - 10 Menit</li><li>1 Foto edit + cetak 16RJ - tanpa figura</li><li>1 Foto edit + cetak 14RJ - tanpa figura</li><li>2 Foto edit + cetak 8RJ - tanpa figura</li><li>Semua file mentah</li><li><b>Harga : Rp 365.700</b></li></ul><hr><b>Family Portrait 4</b><br><ul><li>Maks 1 Kostum - 10 Menit</li><li>1 Foto edit + cetak 14RJ - tanpa figura</li><li>2 Foto edit + cetak 8RJ - tanpa figura</li><li>Semua file mentah</li><li><b>Harga : 285.500</b></li></ul>',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Post Wedding Studio',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>Post Wedding Studio</b><br><ul><li>Maks 2 Kostum - 20 Menit</li><li>1 foto edit + cetak 16RJ + figura random</li><li>1 foto edit + cetak 8RJ + figura random</li><li>2 foto edit + cetak 5R</li><li>Semua file mentah</li><li><b>Harga : Rp 540.000</b></li></ul><hr><b>Post-Wedding Doea</b><br><ul><li>Maks 1 Kostum - 15 Menit</li><li>15 foto edit + cetak 5R + figura random</li><li>Semua file mentah</li><li><b>Harga : Rp 236.000</b></li></ul>',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Single Studio',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>Exclusive Single</b><br><ul><li>Maks 2 Kostum - 15 Menit</li><li>3 foto edit + cetak 5R</li><li>2 foto edit + cetak 8RJ</li><li>Semua file mentah</li><li><b>Harga : 150.000</b></li></ul><hr><b>Solo Single</b><br><ul><li>Maks 1 Kostum - 10 Menit</li><li>3 foto edit + cetak 5R</li><li>1 foto edit + cetak 8RJ</li><li>Semua file mentah</li><li><b>Harga : 125.000</b></li></ul>',
                'is_active' => '1',
            ],
        ];
        foreach ($paket_foto as $pf) {
            \App\Models\Paket::create($pf);
        }

        $sub_paket = [
            [
                'id_paket' => '1',
                'sub_paket' => 'Baby Kiddie Tiny 1',
                'min_org' => '1',
                'max_org' => '99',
                'durasi' => '15',
                'harga' => '125000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '1',
                'sub_paket' => 'Baby Kiddie Tiny 2',
                'min_org' => '1',
                'max_org' => '99',
                'durasi' => '15',
                'harga' => '110000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '2',
                'sub_paket' => 'Pas Foto',
                'min_org' => '1',
                'max_org' => '99',
                'durasi' => '0',
                'harga' => '30000',
                'is_active' => '0',
            ],
            [
                'id_paket' => '2',
                'sub_paket' => 'Pas Foto Gandeng',
                'min_org' => '1',
                'max_org' => '99',
                'durasi' => '0',
                'harga' => '35000',
                'is_active' => '0',
            ],
            [
                'id_paket' => '3',
                'sub_paket' => '2-10 Orang',
                'min_org' => '2',
                'max_org' => '10',
                'durasi' => '15',
                'harga' => '120000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '3',
                'sub_paket' => '11-20 Orang',
                'min_org' => '11',
                'max_org' => '20',
                'durasi' => '15',
                'harga' => '220000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '3',
                'sub_paket' => '21-30 Orang',
                'min_org' => '21',
                'max_org' => '30',
                'durasi' => '15',
                'harga' => '367000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '3',
                'sub_paket' => '31-40 Orang',
                'min_org' => '31',
                'max_org' => '40',
                'durasi' => '15',
                'harga' => '470000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '3',
                'sub_paket' => '41-50 Orang',
                'min_org' => '41',
                'max_org' => '50',
                'durasi' => '15',
                'harga' => '573000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '3',
                'sub_paket' => '51-60 Orang',
                'min_org' => '51',
                'max_org' => '60',
                'durasi' => '15',
                'harga' => '675000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '3',
                'sub_paket' => '61-70 Orang',
                'min_org' => '61',
                'max_org' => '70',
                'durasi' => '15',
                'harga' => '778000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '3',
                'sub_paket' => '71-80 Orang',
                'min_org' => '71',
                'max_org' => '80',
                'durasi' => '15',
                'harga' => '880000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '4',
                'sub_paket' => 'Maternity Moment 1',
                'min_org' => '1',
                'max_org' => '99',
                'durasi' => '15',
                'harga' => '330000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '4',
                'sub_paket' => 'Maternity Moment 2',
                'min_org' => '1',
                'max_org' => '99',
                'durasi' => '10',
                'harga' => '210000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '5',
                'sub_paket' => 'Graduation 3',
                'min_org' => '2',
                'max_org' => '8',
                'durasi' => '15',
                'harga' => '279500',
                'is_active' => '1',
            ],
            [
                'id_paket' => '6',
                'sub_paket' => 'Graduation 1',
                'min_org' => '2',
                'max_org' => '15',
                'durasi' => '15',
                'harga' => '440000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '6',
                'sub_paket' => 'Graduation 2',
                'min_org' => '2',
                'max_org' => '20',
                'durasi' => '15',
                'harga' => '330000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '7',
                'sub_paket' => 'Family Portrait 1',
                'min_org' => '2',
                'max_org' => '20',
                'durasi' => '20',
                'harga' => '931700',
                'is_active' => '1',
            ],
            [
                'id_paket' => '7',
                'sub_paket' => 'Family Portrait 2',
                'min_org' => '2',
                'max_org' => '15',
                'durasi' => '15',
                'harga' => '615800',
                'is_active' => '1',
            ],
            [
                'id_paket' => '8',
                'sub_paket' => 'Family Portrait 3',
                'min_org' => '2',
                'max_org' => '8',
                'durasi' => '10',
                'harga' => '365700',
                'is_active' => '1',
            ],
            [
                'id_paket' => '8',
                'sub_paket' => 'Family Portrait 4',
                'min_org' => '2',
                'max_org' => '5',
                'durasi' => '10',
                'harga' => '285500',
                'is_active' => '1',
            ],
            [
                'id_paket' => '9',
                'sub_paket' => 'Post-Wedding Satoe',
                'min_org' => '1',
                'max_org' => '99',
                'durasi' => '20',
                'harga' => '540000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '9',
                'sub_paket' => 'Post-Wedding Doea',
                'min_org' => '1',
                'max_org' => '99',
                'durasi' => '15',
                'harga' => '236000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '10',
                'sub_paket' => 'Exclusive Single',
                'min_org' => '1',
                'max_org' => '99',
                'durasi' => '15',
                'harga' => '150000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '10',
                'sub_paket' => 'Solo Single',
                'min_org' => '1',
                'max_org' => '99',
                'durasi' => '10',
                'harga' => '125000',
                'is_active' => '1',
            ],
        ];
        foreach ($sub_paket as $sp) {
            \App\Models\SubPaket::create($sp);
        }
    }
}
