<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            SettingAppSeeder::class,
            SubMenuSeeder::class,
            PaketSeeder::class,
            JamSeeder::class,
            PaketWeddingSeeder::class,
            RoleSeeder::class,
            UserAccessMenuSeeder::class,
            MenuSeeder::class,
            PaketUndanganSeeder::class,
            PaketSelfSeeder::class,
        ]);

        $users = [
            [
                'nama' => 'Admin',
                'no_tlp' => '082157254820',
                'email' => 'admin@gmail.com',
                'password' => bcrypt('admin123'),
                'image' => 'default.jpg',
                'role_id' => '1',
                'is_active' => '1',
            ],
            [
                'nama' => 'Konsumen',
                'no_tlp' => '081251206812',
                'email' => 'konsumen@gmail.com',
                'password' => bcrypt('admin123'),
                'image' => 'default.jpg',
                'role_id' => '2',
                'is_active' => '1',
            ]
        ];

        foreach ($users as $user) {
            \App\Models\User::create($user);
        }

        $testimonis = [
            [
                'kode' => '0YONE8',
                'nama' => 'Farah Maryati',
                'rating' => '5',
                'testimoni' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur at voluptate aliquid fuga nam ipsa quaerat inventore esse officiis vel.',
            ],
            [
                'kode' => '1MVNI0',
                'nama' => 'Adika Nugroho',
                'rating' => '4',
                'testimoni' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur at voluptate aliquid fuga nam ipsa quaerat inventore esse officiis vel.',
            ],
            [
                'kode' => '25X6AY',
                'nama' => 'Lutfan Maulana',
                'rating' => '5',
                'testimoni' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur at voluptate aliquid fuga nam ipsa quaerat inventore esse officiis vel.',
            ],
        ];

        foreach ($testimonis as $testimoni) {
            \App\Models\Testimoni::create($testimoni);
        }
    }
}
