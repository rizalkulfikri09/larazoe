<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class JamSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $jam_booking = [
            [ 'jam' => '09:00', 'status' => 7, ],
            [ 'jam' => '09:20', 'status' => 7, ],
            [ 'jam' => '09:40', 'status' => 7, ],
            [ 'jam' => '10:00', 'status' => 7, ],
            [ 'jam' => '10:20', 'status' => 7, ],
            [ 'jam' => '10:40', 'status' => 7, ],
            [ 'jam' => '11:00', 'status' => 7, ],
            [ 'jam' => '11:20', 'status' => 7, ],
            [ 'jam' => '11:40', 'status' => 5, ],
            [ 'jam' => '12:00', 'status' => 5, ],
            [ 'jam' => '12:20', 'status' => 5, ],
            [ 'jam' => '12:40', 'status' => 5, ],
            [ 'jam' => '13:00', 'status' => 5, ],
            [ 'jam' => '13:20', 'status' => 5, ],
            [ 'jam' => '13:40', 'status' => 5, ],
            [ 'jam' => '14:00', 'status' => 5, ],
            [ 'jam' => '14:20', 'status' => 5, ],
            [ 'jam' => '14:40', 'status' => 5, ],
            [ 'jam' => '15:00', 'status' => 7, ],
            [ 'jam' => '15:20', 'status' => 7, ],
            [ 'jam' => '15:40', 'status' => 7, ],
            [ 'jam' => '16:00', 'status' => 7, ],
            [ 'jam' => '16:20', 'status' => 7, ],
            [ 'jam' => '16:40', 'status' => 7, ],
            [ 'jam' => '17:00', 'status' => 7, ],
            [ 'jam' => '17:20', 'status' => 7, ],
            [ 'jam' => '17:40', 'status' => 7, ],
            [ 'jam' => '18:00', 'status' => 7, ],
            [ 'jam' => '18:20', 'status' => 7, ],
            [ 'jam' => '18:40', 'status' => 7, ],
            [ 'jam' => '19:00', 'status' => 7, ],
            [ 'jam' => '19:20', 'status' => 7, ],
            [ 'jam' => '19:40', 'status' => 7, ],
            [ 'jam' => '20:00', 'status' => 7, ],
            [ 'jam' => '20:20', 'status' => 7, ],
            [ 'jam' => '20:40', 'status' => 7, ],
        ];
        foreach ($jam_booking as $jb) {
            \App\Models\JamBooking::create($jb);
        }

        $jam_selfphoto = [
            [ 'jam' => '09:00', 'status' => 7, ],
            [ 'jam' => '09:20', 'status' => 7, ],
            [ 'jam' => '09:40', 'status' => 7, ],
            [ 'jam' => '10:00', 'status' => 7, ],
            [ 'jam' => '10:20', 'status' => 7, ],
            [ 'jam' => '10:40', 'status' => 7, ],
            [ 'jam' => '11:00', 'status' => 7, ],
            [ 'jam' => '11:20', 'status' => 7, ],
            [ 'jam' => '11:40', 'status' => 7, ],
            [ 'jam' => '12:00', 'status' => 7, ],
            [ 'jam' => '12:20', 'status' => 7, ],
            [ 'jam' => '12:40', 'status' => 7, ],
            [ 'jam' => '13:00', 'status' => 7, ],
            [ 'jam' => '13:20', 'status' => 7, ],
            [ 'jam' => '13:40', 'status' => 7, ],
            [ 'jam' => '14:00', 'status' => 7, ],
            [ 'jam' => '14:20', 'status' => 7, ],
            [ 'jam' => '14:40', 'status' => 7, ],
            [ 'jam' => '15:00', 'status' => 7, ],
            [ 'jam' => '15:20', 'status' => 7, ],
            [ 'jam' => '15:40', 'status' => 7, ],
            [ 'jam' => '16:00', 'status' => 7, ],
            [ 'jam' => '16:20', 'status' => 7, ],
            [ 'jam' => '16:40', 'status' => 7, ],
            [ 'jam' => '17:00', 'status' => 7, ],
            [ 'jam' => '17:20', 'status' => 7, ],
            [ 'jam' => '17:40', 'status' => 7, ],
            [ 'jam' => '18:00', 'status' => 7, ],
            [ 'jam' => '18:20', 'status' => 7, ],
            [ 'jam' => '18:40', 'status' => 7, ],
            [ 'jam' => '19:00', 'status' => 7, ],
            [ 'jam' => '19:20', 'status' => 7, ],
            [ 'jam' => '19:40', 'status' => 7, ],
            [ 'jam' => '20:00', 'status' => 7, ],
            [ 'jam' => '20:20', 'status' => 7, ],
            [ 'jam' => '20:40', 'status' => 7, ],
        ];
        foreach ($jam_selfphoto as $jsp) {
            \App\Models\JamSelfPhoto::create($jsp);
        }
    }
}
