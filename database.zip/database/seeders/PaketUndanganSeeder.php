<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PaketUndanganSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $undangan_paket = [
            [
                'durasi' => 182,
                'harga' => 30000,
                'is_active' => 1,
            ],
            [
                'durasi' => 365,
                'harga' => 60000,
                'is_active' => 1,
            ],
            [
                'durasi' => 547,
                'harga' => 120000,
                'is_active' => 1,
            ],
        ];
        foreach ($undangan_paket as $up) {
            \App\Models\UndanganPaket::create($up);
        }

        $undangan_tema = [
            [
                'nama_tema' => 'White Love',
                'thumbnail' => 'white_love.jpg',
                'preview' => 'white_love',
                'aspect_ratio' => '0.7575',
                'width_slider' => '606',
                'height_slider' => '800',
                'is_active' => 1,
            ],
            [
                'nama_tema' => 'Radiant Love',
                'thumbnail' => 'radiant_love.jpg',
                'preview' => 'radiant_love',
                'aspect_ratio' => '1.7250',
                'width_slider' => '1675',
                'height_slider' => '971',
                'is_active' => 1,
            ],
            [
                'nama_tema' => 'Dream Wedding',
                'thumbnail' => 'dream_wedding.jpg',
                'preview' => 'dream_wedding',
                'aspect_ratio' => '1.8566',
                'width_slider' => '1671',
                'height_slider' => '900',
                'is_active' => 1,
            ],
            [
                'nama_tema' => 'Luxe Wedding',
                'thumbnail' => 'luxe_wedding.jpg',
                'preview' => 'luxe_wedding',
                'aspect_ratio' => '1.8566',
                'width_slider' => '1671',
                'height_slider' => '900',
                'is_active' => 1,
            ],
            [
                'nama_tema' => 'True Love',
                'thumbnail' => 'true_love.jpg',
                'preview' => 'true_love',
                'aspect_ratio' => '0.7575',
                'width_slider' => '606',
                'height_slider' => '800',
                'is_active' => 1,
            ],
            [
                'nama_tema' => 'Perfect Love',
                'thumbnail' => 'perfect_love.jpg',
                'preview' => 'perfect_love',
                'aspect_ratio' => '1.8566',
                'width_slider' => '1671',
                'height_slider' => '900',
                'is_active' => 1,
            ],
        ];
        foreach ($undangan_tema as $ut) {
            \App\Models\UndanganTema::create($ut);
        }
    }
}
