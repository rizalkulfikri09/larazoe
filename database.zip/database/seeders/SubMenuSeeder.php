<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SubMenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $sub_menu = [
            [
                'menu_id' => '1',
                'title' => 'Dashboard',
                'url' => 'admin',
                'icon' => 'fas fa-fw fa-desktop',
                'is_active' => 1,
            ],
            [
                'menu_id' => '1',
                'title' => 'Daftar Konsumen',
                'url' => 'daftar_konsumen',
                'icon' => 'fas fa-fw fa-users',
                'is_active' => 1,
            ],
            [
                'menu_id' => '1',
                'title' => 'Pengaturan Jam Booking',
                'url' => 'pengaturan_jam',
                'icon' => 'fas fa-fw fa-clock',
                'is_active' => 1,
            ],
            [
                'menu_id' => '1',
                'title' => 'Pengaturan Aplikasi',
                'url' => 'pengaturan_aplikasi',
                'icon' => 'fas fa-fw fa-gear',
                'is_active' => 1,
            ],
            [
                'menu_id' => '1',
                'title' => 'Daftar Transaksi',
                'url' => 'daftar_transaksi',
                'icon' => 'fas fa-fw fa-sack-dollar',
                'is_active' => 1,
            ],
            [
                'menu_id' => '2',
                'title' => 'Daftar Booking Studio',
                'url' => 'daftar_booking',
                'icon' => 'fas fa-fw fa-book',
                'is_active' => 1,
            ],
            [
                'menu_id' => '2',
                'title' => 'Pengaturan Paket',
                'url' => 'pengaturan_paket',
                'icon' => 'fas fa-fw fa-images',
                'is_active' => 1,
            ],
            [
                'menu_id' => '2',
                'title' => 'Pengaturan Sub Paket',
                'url' => 'pengaturan_sub_paket',
                'icon' => 'fas fa-fw fa-image',
                'is_active' => 1,
            ],
            [
                'menu_id' => '2',
                'title' => 'Daftar Testimoni',
                'url' => 'testimoni_studio',
                'icon' => 'fas fa-fw fa-star',
                'is_active' => 1,
            ],
            [
                'menu_id' => '3',
                'title' => 'Daftar Booking Wedding',
                'url' => 'daftar_wedding',
                'icon' => 'fas fa-fw fa-journal-whills',
                'is_active' => 1,
            ],
            [
                'menu_id' => '3',
                'title' => 'Paket Wedding',
                'url' => 'paket_wedding',
                'icon' => 'far fa-fw fa-file-image',
                'is_active' => 1,
            ],
            [
                'menu_id' => '3',
                'title' => 'Sub Paket Wedding',
                'url' => 'sub_wedding',
                'icon' => 'fas fa-fw fa-file-image',
                'is_active' => 1,
            ],
            [
                'menu_id' => '4',
                'title' => 'Daftar Self Photo',
                'url' => 'daftar_self_photo',
                'icon' => 'fas fa-fw fa-book-bookmark',
                'is_active' => 1,
            ],
            [
                'menu_id' => '4',
                'title' => 'Paket Self Photo',
                'url' => 'paket_self_photo',
                'icon' => 'fas fa-fw fa-newspaper',
                'is_active' => 1,
            ],
            [
                'menu_id' => '4',
                'title' => 'Pengaturan Add Ons',
                'url' => 'addons_self_photo',
                'icon' => 'fas fa-fw fa-file-circle-plus',
                'is_active' => 1,
            ],
            [
                'menu_id' => '4',
                'title' => 'Jam Self Photo',
                'url' => 'jam_self_photo',
                'icon' => 'fas fa-fw fa-clock',
                'is_active' => 1,
            ],
            [
                'menu_id' => '5',
                'title' => 'Daftar Undangan',
                'url' => 'daftar_undangan',
                'icon' => 'fas fa-fw fa-book-journal-whills',
                'is_active' => 1,
            ],
            [
                'menu_id' => '5',
                'title' => 'Paket Undangan',
                'url' => 'paket_undangan',
                'icon' => 'fas fa-fw fa-shield-heart',
                'is_active' => 1,
            ],
            [
                'menu_id' => '5',
                'title' => 'Tema Undangan',
                'url' => 'tema_undangan',
                'icon' => 'fas fa-fw fa-heart-circle-plus',
                'is_active' => 1,
            ],
            [
                'menu_id' => '6',
                'title' => 'Pengaturan Role',
                'url' => 'pengaturan_role',
                'icon' => 'fas fa-fw fa-wrench',
                'is_active' => 1,
            ],
            [
                'menu_id' => '6',
                'title' => 'Pengaturan Menu',
                'url' => 'menu',
                'icon' => 'fas fa-fw fa-folder',
                'is_active' => 1,
            ],
            [
                'menu_id' => '6',
                'title' => 'Pengaturan Submenu',
                'url' => 'sub_menu',
                'icon' => 'fas fa-fw fa-folder-open',
                'is_active' => 1,
            ],
            [
                'menu_id' => '7',
                'title' => 'Profil Saya',
                'url' => 'user',
                'icon' => 'fas fa-fw fa-user',
                'is_active' => 0,
            ],
            [
                'menu_id' => '7',
                'title' => 'Edit Profil',
                'url' => 'user_edit',
                'icon' => 'fas fa-fw fa-cog',
                'is_active' => 1,
            ],
            [
                'menu_id' => '7',
                'title' => 'Ganti Password',
                'url' => 'ganti_password',
                'icon' => 'fas fa-fw fa-key',
                'is_active' => 1,
            ],
            [
                'menu_id' => '8',
                'title' => 'Booking Studio Foto',
                'url' => 'booking_studio',
                'icon' => 'fas fa-fw fa-camera-retro',
                'is_active' => 1,
            ],
            [
                'menu_id' => '8',
                'title' => 'Kalender Booking',
                'url' => 'kalender_booking',
                'icon' => 'fas fa-fw fa-calendar-alt',
                'is_active' => 1,
            ],
            [
                'menu_id' => '8',
                'title' => 'Booking Wedding',
                'url' => 'booking_wedding',
                'icon' => 'far fa-fw fa-heart',
                'is_active' => 1,
            ],
            [
                'menu_id' => '8',
                'title' => 'Undangan Digital',
                'url' => 'pilih_tema',
                'icon' => 'fas fa-fw fa-heart',
                'is_active' => 1,
            ],
            [
                'menu_id' => '8',
                'title' => 'Booking Self Photo',
                'url' => 'self_photo',
                'icon' => 'fas fa-fw fa-camera',
                'is_active' => 1,
            ],
            [
                'menu_id' => '8',
                'title' => 'Log Out',
                'url' => 'logout',
                'icon' => 'fas fa-fw fa-power-off',
                'is_active' => 1,
            ],
        ];
        foreach ($sub_menu as $sm) {
            DB::table('sub_menu')->insert($sm);
        }
    }
}
