<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class PaketSelfSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $paket_self = [
            [
                'nama_paket' => 'Self Photo Silver',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<ul><li>15 menit pemotretan</li><li>Maksimal 5 orang</li><li>Gratis soft file photo</li><li>1 printed photo</li></ul>',
                'min_org' => '1',
                'max_org' => '5',
                'durasi' => '15',
                'harga' => '60000',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Self Photo Gold',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<ul><li>15 menit pemotretan</li><li>Maksimal 10 orang</li><li>Gratis soft file photo</li><li>Unlimited shots</li><li>2 printed photo</li></ul>',
                'min_org' => '1',
                'max_org' => '10',
                'durasi' => '15',
                'harga' => '120000',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Self Photo Platinum',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<ul><li>15 menit pemotretan</li><li>Maksimal 20 orang</li><li>Free all soft file photo</li><li>Unlimited shots</li><li>20 edit digital copies</li><li>3 printed photo</li></ul>',
                'min_org' => '1',
                'max_org' => '20',
                'durasi' => '15',
                'harga' => '240000',
                'is_active' => '1',
            ],
        ];
        foreach ($paket_self as $ps) {
            \App\Models\PaketSelf::create($ps);
        }

        $addon_self = [
            [
                'nama_addon' => 'Tambahan 1 Orang',
                'harga' => '25000',
            ],
            [
                'nama_addon' => 'Tambahan Print Photo',
                'harga' => '30000',
            ],
            [
                'nama_addon' => 'Tambahan Frame',
                'harga' => '45000',
            ],
            [
                'nama_addon' => 'Tambahan 15 Menit',
                'harga' => '50000',
            ],
        ];
        foreach ($addon_self as $as) {
            \App\Models\AddOnSelf::create($as);
        }
    }
}
