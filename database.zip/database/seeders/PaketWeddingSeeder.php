<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class PaketWeddingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $paket_wedding = [
            [
                'nama_paket' => 'Wedding Photography',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>SAMARA 1</b><ul xss=removed><li>1 day ( 8 hours)</li><li>2 Photographer</li><li>1 Helper</li><li>1 Photobook 20x30 - 20 pages</li><li>Unlimited taking pictures</li><li>Sneak peek more than 20 photo</li><li>Flashdisk softcopy all file</li><li>Rp. 3.750.000</li></ul><hr><b>SAMARA 2</b><ul xss=removed><li>1 day ( 8 hours)</li><li>2 Photographer</li><li>1 Helper</li><li>1 Photobook 20x30 - 20 pages</li><li>Unlimited taking pictures</li><li>Sneak peek more than 30 photo</li><li>Flashdisk softcopy all file</li><li>Rp. 5.050.000</li></ul><hr><b>SAMARA 3</b><ul xss=removed><li>1 day ( 8 hours)</li><li>3 Photographer</li><li>1 Helper</li><li>1 Hardcover Album 20x30</li><li>1 Photobook 30x40 - 20 pages</li><li>Unlimited taking pictures</li><li>Sneak peek more than 40 photo</li><li>Flashdisk softcopy all file</li><li>Rp. 8.925.000</li></ul>',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'Wedding Videography',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>SILVER - VIDEO</b><ul><li>1 day ( 8 hours)</li><li>2 Videographers</li><li>Teaser ( 1 min )</li><li>Highlight ( 3-5 min )</li><li>Documentation ( 30 Min )</li><li>Flashdisk all final video</li><li>Rp. 4.425.000</li></ul><hr><b>PLATINUM - VIDEO</b><ul><li>1 day ( 8 hours)</li><li>3 Videographers</li><li>Teaser ( 2 min )</li><li>Highlight ( 10-15 min )</li><li>Documentation ( 45 Min )</li><li>Flashdisk all final video</li><li>Rp. 5.925.000</li></ul>',
                'is_active' => '1',
            ],
            [
                'nama_paket' => 'PostWedding Photography',
                'thumbnail' => 'contoh_paket.jpg',
                'deskripsi' => '<b>SILVER - POSTWEDDING</b><ul><li>5 Hours</li><li>Banjarbaru / Martapura</li><li>2 Costum (max)</li><li>2 Photographers</li><li>40 Photo Edit</li><li>1 Photobook (20x30)</li><li>Flashdisk all file</li><li>Rp. 2.860.000</li></ul><hr><b>PLATINUM - POSTWEDDING</b><ul><li>1 day ( 5 hours)</li><li>Banjarbaru / Martapura</li><li>3 Costum (max)</li><li>2 Photographers</li><li>1 HC 5R</li><li>40 Photo Edit</li><li>1 Photobook (20x30)</li><li>Flashdisk all file</li><li>Rp. 3.920.000</li></ul>',
                'is_active' => '1',
            ],
        ];
        foreach ($paket_wedding as $pw) {
            \App\Models\PaketWedding::create($pw);
        }

        $sub_wedding = [
            [
                'id_paket' => '1',
                'sub_paket' => 'SAMARA 1',
                'harga' => '3750000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '1',
                'sub_paket' => 'SAMARA 2',
                'harga' => '5050000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '1',
                'sub_paket' => 'SAMARA 3',
                'harga' => '8925000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '2',
                'sub_paket' => 'SILVER-VIDEO',
                'harga' => '4425000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '2',
                'sub_paket' => 'PLATINUM-VIDEO',
                'harga' => '5925000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '3',
                'sub_paket' => 'SILVER-POSTWEDDING',
                'harga' => '2860000',
                'is_active' => '1',
            ],
            [
                'id_paket' => '3',
                'sub_paket' => 'PLATINUM-POSTWEDDING',
                'harga' => '3920000',
                'is_active' => '1',
            ],
        ];
        foreach ($sub_wedding as $sw) {
            \App\Models\SubWedding::create($sw);
        }

        $extra_wedding = [
            [
                'extra_wedding' => 'Extra Day (Max 8 Jam)',
                'harga' => '2250000',
            ],
            [
                'extra_wedding' => 'Extra Hours (Max 4 Jam)',
                'harga' => '1500000',
            ],
        ];
        foreach ($extra_wedding as $ew) {
            \App\Models\ExtraWedding::create($ew);
        }
    }
}
