<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SettingAppSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $setting_apps = [
            [
                'value_1' => 'Zahra',
                'value_2' => '1',
                'value_3' => '6',
                'value_4' => '1',
                'value_5' => '2',
                'value_6' => '500000',
                'value_7' => '2',
                'value_8' => 'Transport khusus untuk diluar Banjarbaru / Martapura',
                'value_9' => '12',
                'value_10' => '1',
                'items' => '["Zahra","Jasmin","Nabila","Permata"]',
            ],
            [
                'value_1' => '2',
                'value_2' => '0',
                'value_3' => '0',
                'value_4' => '21:00',
            ],
            [
                'value_1' => 'mandiri.png',
                'value_2' => '1234567890123',
                'value_3' => 'PT Larazoe Studio',
                'value_4' => '50',
                'value_5' => '1',
            ],
            [
                'value_1' => 'bsi.png',
                'value_2' => '1234567890',
                'value_3' => 'PT Larazoe Studio',
            ],
            [
                'value_1' => 'Aplikasi Larazoe',
                'value_2' => 'Larazoe',
                'value_3' => 'Copyright © Larazoe',
                'value_4' => 'favicon.ico',
                'value_5' => '8',
                'value_6' => 'Hafizh Zoelva',
                'value_7' => 'Banjarbaru',
                'value_8' => 'Larazoe Studio Foto',
                'value_9' => 'Jl. Muslim, Kec. Banjarbaru Utara, Kota Banjar Baru, Kalimantan Selatan, 70613. 081251206812',
                'value_10' => 'Barang yang sudah dibeli tidak dapat dikembalikan, kecuali ada perjanjian. Saran melalui 081251206812',
            ],
            [
                'value_1' => 'portofolio_1.jpg',
                'value_2' => 'portofolio_2.jpg',
                'value_3' => 'portofolio_3.jpg',
                'value_4' => 'portofolio_4.jpg',
                'value_5' => 'portofolio_5.jpg',
                'value_6' => 'portofolio_6.jpg',
                'value_7' => 'portofolio_7.jpg',
                'value_8' => 'portofolio_8.jpg',
                'value_9' => 'portofolio_9.jpg',
            ],
            [
                'value_1' => 'Larazoe Studio Foto',
                'value_2' => 'LARAZOE',
                'value_3' => 'Selamat Datang Di Website Larazoe',
                'value_4' => 'We live to code',
                'value_5' => 'Login Aplikasi',
                'value_6' => 'background_1.jpg',
            ],
            [
                'value_1' => 'Tentang Larazoe',
                'value_2' => 'studio.jpg',
                'items' => '<p style="text-align: justify; "><span style="font-size: 18px;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure nemo numquam exercitationem nihil aliquam, accusamus molestiae quisquam odio eum explicabo, magnam dolores quia consequatur doloribus nesciunt suscipit tenetur dolor odit. Lorem ipsum dolor sit amet consectetur adipisicing elit.</span></p><p style="text-align: justify; "><span style="font-size: 18px;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi quo atque, voluptates illum obcaecati ex nihil modi accusantium quisquam! Facere rerum odio amet provident voluptatum nobis optio dolorem voluptatibus, pariatur iste assumenda eos, vero officia molestias dolores praesentium. Lorem ipsum dolor sit amet consectetur adipisicing elit.</span><br></p>',
            ],
            [
                'value_1' => 'Paket dan Produk Larazoe',
                'value_2' => 'studio_2.jpg',
                'value_3' => 'FOTOGRAFI',
                'value_4' => 'CETAK FOTO',
                'value_5' => 'BINGKAI FOTO',
                'value_6' => 'DESAIN & CETAK DIGITAL',
                'value_7' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore quidem, cum aperiam quisquam ex maxime nemo consequuntur reiciendis.',
                'value_8' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore quidem, cum aperiam quisquam ex maxime nemo consequuntur reiciendis.',
                'value_9' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore quidem, cum aperiam quisquam ex maxime nemo consequuntur reiciendis.',
                'value_10' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore quidem, cum aperiam quisquam ex maxime nemo consequuntur reiciendis.',
            ],
            [
                'value_1' => 'background_2.jpg',
                'value_2' => 'Aplikasi ini dibuat untuk memudahkan konsumen dalam mengatur jadwal pemotretan dan mempersingkat waktu konsumen saat melakukan pemesanan studio foto.',
                'value_3' => '1',
                'value_4' => '6281251206812',
                'value_5' => 'Selamat datang di website Larazoe tulis pertanyaan anda pada kolom chat dibawah ini',
                'value_6' => 'Hallo, saya mau tanya tentang ....',
                'items' => '<iframe src="https://www.youtube.com/embed/VBf4dH-qGh8" title="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>',
            ],
            [
                'value_1' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore quidem ?',
                'value_2' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem quaerat beatae at cumque ducimus nulla facilis nemo nobis, dolorum tempore.',
                'value_3' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore quidem ?',
                'value_4' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem quaerat beatae at cumque ducimus nulla facilis nemo nobis, dolorum tempore.',
                'value_5' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore quidem ?',
                'value_6' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem quaerat beatae at cumque ducimus nulla facilis nemo nobis, dolorum tempore.',
                'value_7' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore quidem ?',
                'value_8' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem quaerat beatae at cumque ducimus nulla facilis nemo nobis, dolorum tempore.',
                'value_9' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore quidem ?',
                'value_10' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem quaerat beatae at cumque ducimus nulla facilis nemo nobis, dolorum tempore.',
            ],
            [
                'value_1' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem quaerat beatae at cumque ducimus nulla facilis nemo nobis, dolorum tempore Dolorem quaerat ducimus nulla.',
                'value_2' => 'https://www.instagram.com/#',
                'value_3' => 'https://www.facebook.com/#',
                'value_4' => 'https://www.youtube.com/channel/#',
                'value_5' => 'https://wa.me/6281251206812',
                'value_6' => 'Jl. Muslim, Kec. Banjarbaru Utara, Kota Banjar Baru, Kalimantan Selatan 70613',
                'value_7' => 'hafiizh10@gmail.com',
                'value_8' => '+6281251206812',
                'items' => '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15930.414890610622!2d114.84406340845946!3d-3.4461374381335643!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2de68184b36e55d9%3A0x3d4bb21a044628be!2sBundaran%20Simpang%20Empat%20Banjarbaru!5e0!3m2!1sid!2sid!4v1666251363303!5m2!1sid!2sid" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>',
            ],
            [
                'value_1' => 'canon.png',
                'value_2' => 'epson.png',
                'value_3' => 'frontier.png',
                'value_4' => 'hp.png',
                'value_5' => 'pantone.png',
                'value_6' => 'sandisk.png',
            ],
            [
                'value_1' => '082157254820',
                'value_2' => '1',
                'value_3' => '1',
            ],
        ];
        foreach ($setting_apps as $setting) {
            DB::table('setting_apps')->insert($setting);
        }
    }
}
