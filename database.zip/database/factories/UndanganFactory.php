<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Undangan>
 */
class UndanganFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $pria = fake()->firstnameMale();
        $wanita = fake()->firstNameFemale();
        return [
            'kode' => fake()->regexify('[A-Z0-9]{6}'),
            'user_id' => 1,
            'nama_pria' => $pria,
            'full_nama_pria' => $pria,
            'nama_wanita' => $wanita,
            'full_nama_wanita' => $wanita,
            'link' => strtolower($pria.'-'.$wanita),
            'status_undangan' => fake()->randomElement(['Aktif', 'Nonaktif']),
            'status_bayar' => fake()->randomElement(['Belum Dibayar', 'Lunas']),
            'warna_undangan' => fake()->randomElement(['color1', 'color2', 'color3', 'color4', 'color5']),
            'id_tema' => 1,
            'id_paket' => random_int(1,3),
        ];
    }
}
