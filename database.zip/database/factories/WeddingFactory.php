<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Wedding>
 */
class WeddingFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'kode' => fake()->regexify('[A-Z0-9]{6}'),
            'nama' => fake()->name(),
            'no_tlp' => fake()->randomElement(['081251206812']),
            'alamat' => fake()->address(),
            'paket' => fake()->randomElement(['SAMARA 1 + Extra Day (Max 8 Jam) + Transport', 'SILVER-VIDEO + Extra Day (Max 4 Jam)', 'SILVER-POSTWEDDING + Transport']),
            'status_booking' => 'Dipesan',
            'status_bayar' => fake()->randomElement(['Belum Dibayar', 'DP', 'Lunas']),
            'jml_dp' => fake()->randomElement(['120000', '135000', '142000']),
            'total' => fake()->randomElement(['120000', '135000', '142000']),
            'tgl_wedding' => fake()->dateTimeBetween($startDate = 'now', $endDate = '+20 days', $timezone = 'Asia/Jakarta')->format('Y-m-d'),
            'cs' => fake()->randomElement(["Zahra","Jasmin","Nabila","Permata"]),
        ];
    }
}
