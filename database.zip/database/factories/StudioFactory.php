<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Studio>
 */
class StudioFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'kode' => fake()->regexify('[A-Z0-9]{6}'),
            'nama' => fake()->name(),
            'no_tlp' => fake()->randomElement(['081251206812']),
            'paket' => fake()->randomElement(['Keluarga Studio A - Family Portrait 1', 'Keluarga Studio B - Family Portrait 4', 'Baby & Kid Studio - Baby Kiddie Tiny 2', 'Single Studio - Exclusive Single']),
            'jml_orang' => random_int(0,5),
            'status_booking' => 'Dipesan',
            'status_bayar' => fake()->randomElement(['Belum Dibayar', 'DP', 'Lunas']),
            'jml_dp' => fake()->randomElement(['120000', '135000', '142000']),
            'total' => fake()->randomElement(['120000', '135000', '142000']),
            'tgl_booking' => fake()->dateTimeBetween($startDate = 'now', $endDate = '+20 days', $timezone = 'Asia/Jakarta')->format('Y-m-d'),
            'jam_booking' => fake()->randomElement(['09:00-09:15', '10:00-10:15', '11:00-11:15', '12:00-12:15']),
            'cs' => fake()->randomElement(["Zahra","Jasmin","Nabila","Permata"]),
            'id_sesi' => random_int(1,5),
        ];
    }
}
