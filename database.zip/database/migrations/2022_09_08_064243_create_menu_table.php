<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('menu', function (Blueprint $table) {
            $table->id();
            $table->string('menu', 128);
        });

        Schema::create('sub_menu', function (Blueprint $table) {
            $table->id();
            $table->foreignId('menu_id');
            $table->string('title', 128);
            $table->string('url', 128);
            $table->string('icon', 128);
            $table->boolean('is_active');
            
            $table->index('menu_id');
        });

        Schema::create('user_access_menu', function (Blueprint $table) {
            $table->id();
            $table->foreignId('role_id');
            $table->foreignId('menu_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('menu');
        Schema::dropIfExists('sub_menu');
        Schema::dropIfExists('user_access_menu');
    }
};
