<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('booking_self', function (Blueprint $table) {
            $table->id();
            $table->string('kode', 10)->unique();
            $table->foreignId('user_id');
            $table->string('paket', 255);
            $table->string('status_booking', 20);
            $table->string('status_bayar', 20);
            $table->integer('jml_dp');
            $table->integer('total');
            $table->integer('jml_orang');
            $table->date('tgl_booking');
            $table->string('jam_booking');
            $table->string('cs', 20);
            $table->integer('id_sesi');
            $table->integer('id_paket');
            $table->timestamps();

            $table->index(['kode', 'id_sesi']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('booking_self');
    }
};
