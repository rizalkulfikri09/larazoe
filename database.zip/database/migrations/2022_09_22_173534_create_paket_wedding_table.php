<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('paket_wedding', function (Blueprint $table) {
            $table->id();
            $table->string('nama_paket', 128);
            $table->string('thumbnail', 128);
            $table->longText('deskripsi');
            $table->boolean('is_active');
            $table->timestamps();
        });

        Schema::create('sub_wedding', function (Blueprint $table) {
            $table->id();
            $table->foreignId('id_paket');
            $table->string('sub_paket', 128);
            $table->integer('harga');
            $table->boolean('is_active');
            $table->timestamps();

            $table->index('id_paket');
        });

        Schema::create('extra_wedding', function (Blueprint $table) {
            $table->id();
            $table->string('extra_wedding', 128);
            $table->integer('harga');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('paket_wedding');
        Schema::dropIfExists('sub_wedding');
        Schema::dropIfExists('extra_wedding');
    }
};
