<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transaksi', function (Blueprint $table) {
            $table->id();
            $table->string('kode_booking', 10)->nullable();
            $table->string('kode_wedding', 10)->nullable();
            $table->string('kode_undangan', 10)->nullable();
            $table->string('kode_selfphoto', 10)->nullable();
            $table->string('no_ref', 128)->nullable();
            $table->string('link', 255)->nullable();
            $table->string('status', 20);
            $table->timestamps();

            $table->index(['kode_booking', 'kode_wedding']);
            $table->index(['kode_undangan', 'kode_selfphoto']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transaksi');
    }
};
