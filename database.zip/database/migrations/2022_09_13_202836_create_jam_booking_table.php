<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jam_booking', function (Blueprint $table) {
            $table->id();
            $table->string('jam');
            $table->integer('status');
            $table->timestamps();
        });

        Schema::create('libur_studio', function (Blueprint $table) {
            $table->id();
            $table->string('tanggal', 100);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jam_booking');
        Schema::dropIfExists('libur_studio');
    }
};
