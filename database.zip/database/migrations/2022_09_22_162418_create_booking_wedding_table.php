<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('booking_wedding', function (Blueprint $table) {
            $table->id();
            $table->string('kode', 10);
            $table->string('nama', 128);
            $table->string('no_tlp', 20);
            $table->longText('alamat');
            $table->string('paket', 255);
            $table->string('status_booking', 20);
            $table->string('status_bayar', 20);
            $table->integer('jml_dp');
            $table->integer('total');
            $table->date('tgl_wedding');
            $table->string('cs', 20);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('booking_wedding');
    }
};
