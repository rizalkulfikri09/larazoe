<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('undangan', function (Blueprint $table) {
            $table->id();
            $table->string('kode', 10)->unique();
            $table->foreignId('user_id');
            $table->string('nama_pria', 128);
            $table->string('full_nama_pria', 128);
            $table->string('nama_wanita', 128);
            $table->string('full_nama_wanita', 128);
            $table->string('link', 128);
            $table->string('status_undangan', 20);
            $table->string('status_bayar', 20);
            $table->string('warna_undangan', 20);
            $table->string('id_tema', 128);
            $table->string('id_paket', 128);
            $table->timestamps();
        });

        Schema::create('undangan_detail', function (Blueprint $table) {
            $table->id();
            $table->string('kode_undangan', 10);
            $table->dateTime('tanggal_nikah');
            $table->longText('kalimat_pembuka');
            $table->boolean('status_slider');
            $table->string('foto_slider_1', 128)->nullable();
            $table->string('title_slider_1', 128)->nullable();
            $table->string('foto_slider_2', 128)->nullable();
            $table->string('title_slider_2', 128)->nullable();
            $table->string('foto_slider_3', 128)->nullable();
            $table->string('title_slider_3', 128)->nullable();
            $table->string('foto_slider_4', 128)->nullable();
            $table->string('title_slider_4', 128)->nullable();
            $table->string('link_youtube', 255)->nullable();
            $table->string('musik', 128)->nullable();

            $table->foreign('kode_undangan')->references('kode')->on('undangan')->onDelete('cascade');
        });

        Schema::create('undangan_galeri', function (Blueprint $table) {
            $table->id();
            $table->string('kode_undangan', 10);
            $table->string('foto', 128);

            $table->foreign('kode_undangan')->references('kode')->on('undangan')->onDelete('cascade');
        });

        Schema::create('undangan_pengantin', function (Blueprint $table) {
            $table->id();
            $table->string('kode_undangan', 10);
            $table->string('foto_pria', 128);
            $table->string('foto_wanita', 128);
            $table->string('ortu_pria', 255);
            $table->string('anak_of_pria', 128);
            $table->string('ortu_wanita', 255);
            $table->string('anak_of_wanita', 128);
            $table->string('ig_pria', 128)->nullable();
            $table->string('twitter_pria', 128)->nullable();
            $table->string('fb_pria', 128)->nullable();
            $table->string('ig_wanita', 128)->nullable();
            $table->string('twitter_wanita', 128)->nullable();
            $table->string('fb_wanita', 128)->nullable();

            $table->foreign('kode_undangan')->references('kode')->on('undangan')->onDelete('cascade');
        });

        Schema::create('undangan_cerita', function (Blueprint $table) {
            $table->id();
            $table->string('kode_undangan', 10);
            $table->string('foto_cerita', 128);
            $table->string('judul_cerita', 128);
            $table->string('waktu_cerita', 128);
            $table->longText('isi_cerita');

            $table->foreign('kode_undangan')->references('kode')->on('undangan')->onDelete('cascade');
        });

        Schema::create('undangan_tempat', function (Blueprint $table) {
            $table->id();
            $table->string('kode_undangan', 10);
            $table->string('nama_acara', 128)->nullable();
            $table->dateTime('tanggal_acara')->nullable();
            $table->string('tempat_acara', 128)->nullable();
            $table->string('alamat_acara', 255)->nullable();
            $table->string('link_maps', 255)->nullable();
            $table->string('nama_bank', 128)->nullable();
            $table->string('nomor_rekening', 128)->nullable();
            $table->string('pemilik_rekening', 128)->nullable();

            $table->foreign('kode_undangan')->references('kode')->on('undangan')->onDelete('cascade');
        });

        Schema::create('undangan_ucapan', function (Blueprint $table) {
            $table->id();
            $table->string('kode_undangan', 10);
            $table->string('nama_tamu', 128);
            $table->string('ucapan', 255)->charset('utf8mb4')->collation('utf8mb4_unicode_ci');
            $table->string('kehadiran', 20);
            $table->string('ip_address', 128);
            $table->timestamps();

            $table->foreign('kode_undangan')->references('kode')->on('undangan')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('undangan');
        Schema::dropIfExists('undangan_detail');
        Schema::dropIfExists('undangan_galeri');
        Schema::dropIfExists('undangan_pengantin');
        Schema::dropIfExists('undangan_cerita');
        Schema::dropIfExists('undangan_tempat');
        Schema::dropIfExists('undangan_ucapan');
    }
};
