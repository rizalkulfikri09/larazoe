<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('undangan_paket', function (Blueprint $table) {
            $table->id();
            $table->integer('durasi');
            $table->integer('harga');
            $table->boolean('is_active');
        });

        Schema::create('undangan_tema', function (Blueprint $table) {
            $table->id();
            $table->string('nama_tema', 128);
            $table->string('thumbnail', 128);
            $table->string('preview', 128);
            $table->string('aspect_ratio', 128);
            $table->string('width_slider', 128);
            $table->string('height_slider', 128);
            $table->boolean('is_active');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('undangan_paket');
        Schema::dropIfExists('undangan_tema');
    }
};
