<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminSelfController;
use App\Http\Controllers\StudioController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\WebsiteController;
use App\Http\Controllers\WeddingController;
use App\Http\Controllers\UndanganController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SelfPhotoController;
use App\Http\Controllers\AdminStudioController;
use App\Http\Controllers\AdminWeddingController;
use App\Http\Controllers\AdminUndanganController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::controller(UndanganController::class)->group(function () {
    Route::get('/undangan/{link}/{guest?}', 'showUndangan')->name('show_undangan');
    Route::middleware('XssClean')->post('ucapan_tamu/{kode}', 'ucapanTamu')->name('ucapan_tamu');
    Route::get('undangan_ucapan/{kode}', 'dataUcapan')->name('data_ucapan');
    Route::get('preview/{tema}', 'previewUndangan')->name('preview_undangan');
});

Route::middleware('auth')->group(function () {
    Route::controller(AdminController::class)->group(function () {
        // Bagian route untuk fitur daftar konsumen
        Route::get('daftar_konsumen', 'showKonsumen')->name('daftar_konsumen');
        Route::post('daftar_konsumen', 'createKonsumen')->name('create_konsumen');
        Route::get('daftar_konsumen/{id}/edit', 'editKonsumen');
        Route::delete('daftar_konsumen/{id}', 'deleteKonsumen');
        Route::delete('daftar_konsumen_delete', 'deleteAllKonsumen');
        Route::put('konsumen_reset/{id}', 'resetPasswordAkun');
        Route::get('konsumen_pdf', 'exportKonsumenPdf');
        Route::get('konsumen_excel', 'exportKonsumenExcel');
        // Bagian route untuk fitur pengaturan jam booking
        Route::get('pengaturan_jam', 'pengaturanJam')->name('pengaturan_jam');
        Route::post('pengaturan_jam', 'createJamBooking')->name('create_jam');
        Route::get('pengaturan_jam/{id}/edit', 'editJamBooking')->name('edit_jam');
        Route::put('pengaturan_jam/{id}', 'updateJamBooking')->name('update_jam');
        Route::delete('pengaturan_jam/{id}', 'deleteJamBooking')->name('delete_jam');
        Route::put('update_jml_konsumen', 'updateJmlKonsumen')->name('update_jml_konsumen');
        Route::post('create_libur', 'createTglLibur')->name('create_libur');
        Route::delete('delete_libur/{id}', 'deleteLiburStudio')->name('delete_libur');
        // Bagian route untuk fitur pengaturan aplikasi
        Route::get('pengaturan_aplikasi', 'pengaturanAplikasi')->name('pengaturan_aplikasi');
        Route::put('edit_whatsapp', 'editWhatsapp');
        Route::put('edit_payment_manual', 'editPaymentManual');
        Route::put('edit_bank_1', 'editBankSatu');
        Route::put('edit_bank_2', 'editBankDua');
        Route::put('edit_pengaturan_umum', 'editPengaturanUmum');
        Route::put('edit_pengaturan_sistem', 'editPengaturanSistem');
        Route::put('edit_portofolio', 'editPortofolio');
        Route::put('edit_header', 'editHeaderWeb');
        Route::put('edit_bagian_satu', 'editBagianSatu');
        Route::put('edit_bagian_dua', 'editBagianDua');
        Route::put('edit_bagian_tiga', 'editBagianTiga');
        Route::put('edit_pertanyaan', 'editPertanyaan');
        Route::put('edit_footer', 'editFooterWeb');
        Route::put('edit_logoslide', 'editLogoSlide');
        Route::put('edit_tripay', 'editTripay');
        Route::put('edit_xendit', 'editXendit');
        // Bagian route untuk fitur daftar transaksi
        Route::get('daftar_transaksi', 'daftarTransaksi')->name('daftar_transaksi');
    });
    Route::controller(AdminStudioController::class)->group(function () {
        // Bagian route untuk fitur daftar booking studio
        Route::get('daftar_booking', 'showBooking')->name('daftar_booking');
        Route::post('daftar_booking', 'createBooking')->name('create_booking');
        Route::get('daftar_booking/{kode}/edit', 'editBooking');
        Route::put('daftar_booking/{kode}/edit', 'editBooking')->name('edit_booking');
        Route::put('reschedule_studio/{kode}', 'rescheduleStudio')->name('reschedule_studio');
        Route::delete('daftar_booking/{kode}', 'deleteBooking');
        Route::delete('daftar_booking_delete', 'deleteAllBooking');
        Route::get('studio_pdf', 'exportStudioPdf');
        Route::get('studio_excel', 'exportStudioExcel');
        // Bagian route untuk fitur pengaturan paket
        Route::get('pengaturan_paket', 'pengaturanPaket')->name('pengaturan_paket');
        Route::post('pengaturan_paket', 'pengaturanPaket');
        Route::post('paket/{id}/edit', 'editPaket');
        Route::delete('paket/{id}', 'deletePaket')->name('delete_paket');
        // Bagian route untuk fitur pengaturan sub paket
        Route::get('pengaturan_sub_paket', 'pengaturanSubPaket')->name('pengaturan_sub_paket');
        Route::post('pengaturan_sub_paket', 'pengaturanSubPaket');
        Route::post('sub_paket/{id}/edit', 'editSubPaket');
        Route::delete('sub_paket/{id}', 'deleteSubPaket')->name('delete_sub_paket');
        // Bagian route untuk fitur testimoni booking studio foto
        Route::get('testimoni_studio', 'testimoniStudio')->name('testimoni_studio');
        Route::delete('testimoni_studio/{id}', 'deleteTestimoniStudio')->name('delete_testimoni');
    });
    Route::controller(AdminWeddingController::class)->group(function () {
        // Bagian route untuk fitur daftar booking wedding
        Route::get('daftar_wedding', 'showWedding')->name('daftar_wedding');
        Route::post('daftar_wedding', 'createWedding')->name('create_wedding');
        Route::get('daftar_wedding/{kode}/edit', 'editWedding');
        Route::put('daftar_wedding/{kode}/edit', 'editWedding')->name('edit_wedding');
        Route::put('reschedule_wedding/{kode}', 'rescheduleWedding')->name('reschedule_wedding');
        Route::delete('daftar_wedding/{kode}', 'deleteWedding');
        Route::delete('daftar_wedding_delete', 'deleteAllWedding');
        Route::get('wedding_pdf', 'exportWeddingPdf');
        Route::get('wedding_excel', 'exportWeddingExcel');
        // Bagian route untuk fitur paket wedding
        Route::get('paket_wedding', 'paketWedding')->name('paket_wedding');
        Route::post('paket_wedding', 'paketWedding');
        Route::post('paket_wedding/{id}/edit', 'editPaketWedding');
        Route::delete('paket_wedding/{id}', 'deletePaketWedding')->name('delete_wedding');
        // Bagian route untuk fitur sub paket wedding
        Route::get('sub_wedding', 'subPaketWedding')->name('sub_wedding');
        Route::post('sub_wedding', 'subPaketWedding');
        Route::post('sub_wedding/{id}/edit', 'editSubWedding');
        Route::delete('sub_wedding/{id}', 'deleteSubWedding')->name('delete_sub_wedding');
        Route::post('extra_wedding', 'extraWedding')->name('extra_wedding');
        Route::post('extra_wedding/{id}/edit', 'editExtraWedding');
        Route::delete('extra_wedding/{id}', 'deleteExtraWedding')->name('delete_extra_wedding');
    });
    Route::controller(AdminUndanganController::class)->group(function () {
        // Bagian route untuk fitur daftar undangan
        Route::get('daftar_undangan', 'showUndangan')->name('daftar_undangan');
        Route::get('daftar_undangan/{kode}/edit', 'editUndangan');
        Route::put('daftar_undangan/{kode}/edit', 'editUndangan')->name('edit_undangan');
        Route::delete('delete_undangan/{kode}', 'deleteUndangan');
        Route::delete('daftar_undangan_delete', 'deleteAllUndangan');
        Route::get('undangan_pdf', 'exportUndanganPdf');
        Route::get('undangan_excel', 'exportUndanganExcel');
        // Bagian route untuk fitur paket undangan
        Route::get('paket_undangan', 'paketUndangan')->name('paket_undangan');
        Route::post('paket_undangan', 'paketUndangan');
        Route::post('paket_undangan/{id}/edit', 'editPaketUndangan');
        Route::delete('paket_undangan/{id}', 'deletePaketUndangan')->name('delete_paket_undangan');
        // Bagian route untuk fitur tema undangan
        Route::get('tema_undangan', 'temaUndangan')->name('tema_undangan');
        Route::post('tema_undangan', 'temaUndangan');
        Route::post('tema_undangan/{id}/edit', 'editTemaUndangan');
        Route::delete('tema_undangan/{id}', 'deleteTemaUndangan')->name('delete_tema_undangan');
    });
    Route::controller(AdminSelfController::class)->group(function () {
        // Bagian route untuk fitur daftar self photo
        Route::get('daftar_self_photo', 'showSelfPhoto')->name('daftar_self_photo');
        Route::post('daftar_self_photo', 'createSelfPhoto')->name('create_selfphoto');
        Route::get('daftar_self_photo/{kode}/edit', 'editSelfPhoto');
        Route::put('daftar_self_photo/{kode}/edit', 'editSelfPhoto')->name('edit_selfphoto');
        Route::put('res_selfphoto/{kode}', 'resSelfPhoto')->name('res_selfphoto');
        Route::delete('daftar_self_photo/{kode}', 'deleteSelfPhoto');
        Route::delete('delete_self_photo', 'deleteAllSelfPhoto');
        Route::get('selfphoto_pdf', 'exportSelfPdf');
        Route::get('selfphoto_excel', 'exportSelfExcel');
        // Bagian route untuk fitur pengaturan paket
        Route::get('paket_self_photo', 'paketSelfPhoto')->name('paket_self_photo');
        Route::post('paket_self_photo', 'paketSelfPhoto');
        Route::post('paket_self/{id}/edit', 'editPaketSelfPhoto');
        Route::delete('paket_self/{id}', 'deletePaketSelfPhoto')->name('delete_paket_self');
        // Bagian route untuk fitur pengaturan add ons
        Route::get('addons_self_photo', 'addonsSelfPhoto')->name('addons_self_photo');
        Route::post('addons_self_photo', 'addonsSelfPhoto');
        Route::post('addons_self_photo/{id}/edit', 'editAddOnsSelf');
        Route::delete('addons_self_photo/{id}', 'deleteAddOns')->name('delete_addons');
        // Bagian route untuk fitur pengaturan jam booking self photo
        Route::get('jam_self_photo', 'jamSelfPhoto')->name('jam_self_photo');
        Route::post('jam_self_photo', 'jamSelfPhoto');
        Route::get('edit_jam_self/{id}/edit', 'editJamSelf')->name('edit_jam_self');
        Route::put('edit_jam_self/{id}/edit', 'editJamSelf');
        Route::delete('delete_jam_self/{id}', 'deleteJamSelf')->name('delete_jam_self');
    });
    Route::controller(MenuController::class)->group(function () {
        // Bagian route untuk fitur pengaturan role
        Route::get('pengaturan_role', 'pengaturanRole')->name('pengaturan_role');
        Route::post('pengaturan_role', 'pengaturanRole');
        Route::post('pengaturan_role/{kode}/edit', 'editRole');
        Route::delete('pengaturan_role/{id}', 'deleteRole')->name('delete_role');
        Route::get('pengaturan_role/{id}/akses', 'aksesRole')->name('role_akses');
        Route::post('pengaturan_role/{id}/akses', 'aksesRole');
        // Bagian route untuk fitur pengaturan menu
        Route::get('menu', 'menu')->name('menu');
        Route::post('menu', 'menu');
        Route::post('menu/{id}/edit', 'editMenu');
        Route::delete('menu/{id}', 'deleteMenu')->name('delete_menu');
        // Bagian route untuk fitur pengaturan sub menu
        Route::get('sub_menu', 'subMenu')->name('sub_menu');
        Route::post('sub_menu', 'subMenu');
        Route::post('sub_menu/{id}/edit', 'editSubMenu');
        Route::delete('sub_menu/{id}', 'deleteSubMenu')->name('delete_sub_menu');
    });
    Route::controller(UserController::class)->group(function () {
        // Bagian route untuk fitur user
        Route::get('user', 'index')->name('user');
        Route::middleware('XssClean')->post('hapus_akun', 'hapusAkun')->name('hapus_akun');
        // Bagian route untuk fitur edit profil
        Route::get('user_edit', 'userEdit')->name('user_edit');
        Route::post('user_edit', 'userUpdate')->name('user_update');
        Route::post('user_ganti_nomor', 'userGantiNomor')->name('user_ganti_nomor');
        // Bagian route untuk fitur ganti password
        Route::get('ganti_password', 'gantiPassword')->name('ganti_password');
        Route::post('ganti_password', 'gantiPassword');
    });
    Route::controller(StudioController::class)->group(function () {
        // Bagian route untuk fitur booking studio foto
        Route::get('booking_studio', 'bookingStudio')->name('booking_studio');
        Route::middleware('XssClean')->post('booking_studio', 'bookingStudio');
        Route::get('pilih_paket/{id}', 'pilihPaket')->name('pilih_paket');
        Route::middleware('XssClean')->post('pilih_paket/{id}', 'pilihPaket');
        Route::get('pilih_tanggal', 'pilihTanggal')->name('pilih_tanggal');
        Route::middleware('XssClean')->post('pilih_tanggal', 'pilihTanggal');
        Route::get('pilih_jam', 'pilihJam')->name('pilih_jam');
        Route::middleware('XssClean')->post('pilih_jam', 'pilihJam');
        Route::get('metode_pembayaran', 'metodePembayaran')->name('pilih_bayar');
        Route::middleware('XssClean')->post('metode_pembayaran', 'metodePembayaran');
        Route::get('konfirmasi', 'konfirmasiBooking')->name('konfirmasi_booking');
        Route::middleware('XssClean')->post('create_studio_booking', 'createBookingStudio')->name('create_studio');
        // Bagian route untuk fitur riwayat booking studio foto
        Route::get('riwayat_booking', 'riwayatBooking')->name('riwayat_booking');
        Route::middleware('studio.user')->get('riwayat_booking/{kode}', 'hasilBookingStudio')->name('hasil_booking');
        Route::middleware('studio.user')->delete('riwayat_booking/{kode}', 'hapusBookingStudio');
        Route::middleware('studio.user')->get('cetak_booking/{kode}', 'cetakBooking')->name('cetak_booking');
        Route::middleware('studio.user')->get('bayar_studio/{kode}', 'bayarStudio')->name('bayar_studio');
        Route::middleware('XssClean')->post('bayar_studio/{kode}', '_bayarStudio');
        Route::middleware('studio.user')->get('studio_return/{kode}', 'tripayReturnStudio');
        Route::middleware('studio.user')->get('xendit_studio/{kode}', 'xenditReturnStudio');
        Route::middleware('studio.user')->get('reschedule_tgl/{kode}', 'rescheduleTanggal')->name('reschedule_tgl');
        Route::middleware('XssClean')->post('reschedule_tgl/{kode}', 'rescheduleTanggal');
        Route::middleware('studio.user')->get('reschedule_jam/{kode}', 'rescheduleJam')->name('reschedule_jam');
        Route::middleware('XssClean')->post('reschedule_jam/{kode}', 'rescheduleJam');
        // Bagian route untuk fitur kalender booking studio foto
        Route::get('kalender_booking', 'kalenderBooking')->name('kalender_booking');
        // Bagian route untuk fitur testimoni
        Route::middleware('studio.user')->get('testimoni/{kode}', 'testimoniStudio')->name('studio_testimoni');
        Route::middleware('XssClean')->post('testimoni/{kode}', 'testimoniStudio');
    });
    Route::controller(WeddingController::class)->group(function () {
        // Bagian route untuk fitur booking wedding
        Route::get('booking_wedding', 'bookingWedding')->name('booking_wedding');
        Route::middleware('XssClean')->post('booking_wedding', 'bookingWedding');
        Route::get('pilih_paket_wedding/{id}', 'pilihPaketWedding')->name('pilih_paket_wedding');
        Route::middleware('XssClean')->post('pilih_paket_wedding/{id}', 'pilihPaketWedding');
        Route::get('pilih_tanggal_wedding', 'pilihTanggalWedding')->name('pilih_tanggal_wedding');
        Route::middleware('XssClean')->post('pilih_tanggal_wedding', 'pilihTanggalWedding');
        Route::get('data_wedding', 'dataWedding')->name('data_wedding');
        Route::middleware('XssClean')->post('data_wedding', 'dataWedding');
        Route::get('metode_pembayaran_wedding', 'metodePembayaranWedding')->name('pilih_bayar_wedding');
        Route::middleware('XssClean')->post('metode_pembayaran_wedding', 'metodePembayaranWedding');
        Route::get('konfirmasi_wedding', 'konfirmasiBookingWedding')->name('konfirmasi_wedding');
        Route::middleware('XssClean')->post('create_wedding_booking', 'createBookingWedding')->name('create_wedding_booking');
        // Bagian route untuk fitur riwayat booking studio foto
        Route::get('riwayat_wedding', 'riwayatWedding')->name('riwayat_wedding');
        Route::middleware('wedding.user')->get('riwayat_wedding/{kode}', 'hasilBookingWedding')->name('hasil_wedding');
        Route::middleware('wedding.user')->delete('riwayat_wedding/{kode}', 'hapusBookingWedding');
        Route::middleware('wedding.user')->get('cetak_booking_wedding/{kode}', 'cetakBookingWedding')->name('cetak_booking_wedding');
        Route::middleware('wedding.user')->get('bayar_wedding/{kode}', 'bayarWedding')->name('bayar_wedding');
        Route::middleware('XssClean')->post('bayar_wedding/{kode}', '_bayarWedding');
        Route::middleware('wedding.user')->get('wedding_return/{kode}', 'tripayReturnWedding');
        Route::middleware('wedding.user')->get('xendit_wedding/{kode}', 'xenditReturnWedding');
    });
    Route::controller(UndanganController::class)->group(function () {
        // Bagian route untuk fitur undangan digital
        Route::get('pilih_tema', 'pilihTema')->name('pilih_tema');
        Route::middleware('XssClean')->post('pilih_tema', 'pilihTema');
        Route::get('data_pengantin', 'dataPengantin')->name('data_pengantin');
        Route::middleware('XssClean')->post('data_pengantin', 'dataPengantin');
        Route::get('data_undangan/{kode}', 'dataUndangan')->name('data_undangan');
        Route::middleware('XssClean')->post('data_undangan/{kode}', 'dataUndangan');
        Route::get('data_galeri/{kode}', 'dataGaleri')->name('data_galeri');
        Route::middleware('XssClean')->post('data_galeri/{kode}', 'dataGaleri');
        Route::get('data_cerita/{kode}', 'dataCerita')->name('data_cerita');
        Route::middleware('XssClean')->post('data_cerita/{kode}', 'dataCerita');
        Route::get('bayar_undangan/{kode}', 'bayarUndangan')->name('bayar_undangan');
        Route::middleware('XssClean')->post('bayar_undangan/{kode}', 'bayarUndangan');
        Route::get('transfer_undangan/{kode}', 'transferUndangan')->name('transfer_undangan');
        Route::middleware('XssClean')->post('transfer_undangan/{kode}', '_transferUndangan');
        Route::middleware('undangan.user')->get('undangan_return/{kode}', 'tripayReturnUndangan');
        Route::middleware('undangan.user')->get('xendit_undangan/{kode}', 'xenditReturnUndangan');
        Route::middleware('undangan.user')->get('detail_undangan/{kode}', 'detailUndangan')->name('detail_undangan');
        Route::middleware('undangan.user')->get('update_status_undangan/{kode}', 'updateStatusUndangan')->name('update_status_undangan');
        Route::get('riwayat_undangan', 'riwayatUndangan')->name('riwayat_undangan');
        Route::middleware('undangan.user')->delete('riwayat_undangan/{kode}', 'hapusUndangan');
        Route::middleware('undangan.user')->middleware('XssClean')->put('data_pengantin/{kode}/edit', 'editDataPengantin')->name('edit_data_pengantin');
        Route::middleware('undangan.user')->middleware('XssClean')->put('data_undangan/{kode}/edit', 'editDataUndangan')->name('edit_data_undangan');
        Route::middleware('undangan.user')->middleware('XssClean')->put('data_galeri/{kode}/edit', 'editDataGaleri')->name('edit_data_galeri');
        Route::middleware('undangan.user')->middleware('XssClean')->put('data_cerita/{kode}/edit', 'editDataCerita')->name('edit_data_cerita');
        Route::middleware('undangan.user')->delete('delete_galeri/{kode}/{id}', 'deleteGaleri')->name('delete_fg');
        Route::middleware('undangan.user')->delete('delete_cerita/{kode}/{id}', 'deleteCerita')->name('delete_cp');
    });
    Route::controller(SelfPhotoController::class)->group(function () {
        // Bagian route untuk fitur booking self photo
        Route::get('self_photo', 'selfPhoto')->name('self_photo');
        Route::middleware('XssClean')->post('self_photo', 'selfPhoto');
        Route::get('paket_self/{id}', 'paketSelf')->name('paket_self');
        Route::middleware('XssClean')->post('paket_self/{id}', 'paketSelf');
        Route::get('tanggal_self', 'tanggalSelf')->name('tanggal_self');
        Route::middleware('XssClean')->post('tanggal_self', 'tanggalSelf');
        Route::get('jam_self', 'jamSelf')->name('jam_self');
        Route::middleware('XssClean')->post('jam_self', 'jamSelf');
        Route::get('pembayaran_self', 'pembayaranSelf')->name('pembayaran_self');
        Route::middleware('XssClean')->post('pembayaran_self', 'pembayaranSelf');
        Route::get('konfirmasi_selfphoto', 'konfirmasiSelfPhoto')->name('konfirmasi_selfphoto');
        Route::middleware('XssClean')->post('create_booking_self', 'createBookingSelf')->name('create_self');
        // Bagian route untuk fitur riwayat booking self photo
        Route::get('riwayat_selfphoto', 'riwayatSelfPhoto')->name('riwayat_selfphoto');
        Route::middleware('selfphoto.user')->get('riwayat_selfphoto/{kode}', 'detailSelfPhoto')->name('detail_selfphoto');
        Route::middleware('selfphoto.user')->delete('riwayat_selfphoto/{kode}', 'hapusSelfPhoto');
        Route::middleware('selfphoto.user')->get('cetak_selfphoto/{kode}', 'cetakSelfPhoto')->name('cetak_selfphoto');
        Route::middleware('selfphoto.user')->get('bayar_selfphoto/{kode}', 'bayarSelfPhoto')->name('bayar_selfphoto');
        Route::middleware('XssClean')->post('bayar_selfphoto/{kode}', 'bayarSelfPhoto');
        Route::middleware('selfphoto.user')->get('selfphoto_return/{kode}', 'tripayReturnSelfPhoto');
        Route::middleware('selfphoto.user')->get('xendit_selfphoto/{kode}', 'xenditReturnSelfPhoto');
        Route::middleware('selfphoto.user')->get('restanggal_selfphoto/{kode}', 'resTanggalSelfPhoto')->name('restanggal_selfphoto');
        Route::middleware('XssClean')->post('restanggal_selfphoto/{kode}', 'resTanggalSelfPhoto');
        Route::middleware('selfphoto.user')->get('resjam_selfphoto/{kode}', 'resJamSelfPhoto')->name('resjam_selfphoto');
        Route::middleware('XssClean')->post('resjam_selfphoto/{kode}', 'resJamSelfPhoto');
        // Bagian route untuk fitur testimoni
        Route::middleware('selfphoto.user')->get('testimoni_selfphoto/{kode}', 'testimoniSelfPhoto')->name('testimoni_selfphoto');
        Route::middleware('XssClean')->post('testimoni_selfphoto/{kode}', 'testimoniSelfPhoto');
    });
    Route::controller(DashboardController::class)->group(function () {
        // Bagian route untuk fitur dashboard
        Route::get('admin', 'index')->name('admin');
        Route::post('admin', 'index');
        Route::post('ganti_cs', 'gantiCs')->name('ganti_cs');
        Route::get('grafik_laporan', 'grafikLaporan')->name('grafik');
        Route::get('cari_kode', 'cariKode')->name('cari_kode');
        Route::get('cari_booking/{kode}', 'cariBooking')->name('cari_booking');
        Route::post('cari_booking/{kode}', 'cariBooking');
        Route::get('print_booking/{kode}', 'printBooking');
        Route::get('scan_kode', 'scanKode')->name('scan_kode');
        Route::post('scan_kode', 'scanKode');
        Route::get('data_booking/{kode}', 'dataBooking')->name('data_booking');
    });
    Route::get('logout', [AuthController::class, 'logout'])->name('logout');
});

Route::middleware('guest')->group(function () {
    Route::controller(AuthController::class)->group(function () {
        Route::get('send_aktivasi/{no_tlp}', 'resendAktivasi')->name('send_aktivasi');
        Route::get('send_reset/{no_tlp}', 'resendReset')->name('send_reset');
        Route::get('send_mail/{no_tlp}', 'resendMail')->name('send_mail');
        Route::get('login', 'showLogin')->name('login');
        Route::post('login', '_login');
        Route::get('registrasi', 'showRegistrasi')->name('registrasi');
        Route::middleware('XssClean')->post('registrasi', 'showRegistrasi');
        Route::get('lupa_password', 'lupaPassword')->name('lupa_password');
        Route::middleware('XssClean')->post('lupa_password', 'lupaPassword');
        Route::get('/reset_password/{no_tlp}', 'resetPassword');
        Route::middleware('XssClean')->post('/reset_password/{no_tlp}', 'resetPassword');
        Route::get('/{type}/{no_tlp}', 'verifikasi');
        Route::middleware('XssClean')->post('/{type}/{no_tlp}', 'verifikasi');
    });
});

Route::controller(PaymentController::class)->group(function () {
    Route::post('studio_callback', 'studioCallback');
    Route::post('wedding_callback', 'weddingCallback');
    Route::post('undangan_callback', 'undanganCallback');
    Route::post('selfphoto_callback', 'selfPhotoCallback');
    Route::post('callback_xendit', 'callbackXendit');
});

Route::get('/', WebsiteController::class)->name('/');
Route::get('/default_page', [AuthController::class, 'goToDefaultPage'])->name('default_page');
