<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Config Payment Gateway Tripay
    |--------------------------------------------------------------------------
    */
    'tripay_kode' => env('KODE_MERCHANT_PG', ''),
    'tripay_api' => env('API_KEY_PG', ''),
    'tripay_private' => env('PRIVATE_KEY_PG', ''),
    'tripay_mode' => env('MODE_PG', ''),
    /*
    |--------------------------------------------------------------------------
    | Config Payment Gateway Xendit
    |--------------------------------------------------------------------------
    */
    'xendit_secret' => env('XENDIT_SECRET_KEYS', ''),
    'xendit_token' => env('XENDIT_TOKEN_CALLBACK', ''),
];
