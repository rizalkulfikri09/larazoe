<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Config WhatsApp Gateway
    |--------------------------------------------------------------------------
    */
    'wg_token' => env('TOKEN_WHATSAPP_GATEWAY', ''),
    'wg_domain' => env('DOMAIN_WHATSAPP_GATEWAY', ''),
    /*
    |--------------------------------------------------------------------------
    | Config Google Recaptcha
    |--------------------------------------------------------------------------
    */
    'captcha_key' => env('GOOGLE_RECAPTCHA_KEY', ''),
    'captcha_secret' => env('GOOGLE_RECAPTCHA_SECRET', ''),
];
