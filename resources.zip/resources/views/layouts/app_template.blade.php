<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicons -->
    <link href="{{ asset('frontend/images/favicon/'.$set_umum->value_4) }}" rel="icon">
    <!-- CSS -->
    <link rel="stylesheet" href="{{ asset('frontend/libs/fontawesome/css/all.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/vendor/bootstrap/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/vendor/bootstrap-select/css/bootstrap-select.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/vendor/fonts/circular-std/style.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/libs/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/libs/css/lightbox.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/libs/css/wtf-forms.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/vendor/select2/css/select2.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/libs/css/select2-bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/vendor/datepicker/tempusdominus-bootstrap-4.css') }}" />
    <link rel="stylesheet" href="{{ asset('frontend/vendor/charts/morris-bundle/morris.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/vendor/fonts/flag-icon-css/flag-icon.min.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/datatables/css/jquery.dataTables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/datatables/css/buttons.bootstrap4.min.css') }}">
    <!-- jquery 3.3.1 -->
    <script src="{{ asset('frontend/vendor/jquery/jquery-3.3.1.min.js') }}"></script>
    <script src="{{ asset('frontend/libs/js/jquery-ui.min.js') }}"></script>
    <script src="{{ asset('frontend/libs/cleave/cleave.min.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('frontend/libs/js/jquery-ui.min.css') }}">
    <!-- DataTables -->
    <script src="{{ asset('frontend/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('frontend/datatables/js/dataTables.buttons.min.js') }}"></script>
    <script src="{{ asset('frontend/datatables/js/buttons.bootstrap4.min.js') }}"></script>
    <!-- DataTables Responsive -->
    <script src="{{ asset('frontend/datatables/responsive/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('frontend/datatables/responsive/js/responsive.bootstrap.min.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('frontend/datatables/responsive/css/responsive.bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/libs/css/table.css') }}">
    <script src="{{ asset('frontend/vendor/datepicker/moment.js') }}"></script>
    <script src="{{ asset('frontend/vendor/datepicker/tempusdominus-bootstrap-4.js') }}"></script>
    <script src="{{ asset('frontend/vendor/slimscroll/jquery.slimscroll.js') }}"></script>
    <title>{{ $set_umum->value_1 }}</title>
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="{{ route('user') }}">{{ $set_umum->value_2 }}</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"><i class="fas fa-user" style="color:#fff; transform: scale(1.2); padding-right: 60px;"></i></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        @if (auth()->user()->role_id == 1 && !empty(notif_bayar()))
                        <li class="nav-item dropdown notification">
                            <a class="nav-link nav-icons" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-bell" style="transform: scale(1.2);"></i> <span class="indicator"></span></a>
                            <ul class="dropdown-menu dropdown-menu-right notification-dropdown">
                                <li>
                                    <div class="notification-title">Pembayaran Yang Belum Diproses</div>
                                    <div class="notification-list">
                                        <div class="notification-info">
                                            @foreach (notif_bayar() as $item)
                                                <div class="list-group">
                                                    @if ($item['kode_booking'])
                                                        <a href="{{ route('edit_booking', $item['kode_booking']) }}" class="list-group-item list-group-item-action">
                                                            <div class="notification-info">
                                                                <div>{{ $item['kode_booking'] }} : Klik disini untuk verifikasi pembayaran konsumen</div>
                                                            </div>
                                                        </a>
                                                    @elseif ($item['kode_wedding'])
                                                        <a href="{{ route('edit_wedding', $item['kode_wedding']) }}" class="list-group-item list-group-item-action">
                                                            <div class="notification-info">
                                                                <div>{{ $item['kode_wedding'] }} : Klik disini untuk verifikasi pembayaran konsumen</div>
                                                            </div>
                                                        </a>
                                                    @elseif ($item['kode_undangan'])
                                                        <a href="{{ route('edit_undangan', $item['kode_undangan']) }}" class="list-group-item list-group-item-action">
                                                            <div class="notification-info">
                                                                <div>{{ $item['kode_undangan'] }} : Klik disini untuk verifikasi pembayaran konsumen</div>
                                                            </div>
                                                        </a>
                                                    @elseif ($item['kode_selfphoto'])
                                                        <a href="{{ route('edit_selfphoto', $item['kode_selfphoto']) }}" class="list-group-item list-group-item-action">
                                                            <div class="notification-info">
                                                                <div>{{ $item['kode_selfphoto'] }} : Klik disini untuk verifikasi pembayaran konsumen</div>
                                                            </div>
                                                        </a>
                                                    @endif
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        @endif
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="{{ asset('frontend/images/profile/' . auth()->user()->image) }}" alt="" class="user-avatar-md rounded-circle"><b style="margin-left: 10px; color: white;">{{ auth()->user()->nama }}</b></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown" aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name">{{ auth()->user()->nama }}</h5>
                                    {{ auth()->user()->no_tlp }}
                                </div>
                                <a class="dropdown-item" href="{{ route('user') }}"><i class="fas fa-user mr-2"></i>Profil Saya</a>
                                <a class="dropdown-item" href="{{ route('logout') }}"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>  
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list" id="menu">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#" style="font-size: 25px;">Menu</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse m-b-100" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            @foreach (getMenu() as $menu)
                                <li class="nav-divider">{{ $menu->menu->menu }}</li>
                                @foreach (getSubMenu($menu->menu->id) as $sm)
                                    <li class="nav-item"><a class="nav-link {{ request()->is($sm->url.'*') ? 'active' : '' }}" href="{{ route($sm->url) }}"><i class="{{ $sm->icon }}"></i>{{ $sm->title }}</a></li>
                                @endforeach
                            @endforeach
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">{{ $title }}</h2>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    @yield('body')
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <script src="{{ asset('frontend/vendor/datepicker/datepicker.js') }}"></script>
    <script src="{{ asset('frontend/libs/js/lightbox.js') }}"></script>
    <script src="{{ asset('frontend/libs/js/lazysizes.min.js') }}"></script>
    <!-- bootstap bundle js -->
    <script src="{{ asset('frontend/vendor/bootstrap/js/bootstrap.bundle.js') }}"></script>
    <script src="{{ asset('frontend/vendor/bootstrap-select/js/bootstrap-select.js') }}"></script>
    <!-- main js -->
    <script src="{{ asset('frontend/libs/js/main-js.js') }}"></script>
    <script src="{{ asset('frontend/vendor/select2/js/select2.min.js') }}"></script>
    <script src="{{ asset('frontend/libs/js/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('frontend/libs/js/myscript.js') }}"></script>
    <script type="text/javascript">
        lightbox.option({
            "showImageNumberLabel" : false,
            'disableScrolling': true,
            "wrapAround" : true
        })
        if (window.matchMedia('(max-width: 767px)').matches) { $('#menu').removeClass('menu-list').addClass('menu-remove'); }
    </script>
</body>

</html>