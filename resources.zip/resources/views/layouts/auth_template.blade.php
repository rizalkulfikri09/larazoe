<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicons -->
    <link href="{{ asset('frontend/images/favicon/'.$set_umum->value_4) }}" rel="icon">
    <title>{{ $set_umum->value_1 }}</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ asset('frontend/vendor/bootstrap/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/vendor/fonts/circular-std/style.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/libs/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/libs/css/auth.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/libs/fontawesome/css/all.css') }}">
    <script src="{{ asset('frontend/vendor/jquery/jquery-3.3.1.min.js') }}"></script>
</head>

<body>
    <!-- ============================================================== -->
    <!-- body page  -->
    <!-- ============================================================== -->
@yield('body')
    <!-- ============================================================== -->
    <!-- end body page  -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <script src="{{ asset('frontend/libs/js/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('frontend/libs/js/myscript.js') }}"></script>
    <script src="{{ asset('frontend/vendor/bootstrap/js/bootstrap.bundle.js') }}"></script>
    <script>
        $(".toggle-password").click(function() {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
            input.attr("type", "text");
            } else {
            input.attr("type", "password");
            }
        });
    </script>
</body>

</html>