<!DOCTYPE html>
<html lang="id">
<head>
    <title>{{ $mailData['title'] }}</title>
</head>
<body>
    <h1>{{ $mailData['title'] }}</h1>
    <p>{{ $mailData['body'] }}</p>
    <p><a href="{{ $mailData['link'] }}">{{ $mailData['link'] }}</a></p>
</body>
</html>