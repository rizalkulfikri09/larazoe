@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col-12">
            @include('components.alert')
            <a href="javascript:void(0)" id="tambahPaket" class="btn btn-primary m-b-20">Tambah Paket</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Durasi Undangan Digital</th>
                                    <th scope="col">Harga Paket</th>
                                    <th scope="col">Status Paket</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data_paket as $index => $dp)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ convert_durasi($dp->durasi) }}</td>
                                    <td>{{ format_rupiah($dp->harga) }}</td>
                                    <td>{{ $dp->is_active == 1 ? 'Aktif' : 'Tidak Aktif' }}</td>
                                    <td>
                                        <a href="javascript:void(0)" class="btn btn-success btn-block btn-sm editPaket" data-id="{{ $dp->id }}" data-durasi="{{ $dp->durasi }}" data-harga="{{ $dp->harga }}" data-status="{{ $dp->is_active }}">Edit</a>
                                        <form action="{{ route('delete_paket_undangan', $dp->id) }}" method="post">
                                            @csrf
                                            @method('delete')
                                            <button type="submit" class="btn btn-danger btn-block btn-sm delete_data">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col-12">
            <div class="alert alert-warning" role="alert">
                Hati-hati jika ingin mengubah durasi undangan digital, karena berpengaruh terhadap undangan digital yang telah dibuat.
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="" id="formPaket" method="post" autocomplete="off">
                @csrf
                <div class="modal-body">
                    <input type="hidden" name="" name="id" id="id">
                    <div class="form-group">
                        <label>Durasi Undangan Digital</label>
                        <div class="input-group">
                            <input type="text" id="durasi" name="durasi" class="form-control" placeholder="Isi jumlah hari" required> 
                            <div class="input-group-append"><span class="input-group-text">Hari</span></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Harga Paket</label>
                        <input type="text" id="harga" name="harga" class="form-control" placeholder="Isi harga paket" required>
                    </div>
                    <div class="form-group status_input">
                        <label>Status Paket</label>
                        <select class="form-control selectpicker status" id="is_active" name="is_active">
                            <option value="1">Aktif</option>
                            <option value="0">Tidak Aktif</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    new Cleave('#harga', {
        numeral: true,
        numeralDecimalMark: ',',
        delimiter: '.',
        prefix: 'Rp ',
    });

    $('#tambahPaket').click(function () {
        $('#formPaket').attr('action', "{{ route('paket_undangan') }}");
        $('#simpanBtn').val("tambah-paket");
        $('#id').val('');
        $('#modelHeading').html("Form tambah paket undangan");
        $('#exampleModal').modal('show');
        $('#durasi').val('');
        $('#harga').val('0');
        $('.status_input').hide();
    });

    // Bagian edit data
    $('body').on('click', '.editPaket', function () {
        const id = $(this).data('id');
        const durasi = $(this).data('durasi');
        const harga = $(this).data('harga');
        const status = $(this).data('status');

        $('#formPaket').attr('action', "{{ url('paket_undangan') }}/" + id + "/edit");
        $('#modelHeading').html("Form edit paket undangan");
        $('#simpanBtn').val("edit-paket");
        $('#exampleModal').modal('show');
        $('.status_input').show();
        $('#id').val(id);
        $('#durasi').val(durasi);
        $('#harga').val(harga);
        $('.status').val(status).trigger('change');
    });
</script>
@endsection