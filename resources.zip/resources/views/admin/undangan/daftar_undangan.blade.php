@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="card" style="margin-bottom: 16px;">
                <div class="card-body">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-sm-6 mb-2">
                                <label>Filter Status Undangan</label>
                                <select class="form-control selectpicker" name="status_undangan" id="status_undangan">
                                    <option value="" selected disabled hidden>Pilih di sini</option>
                                    @foreach ($status_undangan as $sun)
                                        <option value="{{ $sun }}">{{ $sun }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label>Filter Paket Undangan</label>
                                <select class="form-control selectpicker" name="id_paket" id="id_paket">
                                    <option value="" selected disabled hidden>Pilih di sini</option>
                                    @foreach ($daftar_paket as $dp)
                                        <option value="{{ $dp->id }}">{{ convert_durasi($dp->durasi) }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 mt-2">
                                <label>Filter Status Pembayaran</label>
                                <select class="form-control selectpicker" name="status_bayar" id="status_bayar">
                                    <option value="" selected disabled hidden>Pilih di sini</option>
                                    @foreach ($status_bayar as $sba)
                                        <option value="{{ $sba }}">{{ $sba }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-sm-6 mt-2">
                                <label>Filter Tema Undangan</label>
                                <select class="form-control selectpicker" name="id_tema" id="id_tema">
                                    <option value="" selected disabled hidden>Pilih di sini</option>
                                    @foreach ($daftar_tema as $dt)
                                        <option value="{{ $dt->id }}">{{ $dt->nama_tema }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <button type="button" id="btn-filter" class="btn btn-space btn-primary">Filter Data</button>
                            <button type="button" id="btn-reset" class="btn btn-space btn-default">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card" style="margin-bottom: 16px;">
                <div class="card-body" style="padding: 16px;">
                    <a href="javascript:void(0)" id="delete_all" class="btn btn-space btn-danger">Hapus Yang Dipilih</a>
                    <a href="{{ url('undangan_excel') }}" class="btn btn-space btn-success tombol_export">Cetak Excel</a>
                    <a href="{{ url('undangan_pdf') }}" class="btn btn-space btn-primary tombol_export">Cetak PDF</a>
                </div>
            </div>
            <div class="card kotak">
                <div class="table-responsive">
                    <table class="display table table-striped table-bordered first data-table" width="99%">
                        <thead>
                            <tr>
                                <th class="colomnSize"><input type="checkbox" id="check_all"></th>
                                <th class="colomnSize">Kode Undangan</th>
                                <th class="colomnSize">Nama Konsumen</th>
                                <th class="colomnSize">Nomor WhatsApp</th>
                                <th class="colomnSize">Status Undangan</th>
                                <th class="colomnSize">Status Bayar</th>
                                <th class="colomnSize">Tema Undangan</th>
                                <th>Masa Aktif</th>
                                <th>Total Transaksi</th>
                                <th width="0">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="8" style="text-align: right!important; font-weight: bold">TOTAL :</th>
                                <th style="font-weight: bold" id="sum_total"></th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.fn.dataTable.ext.classes.sPageButton = 'btn btn-dark';
        var table = $('.data-table').DataTable({
            searchDelay: 500,
            processing: true,
            serverSide: true,
            ajax: {
                'url': "{{ route('daftar_undangan') }}",
                'data': function (d) {
                    d.status_undangan = $('#status_undangan').val();
                    d.id_paket = $('#id_paket').val();
                    d.status_bayar = $('#status_bayar').val();
                    d.id_tema = $('#id_tema').val();
                }
            },
            drawCallback:function(data)
            {
                $('#sum_total').html(data.json.sum_total);
            },
            columns: [
                { data: 'kodes', name: 'kodes' },
                { data: 'kode', name: 'kode' },
                { data: 'nama', name: 'nama' },
                { data: 'no_tlp', name: 'no_tlp' },
                { data: 'status_undangan', name: 'status_undangan' },
                { data: 'status_bayar', name: 'status_bayar' },
                { data: 'tema', name: 'tema' },
                { data: 'masa_aktif', name: 'masa_aktif' },
                { data: 'total', name: 'total' },
                { data: 'opsi', name: 'opsi' },
            ],
            "aoColumnDefs": [
                { "bSortable": false, "aTargets": [0,9] }, 
                { "bSearchable": false, "aTargets": [0,9] },
                { "className": "text-center", "targets" : [0,1,2,3,4,5,6,7,8,9] },
            ],
            "aaSorting": [],
        });
        $('#btn-filter').click(function () {
            reloadTable();
        });
        $('#btn-reset').click(function() {
            $('#status_undangan').val('').selectpicker("refresh");
            $('#id_paket').val('').selectpicker("refresh");
            $('#status_bayar').val('').selectpicker("refresh");
            $('#id_tema').val('').selectpicker("refresh");
            reloadTable();
            location.reload();
        });
        function reloadTable() {
            var table = $('.data-table').DataTable();
            table.cleanData;
            table.ajax.reload();
            {{ session()->forget(['status_undangan', 'id_paket', 'status_bayar', 'id_tema']); }}
        }

        // Bagian delete data
        $('body').on('click', '.deleteUndangan', function (){
            var kode = $(this).data("kode");
            Swal.fire({
                title: 'Apakah anda yakin',
                text: "Data akan dihapus",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Hapus Data!'
            }).then(function (e) {
                if (e.value === true) {
                    $.ajax({
                        type: "DELETE",
                        url: "{{ url('delete_undangan') }}/" + kode,
                        success: function (data) {
                            $('#alert_message').html('<div class="alert alert-success" >'+ data.message +'</div>');
                            alertSuccess(data.message);
                            table.draw();
                        },
                        error: function (data) {
                            console.log('Error:', data);
                        }
                    });
                } else {
                    return false;
                }
            });
        });

        // Bagian multiple delete data
        $('#check_all').on('click', function(e) {
            $(this).is(':checked',true) ? $(".sub_chk").prop('checked', true) : $(".sub_chk").prop('checked',false);
        });
        $('#delete_all').on('click', function(e) {
            var data_chk = [];
            $(".sub_chk:checked").each(function() {  
                data_chk.push($(this).attr('data-kodes'));
            });
            if (data_chk.length<=0) {
                Swal.fire("Pilih data terlebih dahulu!");
            } else {
                Swal.fire({
                    title: 'Apakah anda yakin',
                    text: "Data akan dihapus",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Hapus Data!'
                }).then(function (e) {
                    if (e.value === true) {
                        var join_selected_values = data_chk.join(","); 
                        $.ajax({
                            url: "{{ url('daftar_undangan_delete') }}",
                            type: 'DELETE',
                            data: 'kodes='+join_selected_values,
                            success: function (data) {
                                if (data['success']) {
                                    $(".sub_chk:checked").each(function() {  
                                        $(this).parents("tr").remove();
                                        $("#check_all").prop('checked', false);
                                    });
                                    $('#alert_message').html('<div class="alert alert-success" >'+ data.message +'</div>');
                                    alertSuccess(data.message);
                                    table.draw();
                                } else if (data['error']) {
                                    alert(data['error']);
                                } else {
                                    alert('Ups Ada yang tidak beres.');
                                }
                            },
                            error: function (data) {
                                alert(data.responseText);
                            }
                        });
                    } else {
                        return false;
                    }
                });
            }
        });

    });
</script>
@endsection