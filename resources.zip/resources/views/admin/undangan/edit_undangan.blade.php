@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('edit_undangan', $undangan->kode) }}" method="post">
                        @csrf
                        @method('put')
                        <div class="form-group">
                            <label>Ubah Status Undangan</label>
                            <select class="form-control selectpicker" name="status_undangan" id="status_undangan">
                                @foreach ($status_undangan as $sun)
                                    <option value="{{ $sun }}" @selected($sun == $undangan->status_undangan)>{{ $sun }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Ubah Status Pembayaran</label>
                            <select class="form-control selectpicker" name="status_bayar" id="status_bayar">
                                @foreach ($status_bayar as $sba)
                                    <option value="{{ $sba }}" @selected($sba == $undangan->status_bayar)>{{ $sba }}</option>
                                @endforeach
                            </select>
                        </div>
                        @if (isset($transaksi->link) && is_null($transaksi->no_ref))
                        <div class="form-group">
                            <label>Bukti Pembayaran</label><br>
                            <img src="{{ asset('frontend/images/bukti_tf/' . $transaksi->link) }}" style="width: 250px; height: 400px;" />
                        </div>
                        @endif
                        <div class="row">
                            <div class="col">
                                <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                @include('components.button_kembali', ['url' => route('daftar_undangan')])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection