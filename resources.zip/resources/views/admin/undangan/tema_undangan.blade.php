@extends('layouts.app_template')
@section('body')
<style>
    .paket {
		width: 300px;
		height: 400px;
    }

    @media only screen and (max-width: 600px) {
		.paket {
			width: 100%;
            height: auto;
		}
    }
</style>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <a href="javascript:void(0)" id="tambahTema" class="btn btn-primary m-b-20">Tambah Tema</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Nama Tema</th>
                                    <th scope="col">Status Tema</th>
                                    <th scope="col">Link Preview</th>
                                    <th scope="col">Thumbnail Tema</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data_tema as $index => $dt)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $dt->nama_tema }}</td>
                                    <td>{{ $dt->is_active == 1 ? 'Aktif' : 'Tidak Aktif' }}</td>
                                    <td><a href="{{ url('preview', $dt->preview) }}" target="_blank">{{ url('preview', $dt->preview) }}</a></td>
                                    <td><img data-src="{{ asset('frontend/images/paket/' . $dt->thumbnail) }}" class="lazyload paket"></td>
                                    <td>
                                        <a href="javascript:void(0)" class="btn btn-success btn-block btn-sm editTema" data-id="{{ $dt->id }}" data-nama_tema="{{ $dt->nama_tema }}" data-thumbnail="{{ $dt->thumbnail }}" data-status="{{ $dt->is_active }}" data-aspect="{{ $dt->aspect_ratio }}" data-width="{{ $dt->width_slider }}" data-height="{{ $dt->height_slider }}" data-preview="{{ $dt->preview }}">Edit</a>
                                        <form action="{{ route('delete_tema_undangan', $dt->id) }}" method="post">
                                            @csrf
                                            @method('delete')
                                            <button type="submit" class="btn btn-danger btn-block btn-sm delete_data">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="" id="formTema" method="post" enctype="multipart/form-data" autocomplete="off">
                @csrf
                <div class="modal-body">
                    <input type="hidden" name="" name="id" id="id">
                    <div class="form-group">
                        <label>Nama Tema</label>
                        <input type="text" id="nama_tema" name="nama_tema" placeholder="Isi nama tema" class="form-control" required>
                    </div>
                    <div class="form-group status_input">
                        <label>Status Tema</label>
                        <select class="form-control selectpicker status" id="is_active" name="is_active">
                            <option value="1">Aktif</option>
                            <option value="0">Tidak Aktif</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Link Preview</label>
                        <input type="text" id="preview" name="preview" placeholder="Contoh : white_love" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Aspect Ratio</label>
                        <input type="text" id="aspect_ratio" name="aspect_ratio" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Width Slider</label>
                        <input type="text" id="width_slider" name="width_slider" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Height Slider</label>
                        <input type="text" id="height_slider" name="height_slider" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Thumbnail Tema</label>
                        <div class="custom-file">
                            <label class="file">
                                <input type="file" class="custom-file-input" id="thumbnail" name="thumbnail" aria-label="File browser example" onchange="preview_image(event)">
                                <span class="file-custom m-t-10">Pilih file...</span>
                            </label>
                        </div>
                    </div>
                    <div class="form-group" id="pratinjau" style="display:none;">
                        <br><img id="output_image" width="340px" height="420px"/>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $('#tambahTema').click(function () {
        $('#formTema').attr('action', "{{ route('tema_undangan') }}");
        $('#simpanBtn').val("tambah-paket");
        $('.status_input').hide();
        $('#id').val('');
        $('#modelHeading').html("Form tambah tema undangan digital");
        $('#exampleModal').modal('show');
        $('#nama_tema').val('');
        $('#preview').val('');
        $('#aspect_ratio').val('');
        $('#width_slider').val('');
        $('#height_slider').val('');
        $('#pratinjau').hide();
    });

    // Bagian edit data
    $('body').on('click', '.editTema', function () {
        const id = $(this).data('id');
        const nama_tema = $(this).data('nama_tema');
        const thumbnail = $(this).data('thumbnail');
        const status = $(this).data('status');
        const aspect = $(this).data('aspect');
        const width = $(this).data('width');
        const height = $(this).data('height');
        const preview = $(this).data('preview');

        $('#formTema').attr('action', "{{ url('tema_undangan') }}/" + id + "/edit");
        $('#modelHeading').html("Form edit tema undangan");
        $('#simpanBtn').val("edit-tema");
        $('#exampleModal').modal('show');
        $('.status_input').show();
        $('#id').val(id);
        $('#nama_tema').val(nama_tema);
        $('#preview').val(preview);
        $('#aspect_ratio').val(aspect);
        $('#width_slider').val(width);
        $('#height_slider').val(height);
        $('.status').val(status).trigger('change');
        $('#pratinjau').show();
        $('#output_image').attr('src', '{{ asset('frontend/images/paket') }}/' + thumbnail);
    });

    function preview_image(event) 
    {
        var reader = new FileReader();
        reader.onload = function()
        {
            var output = document.getElementById('output_image');
            output.src = reader.result;
            document.getElementById('pratinjau').style.display = "";
        }
        reader.readAsDataURL(event.target.files[0]);
    }
</script>
@endsection