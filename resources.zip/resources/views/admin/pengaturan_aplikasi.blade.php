@extends('layouts.app_template')
@section('body')
<style>
    .logo-bank {
        width: 90px;
        height: 30px;
    }
    .card-body {
        padding: 1rem;
    }
    .tab-vertical .nav-tabs .nav-link {
        padding: 17px 20px;
    }
    .foto_portofolio {
        width: 305px;
        height: 225px;
    }
    .logo_slider {
        width: 250px;
        height: 50px;
    }
</style>
@include('components.alert')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <h4 class="card-header">Pengaturan WhatsApp Gateway</h4>
                <div class="card-body">
                    <form action="{{ url('edit_whatsapp') }}" method="post">
                        @csrf
                        @method('put')
                        <div class="form-group">
                            <label>Nomor WhatsApp Admin</label>
                            <input type="text" id="nomor_admin" name="nomor_admin" value="{{ $whatsapp->value_1 }}" data-parsley-trigger="change" required="" autocomplete="off" class="form-control" data-toggle="tooltip" data-placement="top" title="Berfungsi untuk mengirimkan notifikasi ke admin jika ada booking studio">
                        </div>
                        <div class="form-group row pt-0">
                            <label class="col-12 col-lg-6 col-form-label">Status WhatsApp Gateway</label>
                            <div class="col-12 col-lg-6 pt-1">
                                <div class="switch-button switch-button-success" data-toggle="tooltip" data-placement="right" title="Pastikan anda sudah mengisi TOKEN & DOMAIN WHATSAPP GATEWAY di env / config">
                                    <input type="hidden" name="status_wg" value="0">
                                    <input type="checkbox" value="1" @checked(1 == $whatsapp->value_2) name="status_wg" id="status_wg"><span>
                                    <label for="status_wg"></label></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row pt-0">
                            <label class="col-12 col-lg-6 col-form-label">Status Fitur Reminder</label>
                            <div class="col-12 col-lg-6 pt-1">
                                <div class="switch-button switch-button-danger" data-toggle="tooltip" data-placement="right" title="Berfungsi untuk mengirimkan pesan pengingat H-1 pemotretan ke konsumen">
                                    <input type="hidden" name="reminder" value="0">
                                    <input type="checkbox" value="1" @checked(1 == $whatsapp->value_3) name="reminder" id="reminder"><span>
                                    <label for="reminder"></label></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row pt-0">
                            <label class="col-12 col-lg-6 col-form-label">Verifikasi Kode Lewat WhatsApp</label>
                            <div class="col-12 col-lg-6 pt-1">
                                <div class="switch-button switch-button-primary" data-toggle="tooltip" data-placement="right" title="Berfungsi untuk mengirimkan kode verifikasi ke WhatsApp konsumen, ubah jadi OFF jika WhatsApp Gateway sedang tidak aktif.">
                                    <input type="hidden" name="verifikasi" value="0">
                                    <input type="checkbox" value="1" @checked(1 == $pengaturan_sistem->value_2) name="verifikasi" id="verifikasi"><span>
                                    <label for="verifikasi"></label></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row pt-0">
                            <label class="col-12 col-lg-6 col-form-label">Verifikasi Kode Lewat Email</label>
                            <div class="col-12 col-lg-6 pt-1">
                                <div class="switch-button switch-button-success" data-toggle="tooltip" data-placement="right" title="Pastikan anda sudah mengisi MAIL_USERNAME, MAIL_PASSWORD, dll pada file .env">
                                    <input type="hidden" name="verifikasi_email" value="0">
                                    <input type="checkbox" value="1" @checked(1 == $pengaturan_sistem->value_10) name="verifikasi_email" id="verifikasi_email"><span>
                                    <label for="verifikasi_email"></label></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 m-t-10">
                                <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <h4 class="card-header">Pengaturan Metode Pembayaran</h4>
                <div class="pills-regular">
                    <ul class="nav nav-pills mb-1" id="pills-manual" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="pills-satu-tab" data-toggle="pill" href="#pills-satu" role="tab" aria-selected="false">Pembayaran Manual</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-dua-tab" data-toggle="pill" href="#pills-dua" role="tab" aria-selected="false">Bank Satu</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-tiga-tab" data-toggle="pill" href="#pills-tiga" role="tab" aria-selected="false">Bank Dua</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-empat-tab" data-toggle="pill" href="#pills-empat" role="tab" aria-selected="false">Tripay</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-lima-tab" data-toggle="pill" href="#pills-lima" role="tab" aria-selected="false">Xendit</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-manualContent" style="padding: 15px;">
                        <div class="tab-pane fade show active" id="pills-satu" role="tabpanel" aria-labelledby="pills-satu-tab">
                            <form action="{{ url('edit_payment_manual') }}" method="post">
                                @csrf
                                @method('put')
                                <div class="form-group">
                                    <label>Status Upload Bukti Transfer</label>
                                    <select class="form-control selectpicker" name="is_active">
                                        <option value="1" @selected(1 == $bank_1->value_5)>Aktif</option>
                                        <option value="0" @selected(0 == $bank_1->value_5)>Tidak Aktif</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Minimal DP Berapa Persen</label>
                                    <div class="input-group">
                                        <input type="text" id="jml_dp" name="jml_dp" value="{{ $bank_1->value_4 }}" required="" autocomplete="off" class="form-control">
                                        <div class="input-group-append"><span class="input-group-text">%</span></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="pills-dua" role="tabpanel" aria-labelledby="pills-dua-tab">
                            <form action="{{ url('edit_bank_1') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('put')
                                <div class="form-group">
                                    <label>Logo Bank 1</label>
                                    <div class="row">
                                        <div class="col-sm-3 mb-2">
                                            <img src="{{ asset('frontend/images/logo_bank/' . $bank_1->value_1) }}" class="logo-bank" id="logo_bank_1" />
                                        </div>
                                        <div class="col-sm-7">
                                            @include('components.file_upload', ['name' => 'logo_bank_1'])
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Nomor Rekening Bank 1</label>
                                    <input type="text" id="rekening_1" name="rekening_1" value="{{ $bank_1->value_2 }}" required="" autocomplete="off" class="form-control"> 
                                </div>
                                <div class="form-group">
                                    <label>Nama Pemilik Rekening 1</label>
                                    <input type="text" id="nama_1" name="nama_1" value="{{ $bank_1->value_3 }}" required="" autocomplete="off" class="form-control"> 
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="pills-tiga" role="tabpanel" aria-labelledby="pills-tiga-tab">
                            <form action="{{ url('edit_bank_2') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('put')
                                <div class="form-group">
                                    <label>Logo Bank 2</label>
                                    <div class="row">
                                        <div class="col-sm-3 mb-2">
                                        <img src="{{ asset('frontend/images/logo_bank/' . $bank_2->value_1) }}" class="logo-bank" id="logo_bank_2" />
                                        </div>
                                        <div class="col-sm-7">
                                            @include('components.file_upload', ['name' => 'logo_bank_2'])
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Nomor Rekening Bank 2</label>
                                    <input type="text" id="rekening_2" name="rekening_2" value="{{ $bank_2->value_2 }}" required="" autocomplete="off" class="form-control"> 
                                </div>
                                <div class="form-group">
                                    <label>Nama Pemilik Rekening 2</label>
                                    <input type="text" id="nama_2" name="nama_2" value="{{ $bank_2->value_3 }}" required="" autocomplete="off" class="form-control"> 
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="pills-empat" role="tabpanel" aria-labelledby="pills-empat-tab">
                            <form action="{{ url('edit_tripay') }}" method="post">
                                @csrf
                                @method('put')
                                <div class="form-group">
                                    <label>Status Payment Gateway Tripay</label>
                                    <select class="form-control selectpicker" name="is_active">
                                        <option value="1" @selected(1 == $pengaturan_pg->value_2)>Aktif</option>
                                        <option value="0" @selected(0 == $pengaturan_pg->value_2)>Tidak Aktif</option>
                                    </select>
                                    * Pastikan anda sudah mengisi API KEY, PRIVATE KEY, KODE MERCHANT di env / config.
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="pills-lima" role="tabpanel" aria-labelledby="pills-lima-tab">
                            <form action="{{ url('edit_xendit') }}" method="post">
                                @csrf
                                @method('put')
                                <div class="form-group">
                                    <label>Status Payment Gateway Xendit</label>
                                    <select class="form-control selectpicker" name="is_active">
                                        <option value="1" @selected(1 == $pengaturan_pg->value_3)>Aktif</option>
                                        <option value="0" @selected(0 == $pengaturan_pg->value_3)>Tidak Aktif</option>
                                    </select>
                                    * Pastikan anda sudah mengisi SECRET KEYS & TOKEN CALLBACK di env / config.
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="tab-vertical">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="satu-vertical-tab" data-toggle="tab" href="#satu-vertical" role="tab" aria-controls="satu" aria-selected="true">Pengaturan Umum</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="dua-vertical-tab" data-toggle="tab" href="#dua-vertical" role="tab" aria-controls="dua" aria-selected="false">Pengaturan Sistem</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="tiga-vertical-tab" data-toggle="tab" href="#tiga-vertical" role="tab" aria-controls="tiga" aria-selected="false">Pengaturan Portofolio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="empat-vertical-tab" data-toggle="tab" href="#empat-vertical" role="tab" aria-controls="empat" aria-selected="false">Header Website</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="lima-vertical-tab" data-toggle="tab" href="#lima-vertical" role="tab" aria-controls="lima" aria-selected="false">Bagian Website 1</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="enam-vertical-tab" data-toggle="tab" href="#enam-vertical" role="tab" aria-controls="enam" aria-selected="false">Bagian Website 2</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="tujuh-vertical-tab" data-toggle="tab" href="#tujuh-vertical" role="tab" aria-controls="tujuh" aria-selected="false">Bagian Website 3</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="delapan-vertical-tab" data-toggle="tab" href="#delapan-vertical" role="tab" aria-controls="delapan" aria-selected="false">FAQ / Pertanyaan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="sembilan-vertical-tab" data-toggle="tab" href="#sembilan-vertical" role="tab" aria-controls="sembilan" aria-selected="false">Footer Website</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="sepuluh-vertical-tab" data-toggle="tab" href="#sepuluh-vertical" role="tab" aria-controls="sepuluh" aria-selected="false">Logo Slider</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent3" style="padding: 15px;">
                        <div class="tab-pane fade show active" id="satu-vertical" role="tabpanel" aria-labelledby="satu-vertical-tab">
                            <form action="{{ url('edit_pengaturan_umum') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('put')
                                <div class="row">
                                    <div class="col-lg-6 col-12">
                                        <div class="form-group">
                                            <label>Title Aplikasi</label>
                                            <input type="text" id="title_aplikasi" name="title_aplikasi" value="{{ $pengaturan_umum->value_1 }}" required="" autocomplete="off" class="form-control" placeholder="Aplikasi Studio Foto"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Nama Aplikasi</label>
                                            <input type="text" id="nama_aplikasi" name="nama_aplikasi" value="{{ $pengaturan_umum->value_2 }}" required="" autocomplete="off" class="form-control" maxlength="12" placeholder="STUDIO FOTO"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Copyright Footer</label>
                                            <input type="text" id="copy_aplikasi" name="copy_aplikasi" value="{{ $pengaturan_umum->value_3 }}" required="" autocomplete="off" class="form-control" placeholder="Copyright © Studio Foto"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Nama Pemilik/Pimpinan</label>
                                            <input type="text" id="pemilik" name="pemilik" value="{{ $pengaturan_umum->value_6 }}" required="" autocomplete="off" class="form-control" placeholder="Isi nama pemilik/pimpinan studio foto">
                                        </div>
                                        <div class="form-group">
                                            <label>Kota Studio Foto</label>
                                            <input type="text" id="kota_studio" name="kota_studio" value="{{ $pengaturan_umum->value_7 }}" required="" autocomplete="off" class="form-control" placeholder="Isi nama kota studio foto, untuk footer PDF">
                                        </div>
                                        <div class="form-group">
                                            <label>Jam Tutup Studio Foto</label>
                                            <input type="text" id="tutup_studio" name="tutup_studio" value="{{ $pengaturan_pg->value_4 }}" required="" autocomplete="off" class="form-control" placeholder="Contoh : 21:00">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12">
                                        <div class="form-group">
                                            <label>Zona Waktu Aplikasi</label>
                                            <select class="form-control selectpicker" name="zona_waktu">
                                                @foreach ($zona_waktu as $zw => $val)
                                                    <option value="{{ $zw }}" @selected($pengaturan_umum->value_5 == $zw)>{{ $val }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Favicon Aplikasi</label>
                                            <div class="row">
                                                <div class="col-lg-3 mb-2">
                                                    <img src="{{ asset('frontend/images/favicon/' . $pengaturan_umum->value_4) }}" id="favicon_aplikasi" width="100%" />
                                                </div>
                                                <div class="col-lg-8" data-toggle="tooltip" data-placement="top" title="Pilih file yang berformat .ico">
                                                    @include('components.file_upload', ['name' => 'favicon_aplikasi'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Header PDF</label>
                                            <input type="text" id="nama_studio" name="nama_studio" value="{{ $pengaturan_umum->value_8 }}" required="" autocomplete="off" class="form-control" placeholder="Isi nama studio foto">
                                        </div>
                                        <div class="form-group">
                                            <textarea rows="3" type="text" id="alamat_studio" name="alamat_studio" required="" autocomplete="off" class="form-control" placeholder="Isi alamat studio foto" style="padding: 10px 10px;" maxlength="254">{{ $pengaturan_umum->value_9 }}</textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Footer PDF</label>
                                            <textarea rows="2" type="text" id="note_studio" name="note_studio" required="" autocomplete="off" class="form-control" placeholder="Catatan untuk cetak PDF" style="padding: 10px 10px;" maxlength="254">{{ $pengaturan_umum->value_10 }}</textarea>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="dua-vertical" role="tabpanel" aria-labelledby="dua-vertical-tab">
                            <form action="{{ url('edit_pengaturan_sistem') }}" method="post">
                                @csrf
                                @method('put')
                                <div class="row">
                                    <div class="col-lg-6 col-12">
                                        <div class="form-group">
                                            <label>Status Fitur Registrasi</label>
                                            <select class="form-control selectpicker" name="registrasi">
                                                <option value="1" @selected(1 == $pengaturan_sistem->value_4)>Aktif</option>
                                                <option value="0" @selected(0 == $pengaturan_sistem->value_4)>Tidak Aktif</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Jam Expired Booking</label>
                                            <div class="input-group">
                                                <input type="text" id="jam_expired" name="jam_expired" value="{{ $pengaturan_sistem->value_3 }}" required="" autocomplete="off" class="form-control @error('jam_expired') is-invalid @enderror" placeholder="Isi jam expired booking"> 
                                                <div class="input-group-append"><span class="input-group-text">Jam</span></div>
                                            </div>
                                            @error('jam_expired')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label>Jumlah Booking Wedding Per Hari</label>
                                            <div class="input-group">
                                                <input type="text" id="jml_wedding" name="jml_wedding" value="{{ $pengaturan_sistem->value_5 }}" required="" autocomplete="off" class="form-control" placeholder="Isi jumlah konsumen yang dapat ditangani"> 
                                                <div class="input-group-append"><span class="input-group-text">Konsumen</span></div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Biaya Transport Untuk Booking Wedding</label>
                                            <input type="text" id="transport" name="transport" value="{{ $pengaturan_sistem->value_6 }}" required="" autocomplete="off" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label>Catatan Untuk Transport</label>
                                            <input type="text" id="catatan_transport" name="catatan_transport" value="{{ $pengaturan_sistem->value_8 }}" required="" autocomplete="off" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Pengaturan Nama Customer Service</label>
                                            <p class="mb-0">Berfungsi untuk mengubah nama Customer Service di aplikasi ini, pisahkan nama dengan koma.</p>
                                            <input type="text" id="nama_cs" name="nama_cs" value="{{ implode(",",json_decode($pengaturan_sistem->items)); }}" required="" autocomplete="off" class="form-control mb-2">
                                        </div>
                                        <div class="form-group">
                                            <label>Minimal Hari Reschedule (h-?)</label>
                                            <div class="input-group">
                                                <input type="text" id="hari_resc" name="hari_resc" value="{{ $pengaturan_sistem->value_7 }}" required="" autocomplete="off" class="form-control" placeholder="Isi minimal berapa hari konsumen bisa reschedule"> 
                                                <div class="input-group-append"><span class="input-group-text">Hari</span></div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Berapa minggu maksimal yang bisa dibooking?</label>
                                            <div class="input-group">
                                                <input type="number" id="max_minggu" name="max_minggu" value="{{ $pengaturan_sistem->value_9 }}" required="" autocomplete="off" class="form-control" placeholder="Isi dengan angka saja">
                                                <div class="input-group-append"><span class="input-group-text">Minggu</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="tiga-vertical" role="tabpanel" aria-labelledby="tiga-vertical-tab">
                            <div class="form-group text-center">
                                Foto yang dapat diupload berukuran <b>width 800px height 600px</b>.
                            </div>
                            <form action="{{ url('edit_portofolio') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('put')
                                <div class="row">
                                    <div class="col-lg-6 col-12">
                                        <div class="form-group">
                                            <label>Portofolio 1</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/gallery/' . $portofolio->value_1) }}" id="portofolio_1" class="foto_portofolio" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'portofolio_1'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Portofolio 2</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/gallery/' . $portofolio->value_2) }}" id="portofolio_2" class="foto_portofolio" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'portofolio_2'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Portofolio 3</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/gallery/' . $portofolio->value_3) }}" id="portofolio_3" class="foto_portofolio" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'portofolio_3'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Portofolio 4</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/gallery/' . $portofolio->value_4) }}" id="portofolio_4" class="foto_portofolio" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'portofolio_4'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Portofolio 5</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/gallery/' . $portofolio->value_5) }}" id="portofolio_5" class="foto_portofolio" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'portofolio_5'])
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12">
                                        <div class="form-group">
                                            <label>Portofolio 6</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/gallery/' . $portofolio->value_6) }}" id="portofolio_6" class="foto_portofolio" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'portofolio_6'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Portofolio 7</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/gallery/' . $portofolio->value_7) }}" id="portofolio_7" class="foto_portofolio" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'portofolio_7'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Portofolio 8</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/gallery/' . $portofolio->value_8) }}" id="portofolio_8" class="foto_portofolio" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'portofolio_8'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Portofolio 9</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/gallery/' . $portofolio->value_9) }}" id="portofolio_9" class="foto_portofolio" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'portofolio_9'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group pt-3">
                                            <button type="submit" class="btn btn-lg btn-primary">Simpan</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="empat-vertical" role="tabpanel" aria-labelledby="empat-vertical-tab">
                            <form action="{{ url('edit_header') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('put')
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Title Website</label>
                                            <input type="text" id="title_website" name="title_website" value="{{ $header_website->value_1 }}" required="" autocomplete="off" class="form-control" placeholder="Studio Foto Larazoe"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Teks Logo</label>
                                            <input type="text" id="teks_logo" name="teks_logo" value="{{ $header_website->value_2 }}" required="" autocomplete="off" class="form-control" maxlength="12" placeholder="STUDIO FOTO"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Teks Tengah</label>
                                            <input type="text" id="teks_tengah" name="teks_tengah" value="{{ $header_website->value_3 }}" required="" autocomplete="off" class="form-control" placeholder="Selamat Datang Di Website Larazoe"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Tagline</label>
                                            <input type="text" id="tagline" name="tagline" value="{{ $header_website->value_4 }}" required="" autocomplete="off" class="form-control" placeholder="Capture With Love"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Tombol Masuk Aplikasi</label>
                                            <input type="text" id="tombol_aplikasi" name="tombol_aplikasi" value="{{ $header_website->value_5 }}" required="" autocomplete="off" class="form-control" placeholder="Aplikasi Larazoe"> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Background Utama</label>
                                            <div class="row mb-2">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/' . $header_website->value_6) }}" id="bg_utama" style="width: 370px; height: 260px;" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'bg_utama'])
                                                </div>
                                            </div>
                                            Foto yang dapat diupload berukuran <b>width 1920px height 1280px</b>.
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="lima-vertical" role="tabpanel" aria-labelledby="lima-vertical-tab">
                            <form action="{{ url('edit_bagian_satu') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('put')
                                <div class="form-group">
                                    <label>Judul</label>
                                    <input type="text" id="judul_1" name="judul_1" value="{{ $bagian_satu->value_1 }}" required="" autocomplete="off" class="form-control" placeholder="Tentang Studio Foto"> 
                                </div>
                                <div class="form-group">
                                    <label>Foto</label>
                                    <div class="row">
                                        <div class="col-lg-7 mb-2">
                                            <img src="{{ asset('frontend/avilon/img/' . $bagian_satu->value_2) }}" id="bagian_1" style="width: 450px; height: 300px;" />
                                        </div>
                                        <div class="col-lg-5">
                                            @include('components.file_upload', ['name' => 'bagian_1'])
                                            <p class="mt-3">Foto yang dapat diupload berukuran <b>width 1280px height 813px.</b></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Isi</label>
                                    <textarea type="text" id="isi_1" name="isi_1" required="" class="form-control summernote">{{ $bagian_satu->items }}</textarea>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="enam-vertical" role="tabpanel" aria-labelledby="enam-vertical-tab">
                            <form action="{{ url('edit_bagian_dua') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('put')
                                <div class="form-group">
                                    <label>Judul</label>
                                    <input type="text" id="judul_2" name="judul_2" value="{{ $bagian_dua->value_1 }}" required="" autocomplete="off" class="form-control" placeholder="Paket dan Produk Studio Foto"> 
                                </div>
                                <div class="form-group">
                                    <label>Foto</label>
                                    <div class="row">
                                        <div class="col-lg-3 mb-2">
                                            <img src="{{ asset('frontend/avilon/img/' . $bagian_dua->value_2) }}" id="bagian_2" style="width: 200px; height: 350px;" />
                                        </div>
                                        <div class="col-lg-8">
                                            @include('components.file_upload', ['name' => 'bagian_2'])
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Title 1</label>
                                            <input type="text" id="title_1" name="title_1" value="{{ $bagian_dua->value_3 }}" required="" autocomplete="off" class="form-control" placeholder="FOTOGRAFI"> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Keterangan 1</label>
                                            <textarea rows="3" type="text" id="keterangan_1" name="keterangan_1" required="" autocomplete="off" class="form-control" placeholder="Isi keterangan" style="padding: 10px 10px;" maxlength="255">{{ $bagian_dua->value_7 }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Title 2</label>
                                            <input type="text" id="title_2" name="title_2" value="{{ $bagian_dua->value_4 }}" required="" autocomplete="off" class="form-control" placeholder="CETAK FOTO"> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Keterangan 2</label>
                                            <textarea rows="3" type="text" id="keterangan_2" name="keterangan_2" required="" autocomplete="off" class="form-control" placeholder="Isi keterangan" style="padding: 10px 10px;" maxlength="255">{{ $bagian_dua->value_8 }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Title 3</label>
                                            <input type="text" id="title_3" name="title_3" value="{{ $bagian_dua->value_5 }}" required="" autocomplete="off" class="form-control" placeholder="BINGKAI FOTO"> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Keterangan 3</label>
                                            <textarea rows="3" type="text" id="keterangan_3" name="keterangan_3" required="" autocomplete="off" class="form-control" placeholder="Isi keterangan" style="padding: 10px 10px;" maxlength="255">{{ $bagian_dua->value_9 }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Title 4</label>
                                            <input type="text" id="title_4" name="title_4" value="{{ $bagian_dua->value_6 }}" required="" autocomplete="off" class="form-control" placeholder="DESAIN & CETAK DIGITAL"> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Keterangan 4</label>
                                            <textarea rows="3" type="text" id="keterangan_4" name="keterangan_4" required="" autocomplete="off" class="form-control" placeholder="Isi keterangan" style="padding: 10px 10px;" maxlength="255">{{ $bagian_dua->value_10 }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="tujuh-vertical" role="tabpanel" aria-labelledby="tujuh-vertical-tab">
                            <form action="{{ url('edit_bagian_tiga') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('put')
                                <div class="form-group">
                                    <label>Foto Background</label>
                                    <div class="row">
                                        <div class="col-lg-12 mb-2">
                                            <img src="{{ asset('frontend/avilon/img/' . $bagian_tiga->value_1) }}" id="bagian_3" style="width: 800px; height: 300px;" />
                                        </div>
                                        <div class="col-lg-5">
                                            @include('components.file_upload', ['name' => 'bagian_3'])
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Keterangan</label>
                                    <textarea rows="3" type="text" id="keterangan" name="keterangan" required="" autocomplete="off" class="form-control" placeholder="Isi keterangan" style="padding: 10px 10px;" maxlength="255">{{ $bagian_tiga->value_2 }}</textarea>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Link Embed Video Youtube</label>
                                            <textarea rows="4" type="text" id="link_youtube" name="link_youtube" required="" autocomplete="off" class="form-control" placeholder="Untuk menampilkan video tentang studio foto di website" style="padding: 10px 10px;">{{ $bagian_tiga->items }}</textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Status Video Youtube</label>
                                            <select class="form-control selectpicker" name="is_active">
                                                <option value="1" @selected(1 == $bagian_tiga->value_3)>Aktif</option>
                                                <option value="0" @selected(0 == $bagian_tiga->value_3)>Tidak Aktif</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Nomor WhatsApp</label>
                                            <input type="text" id="no_whatsapp" name="no_whatsapp" value="{{ $bagian_tiga->value_4 }}" required="" autocomplete="off" class="form-control" placeholder="62812345678"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Pesan Tombol WhatsApp</label>
                                            <textarea rows="3" type="text" id="pesan_wa" name="pesan_wa" required="" autocomplete="off" class="form-control" placeholder="Isi pesan untuk tombol WhatsApp di website" style="padding: 10px 10px;">{{ $bagian_tiga->value_5 }}</textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Template Chat</label>
                                            <textarea rows="3" type="text" id="chat" name="chat" required="" autocomplete="off" class="form-control" placeholder="Isi template chat untuk whatsapp" style="padding: 10px 10px;">{{ $bagian_tiga->value_6 }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="delapan-vertical" role="tabpanel" aria-labelledby="delapan-vertical-tab">
                            <form action="{{ url('edit_pertanyaan') }}" method="post">
                                @csrf
                                @method('put')
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Pertanyaan 1</label>
                                            <textarea rows="3" type="text" id="pertanyaan_1" name="pertanyaan_1" required="" autocomplete="off" class="form-control" placeholder="Tulis pertanyaan tentang studio foto" style="padding: 10px 10px;" maxlength="255">{{ $pertanyaan->value_1 }}</textarea> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Jawaban 1</label>
                                            <textarea rows="3" type="text" id="jawaban_1" name="jawaban_1" required="" autocomplete="off" class="form-control" placeholder="Tulis jawaban" style="padding: 10px 10px;" maxlength="255">{{ $pertanyaan->value_2 }}</textarea> 
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Pertanyaan 2</label>
                                            <textarea rows="3" type="text" id="pertanyaan_2" name="pertanyaan_2" required="" autocomplete="off" class="form-control" placeholder="Tulis pertanyaan tentang studio foto" style="padding: 10px 10px;" maxlength="255">{{ $pertanyaan->value_3 }}</textarea> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Jawaban 2</label>
                                            <textarea rows="3" type="text" id="jawaban_2" name="jawaban_2" required="" autocomplete="off" class="form-control" placeholder="Tulis jawaban" style="padding: 10px 10px;" maxlength="255">{{ $pertanyaan->value_4 }}</textarea> 
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Pertanyaan 3</label>
                                            <textarea rows="3" type="text" id="pertanyaan_3" name="pertanyaan_3" required="" autocomplete="off" class="form-control" placeholder="Tulis pertanyaan tentang studio foto" style="padding: 10px 10px;" maxlength="255">{{ $pertanyaan->value_5 }}</textarea> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Jawaban 3</label>
                                            <textarea rows="3" type="text" id="jawaban_3" name="jawaban_3" required="" autocomplete="off" class="form-control" placeholder="Tulis jawaban" style="padding: 10px 10px;" maxlength="255">{{ $pertanyaan->value_6 }}</textarea> 
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Pertanyaan 4</label>
                                            <textarea rows="3" type="text" id="pertanyaan_4" name="pertanyaan_4" required="" autocomplete="off" class="form-control" placeholder="Tulis pertanyaan tentang studio foto" style="padding: 10px 10px;" maxlength="255">{{ $pertanyaan->value_7 }}</textarea> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Jawaban 4</label>
                                            <textarea rows="3" type="text" id="jawaban_4" name="jawaban_4" required="" autocomplete="off" class="form-control" placeholder="Tulis jawaban" style="padding: 10px 10px;" maxlength="255">{{ $pertanyaan->value_8 }}</textarea> 
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Pertanyaan 5</label>
                                            <textarea rows="3" type="text" id="pertanyaan_5" name="pertanyaan_5" required="" autocomplete="off" class="form-control" placeholder="Tulis pertanyaan tentang studio foto" style="padding: 10px 10px;" maxlength="255">{{ $pertanyaan->value_9 }}</textarea> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Jawaban 5</label>
                                            <textarea rows="3" type="text" id="jawaban_5" name="jawaban_5" required="" autocomplete="off" class="form-control" placeholder="Tulis jawaban" style="padding: 10px 10px;" maxlength="255">{{ $pertanyaan->value_10 }}</textarea> 
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="sembilan-vertical" role="tabpanel" aria-labelledby="sembilan-vertical-tab">
                            <form action="{{ url('edit_footer') }}" method="post">
                                @csrf
                                @method('put')
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Informasi</label>
                                            <textarea rows="3" type="text" id="informasi" name="informasi" required="" autocomplete="off" class="form-control" placeholder="Isi informasi tentang studio foto" style="padding: 10px 10px;" maxlength="255">{{ $footer_website->value_1 }}</textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Link Instagram</label>
                                            <input type="text" id="instagram" name="instagram" value="{{ $footer_website->value_2 }}" required="" autocomplete="off" class="form-control" placeholder="https://www.instagram.com/contoh/"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Link Facebook</label>
                                            <input type="text" id="facebook" name="facebook" value="{{ $footer_website->value_3 }}" required="" autocomplete="off" class="form-control" placeholder="https://www.facebook.com/contoh/"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Link Channel Youtube</label>
                                            <input type="text" id="youtube" name="youtube" value="{{ $footer_website->value_4 }}" required="" autocomplete="off" class="form-control" placeholder="https://www.youtube.com/channel/contoh/videos"> 
                                        </div>
                                        <div class="form-group">
                                            <label>WhatsApp</label>
                                            <input type="text" id="whatsapp" name="whatsapp" value="{{ $footer_website->value_5 }}" required="" autocomplete="off" class="form-control" placeholder="https://api.whatsapp.com/send?phone=62812345678"> 
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Alamat Studio Foto</label>
                                            <textarea rows="3" type="text" name="alamat_studio" required="" autocomplete="off" class="form-control" placeholder="Isi alamat studio foto" style="padding: 10px 10px;" maxlength="255">{{ $footer_website->value_6 }}</textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Email Studio Foto</label>
                                            <input type="text" id="email" name="email" value="{{ $footer_website->value_7 }}" required="" autocomplete="off" class="form-control" placeholder="Isi email studio foto"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Nomor Telepon Studio Foto</label>
                                            <input type="text" id="no_tlp" name="no_tlp" value="{{ $footer_website->value_8 }}" required="" autocomplete="off" class="form-control" placeholder="Isi nomor telepon studio foto"> 
                                        </div>
                                        <div class="form-group">
                                            <label>Link Embed Google Maps</label>
                                            <textarea rows="4" type="text" name="google_maps" required="" autocomplete="off" class="form-control" placeholder="Isi link embed google maps tempat studio foto" style="padding: 10px 10px;">{{ $footer_website->items }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="sepuluh-vertical" role="tabpanel" aria-labelledby="sepuluh-vertical-tab">
                            <div class="form-group text-center">
                                Foto yang dapat diupload berukuran <b>width 300px height 70px</b>.
                            </div>
                            <form action="{{ url('edit_logoslide') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('put')
                                <div class="row">
                                    <div class="col-lg-6 col-12">
                                        <div class="form-group">
                                            <label>Logo Satu</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/clients/' . $logo_slider->value_1) }}" id="logo_1" class="logo_slider" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'logo_1'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Logo Dua</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/clients/' . $logo_slider->value_2) }}" id="logo_2" class="logo_slider" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'logo_2'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Logo Tiga</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/clients/' . $logo_slider->value_3) }}" id="logo_3" class="logo_slider" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'logo_3'])
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12">
                                        <div class="form-group">
                                            <label>Logo Empat</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/clients/' . $logo_slider->value_4) }}" id="logo_4" class="logo_slider" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'logo_4'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Logo Lima</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/clients/' . $logo_slider->value_5) }}" id="logo_5" class="logo_slider" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'logo_5'])
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Logo Enam</label>
                                            <div class="row">
                                                <div class="col-lg-6 mb-2">
                                                    <img src="{{ asset('frontend/avilon/img/clients/' . $logo_slider->value_6) }}" id="logo_6" class="logo_slider" />
                                                </div>
                                                <div class="col-lg-10">
                                                    @include('components.file_upload', ['name' => 'logo_6'])
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group pt-3">
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="editPayment" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editPaymentLabel">Edit data Payment Gateway</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="{{ url('edit_payment') }}" method="post" enctype="multipart/form-data">
                @csrf
                @method('put')
                <div class="modal-body">
                    <div class="form-group">
                        <label>Logo</label>
                        <div class="row">
                            <div class="col-sm-3 mb-2">
                            <img src="" class="logo logo-bank" id="logo" />
                            </div>
                            <div class="col-sm-7">
                                @include('components.file_upload', ['name' => 'logo'])
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Nama Payment</label>
                        <input required="" type="text" name="nama" autocomplete="off" class="form-control nama" placeholder="Nama payment">
                    </div>
                    <div class="form-group">
                        <label>Kode Payment Gateway</label>
                        <input required="" type="text" name="kode" autocomplete="off" class="form-control kode" placeholder="Kode payment gateway">
                    </div>
                    <div class="form-group">
                        <label>Biaya Admin</label>
                        <input required="" type="text" name="biaya" autocomplete="off" class="form-control biaya" placeholder="Biaya admin">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control selectpicker status" name="status">
                            <option value="1">Aktif</option>
                            <option value="0">Tidak Aktif</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="id" class="id">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<link rel="stylesheet" href="{{ asset('frontend/vendor/summernote/css/summernote-bs4.css') }}">
<script src="{{ asset('frontend/vendor/summernote/js/summernote-bs4.js') }}"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.summernote').summernote({
            height: 300,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'clear']],
                ['fontname', ['fontname']],
                ['fontsize', ['fontsize']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['insert', ['link']],
                ['view', ['codeview', 'help']],
            ],
            followingToolbar: false,
        });
    });

    function preview_image(event) 
    {
        var id = event.target.id;
        var reader = new FileReader();
        reader.onload = function()
        {
            var output = document.getElementById(id);
            output.src = reader.result;
            output.setAttribute('width', '100px');
            output.setAttribute('height', '100px');
        }
        reader.readAsDataURL(event.target.files[0]);
    }

    new Cleave('#transport', {
        numeral: true,
        numeralDecimalMark: ',',
        delimiter: '.',
        prefix: 'Rp ',
    });
</script>

@endsection