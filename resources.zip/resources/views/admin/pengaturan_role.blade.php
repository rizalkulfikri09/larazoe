@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <a href="javascript:void(0)" id="tambahRole" class="btn btn-primary m-b-20">Tambah Role Baru</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table" style="text-align: center">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Nama Role</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($roles as $index => $role)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $role->role }}</td>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            <a href="{{ route('role_akses', $role->id) }}" class="btn btn-warning btn-sm tombol">Akses</a>
                                            <a href="javascript:void(0)" class="btn btn-success btn-sm tombol editRole" data-id="{{ $role->id }}" data-role="{{ $role->role }}">Edit</a>
                                            <form action="{{ route('delete_role', $role->id) }}" method="post">
                                                @csrf
                                                @method('delete')
                                                <button type="submit" class="btn btn-danger btn-sm tombol delete_data">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="" id="formModal" method="post" autocomplete="off">
                @csrf
                <div class="modal-body">
                    <input type="hidden" name="id" id="id">
                    <div class="form-group">
                        <label>Nama Role</label>
                        <input required="" type="text" id="role" name="role" autocomplete="off" class="form-control" placeholder="Isi nama role">
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $('#tambahRole').click(function () {
        $('#formModal').attr('action', "{{ route('pengaturan_role') }}");
        $('#id').val('');
        $('#modelHeading').html("Form tambah role baru");
        $('#exampleModal').modal('show');
        $('#role').val('');
    });

    // Bagian edit data
    $('body').on('click', '.editRole', function () {
        const id = $(this).data('id');
        const role = $(this).data('role');
        $('#formModal').attr('action', "{{ url('pengaturan_role') }}/" + id + "/edit");
        $('#modelHeading').html("Form edit role");
        $('#exampleModal').modal('show');
        $('#id').val(id);
        $('#role').val(role);
    });
</script>
@endsection