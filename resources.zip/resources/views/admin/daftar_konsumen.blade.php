@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <a href="javascript:void(0)" id="createKonsumen" class="btn btn-primary mb-3">Tambah Konsumen</a>
            <a href="javascript:void(0)" id="delete_all" class="btn btn-danger mb-3">Hapus Yang Dipilih</a>
            <a href="{{ url('konsumen_excel') }}" class="btn btn-success mb-3 tombol_export">Cetak Excel</a>
            <a href="{{ url('konsumen_pdf') }}" class="btn btn-brand mb-3 tombol_export">Cetak PDF</a>
            <div class="card kotak">
                <div class="table-responsive">
                    <table class="display table table-striped table-bordered first data-table" width="99%">
                        <thead>
                            <tr>
                                <th class="colomnSize"><input type="checkbox" id="check_all"></th>
                                <th class="colomnSize">No</th>
                                <th>Nama Konsumen</th>
                                <th>Nomor WhatsApp</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th width="140">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="ajaxModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form id="konsumenForm" name="konsumenForm" autocomplete="off">
                <div class="modal-body">
                    <input type="hidden" name="user_id" id="user_id">
                    <div class="form-group">
                        <label>Nama Konsumen</label>
                        <input data-parsley-trigger="change" type="text" id="nama" name="nama" class="form-control error_nama" value="{{ old('nama') }}" placeholder="Isi nama konsumen" required />
                        <div class="invalid-feedback error_nama"></div>
                    </div>
                    <div class="form-group">
                        <label>Nomor WhatsApp</label>
                        <input data-parsley-trigger="change" type="text" id="no_tlp" name="no_tlp" class="form-control error_no_tlp" value="{{ old('no_tlp') }}" placeholder="Isi nomor WhatsApp konsumen" required />
                        <div class="invalid-feedback error_no_tlp"></div>
                    </div>
                    <div class="form-group">
                        <label>Email Konsumen</label>
                        <input data-parsley-trigger="change" type="text" id="email" name="email" class="form-control error_email" value="{{ old('email') }}" placeholder="Isi email konsumen" required />
                        <div class="invalid-feedback error_email"></div>
                    </div>
                    <div class="form-group" id="field_password">
                        <label>Password</label>
                        <input data-parsley-trigger="change" type="text" id="password" name="password" class="form-control error_password" placeholder="Isi password akun" required />
                        <div class="invalid-feedback error_password"></div>
                    </div>
                    <div class="form-group" id="field_status">
                        <label>Status</label>
                        <select class="form-control selectpicker" id="status" name="status">
                            <option value="1">Aktif</option>
                            <option value="0">Tidak Aktif</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <a href="javascript:void(0)" class="btn btn-sm btn-danger" id="reset_pass">Reset Password</a>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.fn.dataTable.ext.classes.sPageButton = 'btn btn-dark';
        var table = $('.data-table').DataTable({
            searchDelay: 500,
            processing: true,
            serverSide: true,
            ajax: "{{ route('daftar_konsumen') }}",
            columns: [
                { data: 'ids', name: 'ids' },
                { data: 'DT_RowIndex' },
                { data: 'nama', name: 'nama' },
                { data: 'no_tlp', name: 'no_tlp' },
                { data: 'email', name: 'email' },
                { data: 'is_active', name: 'is_active' },
                { data: 'opsi', name: 'opsi' },
            ],
            "aoColumnDefs": [
                { "bSortable": false, "aTargets": [0,1,6] }, 
                { "bSearchable": false, "aTargets": [0,1,6] },
                { "className": "text-center", "targets" : [0,1,2,3,4,5,6] },
            ],
            "aaSorting": [],
        });

        // Bagian tambah data
        $('#createKonsumen').click(function () {
            $('#simpanBtn').val("create-user");
            $('#user_id').val('');
            $('#konsumenForm').trigger("reset");
            $('#modelHeading').html("Buat Akun Konsumen");
            $('#ajaxModel').modal('show');
            $('#field_password').show();
            $('#password').attr('name', 'password');
            $('#reset_pass').hide();
            $('#field_status').hide();
            $('#status').removeAttr('name');
            $('.error_nama').text('').removeClass('is-invalid');
            $('.error_no_tlp').text('').removeClass('is-invalid');
            $('.error_email').text('').removeClass('is-invalid');
            $('.error_password').text('').removeClass('is-invalid');
        });

        // Bagian edit data
        $('body').on('click', '.editKonsumen', function () {
            var user_id = $(this).data('id');
            $.get("{{ route('daftar_konsumen') }}" +'/' + user_id +'/edit', function (data) {
                $('#reset_pass').show();
                $('#field_password').hide();
                $('#password').removeAttr('name');
                $('#field_status').show();
                $('#status').attr('name', 'status');
                $('#modelHeading').html("Edit Akun Konsumen");
                $('#simpanBtn').val("edit-user");
                $('#ajaxModel').modal('show');
                $('#user_id').val(data.id);
                $('#nama').val(data.nama);
                $('#no_tlp').val(data.no_tlp);
                $('#email').val(data.email);
                $('#status').val(data.is_active).trigger('change');
            });
            $('#reset_pass').on('click', function (e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Apakah anda yakin',
                    html: "Password konsumen akan direset.<p>Default password adalah <strong>password</strong></p>",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Reset'
                }).then(function (e) {
                    if (e.value === true) {
                        $.ajax({
                            type: "PUT",
                            url: "{{ url('konsumen_reset') }}" + '/' + user_id,
                            success: function (data) {
                                $('#alert_message').html('<div class="alert alert-success" >'+ data.message +'</div>');
                                alertSuccess(data.message);
                                $('#ajaxModel').modal('hide');
                                table.draw();
                            },
                            error: function (data) {
                                console.log('Error:', data);
                            }
                        });
                    } else {
                        return false;
                    }
                });
            });
        });

        // Bagian proses simpan data
        $('#simpanBtn').click(function (e) {
            e.preventDefault();
            $.ajax({
                data: $('#konsumenForm').serialize(),
                url: "{{ route('create_konsumen') }}",
                type: "POST",
                dataType: 'json',
                success: function (data) {
                    $('#alert_message').html('<div class="alert alert-success" >'+ data.message +'</div>');
                    $('#konsumenForm').trigger("reset");
                    $('#ajaxModel').modal('hide');
                    alertSuccess(data.message);
                    table.draw();
                },
                error: function (data) {
                    data.responseJSON.errors.nama ? $('.error_nama').text(data.responseJSON.errors.nama).addClass('is-invalid') : $('.error_nama').removeClass('is-invalid');
                    data.responseJSON.errors.no_tlp ? $('.error_no_tlp').text(data.responseJSON.errors.no_tlp).addClass('is-invalid') : $('.error_no_tlp').removeClass('is-invalid');
                    data.responseJSON.errors.email ? $('.error_email').text(data.responseJSON.errors.email).addClass('is-invalid') : $('.error_email').removeClass('is-invalid');
                    data.responseJSON.errors.password ? $('.error_password').text(data.responseJSON.errors.password).addClass('is-invalid') : $('.error_password').removeClass('is-invalid');
                }
            });
        });

        // Bagian delete data
        $('body').on('click', '.deleteKonsumen', function (){
            var user_id = $(this).data("id");
            Swal.fire({
                title: 'Apakah anda yakin',
                text: "Data akan dihapus",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Hapus Data!'
            }).then(function (e) {
                if (e.value === true) {
                    $.ajax({
                        type: "DELETE",
                        url: "{{ route('create_konsumen') }}/" + user_id,
                        success: function (data) {
                            $('#alert_message').html('<div class="alert alert-success" >'+ data.message +'</div>');
                            alertSuccess(data.message);
                            table.draw();
                        },
                        error: function (data) {
                            console.log('Error:', data);
                        }
                    });
                } else {
                    return false;
                }
            });
        });

        // Bagian multiple delete data
        $('#check_all').on('click', function(e) {
            $(this).is(':checked',true) ? $(".sub_chk").prop('checked', true) : $(".sub_chk").prop('checked',false);
        });
        $('#delete_all').on('click', function(e) {
            var data_chk = [];
            $(".sub_chk:checked").each(function() {  
                data_chk.push($(this).attr('data-ids'));
            });
            if (data_chk.length<=0) {
                Swal.fire("Pilih data terlebih dahulu!");
            } else {
                Swal.fire({
                    title: 'Apakah anda yakin',
                    text: "Data akan dihapus",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Hapus Data!'
                }).then(function (e) {
                    if (e.value === true) {
                        var join_selected_values = data_chk.join(","); 
                        $.ajax({
                            url: "{{ url('daftar_konsumen_delete') }}",
                            type: 'DELETE',
                            data: 'ids='+join_selected_values,
                            success: function (data) {
                                if (data['success']) {
                                    $(".sub_chk:checked").each(function() {  
                                        $(this).parents("tr").remove();
                                        $("#check_all").prop('checked', false);
                                    });
                                    alertSuccess(data.message);
                                    table.draw();
                                } else if (data['error']) {
                                    alert(data['error']);
                                } else {
                                    alert('Ups Ada yang tidak beres.');
                                }
                            },
                            error: function (data) {
                                alert(data.responseText);
                            }
                        });
                    } else {
                        return false;
                    }
                });
            }
        });
    });
</script>
@endsection