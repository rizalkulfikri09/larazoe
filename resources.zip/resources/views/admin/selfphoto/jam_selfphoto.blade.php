@extends('layouts.app_template')
@section('body')
@include('components.alert')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-12 col-md-12 col-sm-12 col-12">
            <a href="#" class="btn btn-primary m-b-20" data-toggle="modal" data-target="#jamBooking">Tambah Jam Booking</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered data_table" style="width:99%">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Jam Booking</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($jam_booking as $index => $jb)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $jb->jam }}</td>
                                    <td>{{ statusJam($jb->status) }}</td>
                                    <td>
                                        <div class="d-flex justify-content-center opsi">
                                            <a href="{{ route('edit_jam_self', $jb->id) }}" class="btn btn-success btn-sm tombol">Edit</a>
                                            <form action="{{ route('delete_jam_self', $jb->id) }}" method="post">
                                                @csrf
                                                @method('delete')
                                                <button type="submit" class="btn btn-danger btn-sm tombol delete_data">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="jamBooking" tabindex="-1" role="dialog" aria-labelledby="jamBookingLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="jamBookingLabel">Form tambah jam booking baru</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="{{ route('jam_self_photo') }}" method="post" autocomplete="off">
                @csrf
                <div class="modal-body">
                    <div class="form-group">
                        <label>Jam Booking</label>
                        <input type="text" name="jam" class="form-control datetimepicker-input" placeholder="Isi jam awal booking" id="jam_booking" data-toggle="datetimepicker" data-target="#jam_booking" required>
                    </div>
                    <div class="form-group">
                        <label>Tutup Pada Hari ?</label>
                        <select class="form-control selectpicker" name="status" id="status">
                            <option value="7">Buka Setiap Hari</option>
                            <option value="1">Senin</option>
                            <option value="2">Selasa</option>
                            <option value="3">Rabu</option>
                            <option value="4">Kamis</option>
                            <option value="5">Jumat</option>
                            <option value="6">Sabtu</option>
                            <option value="0">Minggu</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        $.fn.dataTable.ext.classes.sPageButton = 'btn btn-dark';
        $('.data_table').DataTable({
            "bFilter": false,
            "bLengthChange": false,
            "bInfo": false,
            "ordering": false,
            "aoColumnDefs": [
                { "className": "text-center", "targets" : "_all" },
            ],
        });
    });

    $('#jam_booking').datetimepicker({
        format: 'HH:mm'
    });
</script>
@endsection