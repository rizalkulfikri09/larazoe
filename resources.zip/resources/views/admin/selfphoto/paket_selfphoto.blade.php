@extends('layouts.app_template')
@section('body')
<style>
    .paket {
		width: 200px;
		height: 280px;
    }

    @media only screen and (max-width: 600px) {
		.paket {
			width: 100%;
            height: auto;
		}
    }
</style>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <a href="javascript:void(0)" id="tambahPaket" class="btn btn-primary m-b-20">Tambah Paket</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Nama Paket</th>
                                    <th scope="col">Keterangan Paket</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Min Orang</th>
                                    <th scope="col">Max Orang</th>
                                    <th scope="col">Durasi Pemotretan</th>
                                    <th scope="col">Harga</th>
                                    <th scope="col">Thumbnail Paket</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data_paket as $index => $dp)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $dp->nama_paket }}</td>
                                    <td>{!! Str::limit($dp->deskripsi, 100) !!}</td>
                                    <td>{{ $dp->is_active == 1 ? 'Aktif' : 'Tidak Aktif' }}</td>
                                    <td>{{ $dp->min_org }}</td>
                                    <td>{{ $dp->max_org }}</td>
                                    <td>{{ $dp->durasi." Menit" }}</td>
                                    <td>{{ format_rupiah($dp->harga) }}</td>
                                    <td><img data-src="{{ asset('frontend/images/paket/' . $dp->thumbnail) }}" class="lazyload paket"></td>
                                    <td>
                                        <a href="javascript:void(0)" class="btn btn-success btn-block btn-sm editPaket" data-id="{{ $dp->id }}" data-nama_paket="{{ $dp->nama_paket }}" data-deskripsi="{{ $dp->deskripsi }}" data-thumbnail="{{ $dp->thumbnail }}" data-status="{{ $dp->is_active }}" data-min_org="{{ $dp->min_org }}" data-max_org="{{ $dp->max_org }}" data-durasi="{{ $dp->durasi }}" data-harga="{{ $dp->harga }}">Edit</a>
                                        <form action="{{ route('delete_paket_self', $dp->id) }}" method="post">
                                            @csrf
                                            @method('delete')
                                            <button type="submit" class="btn btn-danger btn-block btn-sm delete_data">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="" id="formPaket" method="post" enctype="multipart/form-data" autocomplete="off">
                @csrf
                <div class="modal-body">
                    <input type="hidden" name="" name="id" id="id">
                    <div class="form-group">
                        <label>Nama Paket</label>
                        <input placeholder="Isi nama paket foto" required="" type="text" id="nama_paket" name="nama_paket" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Keterangan Paket</label>
                        <textarea required="" type="text" id="deskripsi" name="deskripsi" class="form-control deskripsi"></textarea>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col col-6">
                                <label>Minimal Orang</label>
                                <input required="" type="number" id="min_org" name="min_org" class="form-control" placeholder="Isi dengan angka saja">
                            </div>
                            <div class="col col-6">
                                <label>Maksimal Orang</label>
                                <input required="" type="number" id="max_org" name="max_org" class="form-control" placeholder="Isi dengan angka saja">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Durasi Pemotretan</label>
                        <div class="input-group">
                            <input required="" type="number" id="durasi" name="durasi" class="form-control" placeholder="Isi dengan angka saja">
                            <div class="input-group-append"><span class="input-group-text">Menit</span></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input required="" type="text" id="harga" name="harga" class="form-control">
                    </div>
                    <div class="form-group status_input">
                        <label>Status Paket</label>
                        <select class="form-control selectpicker status" id="is_active" name="is_active">
                            <option value="1">Aktif</option>
                            <option value="0">Tidak Aktif</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Thumbnail Paket</label>
                        <div class="custom-file">
                            <label class="file">
                                <input type="file" class="custom-file-input" id="thumbnail" name="thumbnail" aria-label="File browser example" onchange="preview_image(event)">
                                <span class="file-custom m-t-10">Pilih file...</span>
                            </label>
                        </div>
                    </div>
                    <div class="form-group" id="pratinjau" style="display:none;">
                        <br><img id="output_image" width="340px" height="420px"/>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Summernote  -->
<link rel="stylesheet" href="{{ asset('frontend/vendor/summernote/css/summernote-bs4.css') }}">
<script src="{{ asset('frontend/vendor/summernote/js/summernote-bs4.js') }}"></script>
<script type="text/javascript">
    new Cleave('#harga', {
        numeral: true,
        numeralDecimalMark: ',',
        delimiter: '.',
        prefix: 'Rp ',
    });

    $(document).ready(function() {
        $('.deskripsi').summernote({
            height: 200,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'clear']],
                ['fontname', ['fontname']],
                ['fontsize', ['fontsize']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['insert', ['link']],
                ['view', ['codeview', 'help']],
            ],
            followingToolbar: false,
            placeholder: 'Jika tidak ada keterangan tulis "Tidak ada"',
        });
    });

    $('#tambahPaket').click(function () {
        $('#formPaket').attr('action', "{{ route('paket_self_photo') }}");
        $('#simpanBtn').val("tambah-paket");
        $('.status_input').hide();
        $('#id').val('');
        $('#modelHeading').html("Form tambah paket baru");
        $('#exampleModal').modal('show');
        $('#nama_paket').val('');
        $('.deskripsi').summernote('code', '');
        $('#min_org').val('');
        $('#max_org').val('');
        $('#durasi').val('');
        $('#harga').val('0');
        $('#pratinjau').hide();
    });

    // Bagian edit data
    $('body').on('click', '.editPaket', function () {
        const id = $(this).data('id');
        const nama_paket = $(this).data('nama_paket');
        const deskripsi = $(this).data('deskripsi');
        const thumbnail = $(this).data('thumbnail');
        const min_org = $(this).data('min_org');
        const max_org = $(this).data('max_org');
        const durasi = $(this).data('durasi');
        const harga = $(this).data('harga');
        const status = $(this).data('status');

        $('#formPaket').attr('action', "{{ url('paket_self') }}/" + id + "/edit");
        $('#modelHeading').html("Form edit paket");
        $('#simpanBtn').val("edit-paket");
        $('#exampleModal').modal('show');
        $('.status_input').show();
        $('#id').val(id);
        $('#nama_paket').val(nama_paket);
        $('.status').val(status).trigger('change');
        $('.deskripsi').summernote('code', deskripsi);
        $('#min_org').val(min_org);
        $('#max_org').val(max_org);
        $('#durasi').val(durasi);
        $('#harga').val(harga);
        $('#pratinjau').show();
        $('#output_image').attr('src', '{{ asset('frontend/images/paket') }}/' + thumbnail);
    });

    function preview_image(event) 
    {
        var reader = new FileReader();
        reader.onload = function()
        {
            var output = document.getElementById('output_image');
            output.src = reader.result;
            document.getElementById('pratinjau').style.display = "";
        }
        reader.readAsDataURL(event.target.files[0]);
    }
</script>
@endsection