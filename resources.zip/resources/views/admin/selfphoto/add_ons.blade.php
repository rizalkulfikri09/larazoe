@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <a href="javascript:void(0)" id="tambahAddOns" class="btn btn-primary m-b-20">Tambah Add Ons</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col" width="250px">Nama Add Ons</th>
                                    <th scope="col">Harga</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data_addons as $index => $da)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $da->nama_addon }}</td>
                                    <td>{{ format_rupiah($da->harga) }}</td>
                                    <td>
                                        <div class="d-flex justify-content-center opsi">
                                            <a href="javascript:void(0)" class="btn btn-success btn-block btn-sm editAddOns" data-id="{{ $da->id }}" data-nama_addon="{{ $da->nama_addon }}" data-harga="{{ $da->harga }}">Edit</a>
                                            <form action="{{ route('delete_addons', $da->id) }}" method="post">
                                                @csrf
                                                @method('delete')
                                                <button type="submit" class="btn btn-danger btn-block btn-sm delete_data">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="" id="formAddOns" method="post" autocomplete="off">
                @csrf
                <div class="modal-body">
                    <input type="hidden" name="id" id="id">
                    <div class="form-group">
                        <label>Nama Add Ons</label>
                        <input required="" type="text" id="nama_addon" name="nama_addon" class="form-control" placeholder="Isi nama add ons">
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input required="" type="text" id="harga" name="harga" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    new Cleave('#harga', {
        numeral: true,
        numeralDecimalMark: ',',
        delimiter: '.',
        prefix: 'Rp ',
    });

    $('#tambahAddOns').click(function () {
        $('#formAddOns').attr('action', "{{ route('addons_self_photo') }}");
        $('#simpanBtn').val("tambah-addon");
        $('#id').val('');
        $('#modelHeading').html("Form tambah add ons");
        $('#exampleModal').modal('show');
        $('#harga').val('0');
    });

    // Bagian edit data
    $('body').on('click', '.editAddOns', function () {
        const id = $(this).data('id');
        const nama_addon = $(this).data('nama_addon');
        const harga = $(this).data('harga');

        $('#formAddOns').attr('action', "{{ url('addons_self_photo') }}/" + id + "/edit");
        $('#modelHeading').html("Form edit add ons");
        $('#simpanBtn').val("edit-addon");
        $('#exampleModal').modal('show');
        $('#id').val(id);
        $('#nama_addon').val(nama_addon);
        $('#harga').val(harga);
    });
</script>
@endsection