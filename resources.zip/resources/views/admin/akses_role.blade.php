@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <h4 class="mb-2">Role : {{ $role->role }}</h4>
                    <div class="table-responsive">
                        <table class="table" style="text-align: center">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Nama Menu</th>
                                    <th scope="col">Akses</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($menus as $index => $menu)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $menu->menu }}</td>
                                    <td>
                                        <input class="check-input" type="checkbox" {{ check_access($role->id, $menu->id) }} data-role="{{ $role->id }}" data-menu="{{ $menu->id }}" style="transform: scale(1.5);">
                                    </td>
                                </tr>
                                @endforeach
                        </table>
                        @include('components.button_kembali', ['url' => route('pengaturan_role')])
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $('.check-input').on('click', function() {
        $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        const menuId = $(this).data('menu');
        const roleId = $(this).data('role');
        const href = "{{ url('pengaturan_role') }}/" + roleId +"/"+"akses";
        $.ajax({
            url: href,
            type: 'POST',
            data: {
                menuId: menuId,
                roleId: roleId,
            },
            success: function() {
                document.location.href = href;
            }
        });
    });
</script>
@endsection