@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="pills-regular">
                    <ul class="nav nav-pills mb-1" id="pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="pills-status" data-toggle="pill" href="#pills-status_bp" role="tab" aria-controls="status" aria-selected="true">Ubah Status Booking & Pembayaran</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-reschedule" data-toggle="pill" href="#pills-rb" role="tab" aria-controls="reschedule_booking" aria-selected="false">Reschedule Booking</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-status_bp" role="tabpanel" aria-labelledby="pills-status">
                            <form action="{{ route('edit_booking', $booking->kode) }}" method="post">
                                @csrf
                                @method('put')
                                <div class="form-group">
                                    <label>Ubah Status Booking</label>
                                    <select class="form-control selectpicker" name="status_booking" id="status_booking">
                                        @foreach ($status_booking as $sbo)
                                            <option value="{{ $sbo }}" @selected($sbo == $booking->status_booking)>{{ $sbo }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Ubah Status Pembayaran</label>
                                    <select class="form-control selectpicker" name="status_bayar" id="status_bayar">
                                        @foreach ($status_bayar as $sba)
                                            <option value="{{ $sba }}" @selected($sba == $booking->status_bayar)>{{ $sba }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group jml_dp" style="display: none;">
                                    <label>Jumlah DP</label>
                                    <input type="text" id="jml_dp" name="jml_dp" value="{{ $booking->jml_dp }}" data-parsley-trigger="change" required="" autocomplete="off" class="form-control">
                                    <b style="color: red;">* Hanya diisi jika konsumen melakukan DP</b>
                                </div>
                                @if (isset($transaksi->link) && is_null($transaksi->no_ref))
                                <div class="form-group">
                                    <label>Bukti Pembayaran</label><br>
                                    <img src="{{ asset('frontend/images/bukti_tf/' . $transaksi->link) }}" style="width: 250px; height: 400px;" />
                                </div>
                                @endif
                                <div class="row">
                                    <div class="col">
                                        <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                        @include('components.button_kembali', ['url' => route('daftar_booking')])
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="pills-rb" role="tabpanel" aria-labelledby="pills-reschedule">
                            <form action="{{ route('reschedule_studio', $booking->kode) }}" method="post">
                                @csrf
                                @method('put')
                                <div class="form-group">
                                    <label>Nama Konsumen</label>
                                    <input type="text" name="nama" value="{{ $booking->nama }}" placeholder="Tulis nama konsumen" data-parsley-trigger="change" required="" autocomplete="off" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Nomor WhatsApp</label>
                                    <input type="text" name="no_tlp" value="{{ $booking->no_tlp }}" placeholder="Nomor WhatsApp konsumen" data-parsley-trigger="change" required="" autocomplete="off" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Tanggal Booking</label>
                                    <input inputmode="none" type="text" name="tgl_booking" class="form-control datetimepicker-input" id="datetimepicker5" data-toggle="datetimepicker" data-target="#datetimepicker5" autocomplete="off" required="" />
                                </div>
                                <div class="form-group">
                                    <label>Jam Booking</label>
                                    <select class="form-control selectpicker dropdown" name="id_sesi" id="id_sesi" data-dropup-auto="false">
                                        @foreach ($jam_booking as $jb)
                                            <option value="{{ $jb->id }}" @selected($jb->id == $booking->id_sesi)>{{ jam_reschedule($jb->jam, $booking->kode) }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Customer Service</label>
                                    <select class="form-control selectpicker" name="cs" id="cs">
                                        @foreach ($nama_cs as $nc)
                                            <option value="{{ $nc }}" @selected($nc == $booking->cs)>{{ $nc }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-xl-12 col-sm-6 m-t-10">
                                        <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                        @include('components.button_kembali', ['url' => route('daftar_booking')])
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript"> 
    var tgl_booking = "{{ $booking->tgl_booking }}";
    $(function() { 
        $('#datetimepicker5').datetimepicker({
            defaultDate: tgl_booking,
            useCurrent: false,
            format: 'YYYY-MM-DD',
            widgetPositioning: { vertical: 'bottom' }
        }); 
    });

    $(function() {
        if ($("#status_bayar").val() == "DP") {
            $(".jml_dp").show();
        } else {
            $(".jml_dp").hide();
        }
        $("#status_bayar").change(function() {
            if ($(this).val() != "DP") {
                $(".jml_dp").hide();
            } else {
                $(".jml_dp").show();
            }
        });
    });

    new Cleave('#jml_dp', {
        numeral: true,
        numeralDecimalMark: ',',
        delimiter: '.',
        prefix: 'Rp ',
    });
</script>
@endsection