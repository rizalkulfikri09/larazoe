@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered data_table" style="width:99%">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Kode Booking</th>
                                    <th scope="col">Nama Konsumen</th>
                                    <th scope="col">Rating</th>
                                    <th scope="col">Testimoni</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($daftar_testimoni as $index => $dt)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $dt->kode }}</td>
                                    <td>{{ $dt->nama }}</td>
                                    <td>{{ $dt->rating }}</td>
                                    <td>{{ $dt->testimoni }}</td>
                                    <td>
                                        <form action="{{ route('delete_testimoni', $dt->id) }}" method="post">
                                            @csrf
                                            @method('delete')
                                            <button type="submit" class="btn btn-danger btn-sm tombol delete_data">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        $.fn.dataTable.ext.classes.sPageButton = 'btn btn-dark';
        $('.data_table').DataTable({
            "bFilter": false,
            "bLengthChange": false,
            "bInfo": false,
            "ordering": false,
            "aoColumnDefs": [
                { "className": "text-center", "targets" : [0,1,2,3] },
            ],
        });
    });
</script>
@endsection