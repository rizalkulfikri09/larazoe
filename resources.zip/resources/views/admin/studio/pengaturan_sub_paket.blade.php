@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <a href="javascript:void(0)" id="tambahPaket" class="btn btn-primary m-b-20">Tambah Sub Paket</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Nama Sub Paket</th>
                                    <th scope="col">Paket</th>
                                    <th scope="col" style="width:5%">Min Orang</th>
                                    <th scope="col" style="width:5%">Max Orang</th>
                                    <th scope="col" style="width:5%">Durasi Pemotretan</th>
                                    <th scope="col">Harga</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($sub_paket as $index => $sp)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $sp->sub_paket }}</td>
                                    <td>{{ $sp->nama_paket }}</td>
                                    <td>{{ $sp->min_org }}</td>
                                    <td>{{ $sp->max_org }}</td>
                                    <td>{{ $sp->durasi }} Menit</td>
                                    <td>{{ format_rupiah($sp->harga) }}</td>
                                    <td>{{ $sp->is_active == 1 ? 'Aktif' : 'Tidak Aktif' }}</td>
                                    <td>
                                        <div class="d-flex justify-content-center opsi">
                                            <a href="javascript:void(0)" class="btn btn-success btn-block btn-sm editPaket" data-id="{{ $sp->id }}" data-sub_paket="{{ $sp->sub_paket }}" data-id_paket="{{ $sp->id_paket }}" data-min_org="{{ $sp->min_org }}" data-max_org="{{ $sp->max_org }}" data-durasi="{{ $sp->durasi }}" data-harga="{{ $sp->harga }}" data-status="{{ $sp->is_active }}">Edit</a>
                                            <form action="{{ route('delete_sub_paket', $sp->id) }}" method="post">
                                                @csrf
                                                @method('delete')
                                                <button type="submit" class="btn btn-danger btn-block btn-sm delete_data">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="" id="formPaket" method="post" autocomplete="off">
                @csrf
                <div class="modal-body">
                    <input type="hidden" name="id" id="id">
                    <div class="form-group">
                        <label>Nama Sub Paket</label>
                        <input required="" type="text" id="sub_paket" name="sub_paket" autocomplete="off" class="form-control" placeholder="Isi nama sub paket">
                    </div>
                    <div class="form-group">
                        <label>Paket</label>
                        <select class="form-control selectpicker" name="id_paket" id="id_paket">
                            <option value="" selected disabled hidden>Pilih di sini</option>
                            @foreach ($daftar_paket as $dp)
                                <option value="{{ $dp->id }}">{{ $dp->nama_paket }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col col-6">
                                <label>Minimal Orang</label>
                                <input required="" type="number" id="min_org" name="min_org" autocomplete="off" class="form-control" placeholder="Isi dengan angka saja">
                            </div>
                            <div class="col col-6">
                                <label>Maksimal Orang</label>
                                <input required="" type="number" id="max_org" name="max_org" autocomplete="off" class="form-control" placeholder="Isi dengan angka saja">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Durasi Waktu Pemotretan</label>
                        <div class="input-group">
                            <input required="" type="number" id="durasi" name="durasi" class="form-control" placeholder="Isi dengan angka saja">
                            <div class="input-group-append"><span class="input-group-text">Menit</span></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input required="" type="text" id="harga" name="harga" autocomplete="off" class="form-control">
                    </div>
                    <div class="form-group status_input">
                        <label>Status Sub Paket</label>
                        <select class="form-control selectpicker status" id="is_active" name="is_active">
                            <option value="1">Aktif</option>
                            <option value="0">Tidak Aktif</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    new Cleave('#harga', {
        numeral: true,
        numeralDecimalMark: ',',
        delimiter: '.',
        prefix: 'Rp ',
    });

    $('#tambahPaket').click(function () {
        $('#formPaket').attr('action', "{{ route('pengaturan_sub_paket') }}");
        $('#simpanBtn').val("tambah-paket");
        $('.status_input').hide();
        $('#id').val('');
        $('#modelHeading').html("Form tambah sub paket baru");
        $('#exampleModal').modal('show');
        $('#sub_paket').val('');
        $('#id_paket').val('').trigger('change');
        $('#min_org').val('');
        $('#max_org').val('');
        $('#durasi').val('');
        $('#harga').val('0');
    });

    // Bagian edit data
    $('body').on('click', '.editPaket', function () {
        const id = $(this).data('id');
        const sub_paket = $(this).data('sub_paket');
        const id_paket = $(this).data('id_paket');
        const min_org = $(this).data('min_org');
        const max_org = $(this).data('max_org');
        const durasi = $(this).data('durasi');
        const harga = $(this).data('harga');
        const status = $(this).data('status');

        $('#formPaket').attr('action', "{{ url('sub_paket') }}/" + id + "/edit");
        $('#modelHeading').html("Form edit sub paket");
        $('#simpanBtn').val("edit-paket");
        $('#exampleModal').modal('show');
        $('.status_input').show();
        $('#id').val(id);
        $('#sub_paket').val(sub_paket);
        $('#id_paket').val(id_paket).trigger('change');
        $('#min_org').val(min_org);
        $('#max_org').val(max_org);
        $('#durasi').val(durasi);
        $('#harga').val(harga);
        $('#is_active').val(status).trigger('change');
    });
</script>
@endsection