@extends('layouts.app_template')
@section('body')
<style>
    @media only screen and (max-width: 600px) {
        #qr-reader {
            width: 350px!important;
        }
    }
</style>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <h5 class="card-header text-center">Arahkan QR kode booking ke kamera</h5>
                <div class="card-body p-1 mx-auto">
                    <div class="form-group">
                        <div class="table-responsive">
                            <div id="qr-reader" style="width:500px;"></div>
                            {{-- <div id="qr-reader-results"></div> --}}
                        </div>
                    </div>
                    <div class="form-group text-center">
                        @include('components.button_kembali', ['url' => route('admin')])
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="{{ asset('frontend/libs/js/html5-qrcode.min.js') }}"></script>
<script>
    function onScanSuccess(decodedText, decodedResult) {
        let qr_code = decodedText;                
        html5QrcodeScanner.clear().then(_ => {
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                url: "{{ route('scan_kode') }}",
                type: "POST",            
                data: {
                    _methode : "POST",
                    _token: CSRF_TOKEN, 
                    kode : qr_code
                },
                success: function (response) { 
                    if (response.status == 200) {
                        window.location=response.redirect;
                    } else if (response.status == 403) {
                        Swal.fire({
                            title: response.message,
                            icon: 'error',
                        });
                        html5QrcodeScanner.render(onScanSuccess, onScanFailure);
                    } else {
                        Swal.fire({
                            title: "Booking studio foto anda tidak ditemukan",
                            icon: 'error',
                        });
                        html5QrcodeScanner.render(onScanSuccess, onScanFailure);
                    }
                }
            });   
        }).catch(error => {
            alert('ada yang tidak beres!');
        });
    }

    function onScanFailure(error) {
    // handle scan failure, usually better to ignore and keep scanning.
    // for example:
        // console.warn(`Code scan error = ${error}`);
    }

    let config = {
        fps: 10,
        qrbox: {width: 250, height: 250},
        supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA],
        rememberLastUsedCamera: true,
    };
    let html5QrcodeScanner = new Html5QrcodeScanner("qr-reader", config, /* verbose= */ false);
    html5QrcodeScanner.render(onScanSuccess, onScanFailure);
</script>
@endsection