@extends('layouts.app_template')
@section('body')
<style>
    .form-group {
        font-size: 16px!important;
    }
    .card_mb {
        margin-bottom: 0px;
    }
</style>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <h5 class="card-header" style="color: #00A300; font-weight: bold; font-size: 16px;">Terima kasih sudah melakukan booking studio foto</h5>
                <div class="card-body">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-lg-4 col-6">Kode Booking</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->kode }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Nama Konsumen</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->nama }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Nomor WhatsApp</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->no_tlp }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Paket Yang Dipesan</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->paket }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Status Booking</div>
                            <div class="col-lg-8 col-6"><b style="color: #00A300;">{{ $booking->status_booking }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Status Pembayaran</div>
                            <div class="col-lg-8 col-6"><b id="status_pembayaran">{{ $booking->status_bayar }} {{ $booking->status_bayar == 'DP' ? rupiah($booking->jml_dp) : '' }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Total Pembayaran</div>
                            <div class="col-lg-8 col-6"><b>{{ format_rupiah($booking->total) }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Tanggal Booking</div>
                            <div class="col-lg-8 col-6"><b>{{ Carbon::parse($booking->tgl_booking)->translatedFormat('d F Y') }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Jam Booking</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->jam_booking }}</b></div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    @include('components.button_kembali', ['url' => route('scan_kode')])
                </div>
            </div>
        </div>
    </div>
</div>
@endsection