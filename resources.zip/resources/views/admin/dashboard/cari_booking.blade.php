@extends('layouts.app_template')
@section('body')
<style>
    .form-group {
        padding: 3px!important;
    }
    .card-body {
        padding-top: 5px!important;
    }
</style>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <h5 class="card-header">Berikut hasil booking studio foto konsumen.</h5>
                <div class="card-body" style="font-size: 15px;">
                    <div class="form-group row">
                        <div class="col col-md-4">
                            <label>Kode Booking : </label>
                        </div>
                        <div class="col col-md">
                            <b>{{ $booking->kode }}</b>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col col-md-4">
                            <label>Nama Konsumen : </label>
                        </div>
                        <div class="col col-md">
                            <b>{{ $booking->nama }}</b>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col col-md-4">
                            <label>Nomor WhatsApp : </label>
                        </div>
                        <div class="col col-md">
                            <b>{{ $booking->no_tlp }}</b>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col col-md-4">
                            <label>Paket Dipesan : </label>
                        </div>
                        <div class="col col-md">
                            <b>{{ $booking->paket }}</b>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col col-md-4">
                            <label>Status Booking : </label>
                        </div>
                        <div class="col col-md">
                            <b>{{ $booking->status_booking }}</b>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col col-md-4">
                            <label>Status Pembayaran : </label>
                        </div>
                        <div class="col col-md">
                            <b>{{ $booking->status_bayar }} {{ $booking->status_bayar == 'DP' ? format_rupiah($booking->jml_dp) : '' }}</b>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col col-md-4">
                            <label>Tanggal Booking : </label>
                        </div>
                        <div class="col col-md">
                            <b>{{ Carbon::parse($booking->tgl_booking)->translatedFormat('d F Y') }}</b>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col col-md-4">
                            <label>Jam Booking : </label>
                        </div>
                        <div class="col col-md">
                            <b>{{ $booking->jam_booking }}</b>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col col-md-4">
                            <label>Total Pembayaran : </label>
                        </div>
                        <div class="col col-md">
                            <b>{{ format_rupiah($booking->total) }}</b>
                        </div>
                    </div>
                    @if (isset($transaksi->link) && is_null($transaksi->no_ref))
                    <div class="form-group row">
                        <div class="col col-md-4">
                            <label>Bukti Pembayaran : </label>
                        </div>
                        <div class="col col-md">
                            <img src="{{ asset('frontend/images/bukti_tf/' . $transaksi->link) }}" style="width: 250px; height: 400px;" />
                        </div>
                    </div>
                    @endif
                    <div class="row">
                        <div class="col-sm-12 m-t-10">
                            <a href="{{ url('print_booking/'.$booking->kode) }}"><button type="button" class="btn btn-space btn-primary tombol_export">Cetak</button></a>
                            @include('components.button_kembali', ['url' => route('admin')])
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Ubah status booking atau status pembayaran.</h5>
                <div class="card-body">
                    <form action="{{ route('cari_booking', $booking->kode) }}" method="post">
                        @csrf
                        <div class="form-group">
                            <label>Ubah Status Booking</label>
                            <select class="form-control selectpicker" name="status_booking" id="status_booking">
                                @foreach ($status_booking as $sbo)
                                    <option value="{{ $sbo }}" @selected($sbo == $booking->status_booking)>{{ $sbo }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Ubah Status Pembayaran</label>
                            <select class="form-control selectpicker" name="status_bayar" id="status_bayar">
                                @foreach ($status_bayar as $sba)
                                    <option value="{{ $sba }}" @selected($sba == $booking->status_bayar)>{{ $sba }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group jml_dp" style="display: none;">
                            <label>Jumlah DP</label>
                            <input type="text" id="jml_dp" name="jml_dp" value="{{ $booking->jml_dp }}" required="" autocomplete="off" class="form-control">
                            <b style="color: red;">* Hanya diisi jika konsumen melakukan DP</b>
                        </div>
                        <div class="row">
                            <div class="col">
                                <button type="submit" class="btn btn-space btn-success">Simpan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript"> 
    new Cleave('#jml_dp', {
        numeral: true,
        numeralDecimalMark: ',',
        delimiter: '.',
        prefix: 'Rp ',
    });

    $(function() {
        if ($("#status_bayar").val() == "DP") {
            $(".jml_dp").show();
        } else {
            $(".jml_dp").hide();
        }
        $("#status_bayar").change(function() {
            if ($(this).val() != "DP") {
                $(".jml_dp").hide();
            } else {
                $(".jml_dp").show();
            }
        });
    });
</script>
@endsection