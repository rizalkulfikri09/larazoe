@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Grafik laporan booking studio foto per bulan tahun {{ Carbon::now()->year }}</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <canvas id="studio_perbulan" style="height:450px"></canvas>
                        <script type="text/javascript" src="{{ asset('frontend/libs/js/Chart.min.js') }}"></script>
                        <script>
                            var ctx = document.getElementById("studio_perbulan").getContext('2d');
                            var myChart = new Chart(ctx, {
                                type: 'line',
                                data: {
                                    labels: ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"],
                                    datasets: [{
                                        label: 'Booking Studio Foto',
                                        data: [
                                            {{ $studio_januari }},
                                            {{ $studio_februari }},
                                            {{ $studio_maret }},
                                            {{ $studio_april }},
                                            {{ $studio_mei }},
                                            {{ $studio_juni }},
                                            {{ $studio_juli }},
                                            {{ $studio_agustus }},
                                            {{ $studio_september }},
                                            {{ $studio_oktober }},
                                            {{ $studio_november }},
                                            {{ $studio_desember }},
                                        ],
                                        borderWidth : 3,
                                        pointBorderWidth : 4,
                                        pointBorderColor : 'rgb(58, 140, 140)',
                                        backgroundColor : 'rgb(41, 224, 224, 0.3)',
                                        borderColor: 'rgb(41, 224, 224)',
                                    }, {
                                        label: 'Booking Wedding',
                                        data: [
                                            {{ $wedding_januari }},
                                            {{ $wedding_februari }},
                                            {{ $wedding_maret }},
                                            {{ $wedding_april }},
                                            {{ $wedding_mei }},
                                            {{ $wedding_juni }},
                                            {{ $wedding_juli }},
                                            {{ $wedding_agustus }},
                                            {{ $wedding_september }},
                                            {{ $wedding_oktober }},
                                            {{ $wedding_november }},
                                            {{ $wedding_desember }},
                                        ],
                                        borderWidth : 3,
                                        pointBorderWidth : 4,
                                        pointBorderColor : 'rgb(6, 145, 28)',
                                        backgroundColor : 'rgb(75, 192, 93, 0.3)',
                                        borderColor: 'rgb(75, 192, 93)',
                                    }, {
                                        label: 'Booking Self Photo',
                                        data: [
                                            {{ $self_januari }},
                                            {{ $self_februari }},
                                            {{ $self_maret }},
                                            {{ $self_april }},
                                            {{ $self_mei }},
                                            {{ $self_juni }},
                                            {{ $self_juli }},
                                            {{ $self_agustus }},
                                            {{ $self_september }},
                                            {{ $self_oktober }},
                                            {{ $self_november }},
                                            {{ $self_desember }},
                                        ],
                                        borderWidth : 3,
                                        pointBorderWidth : 4,
                                        pointBorderColor : 'rgb(6, 20, 145)',
                                        backgroundColor : 'rgb(75, 121, 192, 0.3)',
                                        borderColor: 'rgb(75, 95, 192)',
                                    }]
                                },
                                options: {
                                    responsive:true,
                                    maintainAspectRatio: false,
                                    scales: {
                                        yAxes: [{
                                            ticks: {
                                                beginAtZero: true
                                            }
                                        }]
                                    }
                                }
                            });
                        </script>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Grafik laporan booking studio foto per minggu tanggal {{ Carbon::now()->startOfWeek()->format('d-m-Y') }} s/d {{ Carbon::now()->endOfWeek()->format('d-m-Y') }}</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <canvas id="studio_perminggu" style="height:450px"></canvas>
                        <script>
                            var ctx = document.getElementById("studio_perminggu").getContext('2d');
                            var myChart = new Chart(ctx, {
                                type: 'line',
                                data: {
                                    labels: ["Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu"],
                                    datasets: [{
                                        label: '',
                                        data: [
                                            {{ $studio_senin }},
                                            {{ $studio_selasa }},
                                            {{ $studio_rabu }},
                                            {{ $studio_kamis }},
                                            {{ $studio_jumat }},
                                            {{ $studio_sabtu }},
                                            {{ $studio_minggu }},
                                        ],
                                        borderWidth : 3,
                                        pointBorderWidth : 4,
                                        pointBorderColor : 'rgb(64, 168, 85)',
                                        backgroundColor : 'rgb(80, 212, 107, 0.3)',
                                        borderColor: 'rgb(80, 212, 107)',
                                    }]
                                },
                                options: {
                                    responsive:true,
                                    maintainAspectRatio: false,
                                    scales: {
                                        yAxes: [{
                                            ticks: {
                                                beginAtZero: true
                                            }
                                        }]
                                    }
                                }
                            });
                        </script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection