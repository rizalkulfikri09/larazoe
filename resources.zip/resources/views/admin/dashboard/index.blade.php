@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <form action="{{ url('admin') }}" method="post">
            @csrf
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="kode" id="search" placeholder="Cari Kode Booking Studio Foto" required/>
                    <div class="input-group-append">
                        <button type="submit" class="btn btn-primary">Cari</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 pb-2">
            <a href="{{ route('scan_kode') }}" class="btn btn-space btn-primary">Scan QR Kode Booking</a>
            <a href="{{ route('grafik') }}" class="btn btn-space btn-success">Grafik Laporan</a>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="text-muted">Jumlah Konsumen</h5>
                    <div class="metric-value d-inline-block">
                        <h1 class="mb-1">{{ $konsumen }}</h1>
                    </div>
                    <div class="metric-label float-right text-primary">
                        <span><i class="fas fa-user" style="transform: scale(4); margin-right:20px;"></i></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="text-muted">Jumlah Booking Studio</h5>
                    <div class="metric-value d-inline-block">
                        <h1 class="mb-1">{{ $booking_studio }}</h1>
                    </div>
                    <div class="metric-label float-right text-warning">
                        <span><i class="fas fa-camera" style="transform: scale(4); margin-right:20px;"></i></span>
                    </div>
                </div>
                <div id="sparkline-revenue2"></div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="text-muted">Jumlah Booking Self Foto</h5>
                    <div class="metric-value d-inline-block">
                        <h1 class="mb-1">{{ $booking_selfphoto }}</h1>
                    </div>
                    <div class="metric-label float-right text-success">
                        <span><i class="fas fa-camera-retro" style="transform: scale(4); margin-right:20px;"></i></span>
                    </div>
                </div>
                <div id="sparkline-revenue4"></div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="text-muted">Jumlah Undangan Digital</h5>
                    <div class="metric-value d-inline-block">
                        <h1 class="mb-1">{{ $undangan_digital }}</h1>
                    </div>
                    <div class="metric-label float-right text-danger">
                        <span><i class="fas fa-heart" style="transform: scale(4); margin-right:20px;"></i></span>
                    </div>
                </div>
                <div id="sparkline-revenue3"></div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header text-center">Grafik Status Booking</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <canvas id="status_booking" style="height:300px"></canvas>
                        <script type="text/javascript" src="{{ asset('frontend/libs/js/Chart.min.js') }}"></script>
                        <script>
                            var ctx = document.getElementById("status_booking").getContext('2d');
                            var status_booking = new Chart(ctx, {
                                type: 'bar',
                                data: {
                                    labels: ["Booking Selesai", "Sedang Di Booking"],
                                    datasets: [{
                                        label: 'Booking Studio Foto',
                                        data: [
                                            {{ $selesai_studio }},
                                            {{ $dipesan_studio }},
                                        ],
                                        backgroundColor: [
                                            'rgba(15, 218, 80)',
                                            'rgba(11, 170, 62)',
                                        ],
                                        borderColor: [
                                            'rgba(15, 218, 80)',
                                            'rgba(11, 170, 62)',
                                        ],
                                        borderWidth: 1
                                    }, {
                                        label: 'Booking Foto Wedding',
                                        data: [
                                            {{ $selesai_wedding }},
                                            {{ $dipesan_wedding }},
                                        ],
                                        backgroundColor: [
                                            'rgba(15, 218, 190)',
                                            'rgba(10, 151, 131)',
                                        ],
                                        borderColor: [
                                            'rgba(15, 218, 190)',
                                            'rgba(10, 151, 131)',
                                        ],
                                        borderWidth: 1
                                    }, {
                                        label: 'Booking Self Photo',
                                        data: [
                                            {{ $selesai_self }},
                                            {{ $dipesan_self }},
                                        ],
                                        backgroundColor: [
                                            'rgba(15, 172, 218)',
                                            'rgba(10, 133, 151)',
                                        ],
                                        borderColor: [
                                            'rgba(15, 172, 218)',
                                            'rgba(10, 133, 151)',
                                        ],
                                        borderWidth: 1
                                    }]
                                },
                                options: {
                                    responsive:true,
                                    maintainAspectRatio: false,
                                    scales: {
                                        yAxes: [{
                                            ticks: {
                                                beginAtZero: true
                                            }
                                        }]
                                    }
                                }
                            });
                        </script>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header text-center">Grafik Status Pembayaran</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <canvas id="status_bayar" style="height:300px"></canvas>
                        <script>
                            var ctx = document.getElementById("status_bayar").getContext('2d');
                            var status_bayar = new Chart(ctx, {
                                type: 'bar',
                                data: {
                                    labels: ["Lunas", "DP", "Belum Dibayar"],
                                    datasets: [{
                                        label: 'Booking Studio Foto',
                                        data: [
                                            {{ $lunas_studio }},
                                            {{ $dp_studio }},
                                            {{ $belum_dibayar_studio }},
                                        ],
                                        backgroundColor: [
                                            'rgba(56, 163, 165)',
                                            'rgba(38, 129, 130)',
                                            'rgba(23, 90, 90)',
                                        ],
                                        borderColor: [
                                            'rgba(56, 163, 165)',
                                            'rgba(38, 129, 130)',
                                            'rgba(23, 90, 90)',
                                        ],
                                        borderWidth: 1
                                    }, {
                                        label: 'Booking Foto Wedding',
                                        data: [
                                            {{ $lunas_wedding }},
                                            {{ $dp_wedding }},
                                            {{ $belum_dibayar_wedding }},
                                        ],
                                        backgroundColor: [
                                            'rgba(87, 204, 153)',
                                            'rgba(49, 153, 107)',
                                            'rgba(26, 117, 76)',
                                        ],
                                        borderColor: [
                                            'rgba(87, 204, 153)',
                                            'rgba(49, 153, 107)',
                                            'rgba(26, 117, 76)',
                                        ],
                                        borderWidth: 1
                                    }, {
                                        label: 'Booking Self Photo',
                                        data: [
                                            {{ $lunas_self }},
                                            {{ $dp_self }},
                                            {{ $belum_dibayar_self }},
                                        ],
                                        backgroundColor: [
                                            'rgba(87, 176, 204)',
                                            'rgba(49, 143, 153)',
                                            'rgba(10, 133, 151)',
                                        ],
                                        borderColor: [
                                            'rgba(87, 176, 204)',
                                            'rgba(49, 143, 153)',
                                            'rgba(10, 133, 151)',
                                        ],
                                        borderWidth: 1
                                    }]
                                },
                                options: {
                                    responsive:true,
                                    maintainAspectRatio: false,
                                    scales: {
                                        yAxes: [{
                                            ticks: {
                                                beginAtZero: true
                                            }
                                        }]
                                    }
                                }
                            });
                        </script>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header text-center">Customer Service</h5>
                <div class="card-body">
                    <div class="text-center">
                        <form action="{{ route('ganti_cs') }}" method="post">
                        @csrf
                            @foreach ($nama_cs as $nc)
                                <label class="custom-control custom-radio custom-control-inline">
                                    <input type="radio" name="nama_cs" value="{{ $nc }}" @checked($nc == $cs_now) class="custom-control-input"><span class="custom-control-label">{{ $nc }}</span>
                                </label>
                            @endforeach
                            <br><button type="submit" class="btn btn-space btn-primary" style="margin-top: 10px;">Ganti</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header text-center">Rating Booking Studio Foto</h5>
                <div class="card-body p-2">
                    <div class="table-responsive">
                        <canvas id="rating" height="200"></canvas>
                        <script>
                            var ctx = document.getElementById("rating").getContext('2d');
                            var rating = new Chart(ctx, {
                                type: 'doughnut',
                                data: {
                                    labels: ["Rating 5", "Rating 4", "Rating 3", "Rating 2", "Rating 1"],
                                    datasets: [{
                                        label: 'Rating Booking Studio Foto',
                                        data: [
                                            {{ $rating_5 }},
                                            {{ $rating_4 }},
                                            {{ $rating_3 }},
                                            {{ $rating_2 }},
                                            {{ $rating_1 }},
                                        ],
                                        backgroundColor: [
                                            'rgba(56, 163, 165)',
                                            'rgba(128, 237, 153)',
                                            'rgba(34, 87, 122)',
                                            'rgba(0, 187, 249)',
                                            'rgba(17, 145, 90)',
                                        ],
                                        borderColor: [
                                            'rgba(56, 163, 165)',
                                            'rgba(128, 237, 153)',
                                            'rgba(34, 87, 122)',
                                            'rgba(0, 187, 249)',
                                            'rgba(17, 145, 90)',
                                        ],
                                        borderWidth: 1
                                    }]
                                },
                                options: {
                                    responsive:true,
                                    legend: {
                                    display: true,
                                    position: "bottom",
                                        labels: {
                                            fontColor: "#000",
                                            fontSize: 16
                                        }
                                    }
                                }
                            });
                        </script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $("#search").autocomplete({
        source: function( request, response ) {
            $.ajax({
            url: "{{ route('cari_kode') }}",
            type: 'GET',
            dataType: "json",
            data: {
                search: request.term
            },
            success: function(data) {
                response(data);
            }
            });
        },
        select: function (event, ui) {
            $('#search').val(ui.item.label);
            return false;
        }
    });
</script>
@endsection