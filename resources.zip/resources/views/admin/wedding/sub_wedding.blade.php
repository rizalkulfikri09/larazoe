@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <a href="javascript:void(0)" id="tambahPaket" class="btn btn-primary m-b-20">Tambah Sub Paket</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Nama Sub Paket</th>
                                    <th scope="col">Paket</th>
                                    <th scope="col" style="width:20%">Harga</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($sub_paket as $index => $sp)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $sp->sub_paket }}</td>
                                    <td>{{ $sp->nama_paket }}</td>
                                    <td>{{ format_rupiah($sp->harga) }}</td>
                                    <td>{{ $sp->is_active == 1 ? 'Aktif' : 'Tidak Aktif' }}</td>
                                    <td>
                                        <a href="javascript:void(0)" class="btn btn-success btn-block btn-sm editPaket" data-id="{{ $sp->id }}" data-sub_paket="{{ $sp->sub_paket }}" data-id_paket="{{ $sp->id_paket }}" data-harga="{{ $sp->harga }}" data-status="{{ $sp->is_active }}">Edit</a>
                                        <form action="{{ route('delete_sub_wedding', $sp->id) }}" method="post">
                                            @csrf
                                            @method('delete')
                                            <button type="submit" class="btn btn-danger btn-block btn-sm delete_data">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12 col-12">
            <a href="javascript:void(0)" id="tambahExtraPaket" class="btn btn-primary m-b-20">Tambah Extra Paket</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Extra Paket</th>
                                    <th scope="col" style="width:30%">Harga</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($extra_paket as $index => $ep)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $ep->extra_wedding }}</td>
                                    <td>{{ format_rupiah($ep->harga) }}</td>
                                    <td>
                                        <a href="javascript:void(0)" class="btn btn-success btn-block btn-sm editPaketExtra" data-id="{{ $ep->id }}" data-extra_wedding="{{ $ep->extra_wedding }}" data-harga="{{ $ep->harga }}">Edit</a>
                                        <form action="{{ route('delete_extra_wedding', $ep->id) }}" method="post">
                                            @csrf
                                            @method('delete')
                                            <button type="submit" class="btn btn-danger btn-block btn-sm delete_data">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="" id="formPaket" method="post" autocomplete="off">
                @csrf
                <div class="modal-body">
                    <input type="hidden" name="id" id="id">
                    <div class="form-group">
                        <label>Nama Sub Paket</label>
                        <input required="" type="text" id="sub_paket" name="sub_paket" autocomplete="off" class="form-control" placeholder="Isi nama sub paket">
                    </div>
                    <div class="form-group">
                        <label>Paket</label>
                        <select class="form-control selectpicker" name="id_paket" id="id_paket">
                            <option value="" selected disabled hidden>Pilih di sini</option>
                            @foreach ($daftar_paket as $dp)
                                <option value="{{ $dp->id }}">{{ $dp->nama_paket }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input required="" type="text" id="harga" name="harga" autocomplete="off" class="form-control">
                    </div>
                    <div class="form-group status_input">
                        <label>Status Sub Paket</label>
                        <select class="form-control selectpicker status" id="is_active" name="is_active">
                            <option value="1">Aktif</option>
                            <option value="0">Tidak Aktif</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="extraModal" tabindex="-1" role="dialog" aria-labelledby="extraModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeadingExtra"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="" id="formExtraPaket" method="post" autocomplete="off">
                @csrf
                <div class="modal-body">
                    <input type="hidden" name="id_extra" id="id_extra">
                    <div class="form-group">
                        <label>Nama Extra Paket</label>
                        <input required="" type="text" id="extra_wedding" name="extra_wedding" placeholder="Isi nama extra paket" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input required="" type="text" id="harga_extra" name="harga_extra" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    new Cleave('#harga', {
        numeral: true,
        numeralDecimalMark: ',',
        delimiter: '.',
        prefix: 'Rp ',
    });

    new Cleave('#harga_extra', {
        numeral: true,
        numeralDecimalMark: ',',
        delimiter: '.',
        prefix: 'Rp ',
    });

    $('#tambahPaket').click(function () {
        $('#formPaket').attr('action', "{{ route('sub_wedding') }}");
        $('#simpanBtn').val("tambah-paket");
        $('.status_input').hide();
        $('#id').val('');
        $('#modelHeading').html("Form tambah sub paket wedding");
        $('#exampleModal').modal('show');
        $('#sub_paket').val('');
        $('#id_paket').val('').trigger('change');
        $('#harga').val('0');
    });

    // Bagian edit data
    $('body').on('click', '.editPaket', function () {
        const id = $(this).data('id');
        const sub_paket = $(this).data('sub_paket');
        const id_paket = $(this).data('id_paket');
        const harga = $(this).data('harga');
        const status = $(this).data('status');

        $('#formPaket').attr('action', "{{ url('sub_wedding') }}/" + id + "/edit");
        $('#modelHeading').html("Form edit sub paket wedding");
        $('#simpanBtn').val("edit-paket");
        $('#exampleModal').modal('show');
        $('.status_input').show();
        $('#id').val(id);
        $('#sub_paket').val(sub_paket);
        $('#id_paket').val(id_paket).trigger('change');
        $('#harga').val(harga);
        $('#is_active').val(status).trigger('change');
    });

    $('#tambahExtraPaket').click(function () {
        $('#formExtraPaket').attr('action', "{{ route('extra_wedding') }}");
        $('#modelHeadingExtra').html("Form tambah extra paket wedding");
        $('#extraModal').modal('show');
        $('#id').val('');
        $('#extra_wedding').val('');
        $('#harga_extra').val('0');
    });

    // Bagian edit data
    $('body').on('click', '.editPaketExtra', function () {
        const id = $(this).data('id');
        const extra_wedding = $(this).data('extra_wedding');
        const harga_extra = $(this).data('harga');

        $('#formExtraPaket').attr('action', "{{ url('extra_wedding') }}/" + id + "/edit");
        $('#modelHeadingExtra').html("Form edit extra paket wedding");
        $('#extraModal').modal('show');
        $('#id_extra').val(id);
        $('#extra_wedding').val(extra_wedding);
        $('#harga_extra').val(harga_extra);
    });
</script>
@endsection