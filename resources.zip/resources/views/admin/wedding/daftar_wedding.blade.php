@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="card" style="margin-bottom: 16px;">
                <div class="card-body">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-sm-6 mb-2">
                                <label>Filter Status Booking</label>
                                <select class="form-control selectpicker" name="session_sbo" id="session_sbo">
                                    <option value="" selected disabled hidden>Pilih di sini</option>
                                    @foreach ($session_sbo as $sbo)
                                        <option value="{{ $sbo }}">{{ $sbo }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label>Filter Paket Pemotretan</label>
                                <select class="form-control selectpicker" name="session_dp" id="session_dp">
                                    <option value="" selected disabled hidden>Pilih di sini</option>
                                    @foreach ($session_dp as $dp)
                                        <option value="{{ $dp }}">{{ $dp }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 mt-2">
                                <label>Filter Status Pembayaran</label>
                                <select class="form-control selectpicker" name="session_sba" id="session_sba">
                                    <option value="" selected disabled hidden>Pilih di sini</option>
                                    @foreach ($session_sba as $sba)
                                        <option value="{{ $sba }}">{{ $sba }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-sm-6 mt-2">
                                <label>Filter Tanggal Booking</label>
                                <div class="row">
                                    <div class="col-sm-6 mb-1">
                                        <input type="text" placeholder="Dari Tanggal" class="form-control datetimepicker-input" id="tanggal_1" name="tanggal_1" data-toggle="datetimepicker" data-target="#tanggal_1" autocomplete="off" required="" />
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" placeholder="Sampai Tanggal" class="form-control datetimepicker-input" id="tanggal_2" name="tanggal_2" data-toggle="datetimepicker" data-target="#tanggal_2" autocomplete="off" required="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <button type="button" id="btn-filter" class="btn btn-space btn-primary">Filter Data</button>
                            <button type="button" id="btn-reset" class="btn btn-space btn-default">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body" style="padding: 16px; padding-bottom: 0px;">
                    <a href="javascript:void(0)" id="createBooking" class="btn btn-primary mb-3">Tambah Booking</a>
                    <a href="javascript:void(0)" id="delete_all" class="btn btn-danger mb-3">Hapus Yang Dipilih</a>
                    <a href="{{ url('wedding_excel') }}" class="btn btn-success mb-3 tombol_export">Cetak Excel</a>
                    <a href="{{ url('wedding_pdf') }}" class="btn btn-brand mb-3 tombol_export">Cetak PDF</a>
                </div>
            </div>
            <div class="card kotak">
                <div class="table-responsive">
                    <table class="display table table-striped table-bordered first data-table" width="99%">
                        <thead>
                            <tr>
                                <th class="colomnSize"><input type="checkbox" id="check_all"></th>
                                <th class="colomnSize">Kode Booking</th>
                                <th class="colomnSize">Nama Konsumen</th>
                                <th class="colomnSize">Nomor WhatsApp</th>
                                <th class="colomnSize">Alamat</th>
                                <th class="colomnSize">Paket</th>
                                <th class="colomnSize">Status Booking</th>
                                <th class="colomnSize">Status Pembayaran</th>
                                <th class="colomnSize">Tanggal Wedding</th>
                                <th class="colomnSize">CS</th>
                                <th class="colomnSize">Total Transaksi</th>
                                <th width="0">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="10" style="text-align: right!important; font-weight: bold">TOTAL :</th>
                                <th style="font-weight: bold" id="sum_total"></th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="ajaxModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form id="bookingForm" name="bookingForm" autocomplete="off">
                <div class="modal-body">
                    <input type="hidden" name="kode" id="kode">
                    <div class="form-group">
                        <label>Nama Konsumen</label>
                        <input required="" type="text" id="nama" name="nama" value="{{ old('nama') }}" autocomplete="off" class="form-control error_nama" placeholder="Isi nama konsumen">
                        <div class="invalid-feedback error_nama"></div>
                    </div>
                    <div class="form-group">
                        <label>Nomor WhatsApp</label>
                        <input type="text" id="no_tlp" name="no_tlp" class="form-control error_no_tlp" value="{{ old('no_tlp') }}" placeholder="Isi nomor WhatsApp konsumen" required />
                        <div class="invalid-feedback error_no_tlp"></div>
                    </div>
                    <div class="form-group">
                        <label>Tanggal Wedding</label>
                        <input type="text" name="tgl_wedding" class="form-control datetimepicker-input error_tgl_wedding" id="datetimepicker5" data-toggle="datetimepicker" data-target="#datetimepicker5" placeholder="Pilih tanggal wedding" onkeydown="return false" />
                        <div class="invalid-feedback error_tgl_wedding"></div>
                    </div>
                    <div class="form-group">
                        <label>Paket Wedding</label>
                        <select class="form-control selectpicker select_input is_paket" name="paket" id="paket">
                            <option value="" selected disabled hidden>Pilih di sini</option>
                            @foreach ($sub_wedding as $sw)
                                <option value="{{ $sw->id }}" @selected(old('paket') == $sw->id)>{{ $sw->sub_paket }}</option>
                            @endforeach
                        </select>
                        <div class="invalid-feedback error_paket"></div>
                    </div>
                    <div class="form-group">
                        <select class="form-control selectpicker select_input is_extra" name="extra_wedding" id="extra_wedding">
                            <option value="" selected>Additional Paket</option>
                            @foreach ($extra_wedding as $extra)
                                <option value="{{ $extra->id }}" @selected(old('extra_wedding') == $extra->id)>{{ $extra->extra_wedding }}</option>
                            @endforeach
                        </select>
                        <div class="invalid-feedback error_extra"></div>
                    </div>
                    <div class="form-group">
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" name="transport" value='1' class="custom-control-input"><span class="custom-control-label">Transport</span>
                        </label>
                    </div>
                    <div class="form-group">
                        <label>Alamat Konsumen</label>
                        <textarea type="text" id="alamat" name="alamat" placeholder="Tulis alamat lengkap" autocomplete="off" class="form-control error_alamat"></textarea>
                        <div class="invalid-feedback error_alamat"></div>
                    </div>
                    <div class="form-group">
                        <label>Status Booking</label>
                        <select class="form-control select_input selectpicker is_status_booking" id="status_booking" name="status_booking">
                            <option value="" selected disabled hidden>Pilih di sini</option>
                            <option value="Dipesan" @selected(old('status_booking') == "Dipesan")>Dipesan</option>
                            <option value="Selesai" @selected(old('status_booking') == "Selesai")>Selesai</option>
                        </select>
                        <div class="invalid-feedback error_status_booking"></div>
                    </div>
                    <div class="form-group">
                        <label>Status Pembayaran</label>
                        <select class="form-control select_input selectpicker is_status_bayar" id="status_bayar" name="status_bayar">
                            <option value="" selected disabled hidden>Pilih di sini</option>
                            <option value="Belum Dibayar" @selected(old('status_bayar') == "Belum Dibayar")>Belum Dibayar</option>
                            <option value="DP" @selected(old('status_bayar') == "DP")>DP</option>
                            <option value="Lunas" @selected(old('status_bayar') == "Lunas")>Lunas</option>
                        </select>
                        <div class="invalid-feedback error_status_bayar"></div>
                    </div>
                    <div class="form-group jml_dp" style="display: none;">
                        <label>Jumlah DP</label>
                        <input type="text" id="jml_dp" name="jml_dp" value="{{ old('jml_dp', 0) }}" class="form-control">
                        <b style="color: red;">* Hanya diisi jika konsumen melakukan DP</b>
                    </div>
                    <div class="form-group">
                        <label>Customer Service</label>
                        <p class="text-center">@foreach ($nama_cs as $nc)
                            <label class="custom-control custom-radio custom-control-inline">
                                <input type="radio" name="nama_cs" value="{{ $nc }}" @if(old('nama_cs', $cs_now->value_1) == $nc) checked="checked" @endif class="custom-control-input"><span class="custom-control-label">{{ $nc }}</span>
                            </label>
                        @endforeach</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    new Cleave('#jml_dp', {
        numeral: true,
        numeralDecimalMark: ',',
        delimiter: '.',
        prefix: 'Rp ',
    });

    $(function() { 
        $('#datetimepicker5').datetimepicker({
            defaultDate: "{{ old('tgl_wedding') }}",
            format: 'YYYY-MM-DD',
            widgetPositioning: { vertical: 'bottom' }
        });
        $('#tanggal_1').datetimepicker({
            format: 'YYYY-MM-DD',
            widgetPositioning: { vertical: 'bottom' }
        }); 
        $('#tanggal_2').datetimepicker({
            format: 'YYYY-MM-DD',
            widgetPositioning: { vertical: 'bottom' }
        });
    });

    $(document).ready(function() {
        $('.select2').select2({ 
            tags: true,
            dropdownParent: $('#ajaxModel'), 
            theme: "bootstrap",
            dropdownPosition: 'below'
        });
    });

    $(function() {
        if ($("#status_bayar").val() == "DP") {
            $(".jml_dp").show();
        } else {
            $("#status_bayar").change(function() {
            if ($(this).val() == "DP") {
                $(".jml_dp").show();
            } else {
                $(".jml_dp").hide();
            }
            });
        };
    });

    $(function () {
        $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.fn.dataTable.ext.classes.sPageButton = 'btn btn-dark';
        var table = $('.data-table').DataTable({
            searchDelay: 500,
            processing: true,
            serverSide: true,
            ajax: {
                'url': "{{ route('daftar_wedding') }}",
                'data': function (d) {
                    d.session_sbo = $('#session_sbo').val();
                    d.session_dp = $('#session_dp').val();
                    d.session_sba = $('#session_sba').val();
                    d.tanggal_1 = $('#tanggal_1').val();
                    d.tanggal_2 = $('#tanggal_2').val();
                }
            },
            drawCallback:function(data)
            {
                $('#sum_total').html(data.json.sum_total);
            },
            columns: [
                { data: 'kodes', name: 'kodes' },
                { data: 'kode', name: 'kode' },
                { data: 'nama', name: 'nama' },
                { data: 'no_tlp', name: 'no_tlp' },
                { data: 'alamat', name: 'alamat' },
                { data: 'paket', name: 'paket' },
                { data: 'status_booking', name: 'status_booking' },
                { data: 'status_bayar', name: 'status_bayar' },
                { data: 'tgl_wedding', name: 'tgl_wedding' },
                { data: 'cs', name: 'cs' },
                { data: 'total', name: 'total' },
                { data: 'opsi', name: 'opsi' },
            ],
            "aoColumnDefs": [
                { "bSortable": false, "aTargets": [0,11] }, 
                { "bSearchable": false, "aTargets": [0,11] },
                { "className": "text-center", "targets" : [0,1,2,3,4,5,6,7,8,9,10,11] },
            ],
            "aaSorting": [],
        });
        $('#btn-filter').click(function () {
            reloadTable();
        });
        $('#btn-reset').click(function() {
            {{ session()->forget(['session_sbo', 'session_dp', 'session_sba', 'tanggal_1', 'tanggal_2']); }}
            $('#session_sbo').val('').selectpicker("refresh");
            $('#session_dp').val('').selectpicker("refresh");
            $('#session_sba').val('').selectpicker("refresh");
            $('#tanggal_1').val('');
            $('#tanggal_2').val('');
            reloadTable();
            location.reload();
        });
        function reloadTable() {
            var table = $('.data-table').DataTable();
            table.cleanData;
            table.ajax.reload();
            {{ session()->forget(['session_sbo', 'session_dp', 'session_sba', 'tanggal_1', 'tanggal_2']); }}
        }

        // Bagian tambah data
        $('#createBooking').click(function () {
            $('#simpanBtn').val("create-booking");
            $('#kode').val('');
            $('#bookingForm').trigger("reset");
            $('#modelHeading').html("Tambah Booking Wedding");
            $('#ajaxModel').modal('show');
            $('.error_nama').removeClass('is-invalid');
            $('.error_no_tlp').removeClass('is-invalid');
            $('.error_tgl_wedding').removeClass('is-invalid');
            $('.is_paket').removeClass('is-invalid') + $('#paket').val('').trigger('change');
            $('.is_extra').removeClass('is-invalid') + $('#extra_wedding').val('').trigger('change');
            $('.error_alamat').removeClass('is-invalid');
            $('.is_status_booking').removeClass('is-invalid') + $('#status_booking').val('').trigger('change');
            $('.is_status_bayar').removeClass('is-invalid') + $('#status_bayar').val('').trigger('change');
        });

        // Bagian proses simpan data
        $('#simpanBtn').click(function (e) {
            e.preventDefault();
            $(this).html('Proses Simpan...').prop('disabled', true);
            $.ajax({
                data: $('#bookingForm').serialize(),
                url: "{{ route('create_wedding') }}",
                type: "POST",
                dataType: 'json',
                success: function (data) {
                    $('#bookingForm').trigger("reset");
                    $('.select_input').val('').trigger("change");
                    $('#ajaxModel').modal('hide');
                    $('#alert_message').html('<div class="alert alert-success" >'+ data.message +'</div>');
                    alertSuccess(data.message);
                    table.draw();
                },
                error: function (data) {
                    data.responseJSON.errors.nama ? $('.error_nama').text(data.responseJSON.errors.nama) + $('.error_nama').addClass('is-invalid') : $('.error_nama').removeClass('is-invalid');
                    data.responseJSON.errors.no_tlp ? $('.error_no_tlp').text(data.responseJSON.errors.no_tlp).addClass('is-invalid') : '';
                    data.responseJSON.errors.tgl_wedding ? $('.error_tgl_wedding').text(data.responseJSON.errors.tgl_wedding).addClass('is-invalid') : '';
                    data.responseJSON.errors.paket ? $('.error_paket').text(data.responseJSON.errors.paket) + $('.is_paket').addClass('is-invalid') : $('.is_paket').removeClass('is-invalid');
                    data.responseJSON.errors.extra_wedding ? $('.error_extra').text(data.responseJSON.errors.extra_wedding) + $('.is_extra').addClass('is-invalid') : $('.is_extra').removeClass('is-invalid');
                    data.responseJSON.errors.alamat ? $('.error_alamat').text(data.responseJSON.errors.alamat) + $('.error_alamat').addClass('is-invalid') : '';
                    data.responseJSON.errors.status_booking ? $('.error_status_booking').text(data.responseJSON.errors.status_booking) + $('.is_status_booking').addClass('is-invalid') : $('.is_status_booking').removeClass('is-invalid');
                    data.responseJSON.errors.status_bayar ? $('.error_status_bayar').text(data.responseJSON.errors.status_bayar) + $('.is_status_bayar').addClass('is-invalid') : $('.is_status_bayar').removeClass('is-invalid');
                },
                complete: function () {
                    $('#simpanBtn').html('Simpan').prop('disabled', false);
                }
            });
        });

        // Bagian delete data
        $('body').on('click', '.deleteBooking', function (){
            var kode = $(this).data("kode");
            Swal.fire({
                title: 'Apakah anda yakin',
                text: "Data akan dihapus",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Hapus Data!'
            }).then(function (e) {
                if (e.value === true) {
                    $.ajax({
                        type: "DELETE",
                        url: "{{ route('create_wedding') }}/" + kode,
                        success: function (data) {
                            $('#alert_message').html('<div class="alert alert-success" >'+ data.message +'</div>');
                            alertSuccess(data.message);
                            table.draw();
                        },
                        error: function (data) {
                            console.log('Error:', data);
                        }
                    });
                } else {
                    return false;
                }
            });
        });

        // Bagian multiple delete data
        $('#check_all').on('click', function(e) {
            $(this).is(':checked',true) ? $(".sub_chk").prop('checked', true) : $(".sub_chk").prop('checked',false);
        });
        $('#delete_all').on('click', function(e) {
            var data_chk = [];
            $(".sub_chk:checked").each(function() {  
                data_chk.push($(this).attr('data-kodes'));
            });
            if (data_chk.length<=0) {
                Swal.fire("Pilih data terlebih dahulu!");
            } else {
                Swal.fire({
                    title: 'Apakah anda yakin',
                    text: "Data akan dihapus",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Hapus Data!'
                }).then(function (e) {
                    if (e.value === true) {
                        var join_selected_values = data_chk.join(","); 
                        $.ajax({
                            url: "{{ url('daftar_wedding_delete') }}",
                            type: 'DELETE',
                            data: 'kodes='+join_selected_values,
                            success: function (data) {
                                if (data['success']) {
                                    $(".sub_chk:checked").each(function() {  
                                        $(this).parents("tr").remove();
                                        $("#check_all").prop('checked', false);
                                    });
                                    $('#alert_message').html('<div class="alert alert-success" >'+ data.message +'</div>');
                                    alertSuccess(data.message);
                                    table.draw();
                                } else if (data['error']) {
                                    alert(data['error']);
                                } else {
                                    alert('Ups Ada yang tidak beres.');
                                }
                            },
                            error: function (data) {
                                alert(data.responseText);
                            }
                        });
                    } else {
                        return false;
                    }
                });
            }
        });
    });
</script>
@endsection