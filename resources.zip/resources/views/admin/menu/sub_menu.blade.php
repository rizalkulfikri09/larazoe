@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <a href="javascript:void(0)" id="tambahMenu" class="btn btn-primary m-b-20">Tambah Submenu Baru</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table" style="text-align: center">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Nama Sub Menu</th>
                                    <th scope="col">Nama Menu</th>
                                    <th scope="col">Icon</th>
                                    <th scope="col">URL</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                            @foreach ($sub_menu as $index => $sm)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $sm->title }}</td>
                                    <td>{{ $sm->menu }}</td>
                                    <td><i class="{{ $sm->icon }}"></i></td>
                                    <td>{{ $sm->url }}</td>
                                    <td>{{ $sm->is_active == 1 ? 'Aktif' : 'Tidak Aktif' }}</td>
                                    <td>
                                        <div class="d-flex justify-content-center opsi">
                                            <a href="javascript:void(0)" class="btn btn-success btn-sm tombol editMenu" data-id="{{ $sm->id }}" data-title="{{ $sm->title }}" data-menu_id="{{ $sm->menu_id }}" data-icon="{{ $sm->icon }}" data-url="{{ $sm->url }}" data-is_active="{{ $sm->is_active }}">Edit</a>
                                            <form action="{{ route('delete_sub_menu', $sm->id) }}" method="post">
                                                @csrf
                                                @method('delete')
                                                <button type="submit" class="btn btn-danger btn-sm tombol delete_data">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading"></h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="" id="formModal" method="post" autocomplete="off">
                @csrf
                <div class="modal-body">
                    <input type="hidden" name="id" id="id">
                    <div class="form-group">
                        <label>Nama Sub Menu</label>
                        <input required="" type="text" id="title" name="title" class="form-control" placeholder="Isi nama sub menu">
                    </div>
                    <div class="form-group">
                        <label>Pilih Menu</label>
                        <select class="form-control selectpicker" name="menu_id" id="menu_id">
                            <option value="" selected disabled hidden>Pilih di sini</option>
                            @foreach ($menu as $m)
                                <option value="{{ $m->id }}">{{ $m->menu }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Icon Submenu</label>
                        <input data-parsley-trigger="change" required="" type="text" id="icon" name="icon" placeholder="Isi icon submenu" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>URL Submenu</label>
                        <input data-parsley-trigger="change" required="" type="text" id="url" name="url" placeholder="Isi URL submenu" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control selectpicker" id="is_active" name="is_active">
                            <option value="1">Aktif</option>
                            <option value="0">Tidak Aktif</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-primary" id="simpanBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $('#tambahMenu').click(function () {
        $('#formModal').attr('action', "{{ route('sub_menu') }}");
        $('#modelHeading').html("Form tambah sub menu baru");
        $('#exampleModal').modal('show');
        $('#formModal').trigger("reset");
        $('#menu_id').val('').trigger("change");
    });

    // Bagian edit data
    $('body').on('click', '.editMenu', function () {
        const id = $(this).data('id');
        const title = $(this).data('title');
        const menu_id = $(this).data('menu_id');
        const icon = $(this).data('icon');
        const url = $(this).data('url');
        const is_active = $(this).data('is_active');
        $('#formModal').attr('action', "{{ url('sub_menu') }}/" + id + "/edit");
        $('#modelHeading').html("Form edit sub menu");
        $('#exampleModal').modal('show');
        $('#id').val(id);
        $('#title').val(title);
        $('#menu_id').val(menu_id).trigger('change');
        $('#icon').val(icon);
        $('#url').val(url);
        $('#is_active').val(is_active).trigger('change');
    });
</script>
@endsection