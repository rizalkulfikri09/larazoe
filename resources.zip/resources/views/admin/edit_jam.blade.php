@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('update_jam', $jam_booking->id) }}" method="post">
                        @csrf
                        @method('put')
                        <div class="form-group">
                            <label>Jam Booking</label>
                            <input type="text" id="jam" name="jam" value="{{ old('jam', $jam_booking->jam) }}" required="" autocomplete="off" class="form-control @error('jam') is-invalid @enderror" placeholder="Isi jam awal booking">
                            @error('jam')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select class="form-control selectpicker @error('status') is-invalid @enderror" name="status" id="status">
                                @foreach ($jml_hari as $jh)
                                    <option value="{{ $jh }}" @selected(old('status', $jam_booking->status) == $jh)>{{ statusJam($jh) }}</option>
                                @endforeach
                            </select>
                            @error('status')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 m-t-10">
                                <button type="submit" class="btn btn-space btn-primary">Submit</button>
                                @include('components.button_kembali', ['url' => route('pengaturan_jam')])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection