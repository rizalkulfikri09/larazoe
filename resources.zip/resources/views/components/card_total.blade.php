<div class="col-xl-5 col-lg-5 col-md-5 col-sm-12 col-12">
    <div class="card">
        <div class="card-header" style="font-size: 18px; padding: 0.8rem!important">Total Pembayaran</div>
        <div class="card-body" style="padding: 0.8rem!important; background-color: #e6e6e6;">
            <b style="font-size: 18px; color: #000;">{{ $total_pembayaran }}</b>
        </div>
    </div>
</div>