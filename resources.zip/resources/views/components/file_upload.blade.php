<div class="custom-file">
    <label class="file">
        <input type="file" class="custom-file-input @error($name) is-invalid @enderror" id="{{ $name ?? '' }}" name="{{ $name ?? '' }}" aria-label="File browser example" onchange="preview_image(event)">
        @error($name)
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
        <span class="file-custom">Pilih file...</span>
    </label>
</div>