    <div id="alert_message"></div>
@if (session('success'))
    <div class="alert alert-success" role="alert">
        {!! session('success') !!}
    </div>
    @auth
    <div class="flash-data" data-flashdata="{!! session('success') !!}"></div>
    @endauth
@elseif (session('danger'))
    <div class="alert alert-danger" role="alert">
        {{ session('danger') }}
    </div>
@elseif ($errors->any())
    <div class="alert alert-danger" role="alert">
        @foreach ($errors->all() as $error)
            <div>{{ $error }}</div>
        @endforeach
    </div>
@elseif (session('flash'))
    <div class="flash-data" data-flashdata="{!! session('flash') !!}"></div>
@endif