@extends('layouts.auth_template')
@section('body')
    <div class="splash-container">
        <div class="card">
            <div class="card-header text-center"><a class="logo" href="{{ route('/') }}">{{ $set_umum->value_2 }}</a></div>
                <div class="card-body">
                    @include('components.alert')
                    <form action="{{ route('login') }}" method="post" autocomplete="off">
                        @csrf
                        <div class="form-group">
                            <input type="text" class="form-control form-control-lg @error('no_tlp') is-invalid @enderror" value="{{ old('no_tlp') }}" id="no_tlp" name="no_tlp" placeholder="Nomor WhatsApp atau Email" required autofocus>
                            @error('no_tlp')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <input type="password" class="form-control form-control-lg @error('password') is-invalid @enderror" id="password" name="password" placeholder="Password" required>
                                <div class="input-group-append"><span class="input-group-text"><i class="fas fa-eye field-icon toggle-password" toggle="#password" style="cursor: pointer;"></i></span></div>
                            </div>
                            @error('password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group d-flex justify-content-between" style="margin-bottom: 5px;">
                            <label class="custom-control custom-checkbox">
                                <input class="custom-control-input" type="checkbox" name="remember" id="remember-me"><span class="custom-control-label" for="remember-me">Remember Me</span>
                            </label>
                            <label class="mt-1">
                                <a href="{{ route('lupa_password') }}">Lupa Password?</a>
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary btn-lg btn-block">Login</button>
                    </form>
                    <hr>
                    <div class="button">
                        <div class="form-group" style="margin-bottom: 8px;">
                            @if ($set_sistem->value_4 == '1')
                                <a href="{{ route('registrasi') }}" class="btn btn-block btn-success">Buat Akun Baru</a>
                            @endif
                        </div>
                        <div class="form-group" style="margin-bottom: 0px;">
                            <a href="{{ route('/') }}" class="btn btn-block btn-dark">Kembali Ke Website</a>
                        </div>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-9 col-9">
                        <small>{{ $set_umum->value_3 }}. Dashboard by <a href="https://colorlib.com/wp/" target="_blank">Colorlib</a>.</small>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-3 col-3">
                        <div class="text-md-right footer-links d-sm-block">
                            <small>Versi 2.3</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection