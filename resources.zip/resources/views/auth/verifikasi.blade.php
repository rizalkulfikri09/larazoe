@extends('layouts.auth_template')
@section('body')
    <div class="splash-container" style="max-width: 500px!important">
        @include('components.alert')
        <div class="card">
            <div class="card-header text-center"><h3 class="m-1 font-weight-bold">{{ $title }}</h3></div>
            <div class="card-body">
                <form action="{{ url('/'.$type.'/'.$no_tlp) }}" method="post" autocomplete="off">
                    @csrf
                    <div class="form-group text-center">
                        Masukkan kode OTP pada kolom dibawah ini
                    </div>
                    <div class="form-group inputs d-flex flex-row justify-content-center" id="otp">
                        <input class="text-center form-control rounded m-2" type="text" name="kode_1" maxlength="1" required autofocus>
                        <input class="text-center form-control rounded m-2" type="text" name="kode_2" maxlength="1" required>
                        <input class="text-center form-control rounded m-2" type="text" name="kode_3" maxlength="1" required>
                        <input class="text-center form-control rounded m-2" type="text" name="kode_4" id="end" maxlength="1" required>
                    </div>
                    <div class="form-group text-center">
                        <span class="d-block font-weight-bold" id="countdown"></span>
                        <span class="d-block" id="resend"></span>
                    </div>
                <button type="submit" class="btn btn-primary btn-lg btn-block">Verifikasi</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        $("#otp .form-control").keyup(function() {  
            if (this.value.length == 0) {
                $(this).blur().parent().prev().children('.form-control').focus();
                $(this).blur().prev('.form-control').focus();
            } else if (this.value.length == this.maxLength) {
                $(this).blur().parent().next().children('.form-control').focus();
                $(this).blur().next('.form-control').focus();
            }
            $('#end').on('change', function (e) {
                $('#otp').parent().submit();
                e.preventDefault();
            });
        });

        countdown_time("{{ $expired_time }}", 'menit', 'detik');
        function countdown_time(data, menit, detik) {
            var end = new Date(data);
            var timer;
            function sisa_waktu() {
                var now = new Date();
                var distance = end - now;
                var distance1 = now - end;
                if(distance1 > 0) {
                    clearInterval(timer);
                    document.getElementById("resend").innerHTML = "{!! $resend !!}";
                    return;
                }
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;
                document.getElementById("countdown").innerHTML = "Sisa waktu " + minutes + ":" + seconds;
            }
            timer = setInterval(sisa_waktu, 1000);
        }
    </script>
@endsection