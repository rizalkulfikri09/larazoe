@extends('layouts.auth_template')
@section('body')
    <div class="splash-container" style="max-width: 500px!important">
        <div class="card">
            <div class="card-header text-center"><h3 class="m-1 font-weight-bold">Reset Password Akun</h3></div>
            <div class="card-body">
                <form action="{{ url('/reset_password/'.$no_tlp) }}" method="post" autocomplete="off">
                    @csrf
                    <div class="form-group">
                        <input class="form-control @error('password') is-invalid @enderror" type="text" name="password" placeholder="Password Baru" required autofocus>
                        @error('password')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" name="password_confirmation" placeholder="Ulangi Password" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg btn-block">Simpan</button>
                </form>
            </div>
        </div>
    </div>
@endsection