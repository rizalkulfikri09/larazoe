@extends('layouts.auth_template')
@section('body')
    <script src="https://www.google.com/recaptcha/api.js?hl=id" async defer></script>
    <div class="splash-container">
        <div class="card">
            <div class="card-header">
                <h3 class="m-1">Registrasi Akun</h3>
            </div>
            <div class="card-body">
                <form action="{{ route('registrasi') }}" method="post" autocomplete="off" id="input_form">
                    @csrf
                    <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" id="nama" name="nama" data-parsley-trigger="change" required="" placeholder="Nama Konsumen" class="form-control @error('nama') is-invalid @enderror" value="{{ old('nama') }}" autofocus>
                        @error('nama')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label>Nomor WhatsApp</label>
                        <input type="text" id="no_tlp" name="no_tlp" data-parsley-trigger="change" required="" placeholder="08123XXXXXXX" class="form-control @error('no_tlp') is-invalid @enderror" value="{{ old('no_tlp') }}" autofocus>
                        @error('no_tlp')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" id="email" name="email" data-parsley-trigger="change" required="" placeholder="Email Konsumen" class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}" autofocus>
                        @error('email')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" id="password" name="password" data-parsley-trigger="change" required="" placeholder="Password Konsumen" class="form-control @error('password') is-invalid @enderror" autofocus>
                        @error('password')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label>Ulangi Password</label>
                        <input type="password" id="password_confirmation" name="password_confirmation" data-parsley-trigger="change" required="" placeholder="Masukan Kembali Password" class="form-control" autofocus>
                    </div>
                    <div class="form-group">
                        <div class="g-recaptcha" data-sitekey="{{ $captcha_key }}"></div>
                        @if ($errors->has('g-recaptcha-response'))
                            <div class="text-danger text-center mt-2">{{ $errors->first('g-recaptcha-response') }}</div>
                        @endif
                    </div>
                    <div class="form-group text-center">
                        @if ($set_sistem->value_2)
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" name="type_send" value="wa" class="custom-control-input" @checked(old('type_send', true) == "wa")><span class="custom-control-label">Verifikasi akun lewat WhatsApp</span>
                        </label>
                        @endif
                        @if ($set_sistem->value_10)
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" name="type_send" value="mail" class="custom-control-input" @checked(old('type_send') == "mail") @if ($set_sistem->value_10 && $set_sistem->value_2 == 0) checked @endif><span class="custom-control-label">Verifikasi akun lewat Email</span>
                        </label>
                        @endif
                    </div>
                    <div class="form-group pt-2">
                        <button class="btn btn-block btn-success" type="submit">Buat Akun</button>
                    </div>
                    <div class="form-group row pt-0">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-2">
                            <input type="button" onclick="location.href='{{ route('login') }}'" class="btn btn-block btn-social btn-facebook" value="Login" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $('#input_form').submit(function () {
            $('.btn-block').prop('disabled', true);
        });
    </script>
@endsection