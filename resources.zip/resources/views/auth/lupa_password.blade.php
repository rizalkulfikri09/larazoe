@extends('layouts.auth_template')
@section('body')
    <script src="https://www.google.com/recaptcha/api.js?hl=id" async defer></script>
    <div class="splash-container" style="max-width: 500px!important">
        <div class="card">
            <div class="card-header text-center"><h3 class="m-1 font-weight-bold">Lupa Password Akun</h3></div>
            <div class="card-body">
                @include('components.alert')
                <form action="{{ route('lupa_password') }}" method="post" id="input_form">
                    @csrf
                    <div class="form-group text-center">
                        Masukkan nomor WhatsApp atau email yang terdaftar pada akun Anda.
                    </div>
                    <div class="form-group">
                        <input class="form-control @error('no_tlp') is-invalid @enderror" type="text" name="no_tlp" placeholder="Isi nomor WhatsApp atau email anda" value="{{ old('no_tlp') }}" required autofocus autocomplete="off">
                        @error('no_tlp')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group d-flex justify-content-center">
                        <div class="g-recaptcha" data-sitekey="{{ $captcha_key }}"></div>
                    </div>
                    @if ($errors->has('g-recaptcha-response'))
                        <div class="text-danger text-center mb-2">{{ $errors->first('g-recaptcha-response') }}</div>
                    @endif
                    <div class="form-group text-center">
                        @if ($set_sistem->value_2)
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" name="type_send" value="wa" class="custom-control-input" @checked(old('type_send', true) == "wa")><span class="custom-control-label">Kirim kode lewat WhatsApp</span>
                        </label>
                        @endif
                        @if ($set_sistem->value_10)
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" name="type_send" value="mail" class="custom-control-input" @checked(old('type_send') == "mail") @if ($set_sistem->value_10 && $set_sistem->value_2 == 0) checked @endif><span class="custom-control-label">Kirim kode lewat Email</span>
                        </label>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg btn-block">Kirim</button>
                    <a href="{{ route('login') }}" class="btn btn-block btn-dark">Kembali</a>
                </form>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $('#input_form').submit(function () {
            $('.btn-block').prop('disabled', true);
        });
    </script>
@endsection