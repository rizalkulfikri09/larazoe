@extends('layouts.app_template')
@section('body')
<script src="https://www.google.com/recaptcha/api.js?hl=id" async defer></script>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('user_update') }}" method="post" enctype="multipart/form-data" autocomplete="off">
                        @csrf
                        <div class="form-group">
                            <label>Nomor WhatsApp</label>
                            <div class="input-group">
                                <input type="text" required="" name="no_tlp" value="{{ old('no_tlp', auth()->user()->no_tlp) }}" class="form-control @error('no_tlp') is-invalid @enderror" readonly>
                                <div class="input-group-append">
                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModal">Ganti Nomor</button>
                                </div>
                                @error('no_tlp')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Nama Konsumen</label>
                            <input type="text" required="" placeholder="Nama Lengkap" name="nama" value="{{ old('nama', auth()->user()->nama) }}" class="form-control @error('nama') is-invalid @enderror">
                            @error('nama')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Email Konsumen</label>
                            <input type="text" required="" placeholder="Email" name="email" value="{{ old('email', auth()->user()->email) }}" class="form-control @error('email') is-invalid @enderror">
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Foto Profil</label>
                            <div class="row">
                                <div class="col-sm-3">
                                <img src="{{ asset('frontend/images/profile/' . auth()->user()->image) }}" id="output_image" style="width: 100px; height: 100px; border-radius: 8px;" />
                                </div>
                                <div class="col-sm-9">
                                    <div class="custom-file @error('image') is-invalid @enderror">
                                        <label class="file">
                                            <input type="file" class="custom-file-input" id="image" name="image" aria-label="File browser example" onchange="preview_image(event)">
                                            <span class="file-custom m-t-10">Pilih foto ...</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            @error('image')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="row">
                            <div class="col-sm-6 m-t-20">
                                <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <div class="card">
                <div class="card-body">
                    <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#hapus_akun">Hapus Akun</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="hapus_akun" tabindex="-1" role="dialog" aria-labelledby="hapus_akun" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="hapus_akun">Hapus Akun</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="{{ route('hapus_akun') }}" method="post">
                @csrf
                <div class="modal-body">
                    <div class="form-group">
                        <label>Password Akun</label>
                        <input required="" type="text" name="password" autocomplete="off" class="form-control" placeholder="Masukan password akun anda">
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-primary" data-dismiss="modal">Keluar</a>
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ganti Nomor WhatsApp</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></a>
            </div>
            <form action="{{ route('user_ganti_nomor') }}" method="post" autocomplete="off" id="input_form">
                @csrf
                <div class="modal-body">
                    <div class="form-group text-center">
                        Link verifikasi akan dikirim lewat WhatsApp atau email Anda
                    </div>
                    <div class="form-group">
                        <label>Nomor WhatsApp Baru</label>
                        <input required="" type="text" id="no_tlp" name="no_tlp" class="form-control" value="{{ old('no_tlp') }}" placeholder="08123XXXXXXX">
                    </div>
                    <div class="form-group d-flex justify-content-center">
                        <div class="g-recaptcha" data-sitekey="{{ $captcha_key }}"></div>
                    </div>
                    @if ($errors->has('g-recaptcha-response'))
                        <div class="text-danger text-center mt-2">{{ $errors->first('g-recaptcha-response') }}</div>
                    @endif
                    <div class="form-group text-center mb-0">
                        @if ($set_sistem->value_2)
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" name="type_send" value="wa" class="custom-control-input" @checked(old('type_send', true) == "wa")><span class="custom-control-label">Kirim kode lewat WhatsApp</span>
                        </label>
                        @endif
                        @if ($set_sistem->value_10)
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" name="type_send" value="mail" class="custom-control-input" @checked(old('type_send') == "mail") @if ($set_sistem->value_10 && $set_sistem->value_2 == 0) checked @endif><span class="custom-control-label">Kirim kode lewat Email</span>
                        </label>
                        @endif
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-secondary btn-loading" data-dismiss="modal">Tutup</a>
                    <button type="submit" class="btn btn-primary btn-loading">Kirim</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $('#input_form').submit(function () {
        $('.btn-loading').prop('disabled', true);
    });

    function preview_image(event) 
    {
        var reader = new FileReader();
        reader.onload = function()
        {
            var output = document.getElementById('output_image');
            output.src = reader.result;
            output.setAttribute('width', '100px');
            output.setAttribute('height', '100px');
        }
        reader.readAsDataURL(event.target.files[0]);
    }
</script>
@endsection