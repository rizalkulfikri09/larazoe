@extends('layouts.app_template')
@section('body')
<style>
    .card {
        margin-bottom: 20px;
    }
    .menu-icon {
        width: 160px;
        height: 100px;
        margin: 0 0 10px 0;
    }
    .menu-icon i {
        margin: 20px;
    }
    @media only screen and (max-width: 600px) {
        .menu {
        text-align: center;
        }
    }
</style>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <img src="{{ asset('frontend/images/profile/' . auth()->user()->image) }}" style="width: 100px; height: 100px" />
                        </div>
                        <div class="col-md-9 my-auto">
                            <h3>Nama : <strong>{{ auth()->user()->nama }}</strong><br>
                            Nomor WhatsApp : <strong>{{ auth()->user()->no_tlp }}</strong><br>
                            Email : <strong>{{ auth()->user()->email }}</strong></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
            <a href="{{ route('booking_studio') }}">
                <div class="card bg-primary text-white text-center p-4">
                    Booking Studio Foto
                </div>
            </a>
            <a href="{{ route('riwayat_booking') }}">
                <div class="card bg-primary text-white text-center p-4">
                    Riwayat Booking Studio
                </div>
            </a>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
            <a href="{{ route('booking_wedding') }}">
                <div class="card bg-secondary text-white text-center p-4">
                    Booking Wedding
                </div>
            </a>
            <a href="{{ route('riwayat_wedding') }}">
                <div class="card bg-secondary text-white text-center p-4">
                    Riwayat Booking Wedding
                </div>
            </a>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
            <a href="{{ route('self_photo') }}">
                <div class="card bg-success text-white text-center p-4">
                    Booking Self Photo
                </div>
            </a>
            <a href="{{ route('riwayat_selfphoto') }}">
                <div class="card bg-success text-white text-center p-4">
                    Riwayat Booking Self Photo
                </div>
            </a>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
            <a href="{{ route('pilih_tema') }}">
                <div class="card bg-danger text-white text-center p-4">
                    Undangan Digital
                </div>
            </a>
            <a href="{{ route('riwayat_undangan') }}">
                <div class="card bg-danger text-white text-center p-4">
                    Riwayat Undangan Digital
                </div>
            </a>
        </div>
    </div>
</div>
@endsection