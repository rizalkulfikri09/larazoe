@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('ganti_password') }}" method="post" autocomplete="off">
                        @csrf
                        <div class="form-group">
                            <label>Password Lama</label>
                            <input type="password" id="current_password" name="current_password" required="" class="form-control @error('current_password') is-invalid @enderror" placeholder="Masukan password lama">
                            @error('current_password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Password Baru</label>
                            <input type="password" id="password" name="password" required="" class="form-control @error('password') is-invalid @enderror" placeholder="Masukan password baru">
                            @error('password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Ulangi Password</label>
                            <input type="password" id="password_confirmation" name="password_confirmation" required="" class="form-control @error('password_confirmation') is-invalid @enderror" placeholder="Ulangi password baru">
                            @error('password_confirmation')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection