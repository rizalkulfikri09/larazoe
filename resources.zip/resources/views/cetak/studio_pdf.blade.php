<!DOCTYPE html>
<html>
<head>
    <title>Daftar Booking Studio Foto</title>
    <link rel="stylesheet" href="{{ asset('frontend/vendor/bootstrap/css/bootstrap.min.css') }}">
    <meta charset="utf-8">
    <style>
    body {
        font-family: 'Times New Roman', Times, serif;
        color: #000;
        font-size: 14px;
    }
    .table thead th, .table tbody td, .table tfoot th {
        border: 1px solid #000;
    }
    .table td, .table th {
        padding: 0.10rem;
    }
    .nama_studio {
        font-weight: bold;
        font-size: 24px;
        text-align: center;
    }
    .alamat {
        text-align: center;
        line-height: 1.2;
        margin-left: auto;
        margin-right: auto;
        width: 430px;
    }
    .title {
        text-align: center;
        text-transform: uppercase;
        font-weight: bold;
        text-decoration: underline;
        font-size: 16px;
        margin-top: 6px;
        margin-bottom: 10px;
    }
    </style>
</head>
<body>
    <div class="nama_studio">{{ $set_umum->value_8 }}</div>
    <div class="alamat">{{ $set_umum->value_9 }}</div>
    <div class="title">Daftar Booking Studio Foto</div>
    <table class="table table-bordered text-center">
        <thead style="background-color: #EEE;">
            <tr>
                <th>No</th>
                <th>Kode Booking</th>
                <th>Nama Konsumen</th>
                <th>Nomor WhatsApp</th>
                <th>Paket Pemotretan</th>
                <th>Jumlah Orang</th>
                <th>Status Booking</th>
                <th>Status Pembayaran</th>
                <th>Tanggal Booking</th>
                <th>Jam Booking</th>
                <th>CS</th>
                <th>Total Transaksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($data_booking as $index => $db)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $db->kode }}</td>
                <td>{{ $db->nama }}</td>
                <td>{{ $db->no_tlp }}</td>
                <td>{{ $db->paket }}</td>
                <td>{{ $db->jml_orang }}</td>
                <td>{{ $db->status_booking }}</td>
                <td>{{ $db->status_bayar }} {{ $db->status_bayar == 'DP' ? format_rupiah($db->jml_dp) : '' }}</td>
                <td>{{ Carbon::parse($db->tgl_booking)->translatedFormat('d-m-Y') }}</td>
                <td>{{ $db->jam_booking }}</td>
                <td>{{ $db->cs }}</td>
                <td>{{ format_rupiah($db->total) }}</td>
            </tr>
            @endforeach
        </tbody>
        <tfoot style="background-color: #EEE;">
            <tr>
                <th colspan="11" style="text-align: right!important; font-weight: bold">TOTAL :</th>
                <th style="font-weight: bold">{{ format_rupiah($sum_total) }}</th>
            </tr>
        </tfoot>
    </table>
    <div class="footer">
        <table style="text-align: center; width: 200px" align="right">
            <tr>
                <td>
                    <p style="margin-bottom: 60px;">{{ $set_umum->value_7 }}, {{ Carbon::now()->translatedFormat('d F Y') }}</p>
                    <span style="text-decoration: underline; font-weight: bold;">{{ $set_umum->value_6 }}</span><br>
                    Pemilik {{ $set_umum->value_8 }}
                </td>
            </tr>
        </table>
    </div>
</body>
</html>