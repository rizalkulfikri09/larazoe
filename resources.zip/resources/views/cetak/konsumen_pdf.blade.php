<!DOCTYPE html>
<html>
<head>
    <title>Daftar Konsumen</title>
    <link rel="stylesheet" href="{{ asset('frontend/vendor/bootstrap/css/bootstrap.min.css') }}">
    <meta charset="utf-8">
    <style>
    body {
        font-family: 'Times New Roman', Times, serif;
        color: #000;
        font-size: 14px;
    }
    .table thead th, .table tbody td {
        border: 1px solid #000;
    }
    .table td, .table th {
        padding: 0.10rem;
    }
    .nama_studio {
        font-weight: bold;
        font-size: 24px;
        text-align: center;
    }
    .alamat {
        text-align: center;
        line-height: 1.2;
        margin-left: auto;
        margin-right: auto;
        width: 430px;
    }
    .title {
        text-align: center;
        text-transform: uppercase;
        font-weight: bold;
        text-decoration: underline;
        font-size: 16px;
        margin-top: 6px;
        margin-bottom: 10px;
    }
    </style>
</head>
<body>
    <div class="nama_studio">{{ $set_umum->value_8 }}</div>
    <div class="alamat">{{ $set_umum->value_9 }}</div>
    <div class="title">Daftar Konsumen</div>
    <table class="table table-bordered text-center">
        <thead style="background-color: #EEE;">
            <tr>
                <th>No</th>
                <th>Nama Konsumen</th>
                <th>Nomor WhatsApp</th>
                <th>Email</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($users as $index => $user)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $user->nama }}</td>
                <td>{{ $user->no_tlp }}</td>
                <td>{{ $user->email }}</td>
                <td>{{ $user->is_active == 1 ? 'Aktif' : 'Tidak Aktif' }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="footer">
        <table style="text-align: center; width: 200px" align="right">
            <tr>
                <td>
                    <p style="margin-bottom: 60px;">{{ $set_umum->value_7 }}, {{ Carbon::now()->translatedFormat('d F Y') }}</p>
                    <span style="text-decoration: underline; font-weight: bold;">{{ $set_umum->value_6 }}</span><br>
                    Pemilik {{ $set_umum->value_8 }}
                </td>
            </tr>
        </table>
    </div>
</body>
</html>