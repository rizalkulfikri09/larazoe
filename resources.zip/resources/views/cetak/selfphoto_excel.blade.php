<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <table style="border: 1px solid black">
        <thead>
            <tr>
                <td colspan="12" height="30" style="text-align: center; vertical-align: middle; font-weight: bold; font-size: 16px; text-decoration: underline">Daftar Booking Self Photo</td>
            </tr>
            <tr>
                <th width="5" height="36" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">No</th>
                <th width="10" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Kode</th>
                <th width="25" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Nama Konsumen</th>
                <th width="15" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Nomor WhatsApp</th>
                <th width="44" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Paket</th>
                <th width="9" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Jumlah Orang</th>
                <th width="15" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Status Booking</th>
                <th width="15" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Status Pembayaran</th>
                <th width="12" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Tanggal Booking</th>
                <th width="13" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Jam Booking</th>
                <th width="8" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">CS</th>
                <th width="14" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Total Transaksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($data_booking as $index => $db)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $db->kode }}</td>
                <td>{{ $db->user->nama }}</td>
                <td>{{ $db->user->no_tlp }}</td>
                <td>{{ $db->paket }}</td>
                <td>{{ $db->jml_orang }}</td>
                <td>{{ $db->status_booking }}</td>
                <td>{{ $db->status_bayar }} {{ $db->status_bayar == 'DP' ? format_rupiah($db->jml_dp) : '' }}</td>
                <td>{{ Carbon::parse($db->tgl_booking)->translatedFormat('d-m-Y') }}</td>
                <td>{{ $db->jam_booking }}</td>
                <td>{{ $db->cs }}</td>
                <td>{{ format_rupiah($db->total) }}</td>
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr>
                <th colspan="11" style="text-align: right; font-weight: bold">TOTAL :</th>
                <th style="font-weight: bold">{{ format_rupiah($sum_total) }}</th>
            </tr>
        </tfoot>
    </table>
</body>
</html>