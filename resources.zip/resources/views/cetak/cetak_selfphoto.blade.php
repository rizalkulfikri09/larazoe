<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Booking Self Photo {{ $booking->kode }}</title>
    <style>
    * {
        font-family: "Calibri, sans-serif";
        font-size: 10px;
    }
    @page {
        margin: 11px;
    }
    </style>
</head>

<body>
    <div>
        <p style="text-align:center"><b>{{ $set_umum->value_8 }}</b><br>{{ $set_umum->value_9 }}<br></p>
        <div style="text-align:center"><b>{{ Carbon::now()->translatedFormat('d F Y, H:i:s') }}</b></div>
        <center>==================================</center>
    </div>
    <div>
        <table>
            <tr>
                <td style="width: 88px">Kode Booking</td>
                <td>:</td>
                <td>{{ $booking->kode }}</td>
            </tr>
            <tr>
                <td>Nama Konsumen</td>
                <td>:</td>
                <td>{{ $booking->user->nama }}</td>
            </tr>
            <tr>
                <td>Nomor WhatsApp</td>
                <td>:</td>
                <td>{{ $booking->user->no_tlp }}</td>
            </tr>
            <tr>
                <td>Paket Dipesan</td>
                <td>:</td>
                <td>{{ $booking->paket }}</td>
            </tr>
            <tr>
                <td>Status Booking</td>
                <td>:</td>
                <td>{{ $booking->status_booking }}</td>
            </tr>
            <tr>
                <td>Status Pembayaran</td>
                <td>:</td>
                <td>{{ $booking->status_bayar }} {{ $booking->status_bayar == 'DP' ? format_rupiah($booking->jml_dp) : '' }}</td>
            </tr>
            <tr>
                <td>Total Pembayaran</td>
                <td>:</td>
                <td>{{ format_rupiah($booking->total) }}</td>
            </tr>
            <tr>
                <td>Tanggal Booking</td>
                <td>:</td>
                <td>{{ Carbon::parse($booking->tgl_booking)->translatedFormat('d F Y') }}</td>
            </tr>
            <tr>
                <td>Jam Booking</td>
                <td>:</td>
                <td>{{ $booking->jam_booking }}</td>
            </tr>
        </table>
    </div>
    <div>
        <center>==================================</center>
        <div style="font-weight:bold; margin-left: 3px;">Notes :<br>{{ $set_umum->value_10 }}</div>
    </div>
</body>

</html>