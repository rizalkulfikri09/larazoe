<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <table>
        <thead>
            <tr>
                <td colspan="5" height="30" style="text-align: center; vertical-align: middle; font-weight: bold; font-size: 16px; text-decoration: underline">Daftar Konsumen</td>
            </tr>
            <tr>
                <th width="5" style="text-align: center; font-weight: bold; font-size: 12px;">No</th>
                <th width="30" style="text-align: center; font-weight: bold; font-size: 12px;">Nama</th>
                <th width="20" style="text-align: center; font-weight: bold; font-size: 12px;">Nomor WhatsApp</th>
                <th width="32" style="text-align: center; font-weight: bold; font-size: 12px;">Email</th>
                <th width="14" style="text-align: center; font-weight: bold; font-size: 12px;">Status</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($users as $index => $user)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $user->nama }}</td>
                <td>{{ $user->no_tlp }}</td>
                <td>{{ $user->email }}</td>
                <td style="text-align: center;">{{ $user->is_active == 1 ? 'Aktif' : 'Tidak Aktif' }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>