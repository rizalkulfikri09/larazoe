<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <table style="border: 1px solid black">
        <thead>
            <tr>
                <td colspan="9" height="30" style="text-align: center; vertical-align: middle; font-weight: bold; font-size: 16px; text-decoration: underline">Daftar Undangan Digital</td>
            </tr>
            <tr>
                <th width="5" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">No</th>
                <th width="11" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Kode Undangan</th>
                <th width="25" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Nama Konsumen</th>
                <th width="15" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Nomor WhatsApp</th>
                <th width="15" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Status Undangan</th>
                <th width="15" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Status Pembayaran</th>
                <th width="17" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Tema Undangan</th>
                <th width="19" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Masa Aktif</th>
                <th width="16" style="word-wrap: break-word; text-align: center; font-weight: bold; font-size: 12px;">Total Transaksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($data_undangan as $index => $du)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>{{ $du->kode }}</td>
                <td>{{ $du->user->nama }}</td>
                <td>{{ $du->user->no_tlp }}</td>
                <td>{{ $du->status_undangan }}</td>
                <td>{{ $du->status_bayar }}</td>
                <td>{{ $du->tema->nama_tema }}</td>
                <td>{{ Carbon::parse($du->created_at)->addDays($du->paket->durasi)->translatedFormat('d F Y') }}</td>
                <td>{{ format_rupiah($du->paket->harga) }}</td>
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr>
                <th colspan="8" style="text-align: right; font-weight: bold">TOTAL :</th>
                <th style="font-weight: bold">{{ format_rupiah($sum_total) }}</th>
            </tr>
        </tfoot>
    </table>
</body>
</html>