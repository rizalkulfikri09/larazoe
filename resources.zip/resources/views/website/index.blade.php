<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1" name="viewport">

    <title>{{ $header_website->value_1 ?? config('app.name') }}</title>
    <meta content="{{ $footer_website->value_1 }}" name="description">
    <meta content="studio foto, cetak digital, wedding, photo studio, digital printing, booking, studio, foto" name="keywords">

    <!-- Favicons -->
    <link href="{{ asset('frontend/images/favicon/'.$logo_app->value_4) }}" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700|Open+Sans:300,300i,400,400i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="{{ asset('frontend/avilon/vendor/aos/aos.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/avilon/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/avilon/vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/avilon/vendor/glightbox/css/glightbox.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/avilon/vendor/floating-wpp.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/libs/css/lightbox.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/vendor/owlcarousel/assets/owl.carousel.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/vendor/owlcarousel/assets/owl.theme.green.min.css') }}" rel="stylesheet">
    <!-- FullCalendar -->
    <link href="{{ asset('frontend/vendor/fullcalendar-3.10.0/fullcalendar.css') }}" rel='stylesheet' media="all" />
    <!-- Template Main CSS File -->
    <style>
        #hero {
            background: linear-gradient(45deg, rgba(29, 224, 153, 0.65), rgba(29, 200, 205, 0.65)), url("{{ asset('frontend/avilon/img/'.$header_website->value_6) }}") center top no-repeat;
        }
        #call-to-action {
            background: linear-gradient(rgba(29, 200, 205, 0.80), rgba(29, 205, 89, 0.30)), url("{{ asset('frontend/avilon/img/'.$bagian_tiga->value_1) }}") fixed center center;
        }
        #contact p {
            margin-bottom: 1rem;
        }
    </style>
    <link href="{{ asset('frontend/avilon/css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/avilon/css/kalender.css') }}" rel="stylesheet">
    <!-- =======================================================
    * Template Name: Avilon - v4.1.0
    * Template URL: https://bootstrapmade.com/avilon-bootstrap-landing-page-template/
    * Author: BootstrapMade.com
    * License: https://bootstrapmade.com/license/
    ======================================================== -->
</head>

<body>
    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top d-flex align-items-center header-transparent">
        <div class="container d-flex justify-content-between align-items-center">
            <div id="logo">
                <h1 style="font-weight: 700;"><a href="{{ route('/') }}">{{ $header_website->value_2 }}</a></h1>
                <!-- Uncomment below if you prefer to use an image logo -->
                <!-- <a href="index.html"><img src="assets/img/logo.png" alt=""></a> -->
            </div>
            <nav id="navbar" class="navbar" style="font-weight: 500;">
                <ul>
                    <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
                    <li><a class="nav-link scrollto" href="{{ route('login') }}">{{ $header_website->value_5 }}</a></li>
                    <li><a class="nav-link scrollto" href="#features">Paket & Produk</a></li>
                    <li><a class="nav-link scrollto" href="#more-features">Kalender Booking</a></li>
                    <li><a class="nav-link scrollto" href="#gallery">Galeri</a></li>
                    <li><a class="nav-link scrollto" href="#contact">Kontak</a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav><!-- .navbar -->
        </div>
    </header><!-- End Header -->

    <!-- ======= Hero Section ======= -->
    <section id="hero">
        <div class="hero-text">
            <h2 style="padding-top: 300px; font-weight: 500;">{{ $header_website->value_3 }}</h2>
            <p style="font-size: 25px; letter-spacing: 2px; font-weight: 600; font-style: italic;">"{{ $header_website->value_4 }}"</p>
            <a href="{{ route('login') }}" class="btn-get-started scrollto">{{ $header_website->value_5 }}</a>
        </div>
    </section>
    <!-- End Hero Section -->

    <!-- ======= Main Section ======= -->
    <main id="main">
        <!-- ======= About Section ======= -->
        <section id="about" class="section-bg">
            <div class="container-fluid" data-aos="fade-up" data-aos-duration="500">
                <div class="section-header">
                    <h3 class="section-title">{{ $bagian_satu->value_1 }}</h3>
                    <span class="section-divider"></span>
                </div>
                <div class="row">
                    <div class="col-lg-6 about-img" data-aos="fade-right" dat-aos-delay="100">
                        <img src="{{ asset('frontend/avilon/img/'.$bagian_satu->value_2) }}" alt="">
                    </div>
                    <div class="col-lg-6 content" data-aos="fade-left" dat-aos-delay="100">
                        {!! $bagian_satu->items !!}
                    </div>
                </div>
            </div>
        </section>
        <!-- End About Section -->

        <!-- ======= Featuress Section ======= -->
        <section id="features">
            <div class="container" data-aos="fade-up" data-aos-duration="500">
                <div class="row">
                    <div class="col-lg-8 offset-lg-4">
                        <div class="section-header">
                            <h3 class="section-title">{{ $bagian_dua->value_1 }}</h3>
                            <span class="section-divider"></span>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-5 features-img">
                        <img src="{{ asset('frontend/avilon/img/'.$bagian_dua->value_2) }}" alt="{{ $bagian_dua->value_2 }}" data-aos="fade-right">
                    </div>
                    <div class="col-lg-8 col-md-7">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 box" data-aos="fade-up" dat-aos-delay="100">
                                <div class="icon"><i class="bi bi-camera-fill"></i></div>
                                <h4 class="title">{{ $bagian_dua->value_3 }}</h4>
                                <p class="description">{{ $bagian_dua->value_7 }}</p>
                            </div>
                            <div class="col-lg-6 col-md-6 box" data-aos="fade-up" dat-aos-delay="100">
                                <div class="icon"><i class="bi bi-images"></i></div>
                                <h4 class="title">{{ $bagian_dua->value_4 }}</h4>
                                <p class="description">{{ $bagian_dua->value_8 }}</p>
                            </div>
                            <div class="col-lg-6 col-md-6 box" data-aos="fade-up" dat-aos-delay="100">
                                <div class="icon"><i class="bi bi-file-image"></i></div>
                                <h4 class="title">{{ $bagian_dua->value_5 }}</h4>
                                <p class="description">{{ $bagian_dua->value_9 }}</p>
                            </div>
                            <div class="col-lg-6 col-md-6 box" data-aos="fade-up" data-aos-delay="100">
                                <div class="icon"><i class="bi bi-heart-fill"></i></div>
                                <h4 class="title">{{ $bagian_dua->value_6 }}</h4>
                                <p class="description">{{ $bagian_dua->value_10 }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- End Featuress Section -->

        <!-- ======= Pricing Section ======= -->
        <section id="pricing" class="section-bg">
            <div class="container" data-aos="fade-up" data-aos-duration="500">
                <div class="section-header">
                    <h3 class="section-title">Paket Studio Foto</h3>
                    <span class="section-divider"></span>
                </div>
                <div class="row">
                    @foreach ($daftar_paket as $dp)
                        <div class="col-lg-3 col-sm-3">
                            <div class="box" style="padding: 16px;">
                                <h4>
                                    <a href="{{ asset('frontend/images/paket/'. $dp->thumbnail) }}" data-lightbox="paket">
                                        <img data-src="{{ asset('frontend/images/paket/'. $dp->thumbnail) }}" alt="{{ $dp->nama_paket }}" class="img-fluid lazyload">
                                    </a>
                                </h4>
                                <a href="{{ route('pilih_paket', $dp->id) }}" class="get-started-btn booking">Booking Sekarang</a>
                            </div>
                        </div>
                    @endforeach
                    @foreach ($paket_selfphoto as $ps)
                        <div class="col-lg-3 col-sm-3">
                            <div class="box" style="padding: 16px;">
                                <h4>
                                    <a href="{{ asset('frontend/images/paket/'. $ps->thumbnail) }}" data-lightbox="paket">
                                        <img data-src="{{ asset('frontend/images/paket/'. $ps->thumbnail) }}" alt="{{ $ps->nama_paket }}" class="img-fluid lazyload">
                                    </a>
                                </h4>
                                <a href="{{ route('paket_self', $ps->id) }}" class="get-started-btn booking">Booking Sekarang</a>
                            </div>
                        </div>
                    @endforeach
                </div>
                <div class="section-header">
                    <h3 class="section-title">Tema Undangan Digital</h3>
                    <span class="section-divider"></span>
                </div>
                <div class="row">
                    @foreach ($tema_undangan as $tu)
                        <div class="col-lg-3 col-sm-3">
                            <div class="box" style="padding: 16px;">
                                <h4>
                                    <a href="{{ asset('frontend/images/paket/'. $tu->thumbnail) }}" data-lightbox="paket">
                                        <img data-src="{{ asset('frontend/images/paket/'. $tu->thumbnail) }}" alt="{{ $tu->nama_paket }}" class="img-fluid lazyload">
                                    </a>
                                </h4>
                                <a href="{{ route('pilih_tema') }}" class="get-started-btn booking">Buat Undangan</a>
                            </div>
                        </div>
                    @endforeach
                    <div class="col-lg-3 col-sm-3">
                        <div class="box" style="padding: 16px;">
                            <h4>
                                <a href="{{ asset('frontend/images/paket/coming_soon.jpg') }}" data-lightbox="paket">
                                    <img data-src="{{ asset('frontend/images/paket/coming_soon.jpg') }}" alt="coming_soon.jpg" class="img-fluid lazyload">
                                </a>
                            </h4>
                        </div>
                    </div>
                </div>
        </section>
        <!-- End Pricing Section -->

        <!-- ======= Call To Action Section ======= -->
        <section id="call-to-action">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 text-center text-lg-start">
                        <h3 class="cta-title">{{ $logo_app->value_2 }}</h3>
                        <p class="cta-text" style="font-size: 18px;">{{ $bagian_tiga->value_2 }}</p>
                    </div>
                    <div class="col-lg-3 cta-btn-container text-center">
                        <a class="cta-btn align-middle" href="{{ route('registrasi') }}">Buat Akun</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Call To Action Section -->

        <!-- ======= More Features Section ======= -->
        <section id="more-features" class="section-bg">
            <div class="container" data-aos="fade-up">
                <div class="section-header">
                    <h3 class="section-title">Kalender Booking Studio Foto</h3>
                    <span class="section-divider"></span>
                </div>
                <div class="row">
                    <div class="kotak">
                        <div class="kalender scrollmenu">
                            <div id="calendar1" class="calendar"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End More Features Section -->

        <!-- ======= Clients Section ======= -->
        <section id="clients">
            <div class="container" data-aos="fade-up">
                <div class="row justify-content-center owl-carousel">
                    <div class="col-md-2 logo-client">
                        <img src="{{ asset('frontend/avilon/img/clients/'.$logo_slider->value_1) }}" alt="{{ $logo_slider->value_1 }}">
                    </div>
                    <div class="col-md-2 logo-client">
                        <img src="{{ asset('frontend/avilon/img/clients/'.$logo_slider->value_2) }}" alt="{{ $logo_slider->value_2 }}">
                    </div>
                    <div class="col-md-2 logo-client">
                        <img src="{{ asset('frontend/avilon/img/clients/'.$logo_slider->value_3) }}" alt="{{ $logo_slider->value_3 }}">
                    </div>
                    <div class="col-md-2 logo-client">
                        <img src="{{ asset('frontend/avilon/img/clients/'.$logo_slider->value_4) }}" alt="{{ $logo_slider->value_4 }}">
                    </div>
                    <div class="col-md-2 logo-client">
                        <img src="{{ asset('frontend/avilon/img/clients/'.$logo_slider->value_5) }}" alt="{{ $logo_slider->value_5 }}">
                    </div>
                    <div class="col-md-2 logo-client">
                        <img src="{{ asset('frontend/avilon/img/clients/'.$logo_slider->value_6) }}" alt="{{ $logo_slider->value_6 }}">
                    </div>
                </div>
            </div>
        </section>
        <!-- End Clients Section -->

        <!-- ======= Pricing Section ======= -->
        <section id="pricing" class="section-bg">
            <div class="container" data-aos="fade-up">
                <div class="section-header">
                    <h3 class="section-title">Testimoni Konsumen</h3>
                    <span class="section-divider"></span>
                </div>
                <div class="row">
                    @foreach ($testimoni_konsumen as $tk)
                    <div class="col-lg-4 col-md-6">
                        <div class="box">
                            <div style="margin-bottom: 5px;">"{{ $tk->testimoni }}"</div>
                            <ul><li style="text-align: center;">{!! rating($tk->rating) !!} <b>{{ $tk->nama }}</b></li></ul>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </section>
        <!-- End Pricing Section -->

        <!-- ======= Pertanyaan Yang Sering Diajukan Section ======= -->
        <section id="faq">
            <div class="container">
                <div class="section-header">
                    <h3 class="section-title">Pertanyaan Yang Sering Diajukan</h3>
                    <span class="section-divider"></span>
                </div>
                <ul class="faq-list">
                    <li>
                    <div data-bs-toggle="collapse" class="collapsed question" href="#faq1">{{ $pertanyaan->value_1 }}<i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                    <div id="faq1" class="collapse" data-bs-parent=".faq-list">
                        <p>{{ $pertanyaan->value_2 }}</p>
                    </div>
                    </li>
                    <li>
                    <div data-bs-toggle="collapse" href="#faq2" class="collapsed question">{{ $pertanyaan->value_3 }}<i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                    <div id="faq2" class="collapse" data-bs-parent=".faq-list">
                        <p>{{ $pertanyaan->value_4 }}</p>
                    </div>
                    </li>
                    <li>
                    <div data-bs-toggle="collapse" href="#faq3" class="collapsed question">{{ $pertanyaan->value_5 }}<i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                    <div id="faq3" class="collapse" data-bs-parent=".faq-list">
                        <p>{{ $pertanyaan->value_6 }}</p>
                    </div>
                    </li>
                    <li>
                    <div data-bs-toggle="collapse" href="#faq4" class="collapsed question">{{ $pertanyaan->value_7 }}<i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                    <div id="faq4" class="collapse" data-bs-parent=".faq-list">
                        <p>{{ $pertanyaan->value_8 }}</p>
                    </div>
                    </li>
                    <li>
                    <div data-bs-toggle="collapse" href="#faq5" class="collapsed question">{{ $pertanyaan->value_9 }}<i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                    <div id="faq5" class="collapse" data-bs-parent=".faq-list">
                        <p>{{ $pertanyaan->value_10 }}</p>
                    </div>
                    </li>
                </ul>
            </div>
        </section>
        <!-- Pertanyaan Yang Sering Diajukan Section -->

        <!-- ======= Youtube Section ======= -->
        @if ($bagian_tiga->value_3 == '1')
        <section id="team" class="section-bg">
            <div class="container" data-aos="fade-up">
                <div class="row">
                    <div style="text-align: center;">
                        <div class="video-galeri">
                            <div>{!! $bagian_tiga->items !!}</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        @endif
        <!-- End Youtube Section -->

        <!-- ======= Gallery Section ======= -->
        <section id="gallery">
            <div class="container-fluid" data-aos="fade-up">
                <div class="section-header">
                    <h3 class="section-title">Galeri Studio Foto</h3>
                    <span class="section-divider"></span>
                </div>
                <div class="row no-gutters">
                    <div class="col-lg-4 col-md-6">
                        <div class="gallery-item">
                            <a href="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_1) }}" data-gall="portfolioGallery" class="gallery-lightbox">
                            <img src="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_1) }}" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="gallery-item">
                            <a href="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_2) }}" data-gall="portfolioGallery" class="gallery-lightbox">
                            <img src="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_2) }}" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="gallery-item">
                            <a href="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_3) }}" data-gall="portfolioGallery" class="gallery-lightbox">
                            <img src="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_3) }}" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="gallery-item">
                            <a href="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_4) }}" data-gall="portfolioGallery" class="gallery-lightbox">
                            <img src="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_4) }}" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="gallery-item">
                            <a href="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_5) }}" data-gall="portfolioGallery" class="gallery-lightbox">
                            <img src="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_5) }}" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="gallery-item">
                            <a href="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_6) }}" data-gall="portfolioGallery" class="gallery-lightbox">
                            <img src="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_6) }}" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="gallery-item">
                            <a href="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_7) }}" data-gall="portfolioGallery" class="gallery-lightbox">
                            <img src="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_7) }}" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="gallery-item">
                            <a href="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_8) }}" data-gall="portfolioGallery" class="gallery-lightbox">
                            <img src="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_8) }}" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="gallery-item">
                            <a href="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_9) }}" data-gall="portfolioGallery" class="gallery-lightbox">
                            <img src="{{ asset('frontend/avilon/img/gallery/'.$set_portofolio->value_9) }}" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Gallery Section -->

        <!-- ======= Contact Section ======= -->
        <section id="contact">
            <div class="container" data-aos="fade-up">
                <div class="row">
                    <div class="col-lg-4 col-md-4">
                        <div class="contact-about">
                            <h3>{{ $header_website->value_2 }}</h3>
                            <p>{{ $footer_website->value_1 }}</p>
                            <div class="social-links">
                            <a href="{{ $footer_website->value_2 }}" class="instagram"><i class="bi bi-instagram"></i></a>
                            <a href="{{ $footer_website->value_3 }}" class="facebook"><i class="bi bi-facebook"></i></a>
                            <a href="{{ $footer_website->value_4 }}" class="youtube"><i class="bi bi-youtube"></i></a>
                            <a href="{{ $footer_website->value_5 }}" target="_blank" class="whatsapp"><i class="bi bi-whatsapp"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <div class="info">
                            <div>
                            <i class="bi bi-geo-alt"></i>
                            <p>{{ $footer_website->value_6 }}</p>
                            </div>
                            <div>
                            <i class="bi bi-envelope"></i>
                            <p>{{ $footer_website->value_7 }}</p>
                            </div>
                            <div>
                            <i class="bi bi-phone"></i>
                            <p>{{ $footer_website->value_8 }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-8 peta">
                        {!! $footer_website->items !!}
                    </div>
                </div>
            </div>
        </section>
        <!-- End Contact Section -->

        <div id="tombol_wa"></div>
    </main>
    <!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 text-lg-start text-center">
                    <div class="copyright">
                        {{ $logo_app->value_3 }}. All Rights Reserved
                    </div>
                    <div class="credits">
                    <!--
                    All the links in the footer should remain intact.
                    You can delete the links only if you purchased the pro version.
                    Licensing information: https://bootstrapmade.com/license/
                    Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Avilon
                    -->
                    Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="footer-links text-lg-right text-center pt-2 pt-lg-0">
                    <a href="#about" class="scrollto">About</a>
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Use</a>
                    <a href="https://www.instagram.com/larazoe.app">Larazoe</a>
                    </nav>
                </div>
            </div>
        </div>
    </footer>
    <!-- End  Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-chevron-up"></i></a>

    <!-- Vendor JS Files -->
    <script src="{{ asset('frontend/avilon/vendor/aos/aos.js') }}"></script>
    <script src="{{ asset('frontend/avilon/vendor/bootstrap/js/bootstrap.bundle.js') }}"></script>
    <script src="{{ asset('frontend/avilon/vendor/glightbox/js/glightbox.min.js') }}"></script>
    <!-- jquery 3.3.1 -->
    <script src="{{ asset('frontend/vendor/jquery/jquery-3.3.1.min.js') }}"></script>
    <script src="{{ asset('frontend/vendor/owlcarousel/owl.carousel.min.js') }}"></script>
    <script src="{{ asset('frontend/avilon/vendor/floating-wpp.min.js') }}"></script>
    <script src="{{ asset('frontend/libs/js/lightbox.js') }}"></script>
    <script src="{{ asset('frontend/libs/js/lazysizes.min.js') }}"></script>
    <!-- full calendar requires moment along jquery which is included above -->
    <script src="{{ asset('frontend/vendor/fullcalendar-3.10.0/lib/moment.min.js') }}"></script>
    <script src="{{ asset('frontend/vendor/fullcalendar-3.10.0/fullcalendar.js') }}"></script>
    <script src="{{ asset('frontend/vendor/fullcalendar-3.10.0/locale/id.js') }}"></script>
    <!-- Template Main JS File -->
    <script src="{{ asset('frontend/avilon/js/main.js') }}"></script>
    <script type="text/javascript">
    $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            dots:false,
            loop:true,
            autoWidth:true,
            items:4,
            autoplay:true,
            autoplayTimeout:1000,
            autoplayHoverPause:true
        });
    });

    $(function() {
        $('#tombol_wa').floatingWhatsApp({
            phone: "{{ $bagian_tiga->value_4 }}",
            popupMessage: "{{ $bagian_tiga->value_5 }}",
            message: "{{ $bagian_tiga->value_6 }}",
            showPopup: true,
            showOnIE: false,
            headerTitle: '<b>Customer Service</b>',
            headerColor: '#25D366',
            backgroundColor: '#25D366',
            buttonImage: '<img src="{{ asset('frontend/avilon/vendor/whatsapp.svg') }}" />'
        });
    });

    lightbox.option({
        "showImageNumberLabel" : false,
        'disableScrolling': true,
        "wrapAround" : true
    });

    $(function() {
        let events = [
            @php foreach ($kalender as $kl) : @endphp
            {
                title: "{{ $kl->jam_booking }} \n {{ $kl->status_booking }} ({{ $kl->nama }}) ",
                start: moment().format("{{ $kl->tgl_booking }}"),
                color: "{{ color_status($kl->status_booking) }}",
            },
            @php endforeach @endphp
        ];
        let trivia_nights = []

        $('#calendar1').fullCalendar({
        lang: 'id',
        header: {
            eventBackgroundColor: '#ff0000',
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay,listWeek'
        },
        eventLimit: true,
        eventLimitText: "More",
        events: events.concat(trivia_nights),
        selectable: true,
        });
    });
    </script>
</body>

</html>