@extends('layouts.app_template')
@section('body')
<link rel="stylesheet" href="{{ asset('frontend/libs/css/rating.css') }}">
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form action="" method="post">
                        @csrf
                        <div class="form-group" style="margin-bottom: 0px;">
                            <label>Rating</label><br>
                            <fieldset class="rating">
                                <input type="radio" id="star5" name="rating" value="5" /><label for="star5" title="Sangat Puas - 5 stars"></label>
                                <input type="radio" id="star4" name="rating" value="4" /><label for="star4" title="Puas - 4 stars"></label>
                                <input type="radio" id="star3" name="rating" value="3" /><label for="star3" title="Cukup Puas - 3 stars"></label>
                                <input type="radio" id="star2" name="rating" value="2" /><label for="star2" title="Tidak Puas - 2 stars"></label>
                                <input type="radio" id="star1" name="rating" value="1" /><label for="star1" title="Sangat Tidak Puas - 1 star"></label>
                            </fieldset>
                        </div>
                        <div class="form-group">
                            <label>Testimoni</label>
                            <textarea type="text" id="testimoni" name="testimoni" required="" autocomplete="off" class="form-control" placeholder="Tulis testimoni anda terkait pelayanan studio foto" style="padding: 10px 10px;" maxlength="500"></textarea>
                        </div>
                        <div class="form-group">
                            <span>Rating & testimoni hanya dapat diisi satu kali.</span>
                        </div>
                        <div class="form-group" style="margin-bottom: 0px;">
                            <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                            @include('components.button_kembali', ['url' => route('hasil_booking', $kode_booking)])
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection