@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <h5 class="card-header">Cek kembali pesanan anda, jika sudah benar silahkan klik tombol Simpan.</h5>
                <div class="card-body">
                    <form action="{{ route('create_studio') }}" method="post" autocomplete="off" id="form_booking">
                        @csrf
                        <div class="form-group" style="font-size: 16px;">
                            <div class="row">
                                <div class="col-5">Tanggal Booking</div>
                                <div class="col-7"><b>{{ $tgl_booking }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-5">Jam Booking</div>
                                <div class="col-7"><b>{{ $jam_booking }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-5">Nama Konsumen</div>
                                <div class="col-7"><b>{{ $nama }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-5">Nomor WhatsApp</div>
                                <div class="col-7"><b>{{ $no_tlp }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-5">Paket yang dipilih</div>
                                <div class="col-7"><b>{{ $paket . " - " . $sub_paket }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-5">Total Pembayaran</div>
                                <div class="col-7"><b style="color: #D90429">{{ $total }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-5">Jumlah Orang</div>
                                <div class="col-7"><b>{{ $jml_orang }} Orang</b></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 m-t-10">
                                <button type="submit" class="btn btn-space btn-primary" id="tombol_simpan">Simpan</button>
                                @include('components.button_kembali', ['url' => route('pilih_bayar')])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#form_booking').submit(function () {
        $('.btn-space').prop('disabled', true);
    });
</script>
<script src="{{ asset('frontend/libs/js/loadingSimpan.js') }}"></script>
@endsection