@extends('layouts.app_template')
@section('body')
<!-- FullCalendar -->
<link href="{{ asset('frontend/vendor/fullcalendar-3.10.0/fullcalendar.css') }}" rel='stylesheet' media="all" />
<style>
    .fc-more-popover {
        max-height: 60%;
        overflow-y: auto;
    }
    .fc-event, .fc-event:hover {
        color: #fff !important;
        text-decoration: none;
    }
    .kalender {
        padding: 20px;
    }

    @media only screen and (max-width: 600px)
    {
        .fc-more-popover {
            max-height: 80%;
            overflow-y: auto;
        }
        #calendar1
        {
            width: 400px;
            height: 400px;
            margin: 0 auto;
            font-size: 10px;
        }
        .kalender {
            padding: 6px;
        }
        .fc-more {
            font-weight: bold;
        }
        .fc-center {
            margin-top: 20px;
        }
        div.scrollmenu {
            overflow: auto;
            white-space: nowrap;
        }
    }
</style>
<div class="row">
    <div class="card">
        <div class="kalender scrollmenu">
            <div id="calendar1" class="calendar"></div>
        </div>
    </div>
</div>
<!-- full calendar requires moment along jquery which is included above -->
<script src="{{ asset('frontend/vendor/fullcalendar-3.10.0/lib/moment.min.js') }}"></script>
<script src="{{ asset('frontend/vendor/fullcalendar-3.10.0/fullcalendar.js') }}"></script>
<script src="{{ asset('frontend/vendor/fullcalendar-3.10.0/locale/id.js') }}"></script>
<script type="text/javascript">
    $(function() {
    let events = [
        @php foreach ($kalender as $kl) : @endphp
        {
            title: "{{ $kl->jam_booking }} \n {{ $kl->status_booking }} ({{ $kl->nama }}) ",
            start: moment().format("{{ $kl->tgl_booking }}"),
            color: "{{ color_status($kl->status_booking) }}",
        },
        @php endforeach @endphp
    ];
    let trivia_nights = []

    $('#calendar1').fullCalendar({
    lang: 'id',
    header: {
        eventBackgroundColor: '#ff0000',
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay,listWeek'
    },
    eventLimit: true,
    eventLimitText: "More",
    events: events.concat(trivia_nights),
    selectable: true,
    });
});
</script>
@endsection