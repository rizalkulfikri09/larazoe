@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('pilih_paket', $paket->id) }}" method="post" autocomplete="off">
                        @csrf
                        <div class="form-group">
                            <label>Pilih Paket</label>
                            <select class="form-control selectpicker @error('sub_paket') is-invalid @enderror" name="sub_paket" id="sub_paket">
                                <option value="" selected disabled hidden>--- Pilih Paket ---</option>
                                @foreach ($sub_paket as $sp)
                                    <option value="{{ $sp->id }}" data-harga="{{ format_rupiah($sp->harga) }}" data-min="{{ $sp->min_org }}" data-max="{{ $sp->max_org }}" @selected(old('sub_paket') == $sp->id)>{{ $sp->sub_paket }}</option>
                                @endforeach
                            </select>
                            @error('sub_paket')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Harga</label>
                            <input type="text" id="harga" name="harga" value="{{ old('harga') }}" required="" class="form-control @error('harga') is-invalid @enderror" readonly>
                            @error('harga')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group row">
                            <div class="col-xl-12 col-12">
                                <label>Jumlah Orang</label>
                            </div>
                            <div class="col-xl-5 col-6">
                                <input type="number" id="jml_orang" name="jml_orang" min="" max="" value="{{ old('jml_orang', 1) }}" required  class="form-control @error('jml_orang') is-invalid @enderror">
                                @error('jml_orang')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 m-t-10">
                                <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                                @include('components.button_kembali', ['url' => route('booking_studio')])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @if ($paket->deskripsi != 'Tidak ada')
                <div class="alert alert-success" role="alert">
                    <p style="margin-bottom: 0px!important;"><b style="font-size: 14px;">Keterangan Paket {{ $paket->nama_paket }} :</b></p>
                    {!! $paket->deskripsi !!}
                </div>
            @endif
        </div>
    </div>
</div>

<script src="{{ asset('frontend/libs/js/bootstrap-input-spinner.js') }}"></script>
<script type="text/javascript">
    $("input[type='number']").inputSpinner();
    $(document).ready(function(){
        $("#sub_paket").change(function(){
            var sub_paket =  $(this).find(':selected').data('harga');
            var min_org = $(this).find(':selected').data('min');
            var max_org = $(this).find(':selected').data('max');
            $("#harga").val(sub_paket);
            $("#jml_orang").attr({
                "min": min_org,
                "max": max_org
            }).val(min_org);
        });
    });
</script>
@endsection