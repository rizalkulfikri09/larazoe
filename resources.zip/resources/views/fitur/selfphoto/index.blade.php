@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="alert alert-success" role="alert">
                <a href="{{ route('riwayat_selfphoto') }}" class="btn btn-rounded btn-success btn-sm">Riwayat Booking Self Photo</a>
            </div>
        </div>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="row">
                @foreach ($daftar_paket as $dp)
                <div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 col-12">
                    <div class="product-thumbnail">
                        <div class="product-img-head">
                            <div class="product-img">
                                <a href="{{ asset('frontend/images/paket/' . $dp->thumbnail) }}" data-lightbox="paket">
                                    <img data-src="{{ asset('frontend/images/paket/' . $dp->thumbnail) }}" alt="{{ $dp->thumbnail }}" class="img-fluid lazyload">
                                </a>
                            </div>
                        </div>
                        <div class="product-content">
                            <div class="product-content-head">
                                <h3 class="product-title" style="font-size: 18px; font-weight: bold;">{{ $dp->nama_paket }}</h3>
                            </div>
                            <form action="{{ route('self_photo') }}" method="post">
                                @csrf
                                <input type="hidden" id="id" name="id" value="{{ $dp->id }}" required="" autocomplete="off">
                                <button type="submit" class="btn btn-block btn-primary">Pilih Paket</button>
                            </form>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection