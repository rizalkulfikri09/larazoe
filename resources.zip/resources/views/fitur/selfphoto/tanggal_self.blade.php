@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <h5 class="card-header">Pilih tanggal booking self photo</h5>
                <div class="card-body">
                    <form action="{{ route('tanggal_self') }}" method="post" autocomplete="off">
                        @csrf
                        <div class="form-group">
                            <input type="hidden" inputmode="none" onkeydown="return false" name="tgl_booking" id="tgl_booking">
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 mt-1">
                                <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                                @include('components.button_kembali', ['url' => route('paket_self', session()->get('id_paket'))])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        @include('components.card_total', ['total_pembayaran' => $total_pembayaran])
    </div>
</div>

<script type="text/javascript">
    $(function() {
        var libur = [ @foreach ($tgl_libur as $tgl) "{{ $tgl }}", @endforeach ];
        $('#tgl_booking').datetimepicker({
            inline: true,
            maxDate: moment().add({{ $max_date }},'weeks').toDate(),
            minDate: new Date(moment().add(1,'days')).setHours(0,0,0,0),
            daysOfWeekDisabled: [7, 7],
            format: 'YYYY-MM-DD',
            disabledDates: libur,
        });
    });
</script>
@endsection