@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('paket_self', $paket->id) }}" method="post" autocomplete="off">
                        @csrf
                        @if ($add_ons->isNotEmpty())
                        <div class="form-group">
                            <label>Add Ons</label>
                            @foreach ($add_ons as $add_on)
                                <label class="custom-control custom-checkbox">
                                    <input type="checkbox" name="add_ons[]" value="{{ $add_on->id }}" data-harga="{{ $add_on->harga }}" class="custom-control-input"><span class="custom-control-label">{{ $add_on->nama_addon }}</span>
                                </label>
                            @endforeach
                        </div>
                        @else
                        <div class="form-group">
                            Tidak ada add ons
                        </div>
                        @endif
                        <div class="form-group">
                            <label>Total Pembayaran</label>
                            <input type="text" id="total" name="total" value="{{ old('total', format_rupiah($harga_paket)) }}" required="" class="form-control @error('total') is-invalid @enderror" readonly>
                            @error('total')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-group row">
                            <div class="col-xl-12 col-12">
                                <label>Jumlah Orang</label>
                            </div>
                            <div class="col-xl-5 col-6">
                                <input type="number" id="jml_orang" name="jml_orang" min="{{ $min_org }}" max="{{ $max_org }}" value="{{ old('jml_orang', 1) }}" required  class="form-control @error('jml_orang') is-invalid @enderror">
                                @error('jml_orang')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 m-t-10">
                                <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                                @include('components.button_kembali', ['url' => route('self_photo')])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @if ($paket->deskripsi != 'Tidak ada')
                <div class="alert alert-success" role="alert">
                    <p style="margin-bottom: 0px!important;"><b style="font-size: 14px;">Keterangan Paket {{ $paket->nama_paket }} :</b></p>
                    {!! $paket->deskripsi !!}
                </div>
            @endif
        </div>
    </div>
</div>

<script src="{{ asset('frontend/libs/js/bootstrap-input-spinner.js') }}"></script>
<script type="text/javascript">
    $("input[type='number']").inputSpinner();
    $(document).ready(function(){
        $('input[type=checkbox]').on('change', function() {
            var harga = parseFloat({{ $harga_paket }});
            $('input[type=checkbox]:checked').each(function() {
                harga += parseFloat($(this).data('harga'));
            });
            var harga_rupiah = harga.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            $('#total').val("Rp " + harga_rupiah);
        });
    });
</script>
@endsection