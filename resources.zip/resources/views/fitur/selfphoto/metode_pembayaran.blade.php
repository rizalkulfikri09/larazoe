@extends('layouts.app_template')
@section('body')
<style>
    .payment {
        background-color: #f5f5f5;
    }
    .payment img {
        width: 90px;
        height: 35px;
    }
    .active {
        border: 2px solid #2C7CE4;
    }
</style>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <h5 class="card-header">Pilih salah satu metode pembayaran</h5>
                <div class="card-body p-0">
                    <form action="{{ route('pembayaran_self') }}" method="post">
                        @csrf
                        <div class="accrodion-regular">
                            <div id="accordion3">
                                <div class="card">
                                    @if ($status_tripay == 1 && !empty($daftar_pembayaran))
                                    <div class="card-header py-1" id="bayar_otomatis">
                                        <h5 class="mb-0">
                                            <div class="btn btn-link" data-toggle="collapse" data-target="#bayarotomatis" aria-expanded="true" aria-controls="bayar_otomatis">
                                                <span class="fas fa-angle-down mr-3"></span>Virtual Account / Gerai / E-Wallet
                                            </div>
                                        </h5>
                                    </div>
                                    <div id="bayarotomatis" class="collapse show" aria-labelledby="bayar_otomatis" data-parent="#accordion3">
                                        <div class="card-body pb-0 pt-3">
                                            <div class="row">
                                                @foreach ($daftar_pembayaran as $dp)
                                                    <div class="col col-xl-4 col-lg-4 col-md-4 col-sm-2">
                                                        <label>
                                                            <div class="card p-2 mb-2 card-box payment">
                                                                <label class="custom-control custom-radio"><input type="radio" name="pembayaran" value="{{ $dp->code }}" class="custom-control-input" />
                                                                    <img src="{{ $dp->icon_url }}" alt="logo_bank">
                                                                    <span class="custom-control-label"></span></label>
                                                            </div>
                                                        </label>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                    @elseif ($status_xendit == 1)
                                    <div class="card-header py-1" id="bayar_otomatis">
                                        <h5 class="mb-0">
                                            <div class="btn btn-link" data-toggle="collapse" data-target="#bayarotomatis" aria-expanded="true" aria-controls="bayar_otomatis">
                                                <span class="fas fa-angle-down mr-3"></span>Virtual Account / Gerai / E-Wallet
                                            </div>
                                        </h5>
                                    </div>
                                    <div id="bayarotomatis" class="collapse show" aria-labelledby="bayar_otomatis" data-parent="#accordion3">
                                        <div class="card-body pb-2">
                                            <div class="row">
                                                <div class="col col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                                    <label>
                                                        <div class="card p-2 mb-2 card-box">
                                                            <label class="custom-control custom-radio"><input type="radio" name="pembayaran" value="bayar_otomatis" class="custom-control-input" />
                                                                <img src="{{ asset('frontend/images/logo_bank/logo_bank.jpg') }}" alt="logo_bank" width="200" height="80">
                                                                <span class="custom-control-label"></span></label>
                                                        </div>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    @if ($bank_1->value_5 == 1)
                                    <div class="card-header py-1" id="bayar_manual" style="border-top: 1px solid #e6e6f2;">
                                        <h5 class="mb-0">
                                            <div class="btn btn-link" data-toggle="collapse" data-target="#bayarmanual" aria-expanded="true" aria-controls="bayar_manual">
                                                <span class="fas fa-angle-down mr-3"></span>Upload bukti transfer (bisa DP / Lunas)
                                            </div>
                                        </h5>
                                    </div>
                                    <div id="bayarmanual" class="collapse @if(empty($status_tripay) && empty($status_xendit)) show @endif" aria-labelledby="bayar_manual" data-parent="#accordion3">
                                        <div class="card-body pb-2">
                                            <div class="row">
                                                <div class="col col-xl-6 col-lg-6 col-md-6 col-sm-2">
                                                    <label>
                                                        <div class="card p-2 mb-2 card-box payment">
                                                            <label class="custom-control custom-radio"><input type="radio" name="pembayaran" value="bayar_manual" class="custom-control-input" />
                                                                <img src="{{ asset('frontend/images/logo_bank/' . $bank_1->value_1) }}" style="padding-right: 5px;">
                                                                <img src="{{ asset('frontend/images/logo_bank/' . $bank_2->value_1) }}">
                                                            <span class="custom-control-label"></span></label>
                                                        </div>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row m-2 mt-3">
                            <div class="col-sm-6">
                                <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                                @include('components.button_kembali', ['url' => route('jam_self')])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        @include('components.card_total', ['total_pembayaran' => $total_pembayaran])
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            <div class="alert alert-warning" role="alert">
                1. Pembayaran melalui virtual account & e-wallet diproses secara otomatis. Hanya bisa pembayaran lunas tidak bisa DP.<br>
                2. Pembayaran manual adalah konsumen melakukan upload bukti transfer dan akan dicek oleh admin.
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $('.card-box').click(function() {
            $('.card-box.active').removeClass("active");
            $(this).addClass("active");
            $(this).find('input[type="radio"]').prop('checked', true);
        });
    });
</script>
@endsection
