@extends('layouts.app_template')
@section('body')
<style>
    .form-group {
        font-size: 16px!important;
        margin-bottom: 0px;
    }
    .col_waktu {
        padding: 4px;
    }
    .card_mb {
        margin-bottom: 0px;
    }
    .text_waktu {
        margin: 15px 0px 15px 0px;
        font-size: 16px;
    }
</style>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    @if (new DateTime($waktu_expired) > new DateTime("Now") && $booking->status_bayar == "Belum Dibayar")
                    <div class="alert alert-success" role="alert">
                        <div class="row mb-2">
                            <div class="col-12 text-center" style="padding: 0px;">
                                <span style="font-weight: bold;">MOHON SEGERA MELAKUKAN PEMBAYARAN DALAM WAKTU</span>
                            </div>
                        </div>
                        <div class="row d-flex justify-content-center mb-2">
                            <div class="col-xl-2 col-4 col_waktu">
                                <div class="card card_mb">
                                    <div class="card-content text-center"><h5 id="jam" class="text_waktu"></h5></div>
                                </div>
                            </div>
                            <div class="col-xl-2 col-4 col_waktu">
                                <div class="card card_mb">
                                    <div class="card-content text-center"><h5 id="menit" class="text_waktu"></h5></div>
                                </div>
                            </div>
                            <div class="col-xl-2 col-4 col_waktu">
                                <div class="card card_mb">
                                    <div class="card-content text-center"><h5 id="detik" class="text_waktu"></h5></div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-12 text-center" style="padding: 0px;">
                                <span style="font-style: italic;">(Sebelum {{ Carbon::parse($waktu_expired)->translatedFormat('l d F Y') }} pukul {{ Carbon::parse($waktu_expired)->translatedFormat('H:i') }})</span>
                            </div>
                        </div>
                    </div>
                    @endif
                    <div class="form-group">
                        <div class="row">
                            <div class="col-lg-4 col-6">Kode Booking</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->kode }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Nama Konsumen</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->user->nama }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Nomor WhatsApp</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->user->no_tlp }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Paket Yang Dipesan</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->paket }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Status Booking</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->status_booking }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Status Pembayaran</div>
                            <div class="col-lg-8 col-6"><b id="status_pembayaran">{{ $booking->status_bayar }} {{ $booking->status_bayar == 'DP' ? format_rupiah($booking->jml_dp) : '' }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Total Pembayaran</div>
                            <div class="col-lg-8 col-6"><b>{{ format_rupiah($booking->total) }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Jumlah Orang</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->jml_orang }} Orang</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Tanggal Booking</div>
                            <div class="col-lg-8 col-6"><b>{{ Carbon::parse($booking->tgl_booking)->translatedFormat('d F Y') }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col-lg-4 col-6">Jam Booking</div>
                            <div class="col-lg-8 col-6"><b>{{ $booking->jam_booking }}</b></div>
                        </div>
                        <div class="row" style="margin-top: 12px;">
                            <div class="col m-t-10">
                                <a href="{{ route('cetak_selfphoto', $booking->kode) }}" class="btn btn-space btn-primary tombol_export">Cetak</a>
                                <!-- Start bagian pembayaran -->
                                @if (!isset($transaksi->no_ref) && $bank_1->value_5 == '1')
                                    <a href="{{ route('bayar_selfphoto', $booking->kode) }}" class="btn btn-space btn-success">Upload Bukti Transfer</a>
                                @endif
                                @if (tgl_reschedule($booking->tgl_booking) && $booking->status_booking == 'Dipesan' && $booking->status_bayar != 'Belum Dibayar')
                                    <a href="{{ route('restanggal_selfphoto', $booking->kode) }}" class="btn btn-space btn-brand">Reschedule</a>
                                @endif
                                @if (isset($transaksi->no_ref) && $booking->status_bayar != 'Lunas')
                                    <a href="{{ url("$transaksi->link") }}" class="btn btn-space btn-danger">Selesaikan Pembayaran Anda</a>
                                @endif
                                <!-- End bagian pembayaran -->
                                @if ($booking->status_booking == 'Selesai' && !isset($testimoni->kode))
                                    <a href="{{ route('testimoni_selfphoto', $booking->kode) }}" class="btn btn-space btn-warning">Rating & Testimoni</a>
                                @endif
                                <a href="{{ $kirim_admin }}" target="_blank" class="btn btn-space btn-dark">Kirim Ke Admin</a>
                                @include('components.button_kembali', ['url' => route('riwayat_selfphoto')])
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    countdown_bayar("{{ $waktu_expired }}", 'jam', 'menit', 'detik');
    function countdown_bayar(data, jam, menit, detik) {
        var timer = setInterval(function() {
            var end = new Date(data);
            var now = new Date();
            var status_pembayaran = "{{ $booking->status_bayar }}";
            var distance = end - now;
            var distance1 = now - end;
            if(distance1 > 0 || status_pembayaran == "Lunas") {
                clearInterval(timer);
                return;
            }
            var hours = Math.floor(distance / 3600000);
            var minutes = Math.floor((distance % 3600000) / 60000);
            var seconds = Math.floor((distance % 60000) / 1000);
            document.getElementById(jam).innerHTML = hours + ' Jam';
            document.getElementById(menit).innerHTML = minutes + ' Menit';
            document.getElementById(detik).innerHTML = seconds + ' Detik';
        }, 1000);
    }
</script>
@endsection