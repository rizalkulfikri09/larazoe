@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body" style="padding: 16px">
                    <form action="{{ route('bayar_selfphoto', $booking->kode) }}" method="post" enctype="multipart/form-data" autocomplete="off">
                        @csrf
                        <div class="form-group row">
                            <div class="col-12 col-lg-12">
                                <div class="alert alert-primary" role="alert" style="text-align: center;">Konsumen dapat melakukan pembayaran minimal DP {{ $bank_1->value_4 }}% dari harga paket atau langsung pelunasan. Silahkan upload bukti pembayaran pada form dibawah ini.</div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-lg-6 justify-content-center" style="text-align: center;">
                                <img src="{{ asset('frontend/images/logo_bank/' . $bank_1->value_1) }}" height="50" width="130">
                                <div style="font-weight: bold; font-size: 20px; padding-top: 5px;">{{ $bank_1->value_2 }}</div>
                                <div>a/n {{ $bank_1->value_3 }}</div>
                                <a onclick="BankSatu()" class="btn btn-light"><i class="fas fa-copy"></i> Salin nomor rekening</a>
                            </div>
                            <div class="col-lg-6 justify-content-center" style="text-align: center;">
                                <img src="{{ asset('frontend/images/logo_bank/' . $bank_2->value_1) }}" height="50" width="130">
                                <div style="font-weight: bold; font-size: 20px; padding-top: 5px;">{{ $bank_2->value_2 }}</div>
                                <div>a/n {{ $bank_2->value_3 }}</div>
                                <a onclick="BankDua()" class="btn btn-light"><i class="fas fa-copy"></i> Salin nomor rekening</a>
                            </div>
                        </div>
                        @if (!isset($transaksi->kode_selfphoto) && $booking->status_bayar == 'Belum Dibayar')
                            <div class="form-group row">
                                <label class="col-10 col-lg-4 col-form-label text-left">Pilih Pembayaran</label>
                                <div class="col-12 col-lg-8">
                                    <select class="form-control selectpicker" name="status_bayar" id="status_bayar">
                                        <option value="DP">DP</option>
                                        <option value="Lunas">Lunas</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row jml_dp" style="display: none;">
                                <label class="col-10 col-lg-4 col-form-label text-left">Masukan Nominal DP</label>
                                <div class="col-12 col-lg-8">
                                    <input type="text" id="jml_dp" name="jml_dp" value="{{ nominal_dp($booking->total) }}" data-parsley-trigger="change" required="" class="form-control">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-10 col-lg-4 col-form-label text-left">Upload Bukti Pembayaran</label>
                                <div class="col-12 col-lg-8">
                                    <div class="custom-file">
                                        <label class="file">
                                            <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input @error('bukti_tf') is-invalid @enderror" id="bukti_tf" name="bukti_tf" aria-label="File browser example" onchange="preview_image(event)" required>
                                            <span class="file-custom m-t-10">Pilih Foto</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            @error('bukti_tf')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        @endif
                        @if (isset($transaksi->link))
                            <div class="form-group row m-t-10">
                                <div class="col-12 col-lg-8">
                                    <img src="{{ asset('frontend/images/bukti_tf/' . $transaksi->link) }}" style="width: 250px; height: 400px;" />
                                </div>
                            </div>
                        @else
                            <div class="form-group row" id="pratinjau" style="display:none;">
                                <div class="col-12 col-lg-8">
                                    <br><img id="output_image" />
                                </div>
                            </div>
                        @endif
                        <div class="row">
                            <div class="col-sm-6 m-t-20">
                                @if (!isset($transaksi->kode_selfphoto) && $booking->status_bayar == 'Belum Dibayar')
                                <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                @endif
                                @include('components.button_kembali', ['url' => route('detail_selfphoto', $booking->kode)])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12 col-12">
            <div class="alert alert-warning" role="alert">
                1. Upload foto bukti pembayaran dengan format file JPG/PNG/JPEG.<br>
                2. File yang diupload maksimal 4 MB.
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    try {
        new Cleave('#jml_dp', {
            numeral: true,
            numeralDecimalMark: ',',
            delimiter: '.',
            prefix: 'Rp ',
        });
    } catch (error) { }
    
    $(function() {
        $(".jml_dp").show();
        $("#status_bayar").change(function() {
            if ($(this).val() == "Lunas") {
                $(".jml_dp").hide();
            } else {
                $(".jml_dp").show();
            }
        });
    });
    
    function preview_image(event) 
    {
        var reader = new FileReader();
        reader.onload = function()
        {
            var output = document.getElementById('output_image');
            output.src = reader.result;
            output.setAttribute('width', '250px');
            output.setAttribute('height', '400px');
            document.getElementById('pratinjau').style.display = "";
        }
        reader.readAsDataURL(event.target.files[0]);
    }
    
    function BankSatu() {
        Swal.fire({
            position: 'center',
            icon: 'success',
            title: 'Nomor rekening berhasil disalin',
            showConfirmButton: false,
            width: '35em',
            timer: 1500
        });
        navigator.clipboard.writeText("{{ $bank_1->value_2 }}");
    }
    
    function BankDua() {
        Swal.fire({
            position: 'center',
            icon: 'success',
            title: 'Nomor rekening berhasil disalin',
            showConfirmButton: false,
            width: '35em',
            timer: 1500
        });
        navigator.clipboard.writeText("{{ $bank_2->value_2 }}");
    }
</script>
@endsection