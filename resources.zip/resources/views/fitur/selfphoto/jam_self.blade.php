@extends('layouts.app_template')
@section('body')
<style>
    .custom-control {
        padding-left: 0px;
        margin-bottom: 0px;
    }
    .payment {
        background-color: #EEEEEE;
    }
    .active {
        border: 2px solid #2C7CE4;
    }
    @media (max-width: 767px) {
        .col-sm-6 {
            width: 50%;
            float: left;
        }
    }
</style>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <h5 class="card-header">Pilih salah satu jam booking yang tersedia</h5>
                <div class="card-body">
                    <form action="{{ route('jam_self') }}" method="post" autocomplete="off">
                        @csrf
                        <div class="form-group">
                            @if (count($jam_selfphoto) > 0)
                            <div class="row">
                                @foreach ($jam_selfphoto as $js)
                                    @php
                                        $jam_akhir = Carbon::createFromFormat('H:i', $js->jam)->addMinutes($durasi);
                                    @endphp
                                    @if ($jam_akhir->lessThan($tutup_studio))
                                        <div class="col-lg-4 col-sm-6 mb-2">
                                            <div class="card card-box payment text-center" style="margin-bottom: 10px; padding: 14px;">
                                                <label class="custom-control custom-radio">
                                                    <input type="radio" name="jam_booking" value="{{ $js->id }}" class="custom-control-input" />
                                                    <span style="color: #000;">{{ jam_selfphoto($js->jam) }}</span>
                                                </label>
                                            </div>
                                        </div>
                                    @endif
                                @endforeach
                            </div>
                            @else
                                <p class="text-center">Tidak ada jam yang tersedia, silahkan pilih tanggal lain.</p>
                            @endif
                        </div>
                        <div class="row">
                            <div class="col-xl-12">
                                <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                                @include('components.button_kembali', ['url' => route('tanggal_self')])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        @include('components.card_total', ['total_pembayaran' => $total_pembayaran])
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('.card-box').click(function() {
            $('.card-box.active').removeClass("active");
            $(this).addClass("active");
            $(this).find('input[type="radio"]').prop('checked', true);
        });
    });
</script>
@endsection