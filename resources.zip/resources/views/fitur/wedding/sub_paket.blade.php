@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <form action="{{ route('pilih_paket_wedding', $paket->id) }}" method="post" autocomplete="off">
                    @csrf
                    <div class="pills-regular">
                        <ul class="nav nav-pills" id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="pills-paket" data-toggle="pill" href="#pills-paket_wedding" role="tab" aria-controls="paket_wedding" aria-selected="true">Paket Wedding</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-additional" data-toggle="pill" href="#pills-additional_paket" role="tab" aria-controls="additional_paket" aria-selected="false">Add Ons</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent" style="padding: 20px; padding-bottom: 0px;">
                            <div class="tab-pane fade show active" id="pills-paket_wedding" role="tabpanel" aria-labelledby="pills-paket">
                                <div class="form-group">
                                    <label>Pilih Paket</label>
                                    <select class="form-control selectpicker @error('sub_paket') is-invalid @enderror" name="sub_paket" id="sub_paket">
                                        <option value="" selected disabled hidden>--- Pilih Paket ---</option>
                                        @foreach ($sub_paket as $sp)
                                            <option value="{{ $sp->id }}" data-harga="{{ format_rupiah($sp->harga) }}" @selected(old('sub_paket') == $sp->id)>{{ $sp->sub_paket }}</option>
                                        @endforeach
                                    </select>
                                    @error('sub_paket')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Harga</label>
                                    <input type="text" id="harga" name="harga" value="{{ old('harga') }}" required="" class="form-control @error('harga') is-invalid @enderror" readonly>
                                    @error('harga')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-additional_paket" role="tabpanel" aria-labelledby="pills-additional">
                                <div class="form-group">
                                    <label>Pilih Add Ons</label>
                                    <select class="form-control selectpicker" name="paket_extra" id="paket_extra">
                                        <option value="" selected disabled hidden>--- Pilih Paket ---</option>
                                        @foreach ($paket_extra as $pe)
                                            <option value="{{ $pe->id }}" data-harga_extra="{{ format_rupiah($pe->harga) }}" @selected(old('paket_extra') == $pe->id)>{{ $pe->extra_wedding }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Harga</label>
                                    <input type="text" id="harga_extra" name="harga_extra" value="{{ old('harga_extra') }}" required="" class="form-control" readonly>
                                </div>
                                <div class="form-group">
                                    <label class="custom-control custom-checkbox">
                                        <input type="checkbox" name="transport" value='1' class="custom-control-input"><span class="custom-control-label">Transport</span>
                                    </label>
                                    <b style="color:red">* {{ $get_catatan }}</b>
                                </div>
                            </div>
                        </div>
                        <div class="form-group m-l-20 mt-3">
                            <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                            @include('components.button_kembali', ['url' => route('booking_wedding')])
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            @if ($paket->deskripsi != 'Tidak ada')
                <div class="alert alert-success" role="alert">
                    <p style="margin-bottom: 0px!important;"><b style="font-size: 14px;">Keterangan Paket {{ $paket->nama_paket }} :</b></p>
                    {!! $paket->deskripsi !!}
                </div>
            @endif
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $("#sub_paket").change(function(){
            var sub_paket =  $(this).find(':selected').data('harga');
            $("#harga").val(sub_paket);
        });
    });
    $(document).ready(function(){
        $("#paket_extra").change(function(){
            var paket_extra =  $(this).find(':selected').data('harga_extra');
            $("#harga_extra").val(paket_extra);
        });
    });
</script>
@endsection