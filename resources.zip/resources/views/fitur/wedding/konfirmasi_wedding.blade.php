@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <h5 class="card-header">Cek kembali pesanan anda, jika sudah benar silahkan klik tombol Simpan.</h5>
                <div class="card-body">
                    <form action="{{ route('create_wedding_booking') }}" method="post" autocomplete="off" id="form_booking">
                        @csrf
                        <div class="form-group" style="font-size: 16px;">
                            <div class="row">
                                <div class="col-6">Tanggal Wedding</div>
                                <div class="col-6"><b>{{ $tgl_wedding }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-6">Nama Konsumen</div>
                                <div class="col-6"><b>{{ $nama }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-6">Nomor WhatsApp</div>
                                <div class="col-6"><b>{{ $no_tlp }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-6">Paket Wedding</div>
                                <div class="col-6"><b>{{ $paket_wedding }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-6">Total Pembayaran</div>
                                <div class="col-6"><b style="color: #D90429">{{ $total }}</b></div>
                            </div>
                            <div class="row" style="margin-top: 12px;">
                                <div class="col-6">Alamat</div>
                                <div class="col-6"><b>{{ $alamat }}</b></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 m-t-10">
                                <button type="submit" class="btn btn-space btn-primary" id="tombol_simpan">Simpan</button>
                                @include('components.button_kembali', ['url' => route('pilih_bayar_wedding')])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#form_booking').submit(function () {
        $('.btn-space').prop('disabled', true);
    });
</script>
<script src="{{ asset('frontend/libs/js/loadingSimpan.js') }}"></script>
@endsection