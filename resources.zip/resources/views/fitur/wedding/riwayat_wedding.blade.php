@extends('layouts.app_template')
@section('body')
<link rel="stylesheet" href="{{ asset('frontend/libs/css/custom_table.css') }}">
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="alert alert-success" role="alert">
                <a href="{{ route('booking_wedding') }}" class="btn btn-rounded btn-success btn-sm">Kembali</a>
            </div>
        </div>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="card kotak">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered dt-responsive nowrap" width="99%" id="table_booking">
                        <thead>
                            <tr>
                                <th width="0">No</th>
                                <th class="colomnSize">Kode Booking</th>
                                <th class="colomnSize">Status Pembayaran</th>
                                <th class="colomnSize">Status Booking</th>
                                <th class="colomnSize">Tanggal Wedding</th>
                                <th width="0">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.fn.dataTable.ext.classes.sPageButton = 'btn btn-dark';
        var table = $('#table_booking').DataTable({
            language: {
                "infoFiltered": "",
                "zeroRecords": "Riwayat booking wedding anda kosong"
            },
            searchDelay: 500,
            processing: true,
            serverSide: true,
            ajax: "{{ route('riwayat_wedding') }}",
            columns: [
                { data: 'DT_RowIndex' },
                { data: 'kode', name: 'kode' },
                { data: 'status_bayar', name: 'status_bayar' },
                { data: 'status_booking', name: 'status_booking' },
                { data: 'tgl_wedding', name: 'tgl_wedding' },
                { data: 'opsi', name: 'opsi' },
            ],
            "bFilter": false,
            "bLengthChange": false,
            "bInfo": false,
            "aoColumnDefs": [
                { "bSortable": false, "aTargets": [0,5] }, 
                { "bSearchable": false, "aTargets": [0,5] },
                { "className": "text-center", "targets" : [0,1,5] },
            ],
            "aaSorting": [],
        });

        // Bagian delete data
        $('body').on('click', '.deleteBooking', function (){
            var kode = $(this).data("kode");
            Swal.fire({
                title: 'Apakah anda yakin',
                text: "Data akan dihapus",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Hapus Data!'
            }).then(function (e) {
                if (e.value === true) {
                    $.ajax({
                        type: "DELETE",
                        url: "{{ route('riwayat_wedding') }}/" + kode,
                        success: function (data) {
                            $('#alert_message').html('<div class="alert alert-success" >'+ data.message +'</div>');
                            alertSuccess(data.message);
                            table.draw();
                        },
                        error: function (data) {
                            console.log('Error:', data);
                        }
                    });
                } else {
                    return false;
                }
            });
        });
    });
</script>
@endsection