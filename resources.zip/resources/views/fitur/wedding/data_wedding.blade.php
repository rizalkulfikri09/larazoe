@extends('layouts.app_template')
@section('body')
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('data_wedding') }}" method="post" autocomplete="off">
                        @csrf
                        <div class="form-group">
                            <label>Alamat Tempat Acara</label>
                            <textarea type="text" id="alamat" name="alamat" placeholder="Tulis detail alamat dengan jelas" autocomplete="off" class="form-control @error('alamat') is-invalid @enderror"></textarea>
                            @error('alamat')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 m-t-10">
                                <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                                @include('components.button_kembali', ['url' => route('pilih_tanggal_wedding')])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        @include('components.card_total', ['total_pembayaran' => $total_pembayaran])
    </div>
</div>
@endsection