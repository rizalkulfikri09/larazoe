<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="{{ asset('frontend/images/favicon/'.$set_umum->value_4) }}">
    <title>Malik & Belinda</title>
    <meta name="description" content="Pernikahan Malik & Belinda 26 Februari 2023">
    <meta name="keywords" content="undangan digital, undangan online, undangan nikah online, website undangan pernikahan">
    <meta property="og:locale" content="id_ID">
    <meta property="og:type" content="article">
    <meta property="og:title" content="Pernikahan Malik & Belinda">
    <meta property="og:description" content="Minggu, 26 Februari 2023">
    <meta property="og:url" content="{{ url('preview/dream_wedding') }}/">
    <meta property="og:image" content="{{ asset('frontend/undangan/preview/2.jpg') }}">
    <meta property="og:image:secure_url" content="{{ asset('frontend/undangan/preview/2.jpg') }}">
    <meta property="og:image:width" content="500">
    <meta property="og:image:height" content="500">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:title" content="Pernikahan Malik & Belinda">
    <meta property="twitter:description" content="Minggu, 26 Februari 2023">
    <meta property="twitter:image" content="{{ asset('frontend/undangan/preview/2.jpg') }}">
    <meta itemprop="name" content="Pernikahan Malik & Belinda">
    <meta itemprop="description" content="Minggu, 26 Februari 2023">
    <meta itemprop="image" content="{{ asset('frontend/undangan/preview/2.jpg') }}">
    <link href="{{ asset('frontend/undangan/mylove/css/themify-icons.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/flaticon.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/owl.carousel.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/owl.theme.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/slick.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/slick-theme.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/swiper.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/nice-select.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/owl.transitions.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/jquery.fancybox.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/odometer-theme-default.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/sass/style.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/datatables/css/jquery.dataTables.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/template.css') }}" rel="stylesheet">
    <style>
        .wpo-video-section {
            background: url("{{ asset('frontend/undangan/preview/7.jpg') }}") no-repeat center center;
        }
        .wpo-event-section:before,
        .wpo-event-section-s2:before {
            background: url("{{ asset('frontend/undangan/mylove/images/event/bg.jpg') }}") no-repeat center center;
        }
    </style>
</head>

<body class="color2">
    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <div class="preloader">
            <div class="vertical-centered-box">
                <div class="content">
                    <div class="loader-circle"></div>
                    <div class="loader-line-mask">
                        <div class="loader-line"></div>
                    </div>
                    <img src="{{ asset('frontend/undangan/mylove/images/preloader.png') }}" alt="">
                </div>
            </div>
        </div>
        <!-- end preloader -->
        <!-- Start header -->
        <header id="header">
            <div class="wpo-site-header">
                <nav class="navigation navbar navbar-expand-lg navbar-light" style="z-index: 99">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <div class="col-lg-3 col-md-3 col-3 d-lg-none dl-block">
                                <div class="mobail-menu">
                                    <button type="button" class="navbar-toggler open-btn">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar first-angle"></span>
                                        <span class="icon-bar middle-angle"></span>
                                        <span class="icon-bar last-angle"></span>
                                    </button>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-6 col-6">
                                <div class="navbar-header" style="text-align: center;">
                                    <a class="navbar-brand logo" href="" style="top: 0px;">M <small>&</small> B</a>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-1 col-1">
                                <div id="navbar" class="collapse navbar-collapse navigation-holder">
                                    <button class="menu-close"><i class="ti-close"></i></button>
                                    <ul class="nav navbar-nav mb-2 mb-lg-0">
                                        <li><a href="#home">Beranda</a></li>
                                        <li><a href="#story">Cerita</a></li>
                                        <li><a href="#gallery">Galeri</a></li>
                                        <li><a href="#rsvp">Ucapan</a></li>
                                        <li><a href="#event">Tempat</a></li>
                                        <li><a href="#gift">Amplop</a></li>
                                    </ul>
                                </div><!-- end of nav-collapse -->
                            </div>
                        </div>
                    </div><!-- end of container -->
                </nav>
            </div>
        </header>
        <!-- end of header -->
        <!-- start of hero -->
        <section class="wpo-hero-slider wpo-hero-style-3">
            <div class="wedding-announcement">
                <div class="couple-text">
                    <h2 class="wow slideInUp" data-wow-duration="1s">Malik & Belinda</h2>
                    <p class="wow slideInUp" data-wow-duration="1.8s">Minggu, 26 Februari 2023</p>
                    <!-- start wpo-wedding-date -->
                    <div class="wpo-wedding-date wow slideInUp" data-wow-duration="2.1s">
                        <div class="clock-grids">
                            <div id="clock"></div>
                        </div>
                    </div>
                    <a href="https://www.google.com/calendar/render?action=TEMPLATE&text=Pernikahan+Malik+%26+Belinda&dates=20230226T080000/20230226T230000&location=Hotel+Grand+Dafam+Banjarbaru&details=Kami+sangat+berharap+anda+dapat+hadir+di+momen+bahagia+ini." target="_blank" class="btn btn-primary wow slideInUp mt-3" data-wow-duration="2.1s">Simpan Tanggal Acara</a>
                    <!-- end wpo-wedding-date -->
                </div>
            </div>
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/preview/7.jpg') }}">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/preview/9.jpg') }}">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/preview/7.jpg') }}">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/preview/9.jpg') }}">
                        </div>
                    </div>
                </div>
                <!-- end swiper-wrapper -->
                <!-- swipper controls -->
                <div class="swiper-pagination"></div>
                <div class="next-prev-btn">
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
            </div>
        </section>
        <!-- end of hero slider -->
        <div class="container" id="home" style="padding-top: 40px; padding-bottom: 40px; text-align: center;">
            <div class="wpo-section-title" style="margin-bottom: 10px;">
                <div class="section-title-icon">
                    <i class="fi flaticon-dove"></i>
                </div>
            </div>
            <p class="wow fadeInUp" data-wow-duration="1200ms" style="line-height: 30px; font-size: 20px; margin-bottom: 0px;">Assalamu'alaikum Warahmatullaahi Wabarakaatuh. Maha Suci Allah yang telah menciptakan makhluk-Nya berpasang-pasangan. Ya Allah semoga ridho-Mu tercurah mengiringi pernikahan kami.</p>
        </div>
        <!-- start couple-section -->
        <section class="couple-section section-padding" style="padding-top: 0px;">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col col-lg-11">
                        <div class="couple-area clearfix">
                            <div class="couple-item bride wow fadeInLeft" data-wow-duration="2s">
                                <div class="row align-items-center">
                                    <div class="col-lg-4">
                                        <div style="border: 10px solid #EEE;">
                                            <img src="{{ asset('frontend/undangan/preview/1.jpg') }}" alt="foto pengantin">
                                        </div>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="couple-text" style="padding-left: 20px;">
                                            <h3 style="line-height: 60px;">Malik Haryanto Budiman</h3>
                                            <p style="margin-bottom: 0px;">Putra ketiga dari</p>
                                            <p style="margin-bottom: 0px; font-weight: bold;">Bapak Kurnia Najmudin & Ibu Yani Mulyani</p>
                                            <div class="social">
                                                <ul>
                                                    <li><a href="https://www.instagram.com/malik1" target="_blank"><i class="ti-instagram"></i></a></li>
                                                    <li><a href="https://www.twitter.com/malik12" target="_blank"><i class="ti-twitter-alt"></i></a></li>
                                                    <li><a href="https://www.facebook.com/malik123" target="_blank"><i class="ti-facebook"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="couple-item groom wow fadeInRight" data-wow-duration="2s">
                                <div class="row align-items-center">
                                    <div class="col-lg-8 order-lg-1 order-2">
                                        <div class="couple-text" style="padding-right: 20px;">
                                            <h3 style="line-height: 60px;">Belinda Wulandari Mayasari</h3>
                                            <p style="margin-bottom: 0px;">Putri pertama dari</p>
                                            <p style="margin-bottom: 0px; font-weight: bold;">Bapak Hasim Hidayanto & Ibu Nadine Wastuti</p>
                                            <div class="social">
                                                <ul>
                                                    <li><a href="https://www.instagram.com/belinda1" target="_blank"><i class="ti-instagram"></i></a></li>
                                                    <li><a href="https://www.twitter.com/belinda12" target="_blank"><i class="ti-twitter-alt"></i></a></li>
                                                    <li><a href="https://www.facebook.com/belinda123" target="_blank"><i class="ti-facebook"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 order-lg-2 order-1">
                                        <div style="border: 10px solid #EEE;">
                                            <img src="{{ asset('frontend/undangan/preview/2.jpg') }}" alt="foto pengantin">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end couple-section -->

        <!-- start wpo-video-section -->
        <section class="wpo-video-section wow zoomIn" data-wow-duration="2s">
            <h2 class="hidden">some</h2>
            <a href="https://www.youtube.com/embed/VBf4dH-qGh8" class="video-btn" data-type="iframe"><i class="fi flaticon-play"></i></a>
        </section>
        <!-- end wpo-video-section-->

        <!-- start story-section -->
        <section class="story-section section-padding" id="story">
            <div class="container">
                <div class="row">
                    <div class="wpo-section-title">
                        <div class="section-title-icon">
                            <i class="fi flaticon-dove"></i>
                        </div>
                        <h2>Cerita Cinta</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="story-timeline">
                            <div class="row">
                                <div class="col offset-lg-6 col-lg-6 col-12 text-holder">
                                    <span class="heart">
                                        <i class="fi flaticon-balloon"></i>
                                    </span>
                                </div>
                            </div>
                            <div class="story-timeline-item s1">
                                <div class="row align-items-center">
                                    <div class="col col-lg-6 col-12">
                                        <div class="img-holder right-align-text wow fadeInLeftSlow" data-wow-duration="1500ms">
                                            <img src="{{ asset('frontend/undangan/preview/12.jpg') }}" alt class="img img-responsive">
                                        </div>
                                    </div>
                                    <div class="col col-lg-6 col-12">
                                        <div class="story-text left-align-text wow fadeInRightSlow" data-wow-duration="2000ms">
                                            <h3>Pertemuan pertama</h3>
                                            <span class="date">12 Mei 2022</span>
                                            <div class="line-shape">
                                                <div class="outer-ball">
                                                    <div class="inner-ball"></div>
                                                </div>
                                            </div>
                                            <p>Pertemuan pertama kami berawal dari acara yang diselenggarakan kampus dan kami sebagai panitianya pada saat itu.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="story-timeline-item">
                                <div class="row align-items-center">
                                    <div class="col col-lg-6 col-12 order-lg-1 order-2 text-holder left-text">
                                        <div class="story-text right-align-text wow fadeInLeftSlow" data-wow-duration="2000ms">
                                            <h3>Jadian</h3>
                                            <span class="date">12 Mei 2022</span>
                                            <div class="line-shape s2">
                                                <div class="outer-ball">
                                                    <div class="inner-ball"></div>
                                                </div>
                                            </div>
                                            <p>Tidak lama setelah pertemuan pertama, hubungan kami semakin lebih dekat dan kami sering bertemu sampai akhirnya memutuskan untuk jadian.</p>
                                        </div>
                                    </div>
                                    <div class="col col-lg-6 col-12 order-lg-2 order-1">
                                        <div class="img-holder left-align-text">
                                            <img src="{{ asset('frontend/undangan/preview/13.jpg') }}" alt class="img img-responsive wow fadeInRightSlow" data-wow-duration="1500ms">
                                            <span class="heart">
                                                <i class="fi flaticon-dance"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="story-timeline-item">
                                <div class="row align-items-center">
                                    <div class="col col-lg-6 col-12">
                                        <div class="img-holder right-align-text left-site right-heart">
                                            <img src="{{ asset('frontend/undangan/preview/14.jpg') }}" alt class="img img-responsive wow fadeInLeftSlow" data-wow-duration="1500ms">
                                            <span class="heart">
                                                <i class="fi flaticon-dove"></i>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col col-lg-6 col-12">
                                        <div class="story-text left-align-text wow fadeInRightSlow" data-wow-duration="2000ms">
                                            <h3>Lamaran</h3>
                                            <span class="date">12 Mei 2022</span>
                                            <div class="line-shape">
                                                <div class="outer-ball">
                                                    <div class="inner-ball"></div>
                                                </div>
                                            </div>
                                            <p>3 tahun lebih menjalin hubungan dan kami mempunyai visi misi yang sama untuk membawa hubungan ini ke jenjang yg lebih serius, dengan mempertemukan keluarga besar kami untuk menentukan tanggal pernikahan.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
            <div class="shape-1">
                <div class="sticky-shape">
                    <img src="{{ asset('frontend/undangan/mylove/images/story/shape-1.png') }}" alt="">
                </div>  
            </div>
            <div class="shape-2">
                <div class="sticky-shape">
                    <img src="{{ asset('frontend/undangan/mylove/images/story/shape-2.png') }}" alt="">
                </div>
            </div>
        </section>
        <!-- end story-section -->

        <!-- start wpo-portfolio-section -->
        <section class="wpo-portfolio-section section-padding pt-0" id="gallery">
            <div class="container">
                <div class="row">
                    <div class="wpo-section-title">
                        <div class="section-title-icon">
                            <i class="fi flaticon-dove"></i>
                        </div>
                        <h2>Galeri Foto</h2>
                    </div>
                </div>
                <div class="sortable-gallery wow fadeInUp" data-wow-duration="2s">
                    <div class="gallery-filters"></div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="portfolio-grids gallery-container clearfix">
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/7.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/7.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/9.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/9.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/10.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/10.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/11.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/11.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/7.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/7.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/9.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/9.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- end container -->
        </section>
        <!-- end wpo-portfolio-section -->

        <!-- start of wpo-contact-section -->
        <section class="wpo-contact-section section-padding" id="rsvp">
            <div class="container">
                <div class="wpo-contact-section-wrapper">
                    <div class="wpo-contact-form-area" style="padding: 130px 40px;">
                        <div class="wpo-section-title">
                            <div class="section-title-icon">
                                <i class="fi flaticon-dove"></i>
                            </div>
                            <h4>Berikan ucapan dan kehadiran anda</h4>
                        </div>
                        <form autocomplete="off">
                            <div>
                                <input type="text" class="form-control" placeholder="Nama Anda">
                            </div>
                            <div>
                                <textarea class="form-control" placeholder="Ketik Ucapan & Doa" style="height: 80px;" required></textarea>
                            </div>
                            <div class="radio-buttons">
                                <p>
                                    <input type="radio" id="ya" name="kehadiran" checked>
                                    <label for="ya">Ya, saya akan hadir</label>
                                </p>
                                <p>
                                    <input type="radio" id="tidak" name="kehadiran">
                                    <label for="tidak">Maaf, saya tidak bisa hadir</label>
                                </p>
                                <p>
                                    <input type="radio" id="ragu" name="kehadiran">
                                    <label for="ragu">Saya belum yakin bisa hadir atau tidak</label>
                                </p>
                            </div>
                            <div class="submit-area">
                                <button class="btn btn-primary">Kirim</button>
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#ucapanModal">
                                    Lihat Semua Ucapan
                                </button>
                            </div>
                        </form>
                        <div class="border-style"></div>
                    </div>
                    <div class="vector-1">
                        <img src="{{ asset('frontend/undangan/mylove/images/rsvp/flower1.png') }}" alt="">
                    </div>
                    <div class="vector-2">
                        <img src="{{ asset('frontend/undangan/mylove/images/rsvp/flower2.png') }}" alt="">
                    </div>
                </div>
            </div>
            <div class="shape-1">
                <img src="{{ asset('frontend/undangan/mylove/images/rsvp/shape1.png') }}" alt="">
            </div>
            <div class="shape-2">
                <img src="{{ asset('frontend/undangan/mylove/images/rsvp/shape2.png') }}" alt="">
            </div>
        </section>
        <!-- end of wpo-contact-section -->

        <!-- start wpo-event-section -->
        <section class="wpo-event-section section-padding" id="event" style="padding-bottom: 0px;">
            <div class="container">
                <div class="row">
                    <div class="wpo-section-title-s2">
                        <div class="section-title-icon">
                            <i class="fi flaticon-dove"></i>
                        </div>
                        <h2>Waktu & Tempat Acara</h2>
                    </div>
                </div>
                <div class="wpo-event-wrap">
                    <div class="row justify-content-center">
                        <div class="col col-lg-4 col-md-6 col-12 wow fadeInLeft" data-wow-duration="2s">
                            <div class="wpo-event-item">
                                <div class="wpo-event-text">
                                    <h2>Akad Nikah</h2>
                                    <ul>
                                        <li>Minggu, 26 Februari 2023 Pukul 08:00</li>
                                        <li style="font-weight: bold;">Hotel Grand Dafam Banjarbaru</li>
                                        <li>Q Mall, Jl. A. Yani No.km 36.8, Komet, Kec. Banjarbaru Utara, Kota Banjar Baru</li>
                                        <li><a href="https://goo.gl/maps/KnXQbcbrw6bprrjQA" target="_blank" class="btn btn-primary text-white">Buka Maps</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-4 col-md-6 col-12 wow fadeInRight" data-wow-duration="2s">
                            <div class="wpo-event-item">
                                <div class="wpo-event-text">
                                    <h2>Resepsi</h2>
                                    <ul>
                                        <li>Minggu, 26 Februari 2023 Pukul 08:00</li>
                                        <li style="font-weight: bold;">Hotel Grand Dafam Banjarbaru</li>
                                        <li>Q Mall, Jl. A. Yani No.km 36.8, Komet, Kec. Banjarbaru Utara, Kota Banjar Baru</li>
                                        <li><a href="https://goo.gl/maps/KnXQbcbrw6bprrjQA" target="_blank" class="btn btn-primary text-white">Buka Maps</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- end container -->
        </section>
        <!-- end wpo-event-section -->

        <!-- start wpo-pricing-section -->
        <section class="wpo-pricing-section section-padding" style="padding-top: 70px; padding-bottom: 40px;" id="gift">
            <div class="container">
                <div class="row">
                    <div class="wpo-section-title" style="margin-bottom: 30px;">
                        <div class="section-title-icon">
                            <i class="fi flaticon-dove"></i>
                        </div>
                        <h2>Amplop Digital</h2>
                    </div>
                </div>
                <div class="wpo-pricing-wrap wow zoomIn" data-wow-duration="2s">
                    <div class="row">
                        <div class="col col-lg-6 col-md-6 col-12" style="text-align: center;">
                            <div class="wpo-pricing-item">
                                <div class="wpo-pricing-top pb-1">
                                    <div class="wpo-pricing-text">
                                        <h3>Bank BNI</h3>
                                        <h2 style="font-size: 28px; font-weight: bold; padding-top: 10px;" id="bank_1">1234567890</h2>
                                        <h4 style="padding-top: 10px;">Malik Haryanto Budiman</h4>
                                    </div>
                                </div>
                                <div class="shape"><img src="{{ asset('frontend/undangan/lovelove/images/pricing/p-shape.svg') }}" alt=""></div>
                                <div class="wpo-pricing-bottom py-3">
                                    <div class="wpo-pricing-bottom-text">
                                        <button onclick="copyNoRekening('#bank_1')" class="btn btn-primary mb-2">Salin Nomor Rekening</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-6 col-md-6 col-12" style="text-align: center;">
                            <div class="wpo-pricing-item">
                                <div class="wpo-pricing-top pb-1">
                                    <div class="wpo-pricing-text">
                                        <h3>Bank BCA</h3>
                                        <h2 style="font-size: 28px; font-weight: bold; padding-top: 10px;" id="bank_2">0987654321</h2>
                                        <h4 style="padding-top: 10px;">Malik Haryanto Budiman</h4>
                                    </div>
                                </div>
                                <div class="shape"><img src="{{ asset('frontend/undangan/lovelove/images/pricing/p-shape.svg') }}" alt=""></div>
                                <div class="wpo-pricing-bottom py-3">
                                    <div class="wpo-pricing-bottom-text">
                                        <button onclick="copyNoRekening('#bank_2')" class="btn btn-primary mb-2">Salin Nomor Rekening</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- start wpo-pricing-section -->

        <!-- start of wpo-site-footer-section -->
        <footer class="wpo-site-footer">
            <div class="wpo-lower-footer">
                <div class="container">
                    <div class="row">
                        <div class="col col-xs-12">
                            <p class="copyright"><a href="{{ url('/') }}">{{ $set_umum->value_3 }}. All Right Reserved.</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end of wpo-site-footer-section -->
    </div>
    <!-- end of page-wrapper -->

    <!-- Modal -->
    <div class="modal fade show" id="fullwedding" style="display: block">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="modal-body" style="padding: 0px;">
                    <!-- start of hero -->
                    <section class="static-hero-s4" style="height: 100vh;">
                        <div class="hero-container">
                            <div class="hero-inner" style="padding: 0px;">
                                <div class="container" style="padding-left: 0px; padding-right: 0px;">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-12">
                                            <div class="wpo-event-item" style="padding: 100px 0px;">
                                                <div class="wpo-event-text">
                                                    <h2>Malik & Belinda</h2>
                                                    <p style="color: #06002E; font-size: 18px; margin-bottom: 0px; line-height: 24px;">Kepada yang terhormat Bapak/Ibu/Saudara/i :</p>
                                                    <p style="color: #06002E; font-size: 25px; font-weight: bold; margin: 10px 0px; line-height: 28px;">Tamu Undangan</p>
                                                    <button class="btn btn-primary btn-lg mb-2" id="bukaUndangan">Buka Undangan</button>
                                                    <p style="color: #06002E; margin: 5px 0px; font-size: 18px; line-height: 20px;">Mohon maaf jika ada kesalahan penulisan nama dan gelar</p>
                                                </div>
                                                <div class="shape-1"><img src="{{ asset('frontend/undangan/mylove/images/slider/flower1.png') }}" alt=""></div>
                                                <div class="shape-2"><img src="{{ asset('frontend/undangan/mylove/images/slider/flower2.png') }}" alt=""></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- end of hero slider -->
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="ucapanModal" tabindex="-1" aria-labelledby="ucapanModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="ucapanModalLabel">Ucapan dari tamu undangan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-striped" width="100%" id="table_ucapan">
                            <thead>
                                <tr>
                                    <th style="text-align: center">Nama Tamu</th>
                                    <th style="text-align: center; width: 400px;">Ucapan Tamu</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style="text-align: center">Hamima Yuniar</td>
                                    <td>Selamat menempuh hidup baru dengan pujaan hatimu. Semoga cinta kalian bertumbuh setiap harinya.</td>
                                </tr>
                                <tr>
                                    <td style="text-align: center">Galang Prabowo</td>
                                    <td>Selamat atas pernikahannya, semoga menjadi titik perjalanan hidup bersama yang lebih membahagiakan.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <button class="button-musik"><i class="fa fa-pause"></i></button>
    <audio id="musik" src="{{ asset('frontend/undangan/musik/Musik 1.mp3') }}"></audio>
    <!-- All JavaScript files
    ================================================== -->
    <script src="{{ asset('frontend/undangan/mylove/js/jquery.min.js') }}"></script>
    <script src="{{ asset('frontend/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('frontend/undangan/mylove/js/bootstrap.bundle.min.js') }}"></script>
    <!-- Plugins for this template -->
    <script src="{{ asset('frontend/undangan/mylove/js/modernizr.custom.js') }}"></script>
    <script src="{{ asset('frontend/undangan/mylove/js/jquery.dlmenu.js') }}"></script>
    <script src="{{ asset('frontend/undangan/mylove/js/jquery-plugin-collection.js') }}"></script>
    <!-- Custom script for this template -->
    <script src="{{ asset('frontend/libs/js/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('frontend/undangan/mylove/js/script.js') }}"></script>
    <script type="text/javascript">
        let tanggalNikah = new Date();
        tanggalNikah.setDate(tanggalNikah.getDate() + 90);
        let tanggalNikahFormat = tanggalNikah.getFullYear() + '/' + (tanggalNikah.getMonth() + 1) + '/' + tanggalNikah.getDate() + ' 08:00:00';
        $('#clock').countdown(tanggalNikahFormat, function (event) {
            var $this = $(this).html(event.strftime(''
                + '<div class="box"><div><div class="time">%D</div> <span>Hari</span> </div></div>'
                + '<div class="box"><div><div class="time">%H</div> <span>Jam</span> </div></div>'
                + '<div class="box"><div><div class="time">%M</div> <span>Menit</span> </div></div>'
                + '<div class="box"><div><div class="time">%S</div> <span>Detik</span> </div></div>'));
        });

        $("#bukaUndangan").click(function () {
            $("#fullwedding").fadeToggle("slow");
            $("#musik")[0].play();
            $("#musik").on("ended", function() {
                this.currentTime = 0;
                this.play();
            });
            $(".button-musik").click(function() {
                if ($(this).find("i").hasClass("fa-play")) {
                    $("#musik")[0].play();
                    $(this).html('<i class="fa fa-pause"></i>');
                } else {
                    $("#musik")[0].pause();
                    $(this).html('<i class="fa fa-play"></i>');
                }
            });
        });
    </script>
    <!-- =======================================================
    * Template Mylove: https://themeforest.net/item/mylove-wedding-html5-template/38484030
    * Image by: https://www.freepik.com/
    ======================================================== -->
</body>

</html>