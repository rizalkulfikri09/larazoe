<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="{{ asset('frontend/images/favicon/'.$set_umum->value_4) }}">
    <title>Malik & Belinda</title>
    <meta name="description" content="Pernikahan Malik & Belinda 26 Februari 2023">
    <meta name="keywords" content="undangan digital, undangan online, undangan nikah online, website undangan pernikahan">
    <meta property="og:locale" content="id_ID">
    <meta property="og:type" content="article">
    <meta property="og:title" content="Pernikahan Malik & Belinda">
    <meta property="og:description" content="Minggu, 26 Februari 2023">
    <meta property="og:url" content="{{ url('preview/radiant_love') }}/">
    <meta property="og:image" content="{{ asset('frontend/undangan/preview/2.jpg') }}">
    <meta property="og:image:secure_url" content="{{ asset('frontend/undangan/preview/2.jpg') }}">
    <meta property="og:image:width" content="500">
    <meta property="og:image:height" content="500">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:title" content="Pernikahan Malik & Belinda">
    <meta property="twitter:description" content="Minggu, 26 Februari 2023">
    <meta property="twitter:image" content="{{ asset('frontend/undangan/preview/2.jpg') }}">
    <meta itemprop="name" content="Pernikahan Malik & Belinda">
    <meta itemprop="description" content="Minggu, 26 Februari 2023">
    <meta itemprop="image" content="{{ asset('frontend/undangan/preview/2.jpg') }}">
    <link href="{{ asset('frontend/undangan/lovelove/css/themify-icons.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/flaticon.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/owl.carousel.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/owl.theme.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/slick.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/slick-theme.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/swiper.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/nice-select.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/owl.transitions.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/jquery.fancybox.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/odometer-theme-default.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/jquery-ui.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/sass/style.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/datatables/css/jquery.dataTables.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/template.css') }}" rel="stylesheet">
    <style>
        .wpo-hero-style-3 .slide-inner {
            margin: 0 auto;
            width: 89%;
            left: 5%;
            top: 0;
        }
        .wpo-contact-section-s5 {
            background: url("{{ asset('frontend/undangan/lovelove/images/contact/bg_2.jpg') }}") no-repeat center center;
        }
        @media (min-width: 1200px) {
            .container, .container-lg, .container-md, .container-sm, .container-xl {
                max-width: 1246px;
            }
        }
        @media (min-width: 1400px) {
            .container {
                max-width: 1455px;
            }
        }
    </style>
</head>

<body class="color3">
    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <div class="preloader">
            <div class="vertical-centered-box">
                <div class="content">
                    <div class="loader-circle"></div>
                    <div class="loader-line-mask">
                        <div class="loader-line"></div>
                    </div>
                    <img src="{{ asset('frontend/undangan/lovelove/images/preloader.svg') }}" alt="">
                </div>
            </div>
        </div>
        <!-- end preloader -->

        <!-- Start header -->
        <header id="header">
            <div class="wpo-site-header wpo-header-style-1" id="sticky-header">
                <nav class="navigation navbar navbar-expand-lg navbar-light">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <div class="col-md-2 col-2 d-lg-none d-block">
                                <div class="mobail-menu">
                                    <button type="button" class="navbar-toggler open-btn">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar first-angle"></span>
                                        <span class="icon-bar middle-angle"></span>
                                        <span class="icon-bar last-angle"></span>
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-10 col-10 d-lg-none d-block">
                                <div class="navbar-header">
                                    <a class="navbar-brand mx-auto" href="#"><h3 style="margin: 14px 0px 0px; font-weight: bold; text-align: center;" id="inisial">
                                        <span class="shape-1"><img src="{{ asset('frontend/undangan/lovelove/images/slider/shape.png') }}" alt="" width="80"></span>
                                        M & B
                                        <span class="shape-2"><img src="{{ asset('frontend/undangan/lovelove/images/slider/shape2.png') }}" alt="" width="80"></span>
                                    </h3></a>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-1 col-1">
                                <div id="navbar" class="collapse navbar-collapse navigation-holder">
                                    <button class="menu-close"><i class="ti-close"></i></button>
                                    <ul class="nav navbar-nav mb-2 mb-lg-0">
                                        <li><a href="#home">Beranda</a></li>
                                        <li><a href="#story">Cerita</a></li>
                                        <li><a href="#gallery">Galeri</a></li>
                                        <li><a href="#rsvp">Ucapan</a></li>
                                        <li><a href="#event">Tempat</a></li>
                                        <li><a href="#gift">Amplop</a></li>
                                    </ul>
                                </div><!-- end of nav-collapse -->
                            </div>
                        </div>
                    </div><!-- end of container -->
                </nav>
            </div>
        </header>
        <!-- end of header -->

        <!-- start of hero -->
        <section class="wpo-hero-slider wpo-hero-style-3">
            <h2 class="hidden">some</h2>
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/preview/7.jpg') }}">
                        </div> <!-- end slide-inner -->
                    </div> <!-- end swiper-slide -->

                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/preview/9.jpg') }}">
                        </div> <!-- end slide-inner -->
                    </div> <!-- end swiper-slide -->

                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/preview/7.jpg') }}">
                        </div> <!-- end slide-inner -->
                    </div> <!-- end swiper-slide -->

                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/preview/9.jpg') }}">
                        </div> <!-- end slide-inner -->
                    </div> <!-- end swiper-slide -->
                </div>
                <!-- end swiper-wrapper -->

                <!-- swipper controls -->
                <div class="swiper-pagination"></div>
            </div>
        </section>
        <!-- end of hero slider -->

        <!-- start wpo-wedding-date -->
        <section class="wpo-wedding-date section-padding pt-5" id="home">
            <div class="container" style="max-width: 1200px;">
                <h2 class="wow fadeInUp" data-wow-duration="1200ms" style="font-weight: bold;">
                    <span class="shape-1"><img src="{{ asset('frontend/undangan/lovelove/images/slider/shape.png') }}" alt="" width="200px"></span>
                    Malik & Belinda
                    <span class="shape-2"><img src="{{ asset('frontend/undangan/lovelove/images/slider/shape2.png') }}" alt=""width="200px"></span>
                </h2>
                <p class="wow fadeInUp" data-wow-duration="1200ms" style="line-height: 28px; margin-top: 10px;">Assalamu'alaikum Warahmatullaahi Wabarakaatuh. Maha Suci Allah yang telah menciptakan makhluk-Nya berpasang-pasangan. Ya Allah semoga ridho-Mu tercurah mengiringi pernikahan kami.</p>
                <div class="row wow fadeInUp pb-4" data-wow-duration="1400ms">
                    <div class="col col-xs-12">
                        <div class="clock-grids">
                            <div id="clock" style="font-weight: bold;"></div>
                        </div>
                    </div>
                </div>
                <a href="https://www.google.com/calendar/render?action=TEMPLATE&text=Pernikahan+Malik+%26+Belinda&dates=20230226T080000/20230226T230000&location=Hotel+Grand+Dafam+Banjarbaru&details=Kami+sangat+berharap+anda+dapat+hadir+di+momen+bahagia+ini." target="_blank" class="btn btn-primary wow zoomIn" data-wow-duration="1400ms">Simpan Tanggal Acara</a>
            </div> <!-- end container -->
        </section>
        <!-- end wpo-wedding-date -->

        <!-- start couple-section -->
        <section class="wpo-couple-section-s2 section-padding" id="couple">
            <div class="container">
                <div class="couple-area clearfix">
                    <div class="shape-1"><img class="wow fadeInLeftSlow" data-wow-duration="1700ms" src="{{ asset('frontend/undangan/lovelove/images/couple/shape-2.png') }}" alt=""></div>
                    <div class="shape-2"><img class="wow fadeInRightSlow" data-wow-duration="1700ms" src="{{ asset('frontend/undangan/lovelove/images/couple/shape-3.png') }}" alt=""></div>
                    <div class="row align-items-center justify-content-center  wow fadeInUp" data-wow-duration="1500ms">
                        <div class="col col-lg-4 col-md-6 col-12">
                            <div class="couple-item">
                                <div class="couple-img">
                                    <img src="{{ asset('frontend/undangan/preview/1.jpg') }}" height="100%" alt="foto pengantin">
                                </div>
                                <div class="couple-text">
                                    <h3>Malik Haryanto Budiman</h3>
                                    <b>Putra ketiga dari</b>
                                    <p style="margin-bottom: 0px;">Bapak Kurnia Najmudin & Ibu Yani Mulyani</p>
                                    <div class="social">
                                        <ul>
                                            <li><a href="https://www.instagram.com/malik1" target="_blank"><i class="ti-instagram"></i></a></li>
                                            <li><a href="https://www.twitter.com/malik12" target="_blank"><i class="ti-twitter-alt"></i></a></li>
                                            <li><a href="https://www.facebook.com/malik123" target="_blank"><i class="ti-facebook"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="round-1"></div>
                                <div class="round-2"></div>
                                <div class="round-3"></div>
                                <div class="layer-1"></div>
                                <div class="layer-2"></div>
                                <div class="layer-3"></div>
                            </div>
                        </div>
                        <div class="col col-lg-4 col-md-6 col-12">
                            <div class="couple-item">
                                <div class="couple-img">
                                    <img src="{{ asset('frontend/undangan/preview/2.jpg') }}" height="100%" alt="foto pengantin">
                                </div>
                                <div class="couple-text">
                                    <h3>Belinda Wulandari Mayasari</h3>
                                    <b>Putri pertama dari</b>
                                    <p style="margin-bottom: 0px;">Bapak Hasim Hidayanto & Ibu Nadine Wastuti</p>
                                    <div class="social">
                                        <ul>
                                            <li><a href="https://www.instagram.com/belinda1" target="_blank"><i class="ti-instagram"></i></a></li>
                                            <li><a href="https://www.twitter.com/belinda12" target="_blank"><i class="ti-twitter-alt"></i></a></li>
                                            <li><a href="https://www.facebook.com/belinda123" target="_blank"><i class="ti-facebook"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="layer-1"></div>
                                <div class="layer-2"></div>
                                <div class="layer-3"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end couple-section -->

        <!-- start wpo-video-section -->
        <section class="wpo-video-section-s3">
            <h2 class="hidden">some</h2>
            <div class="container-fluid">
                <div class="video-wrap overflow-hidden" style="max-height: 500px; text-align: center;">
                    <img src="{{ asset('frontend/undangan/preview/7.jpg') }}" alt="video" style="width: 100%;">
                    <a href="https://www.youtube.com/embed/VBf4dH-qGh8" class="video-btn" data-type="iframe"><i class="fi flaticon-play"></i></a>
                </div>
            </div>
        </section>
        <!-- end wpo-video-section-->

        <!-- start wpo-story-section -->
        <section class="wpo-story-section-s2 section-padding pb-0" id="story">
            <div class="container">
                <div class="wpo-section-title mb-3">
                    <h2 class="wow fadeInUp" data-wow-duration="1200ms" style="margin-top: 0px;">Cerita Cinta</h2>
                </div>
                <div class="wpo-story-wrap">
                    <div class="wpo-story-item">
                        <div class="wpo-story-img-wrap">
                            <div class="wpo-story-img floating-item wow fadeInLeftSlow" data-wow-duration="1700ms">
                                <img src="{{ asset('frontend/undangan/preview/12.jpg') }}" height="100%" alt="foto cerita">
                            </div>
                        </div>
                        <div class="wpo-story-content wow fadeInRightSlow" data-wow-duration="1700ms">
                            <div class="wpo-story-content-inner">
                                <h2>Pertemuan pertama</h2>
                                <span>12 Mei 2022</span>
                                <p>Pertemuan pertama kami berawal dari acara yang diselenggarakan kampus dan kami sebagai panitianya pada saat itu.</p>
                            </div>
                        </div>
                    </div>
                    <div class="wpo-story-item">
                        <div class="wpo-story-img-wrap">
                            <div class="wpo-story-img floating-item wow fadeInLeftSlow" data-wow-duration="1700ms">
                                <img src="{{ asset('frontend/undangan/preview/13.jpg') }}" height="100%" alt="foto cerita">
                            </div>
                        </div>
                        <div class="wpo-story-content wow fadeInRightSlow" data-wow-duration="1700ms">
                            <div class="wpo-story-content-inner">
                                <h2>Jadian</h2>
                                <span>12 Mei 2022</span>
                                <p>Tidak lama setelah pertemuan pertama, hubungan kami semakin lebih dekat dan kami sering bertemu sampai akhirnya memutuskan untuk jadian.</p>
                            </div>
                        </div>
                    </div>
                    <div class="wpo-story-item">
                        <div class="wpo-story-img-wrap">
                            <div class="wpo-story-img floating-item wow fadeInLeftSlow" data-wow-duration="1700ms">
                                <img src="{{ asset('frontend/undangan/preview/14.jpg') }}" height="100%" alt="foto cerita">
                            </div>
                        </div>
                        <div class="wpo-story-content wow fadeInRightSlow" data-wow-duration="1700ms">
                            <div class="wpo-story-content-inner">
                                <h2>Lamaran</h2>
                                <span>12 Mei 2022</span>
                                <p>3 tahun lebih menjalin hubungan dan kami mempunyai visi misi yang sama untuk membawa hubungan ini ke jenjang yg lebih serius, dengan mempertemukan keluarga besar kami untuk menentukan tanggal pernikahan.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end story-section -->

        <!-- start wpo-portfolio-section -->
        <section class="wpo-portfolio-section-s2 section-padding pb-0" id="gallery" style="padding-top: 60px;">
            <div class="container-fluid">
                <div class="wpo-section-title">
                    <h2 class="wow fadeInUp" data-wow-duration="1200ms" style="margin-top: 0px;">Galeri Foto</h2>
                </div>
                <div class="sortable-gallery wow zoomIn" data-wow-duration="1200ms">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="portfolio-grids gallery-container clearfix">
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/7.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/7.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/9.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/9.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/10.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/10.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/11.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/11.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/11.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/11.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/10.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/10.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/9.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/9.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/preview/7.jpg') }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/preview/7.jpg') }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end wpo-portfolio-section -->

        <!-- start of wpo-contact-section-s5 -->
        <section class="wpo-contact-section-s5 section-padding" id="rsvp">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col col-lg-12 col-md-12 col-12">
                        <div class="wpo-contact-section-wrapper wow slideInUp mx-auto" data-wow-duration="1200ms">
                            <div class="wpo-contact-section-inner">
                                <div class="wpo-contact-form-area" style="padding: 40px 10px">
                                    <div class="wpo-section-title">
                                        <div style="font-size: 18px; font-weight: bold;">Berikan ucapan dan kehadiran anda</div>
                                    </div>
                                    <form autocomplete="off">
                                        <div>
                                            <input type="text" class="form-control" placeholder="Nama Anda" required>
                                        </div>
                                        <div>
                                            <textarea class="form-control" placeholder="Ketik Ucapan & Doa" style="height: 80px;" required></textarea>
                                        </div>
                                        <div class="radio-buttons p-0">
                                            <p>
                                                <input type="radio" id="ya" name="kehadiran" checked>
                                                <label for="ya">Ya, saya akan hadir</label>
                                            </p>
                                            <p>
                                                <input type="radio" id="tidak" name="kehadiran">
                                                <label for="tidak">Maaf, saya tidak bisa hadir</label>
                                            </p>
                                            <p>
                                                <input type="radio" id="ragu" name="kehadiran">
                                                <label for="ragu">Saya belum yakin bisa hadir atau tidak</label>
                                            </p>
                                        </div>
                                        <div class="submit-area" style="margin-top: 20px;">
                                            <button class="btn btn-primary">Kirim</button>
                                            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#ucapanModal">
                                                Lihat Semua Ucapan
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-contact-section -->

        <!-- start wpo-event-section -->
        <section class="wpo-event-section section-padding pb-0" id="event" style="padding-top: 80px;">
            <div class="container">
                <div class="wpo-section-title">
                    <h2 class="wow fadeInUp" data-wow-duration="1200ms" style="margin-top: 0px;">Waktu & Tempat Acara</h2>
                </div>
                <div class="wpo-event-wrap wow slideInUp" data-wow-duration="1200ms">
                    <div class="row justify-content-center">
                        <div class="col col-lg-4 col-md-6 col-12">
                            <div class="wpo-event-item">
                                <div class="wpo-event-img">
                                    <img src="{{ asset('frontend/undangan/lovelove/images/event/wedding_1.jpg') }}" alt="wedding_1.jpg">
                                    <div class="title"><h2 style="font-weight: bold;">Akad Nikah</h2></div>
                                </div>
                                <div class="wpo-event-text">
                                    <ul>
                                        <li>Minggu, 26 Februari 2023 Pukul 08:00</li>
                                        <li style="font-weight: bold;">Hotel Grand Dafam Banjarbaru</li>
                                        <li>Q Mall, Jl. A. Yani No.km 36.8, Komet, Kec. Banjarbaru Utara, Kota Banjar Baru</li>
                                        <li><a href="https://goo.gl/maps/KnXQbcbrw6bprrjQA" target="_blank" class="btn btn-primary text-white">Buka Maps</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-4 col-md-6 col-12">
                            <div class="wpo-event-item">
                                <div class="wpo-event-img">
                                    <img src="{{ asset('frontend/undangan/lovelove/images/event/wedding_2.jpg') }}" alt="wedding_2.jpg">
                                    <div class="title"><h2 style="font-weight: bold;">Resepsi</h2></div>
                                </div>
                                <div class="wpo-event-text">
                                    <ul>
                                        <li>Minggu, 26 Februari 2023 Pukul 08:00</li>
                                        <li style="font-weight: bold;">Hotel Grand Dafam Banjarbaru</li>
                                        <li>Q Mall, Jl. A. Yani No.km 36.8, Komet, Kec. Banjarbaru Utara, Kota Banjar Baru</li>
                                        <li><a href="https://goo.gl/maps/KnXQbcbrw6bprrjQA" target="_blank" class="btn btn-primary text-white">Buka Maps</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end wpo-event-section -->

        <!-- start wpo-pricing-section -->
        <section class="wpo-pricing-section section-padding pb-5" id="gift" style="padding-top: 80px;">
            <div class="container">
                <div class="wpo-section-title mb-4">
                    <h2 class="wow fadeInUp" data-wow-duration="1200ms" style="margin-top: 0px;">Amplop Digital</h2>
                </div>
                <div class="wpo-pricing-wrap pt-0 pb-5 wow zoomIn" data-wow-duration="1200ms">
                    <div class="row">
                        <div class="col col-lg-6 col-md-6 col-12">
                            <div class="wpo-pricing-item">
                                <div class="wpo-pricing-top pb-1">
                                    <div class="wpo-pricing-text">
                                        <h4 style="font-weight: bold; padding-top: 16px;">Bank BNI</h4>
                                        <h2 style="font-size: 28px;" id="bank_1">1234567890</h2>
                                        <h4 class="pt-3">Malik Haryanto Budiman</h4>
                                    </div>
                                </div>
                                <div class="shape"><img src="{{ asset('frontend/undangan/lovelove/images/pricing/p-shape.svg') }}" alt=""></div>
                                <div class="wpo-pricing-bottom py-3">
                                    <div class="wpo-pricing-bottom-text">
                                        <button onclick="copyNoRekening('#bank_1')" class="btn btn-primary mb-2">Salin Nomor Rekening</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-6 col-md-6 col-12">
                            <div class="wpo-pricing-item">
                                <div class="wpo-pricing-top pb-1">
                                    <div class="wpo-pricing-text">
                                        <h4 style="font-weight: bold; padding-top: 16px;">Bank BCA</h4>
                                        <h2 style="font-size: 28px;" id="bank_2">0987654321</h2>
                                        <h4 class="pt-3">Malik Haryanto Budiman</h4>
                                    </div>
                                </div>
                                <div class="shape"><img src="{{ asset('frontend/undangan/lovelove/images/pricing/p-shape.svg') }}" alt=""></div>
                                <div class="wpo-pricing-bottom py-3">
                                    <div class="wpo-pricing-bottom-text">
                                        <button onclick="copyNoRekening('#bank_2')" class="btn btn-primary mb-2">Salin Nomor Rekening</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- start wpo-pricing-section -->

        <!-- wpo-site-footer start -->
        <div class="wpo-site-footer text-center" style="padding-top: 30px; padding-bottom: 30px;">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="copyright mt-0">
                            <p><a href="{{ url('/') }}">{{ $set_umum->value_3 }}. All Right Reserved.</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- wpo-site-footer end -->

    <!-- Modal -->
    <div class="modal fade show" id="fullwedding" style="display: block">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="modal-body" style="padding: 0px;">
                    <!-- start of hero -->
                    <section class="static-hero-s4" style="min-height: 650px;">
                        <div class="hero-container">
                            <div class="hero-inner" style="padding: 0px;">
                                <div class="container">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-12">
                                            <div class="wpo-event-item" style="padding: 0px; height: 650px; margin-top: 40px;">
                                                <div class="wpo-event-text">
                                                    <h2 style="font-weight: bold;">Malik & Belinda</h2>
                                                    <p style="font-size: 20px; margin-bottom: 10px; line-height: 24px;">Kepada yang terhormat Bapak/Ibu/Saudara/i :</p>
                                                    <p style="font-size: 25px; font-weight: bold; margin-bottom: 10px;">Tamu Undangan</p>
                                                    <button class="btn btn-primary btn-lg mb-2" id="bukaUndangan">Buka Undangan</button>
                                                    <p style="margin-bottom: 0px; font-size: 18px; line-height: 20px;">Mohon maaf jika ada kesalahan penulisan nama dan gelar</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- end of hero slider -->
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="ucapanModal" tabindex="-1" aria-labelledby="ucapanModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="ucapanModalLabel">Ucapan dari tamu undangan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-striped" width="100%" id="table_ucapan">
                            <thead>
                                <tr>
                                    <th style="text-align: center">Nama Tamu</th>
                                    <th style="text-align: center; width: 400px;">Ucapan Tamu</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style="text-align: center">Hamima Yuniar</td>
                                    <td>Selamat menempuh hidup baru dengan pujaan hatimu. Semoga cinta kalian bertumbuh setiap harinya.</td>
                                </tr>
                                <tr>
                                    <td style="text-align: center">Galang Prabowo</td>
                                    <td>Selamat atas pernikahannya, semoga menjadi titik perjalanan hidup bersama yang lebih membahagiakan.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <button class="button-musik"><i class="fa fa-pause"></i></button>
    <audio id="musik" src="{{ asset('frontend/undangan/musik/Musik 1.mp3') }}"></audio>
    <!-- All JavaScript files
    ================================================== -->
    <script src="{{ asset('frontend/undangan/lovelove/js/jquery.min.js') }}"></script>
    <!-- DataTables -->
    <script src="{{ asset('frontend/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('frontend/undangan/lovelove/js/bootstrap.bundle.min.js') }}"></script>
    <!-- Plugins for this template -->
    <script src="{{ asset('frontend/undangan/lovelove/js/modernizr.custom.js') }}"></script>
    <script src="{{ asset('frontend/undangan/lovelove/js/jquery.dlmenu.js') }}"></script>
    <script src="{{ asset('frontend/undangan/lovelove/js/jquery-plugin-collection.js') }}"></script>
    <!-- Custom script for this template -->
    <script src="{{ asset('frontend/libs/js/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('frontend/undangan/lovelove/js/script.js') }}"></script>
    <script type="text/javascript">
        let tanggalNikah = new Date();
        tanggalNikah.setDate(tanggalNikah.getDate() + 90);
        let tanggalNikahFormat = tanggalNikah.getFullYear() + '/' + (tanggalNikah.getMonth() + 1) + '/' + tanggalNikah.getDate() + ' 08:00:00';
        $('#clock').countdown(tanggalNikahFormat, function (event) {
            var $this = $(this).html(event.strftime(''
                + '<div class="box"><div><div class="time">%D</div> <span>Hari</span> </div></div>'
                + '<div class="box"><div><div class="time">%H</div> <span>Jam</span> </div></div>'
                + '<div class="box"><div><div class="time">%M</div> <span>Menit</span> </div></div>'
                + '<div class="box"><div><div class="time">%S</div> <span>Detik</span> </div></div>'));
        });

        $("#bukaUndangan").click(function () {
            $("#fullwedding").fadeToggle("slow");
            $("#musik")[0].play();
            $("#musik").on("ended", function() {
                this.currentTime = 0;
                this.play();
            });
            $(".button-musik").click(function() {
                if ($(this).find("i").hasClass("fa-play")) {
                    $("#musik")[0].play();
                    $(this).html('<i class="fa fa-pause"></i>');
                } else {
                    $("#musik")[0].pause();
                    $(this).html('<i class="fa fa-play"></i>');
                }
            });
        });
    </script>
    <!-- =======================================================
    * Template LoveLove: https://themeforest.net/item/lovelove-wedding-wedding-planner-html5-template/39643981
    * Image by: https://www.freepik.com/
    ======================================================== -->
</body>

</html>