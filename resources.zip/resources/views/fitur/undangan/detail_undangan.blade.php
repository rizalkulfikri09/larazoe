@extends('layouts.app_template')
@section('body')
<style>
    .form-group {
        font-size: 16px!important;
        padding: 0px!important;
    }
    .col_waktu {
        padding: 4px;
    }
    .card_mb {
        margin-bottom: 0px;
    }
    .text_waktu {
        margin: 15px 0px 15px 0px;
        font-size: 16px;
    }
    .pills-regular .nav.nav-pills .nav-item .nav-link {
        font-size: 14px;
    }
    #table_ucapan th:nth-child(3) {
        width: 200px!important;
    }
    #table_ucapan th:nth-child(2) {
        width: 100px!important;
    }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" integrity="sha512-cyzxRvewl+FOKTtpBzYjW6x6IAYUCZy3sGP40hn+DQkqeluGRCax7qztK2ImL64SA+C7kVWdLI6wvdlStawhyw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="{{ asset('frontend/vendor/summernote/css/summernote-bs4.css') }}">
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            @if (new DateTime($waktu_expired) > new DateTime("Now") && $undangan->status_bayar == "Belum Dibayar")
            <div class="alert alert-success" role="alert">
                <div class="row mb-2">
                    <div class="col-12 text-center" style="padding: 0px;">
                        <span style="font-weight: bold;">MOHON SEGERA MELAKUKAN PEMBAYARAN DALAM WAKTU</span>
                    </div>
                </div>
                <div class="row d-flex justify-content-center mb-2">
                    <div class="col-xl-2 col-4 col_waktu">
                        <div class="card card_mb">
                            <div class="card-content text-center"><h5 id="jam" class="text_waktu"></h5></div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-4 col_waktu">
                        <div class="card card_mb">
                            <div class="card-content text-center"><h5 id="menit" class="text_waktu"></h5></div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-4 col_waktu">
                        <div class="card card_mb">
                            <div class="card-content text-center"><h5 id="detik" class="text_waktu"></h5></div>
                        </div>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-12 text-center" style="padding: 0px;">
                        <span style="font-style: italic;">(Sebelum {{ Carbon::parse($waktu_expired)->translatedFormat('l d F Y') }} pukul {{ Carbon::parse($waktu_expired)->translatedFormat('H:i') }})</span>
                    </div>
                </div>
            </div>
            @endif
            <div class="tab-regular">
                <ul class="nav nav-tabs nav-fill" id="myTab7" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="satu-tab-justify" data-toggle="tab" href="#satu-justify" role="tab" aria-controls="satu" aria-selected="true">Undangan Anda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="dua-tab-justify" data-toggle="tab" href="#dua-justify" role="tab" aria-controls="dua" aria-selected="false">Pengaturan Undangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="tiga-tab-justify" data-toggle="tab" href="#tiga-justify" role="tab" aria-controls="tiga" aria-selected="false">Daftar Tamu & Ucapan</a>
                    </li>
                </ul>
                <div class="tab-content" style="padding: 20px;">
                    <div class="tab-pane fade show active" id="satu-justify" role="tabpanel" aria-labelledby="satu-tab-justify">
                        <div class="form-group row">
                            <div class="col-lg-3 col-6">Kode Undangan</div>
                            <div class="col-lg-9 col-6"><b>{{ $undangan->kode }}</b></div>
                        </div>
                        <div class="form-group row mt-3">
                            <div class="col-lg-3 col-6">Status Pembayaran</div>
                            <div class="col-lg-9 col-6"><b>{{ $undangan->status_bayar }}</b></div>
                        </div>
                        <div class="form-group row mt-3">
                            <div class="col-lg-3 col-6">Link Undangan<a href="javascript:void(0)" onclick="copyLink('#link_undangan')" class="ml-2"><i class="fa-solid fa-copy"></i></a></div>
                            <div class="col-lg-9 col-6" style="word-wrap: break-word;"><b><a href="{{ url('undangan',$undangan->link) }}" target="_blank" id="link_undangan">{{ url('undangan',$undangan->link) }}</a></b></div>
                        </div>
                        <div class="form-group row mt-3">
                            <div class="col-lg-3 col-6">Masa Aktif</div>
                            <div class="col-lg-9 col-6">{{ Carbon::parse($undangan->created_at)->addDays($undangan->paket->durasi)->translatedFormat('d F Y') }}</div>
                        </div>
                        <div class="form-group row mt-3">
                            <div class="col-lg-3 col-6">Status Undangan</div>
                            <div class="col-lg-9 col-6"><a href="{{ $undangan->status_bayar == 'Lunas' ? route('update_status_undangan', $undangan->kode) : "#" }}" class="btn btn-rounded btn-sm {{ $btn_status_undangan }}" data-toggle="tooltip" data-placement="top" title="Klik tombol ini untuk mengganti status undangan">{{ $status_undangan }}</a></div>
                        </div>
                        <div class="form-group row mt-3">
                            <div class="col m-t-10">
                                <!-- Start bagian pembayaran -->
                                @if (!isset($transaksi->no_ref) && $bank_1)
                                    <a href="{{ route('transfer_undangan', $undangan->kode) }}" class="btn btn-space btn-success">Upload Bukti Transfer</a>
                                @endif
                                @if (isset($transaksi->no_ref) && $undangan->status_bayar == 'Belum Dibayar')
                                    <a href="{{ url("$transaksi->link") }}" class="btn btn-space btn-danger">Selesaikan Pembayaran Anda</a>
                                @endif
                                <!-- End bagian pembayaran -->
                                @include('components.button_kembali', ['url' => route('riwayat_undangan')])
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="form-group">
                                    <label>Template Undangan</label>
                                    <select class="form-control selectpicker" name="template_undangan" id="template_undangan">
                                        <option value="syari" selected>Undangan Syar'i</option>
                                        <option value="formal">Undangan Formal</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Nomor WhatsApp Tamu</label>
                                    <input type="text" id="whatsapp_tamu" name="whatsapp_tamu" placeholder="Contoh : 081234567890 atau +62 812-3456-7890" class="form-control" data-toggle="tooltip" data-placement="top" title="Kosongkan kolom ini untuk undangan umum">
                                </div>
                                <div class="form-group">
                                    <label>Nama Tamu</label>
                                    <input type="text" id="nama_tamu" name="nama_tamu" placeholder="Isi nama tamu disini" class="form-control" data-toggle="tooltip" data-placement="top" title="Kosongkan kolom ini untuk undangan umum">
                                </div>
                                <div class="form-group">
                                    <label>Kalimat Undangan</label>
                                    <textarea type="text" id="kalimat_undangan" name="kalimat_undangan" class="form-control" rows="10" style="padding: 10px;"></textarea>
                                </div>
                                <div class="form-group">
                                    <a href="javascript:void(0)" target="_blank" class="btn btn-sm btn-success" id="kirim_whatsapp">Kirim Lewat WhatsApp</a>
                                    <button class="btn btn-sm btn-primary" id="salin_undangan">Salin</button>
                                    <button class="btn btn-sm btn-dark my-1" id="reset">Reset</button>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="form-group">
                                    <label>Link Undangan Untuk Tamu</label>
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" name="link_tamu" id="link_tamu" placeholder="">
                                        <div class="input-group-append">
                                            <button id="salin_link" class="btn btn-primary">Salin</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Share Undangan Ke Media Sosial</label><br>
                                    <button class="btn btn-primary" onclick="shareOnFacebook()"><i class="fab fa-facebook-f"></i> Facebook</button>
                                    <button class="btn btn-info" onclick="shareOnTwitter()"><i class="fab fa-twitter"></i> Twitter</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="dua-justify" role="tabpanel" aria-labelledby="dua-tab-justify">
                    @if ($undangan->status_bayar == "Lunas")
                        <div class="pills-regular">
                            <ul class="nav nav-pills nav-fill mb-1" id="pills-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="pills-satu-tab" data-toggle="pill" href="#pills-satu" role="tab" aria-controls="satu" aria-selected="true">Ubah Data Pengantin</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-dua-tab" data-toggle="pill" href="#pills-dua" role="tab" aria-controls="dua" aria-selected="false">Ubah Data Undangan</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-tiga-tab" data-toggle="pill" href="#pills-tiga" role="tab" aria-controls="tiga" aria-selected="false">Ubah Galeri Pengantin</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-empat-tab" data-toggle="pill" href="#pills-empat" role="tab" aria-controls="empat" aria-selected="false">Ubah Cerita Pengantin</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="pills-tabContent" style="border: none; padding: 20px 0px 0px 0px;">
                                <div class="tab-pane fade show active" id="pills-satu" role="tabpanel" aria-labelledby="pills-satu-tab">
                                <form enctype="multipart/form-data" action="{{ route('edit_data_pengantin', $undangan->kode) }}" method="post" autocomplete="off" class="form_input">
                                    @method('PUT')
                                    @csrf
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                            <div class="form-group">
                                                <label>Foto Pria</label>
                                                <div class="form-group">
                                                    <img data-src="{{ asset('frontend/undangan/foto_pengantin/'.$undangan->pengantin->foto_pria) }}" class="lazyload" id="foto_pria" width="310px" height="260px"/>
                                                </div>
                                                <div class="custom-file">
                                                    <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                        <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_pria" data-idfoto="foto_pria" data-base64="base64_foto_pria" data-typefoto="foto_pengantin">
                                                        <span class="file-custom">Pilih file...</span>
                                                    </label>
                                                </div>
                                                <input type="hidden" name="base64_foto_pria" id="base64_foto_pria">
                                            </div>
                                            <div class="form-group">
                                                <label>Nama Lengkap Pria</label>
                                                <input type="text" id="full_nama_pria" name="full_nama_pria" required="" placeholder="Contoh : Malik Haryanto Budiman" class="form-control @error('full_nama_pria') is-invalid @enderror" value="{{ old('full_nama_pria', $undangan->full_nama_pria) }}">
                                                @error('full_nama_pria')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label>Nama Panggilan Pria</label>
                                                <input type="text" id="nama_pria" name="nama_pria" required="" placeholder="Contoh : Malik" class="form-control @error('nama_pria') is-invalid @enderror" value="{{ old('nama_pria', $undangan->nama_pria) }}" onkeyup="linkUndangan()">
                                                @error('nama_pria')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label>Anak Keberapa?</label>
                                                <input type="text" id="anak_of_pria" name="anak_of_pria" required="" placeholder="Contoh : Putra ketiga dari" class="form-control @error('anak_of_pria') is-invalid @enderror" value="{{ old('anak_of_pria', $undangan->pengantin->anak_of_pria) }}">
                                                @error('anak_of_pria')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label>Nama Kedua Orang Tua Pria</label>
                                                <input type="text" id="ortu_pria" name="ortu_pria" required="" placeholder="Contoh : Bapak Kurnia Najmudin & Ibu Yani Mulyani" class="form-control @error('ortu_pria') is-invalid @enderror" value="{{ old('ortu_pria', $undangan->pengantin->ortu_pria) }}">
                                                @error('ortu_pria')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label>Akun Instagram Pria</label>
                                                <div class="form-group">
                                                    <div class="switch-button switch-button-success">
                                                        <input type="hidden" name="status_ig_pria" value="0">
                                                        <input type="checkbox" value="1" name="status_ig_pria" id="status_ig_pria" onchange="switchButton('status_ig_pria', '#ig_pria')" @checked($undangan->pengantin->ig_pria)><span>
                                                        <label for="status_ig_pria"></label></span>
                                                    </div>
                                                </div>
                                                <div class="input-group" id="ig_pria"><span class="input-group-prepend"><span class="input-group-text">www.instagram.com/</span></span>
                                                    <input type="text" name="ig_pria" placeholder="Username" class="form-control @error('ig_pria') is-invalid @enderror" value="{{ old('ig_pria', $undangan->pengantin->ig_pria) }}">
                                                    @error('ig_pria')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Akun Twitter Pria</label>
                                                <div class="form-group">
                                                    <div class="switch-button switch-button-success">
                                                        <input type="hidden" name="status_twitter_pria" value="0">
                                                        <input type="checkbox" value="1" name="status_twitter_pria" id="status_twitter_pria" onchange="switchButton('status_twitter_pria', '#twitter_pria')" @checked($undangan->pengantin->twitter_pria)><span>
                                                        <label for="status_twitter_pria"></label></span>
                                                    </div>
                                                </div>
                                                <div class="input-group" id="twitter_pria"><span class="input-group-prepend"><span class="input-group-text">www.twitter.com/</span></span>
                                                    <input type="text" name="twitter_pria" placeholder="Username" class="form-control @error('twitter_pria') is-invalid @enderror" value="{{ old('twitter_pria', $undangan->pengantin->twitter_pria) }}">
                                                    @error('twitter_pria')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Akun Facebook Pria</label>
                                                <div class="form-group">
                                                    <div class="switch-button switch-button-success">
                                                        <input type="hidden" name="status_fb_pria" value="0">
                                                        <input type="checkbox" value="1" name="status_fb_pria" id="status_fb_pria" onchange="switchButton('status_fb_pria', '#fb_pria')" @checked($undangan->pengantin->fb_pria)><span>
                                                        <label for="status_fb_pria"></label></span>
                                                    </div>
                                                </div>
                                                <div class="input-group" id="fb_pria"><span class="input-group-prepend"><span class="input-group-text">www.facebook.com/</span></span>
                                                    <input type="text" name="fb_pria" placeholder="Username" class="form-control @error('fb_pria') is-invalid @enderror" value="{{ old('fb_pria', $undangan->pengantin->fb_pria) }}">
                                                    @error('fb_pria')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                            <div class="form-group">
                                                <label>Foto Wanita</label>
                                                <div class="form-group">
                                                    <img data-src="{{ asset('frontend/undangan/foto_pengantin/'.$undangan->pengantin->foto_wanita) }}" class="lazyload" id="foto_wanita" width="310px" height="260px"/>
                                                </div>
                                                <div class="custom-file">
                                                    <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                        <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_wanita" data-idfoto="foto_wanita" data-base64="base64_foto_wanita" data-typefoto="foto_pengantin">
                                                        <span class="file-custom">Pilih file...</span>
                                                    </label>
                                                </div>
                                                <input type="hidden" name="base64_foto_wanita" id="base64_foto_wanita">
                                            </div>
                                            <div class="form-group">
                                                <label>Nama Lengkap Wanita</label>
                                                <input type="text" id="full_nama_wanita" name="full_nama_wanita" required="" placeholder="Contoh : Belinda Wulandari Mayasari" class="form-control @error('full_nama_wanita') is-invalid @enderror" value="{{ old('full_nama_wanita', $undangan->full_nama_wanita) }}">
                                                @error('full_nama_wanita')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label>Nama Panggilan Wanita</label>
                                                <input type="text" id="nama_wanita" name="nama_wanita" required="" placeholder="Contoh : Belinda" class="form-control @error('nama_wanita') is-invalid @enderror" value="{{ old('nama_wanita', $undangan->nama_wanita) }}" onkeyup="linkUndangan()">
                                                @error('nama_wanita')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label>Anak Keberapa?</label>
                                                <input type="text" id="anak_of_wanita" name="anak_of_wanita" required="" placeholder="Contoh : Putri pertama dari" class="form-control @error('anak_of_wanita') is-invalid @enderror" value="{{ old('anak_of_wanita', $undangan->pengantin->anak_of_wanita) }}">
                                                @error('anak_of_wanita')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label>Nama Kedua Orang Tua Wanita</label>
                                                <input type="text" id="ortu_wanita" name="ortu_wanita" required="" placeholder="Contoh : Bapak Hasim Hidayanto & Ibu Nadine Wastuti" class="form-control @error('ortu_wanita') is-invalid @enderror" value="{{ old('ortu_wanita', $undangan->pengantin->ortu_wanita) }}">
                                                @error('ortu_wanita')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label>Akun Instagram Wanita</label>
                                                <div class="form-group">
                                                    <div class="switch-button switch-button-success">
                                                        <input type="hidden" name="status_ig_wanita" value="0">
                                                        <input type="checkbox" value="1" name="status_ig_wanita" id="status_ig_wanita" onchange="switchButton('status_ig_wanita', '#ig_wanita')" @checked($undangan->pengantin->ig_wanita)><span>
                                                        <label for="status_ig_wanita"></label></span>
                                                    </div>
                                                </div>
                                                <div class="input-group" id="ig_wanita"><span class="input-group-prepend"><span class="input-group-text">www.instagram.com/</span></span>
                                                    <input type="text" name="ig_wanita" placeholder="Username" class="form-control @error('ig_wanita') is-invalid @enderror" value="{{ old('ig_wanita', $undangan->pengantin->ig_wanita) }}">
                                                    @error('ig_wanita')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Akun Twitter Wanita</label>
                                                <div class="form-group">
                                                    <div class="switch-button switch-button-success">
                                                        <input type="hidden" name="status_twitter_wanita" value="0">
                                                        <input type="checkbox" value="1" name="status_twitter_wanita" id="status_twitter_wanita" onchange="switchButton('status_twitter_wanita', '#twitter_wanita')" @checked($undangan->pengantin->twitter_wanita)><span>
                                                        <label for="status_twitter_wanita"></label></span>
                                                    </div>
                                                </div>
                                                <div class="input-group" id="twitter_wanita"><span class="input-group-prepend"><span class="input-group-text">www.twitter.com/</span></span>
                                                    <input type="text" name="twitter_wanita" placeholder="Username" class="form-control @error('twitter_wanita') is-invalid @enderror" value="{{ old('twitter_wanita', $undangan->pengantin->twitter_wanita) }}">
                                                    @error('twitter_wanita')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Akun Facebook Wanita</label>
                                                <div class="form-group">
                                                    <div class="switch-button switch-button-success">
                                                        <input type="hidden" name="status_fb_wanita" value="0">
                                                        <input type="checkbox" value="1" name="status_fb_wanita" id="status_fb_wanita" onchange="switchButton('status_fb_wanita', '#fb_wanita')" @checked($undangan->pengantin->fb_wanita)><span>
                                                        <label for="status_fb_wanita"></label></span>
                                                    </div>
                                                </div>
                                                <div class="input-group" id="fb_wanita"><span class="input-group-prepend"><span class="input-group-text">www.facebook.com/</span></span>
                                                    <input type="text" name="fb_wanita" placeholder="Username" class="form-control @error('fb_wanita') is-invalid @enderror" value="{{ old('fb_wanita', $undangan->pengantin->fb_wanita) }}">
                                                    @error('fb_wanita')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12 col-sm-6 m-t-10">
                                            <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                            @include('components.button_kembali', ['url' => route('riwayat_undangan')])
                                        </div>
                                    </div>
                                </form>
                                </div>
                                <div class="tab-pane fade" id="pills-dua" role="tabpanel" aria-labelledby="pills-dua-tab">
                                <form enctype="multipart/form-data" action="{{ route('edit_data_undangan', $undangan->kode) }}" method="post" autocomplete="off" class="form_input">
                                    @method('PUT')
                                    @csrf
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                            <div class="form-group" data-toggle="tooltip" data-placement="top" title="Digunakan untuk countdown">
                                                <label>Tanggal Dan Jam Pernikahan</label>
                                                <input placeholder="Contoh : 2022-12-15 21:00" type="text" name="tanggal_nikah" class="datetimepicker-input form-control @error('tanggal_nikah') is-invalid @enderror" id="tanggal_nikah" data-toggle="datetimepicker" data-target="#tanggal_nikah" required>
                                                @error('tanggal_nikah')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label>Kalimat Pembuka</label>
                                                <textarea type="text" id="kalimat_pembuka" name="kalimat_pembuka" class="form-control @error('kalimat_pembuka') is-invalid @enderror" rows="5" required>{{ old('kalimat_pembuka', $undangan->slider->kalimat_pembuka) }}</textarea>
                                                @error('kalimat_pembuka')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                            <div class="form-group">
                                                <label>Status Video</label>
                                                <div class="form-group">
                                                    <div class="switch-button switch-button-success">
                                                        <input type="hidden" name="status_link_youtube" value="0">
                                                        <input type="checkbox" value="1" name="status_link_youtube" id="status_link_youtube" onchange="switchButton('status_link_youtube', '#form_link_youtube')" @checked($undangan->slider->link_youtube)><span>
                                                        <label for="status_link_youtube"></label></span>
                                                    </div>
                                                </div>
                                                <div class="form-group" id="form_link_youtube">
                                                    <label>Link Video Dari Youtube</label>
                                                    <textarea type="text" id="link_youtube" name="link_youtube" class="form-control @error('link_youtube') is-invalid @enderror" rows="3" placeholder="Paste link youtube disini, contoh : https://youtu.be/VBf4dH-qGh8">{{ old('link_youtube', $undangan->slider->link_youtube) }}</textarea>
                                                    @error('link_youtube')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        @foreach ($undangan->tempat as $tempat)
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                            <div class="form-group">
                                                <label>Nama Acara</label>
                                                <input type="hidden" name="tempat_{{ $loop->iteration }}" value="{{ $tempat->id }}">
                                                <input type="text" id="nama_acara_{{ $loop->iteration }}" name="nama_acara_{{ $loop->iteration }}" placeholder="Contoh : Akad Nikah" class="form-control" value="{{ old("nama_acara_$loop->iteration", $tempat->nama_acara) }}">
                                            </div>
                                            <div class="form-group">
                                                <label>Tanggal Acara</label>
                                                <input type="text" id="tanggal_acara_{{ $loop->iteration }}" name="tanggal_acara_{{ $loop->iteration }}" placeholder="Contoh : 2022-12-15 21:00" class="datetimepicker-input form-control" data-toggle="datetimepicker" data-target="#tanggal_acara_{{ $loop->iteration }}">
                                            </div>
                                            <div class="form-group">
                                                <label>Tempat Acara</label>
                                                <input type="text" id="tempat_acara_{{ $loop->iteration }}" name="tempat_acara_{{ $loop->iteration }}" placeholder="Contoh : Hotel Grand Dafam Banjarbaru" class="form-control" value="{{ old("tempat_acara_$loop->iteration", $tempat->tempat_acara) }}">
                                            </div>
                                            <div class="form-group">
                                                <label>Alamat Acara</label>
                                                <textarea type="text" id="alamat_acara_{{ $loop->iteration }}" name="alamat_acara_{{ $loop->iteration }}" class="form-control" rows="3" placeholder="Contoh : Q Mall, Jl. A. Yani No.km 36.8, Komet, Kec. Banjarbaru Utara, Kota Banjar Baru">{{ old("alamat_acara_$loop->iteration", $tempat->alamat_acara) }}</textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Link Google Maps Acara</label>
                                                <textarea type="text" id="link_maps_{{ $loop->iteration }}" name="link_maps_{{ $loop->iteration }}" class="form-control" rows="3" placeholder="Paste link google maps disini, contoh : https://goo.gl/maps/KnXQbcbrw6bprrjQA">{{ old("link_maps_$loop->iteration", $tempat->link_maps) }}</textarea>
                                            </div>
                                        </div>
                                        @endforeach
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                            <div class="form-group">
                                                <label>Status Foto Slider</label>
                                                <div class="form-group">
                                                    <div class="switch-button switch-button-success">
                                                        <input type="hidden" name="status_slider" value="0">
                                                        <input type="checkbox" value="1" name="status_slider" id="status_slider" onchange="switchButton('status_slider', '.form_foto_slider')" @checked($undangan->slider->status_slider == 1)><span>
                                                        <label for="status_slider"></label></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form_foto_slider">
                                                <div class="form-group">
                                                    <label>Title Foto 1</label>
                                                    <input type="text" id="title_slider_1" name="title_slider_1" placeholder="Contoh : Love" class="form-control" value="{{ old('title_slider_1', $undangan->slider->title_slider_1) }}" data-toggle="tooltip" data-placement="top" title="Kolom ini tidak wajib diisi, bisa dikosongkan">
                                                </div>
                                                <div class="form-group">
                                                    <label>Foto Slider 1</label>
                                                    <div class="form-group">
                                                        <img data-src="{{ !empty($undangan->slider->foto_slider_1) ? asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_1) : asset('frontend/undangan/lovelove/images/default_img.jpg') }}" class="lazyload" id="foto_slider_1" width="60%"/>
                                                    </div>
                                                    <div class="custom-file">
                                                        <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                            <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_slider_1" data-idfoto="foto_slider_1" data-base64="base64_slider_1" data-typefoto="foto_slider">
                                                            <span class="file-custom">Pilih file...</span>
                                                        </label>
                                                    </div>
                                                    <input type="hidden" name="base64_slider_1" id="base64_slider_1">
                                                </div>
                                                <div class="form-group">
                                                    <label>Title Foto 2</label>
                                                    <input type="text" id="title_slider_2" name="title_slider_2" placeholder="Contoh : Happy" class="form-control" value="{{ old('title_slider_2', $undangan->slider->title_slider_2) }}" data-toggle="tooltip" data-placement="top" title="Kolom ini tidak wajib diisi, bisa dikosongkan">
                                                </div>
                                                <div class="form-group">
                                                    <label>Foto Slider 2</label>
                                                    <div class="form-group">
                                                        <img data-src="{{ !empty($undangan->slider->foto_slider_2) ? asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_2) : asset('frontend/undangan/lovelove/images/default_img.jpg') }}" class="lazyload" id="foto_slider_2" width="60%"/>
                                                    </div>
                                                    <div class="custom-file">
                                                        <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                            <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_slider_2" data-idfoto="foto_slider_2" data-base64="base64_slider_2" data-typefoto="foto_slider">
                                                            <span class="file-custom">Pilih file...</span>
                                                        </label>
                                                    </div>
                                                    <input type="hidden" name="base64_slider_2" id="base64_slider_2">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 form_foto_slider">
                                            <div class="form-group">
                                                <label>Title Foto 3</label>
                                                <input type="text" id="title_slider_3" name="title_slider_3" placeholder="Contoh : Sweet" class="form-control" value="{{ old('title_slider_3', $undangan->slider->title_slider_3) }}" data-toggle="tooltip" data-placement="top" title="Kolom ini tidak wajib diisi, bisa dikosongkan">
                                            </div>
                                            <div class="form-group">
                                                <label>Foto Slider 3</label>
                                                <div class="form-group">
                                                    <img data-src="{{ !empty($undangan->slider->foto_slider_3) ? asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_3) : asset('frontend/undangan/lovelove/images/default_img.jpg') }}" class="lazyload" id="foto_slider_3" width="60%"/>
                                                </div>
                                                <div class="custom-file">
                                                    <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                        <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_slider_3" data-idfoto="foto_slider_3" data-base64="base64_slider_3" data-typefoto="foto_slider">
                                                        <span class="file-custom">Pilih file...</span>
                                                    </label>
                                                </div>
                                                <input type="hidden" name="base64_slider_3" id="base64_slider_3">
                                            </div>
                                            <div class="form-group">
                                                <label>Title Foto 4</label>
                                                <input type="text" id="title_slider_4" name="title_slider_4" placeholder="Contoh : Friendship" class="form-control" value="{{ old('title_slider_4', $undangan->slider->title_slider_4) }}" data-toggle="tooltip" data-placement="top" title="Kolom ini tidak wajib diisi, bisa dikosongkan">
                                            </div>
                                            <div class="form-group">
                                                <label>Foto Slider 4</label>
                                                <div class="form-group">
                                                    <img data-src="{{ !empty($undangan->slider->foto_slider_4) ? asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_4) : asset('frontend/undangan/lovelove/images/default_img.jpg') }}" class="lazyload" id="foto_slider_4" width="60%"/>
                                                </div>
                                                <div class="custom-file">
                                                    <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                        <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_slider_4" data-idfoto="foto_slider_4" data-base64="base64_slider_4" data-typefoto="foto_slider">
                                                        <span class="file-custom">Pilih file...</span>
                                                    </label>
                                                </div>
                                                <input type="hidden" name="base64_slider_4" id="base64_slider_4">
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        @foreach ($undangan->tempat as $rekening)
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                            <div class="form-group">
                                                <label>Status Amplop Digital</label>
                                                <div class="form-group">
                                                    <div class="switch-button switch-button-success">
                                                        <input type="hidden" name="status_bank_{{ $loop->iteration }}" value="0">
                                                        <input type="checkbox" value="1" name="status_bank_{{ $loop->iteration }}" id="status_bank_{{ $loop->iteration }}" onchange='switchButton("status_bank_{{ $loop->iteration }}", "#form_bank_{{ $loop->iteration }}")' @checked($rekening->nama_bank)><span>
                                                        <label for="status_bank_{{ $loop->iteration }}"></label></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="form_bank_{{ $loop->iteration }}">
                                                <div class="form-group">
                                                    <label>Nama Bank {{ $loop->iteration }}</label>
                                                    <input type="text" id="nama_bank_{{ $loop->iteration }}" name="nama_bank_{{ $loop->iteration }}" placeholder="Contoh : Bank BNI" class="form-control" value="{{ old("nama_bank_$loop->iteration", $rekening->nama_bank) }}">
                                                </div>
                                                <div class="form-group">
                                                    <label>Nomor Rekening {{ $loop->iteration }}</label>
                                                    <input type="text" id="nomor_rekening_{{ $loop->iteration }}" name="nomor_rekening_{{ $loop->iteration }}" placeholder="Contoh : 1234567890" class="form-control" value="{{ old("nomor_rekening_$loop->iteration", $rekening->nomor_rekening) }}">
                                                </div>
                                                <div class="form-group">
                                                    <label>Pemilik Rekening {{ $loop->iteration }}</label>
                                                    <input type="text" id="pemilik_rekening_{{ $loop->iteration }}" name="pemilik_rekening_{{ $loop->iteration }}" placeholder="Contoh : Malik Haryanto Budiman" class="form-control" value="{{ old("pemilik_rekening_$loop->iteration", $rekening->pemilik_rekening) }}">
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                            <div class="form-group">
                                                <label>Status Backsound</label>
                                                <div class="form-group">
                                                    <div class="switch-button switch-button-success">
                                                        <input type="hidden" name="status_musik" value="0">
                                                        <input type="checkbox" value="1" name="status_musik" id="status_musik" onchange='switchButton("status_musik", "#form_musik")' @checked($undangan->slider->musik)><span>
                                                        <label for="status_musik"></label></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                            <div id="form_musik">
                                                <div class="form-group">
                                                    <label>Pilih Backsound</label>
                                                    <select class="form-control selectpicker" name="musik" id="musik">
                                                        @foreach ($daftar_musik as $key => $musik)
                                                            <option value="{{ $key }}" @selected($undangan->slider->musik == $key)>{{ $musik }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <audio controls preload="none">
                                                        <source src="" type="audio/mpeg">
                                                    </audio>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12 col-sm-6 m-t-10">
                                            <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                            @include('components.button_kembali', ['url' => route('riwayat_undangan')])
                                        </div>
                                    </div>
                                </form>
                                </div>
                                <div class="tab-pane fade" id="pills-tiga" role="tabpanel" aria-labelledby="pills-tiga-tab">
                                    <form enctype="multipart/form-data" action="{{ route('edit_data_galeri', $undangan->kode) }}" method="post" autocomplete="off" class="form_input">
                                        @method('PUT')
                                        @csrf
                                        <div class="row">
                                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                                <div class="form-group">
                                                    <div class="row">
                                                        @for ($i = 0; $i < 10; $i++)
                                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12 pb-4">
                                                            <label>Foto {{ $i + 1 }}</label>
                                                            <div class="form-group">
                                                                <img data-src="{{ isset($undangan->galeri[$i]->foto) ? asset('frontend/undangan/foto_galeri/'.$undangan->galeri[$i]->foto) : asset('frontend/undangan/lovelove/images/default_img.jpg') }}" class="lazyload" id="foto_{{ $i + 1 }}" width="100%"/>
                                                            </div>
                                                            <div class="custom-file">
                                                                <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                                    <input type="hidden" name="id_foto_{{ $i + 1 }}" value="{{ isset($undangan->galeri[$i]->id) ? $undangan->galeri[$i]->id : '' }}">
                                                                    <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_{{ $i + 1 }}" data-idfoto="foto_{{ $i + 1 }}" data-base64="base64_foto_{{ $i + 1 }}" data-typefoto="foto_galeri">
                                                                    <span class="file-custom">Pilih file...</span>
                                                                </label>
                                                            </div>
                                                            @if (isset($undangan->galeri[$i]->id))
                                                                <a href="{{ route('delete_fg',['kode' => $undangan->kode, 'id' => $undangan->galeri[$i]->id]) }}" class="btn btn-sm btn-danger mt-3 deleteGaleri">Hapus</a>
                                                            @endif
                                                            <input type="hidden" name="base64_foto_{{ $i + 1 }}" id="base64_foto_{{ $i + 1 }}">
                                                        </div>
                                                        @endfor
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xl-12 col-sm-6">
                                                <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                                @include('components.button_kembali', ['url' => route('riwayat_undangan')])
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane fade" id="pills-empat" role="tabpanel" aria-labelledby="pills-empat-tab">
                                    <form enctype="multipart/form-data" action="{{ route('edit_data_cerita', $undangan->kode) }}" method="post" autocomplete="off" class="form_input">
                                        @method('PUT')
                                        @csrf
                                        <div class="row">
                                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                                <div class="form-group">
                                                    <label>Judul Cerita 1</label>
                                                    <input type="text" id="judul_cerita_1" name="judul_cerita_1" placeholder="Contoh : Pertemuan pertama" class="form-control" value='{{ old("judul_cerita_1", isset($undangan->cerita[0]->judul_cerita) ? $undangan->cerita[0]->judul_cerita : '') }}' required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Isi Cerita 1</label>
                                                    <textarea type="text" id="isi_cerita_1" name="isi_cerita_1" class="form-control" rows="5" placeholder="Contoh : Pertemuan pertama kami berawal dari acara yang diselenggarakan kampus dan kami sebagai panitianya pada saat itu." required>{{ old("isi_cerita_1", isset($undangan->cerita[0]->isi_cerita) ? $undangan->cerita[0]->isi_cerita : '') }}</textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label>Waktu Cerita 1</label>
                                                    <input type="text" id="waktu_cerita_1" name="waktu_cerita_1" placeholder="Contoh : 2020 / Mei 2020 / 12 Mei 2020" class="form-control" value='{{ old("waktu_cerita_1", isset($undangan->cerita[0]->waktu_cerita) ? $undangan->cerita[0]->waktu_cerita : '') }}' required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Upload Foto 1</label>
                                                    <div class="form-group">
                                                        <img data-src="{{ isset($undangan->cerita[0]->foto_cerita) ? asset('frontend/undangan/foto_cerita/'.$undangan->cerita[0]->foto_cerita) : asset('frontend/undangan/lovelove/images/default_img.jpg')  }}" class="lazyload" id="foto_cerita_1" width="70%"/>
                                                    </div>
                                                    <div class="custom-file">
                                                        <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                            <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_cerita_1" data-idfoto="foto_cerita_1" data-base64="base64_cerita_1" data-typefoto="foto_cerita">
                                                            <span class="file-custom">Pilih file...</span>
                                                        </label>
                                                    </div>
                                                    @if (isset($undangan->cerita[0]->id))
                                                        <a href="{{ route('delete_cp',['kode' => $undangan->kode, 'id' => $undangan->cerita[0]->id]) }}" class="btn btn-sm btn-danger mt-3 deleteCerita">Hapus</a>
                                                    @endif
                                                    <input type="hidden" name="id_cerita_1" value="{{ isset($undangan->cerita[0]->id) ? $undangan->cerita[0]->id : '' }}">
                                                    <input type="hidden" name="base64_cerita_1" id="base64_cerita_1">
                                                </div>
                                                <hr>
                                                <div class="form-group">
                                                    <label>Judul Cerita 2</label>
                                                    <input type="text" id="judul_cerita_2" name="judul_cerita_2" placeholder="Contoh : Jadian" class="form-control" value='{{ old("judul_cerita_2", isset($undangan->cerita[1]->judul_cerita) ? $undangan->cerita[1]->judul_cerita : '') }}' required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Isi Cerita 2</label>
                                                    <textarea type="text" id="isi_cerita_2" name="isi_cerita_2" class="form-control" rows="5" placeholder="Contoh : Tidak lama setelah pertemuan pertama, hubungan kami semakin lebih dekat dan kami sering bertemu sampai akhirnya memutuskan untuk jadian." required>{{ old("isi_cerita_2", isset($undangan->cerita[1]->isi_cerita) ? $undangan->cerita[1]->isi_cerita : '') }}</textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label>Waktu Cerita 2</label>
                                                    <input type="text" id="waktu_cerita_2" name="waktu_cerita_2" placeholder="Contoh : 2020 / Mei 2020 / 12 Mei 2020" class="form-control" value='{{ old("waktu_cerita_2", isset($undangan->cerita[1]->waktu_cerita) ? $undangan->cerita[1]->waktu_cerita : '') }}' required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Upload Foto 2</label>
                                                    <div class="form-group">
                                                        <img data-src="{{ isset($undangan->cerita[1]->foto_cerita) ? asset('frontend/undangan/foto_cerita/'.$undangan->cerita[1]->foto_cerita) : asset('frontend/undangan/lovelove/images/default_img.jpg')  }}" class="lazyload" id="foto_cerita_2" width="70%"/>
                                                    </div>
                                                    <div class="custom-file">
                                                        <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                            <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_cerita_2" data-idfoto="foto_cerita_2" data-base64="base64_cerita_2" data-typefoto="foto_cerita">
                                                            <span class="file-custom">Pilih file...</span>
                                                        </label>
                                                    </div>
                                                    @if (isset($undangan->cerita[1]->id))
                                                        <a href="{{ route('delete_cp',['kode' => $undangan->kode, 'id' => $undangan->cerita[1]->id]) }}" class="btn btn-sm btn-danger mt-3 deleteCerita">Hapus</a>
                                                    @endif
                                                    <input type="hidden" name="id_cerita_2" value="{{ isset($undangan->cerita[1]->id) ? $undangan->cerita[1]->id : '' }}">
                                                    <input type="hidden" name="base64_cerita_2" id="base64_cerita_2">
                                                </div>
                                                <hr>
                                                <div class="form-group">
                                                    <label>Judul Cerita 3</label>
                                                    <input type="text" id="judul_cerita_3" name="judul_cerita_3" placeholder="Contoh : Lamaran" class="form-control" value='{{ old("judul_cerita_3", isset($undangan->cerita[2]->judul_cerita) ? $undangan->cerita[2]->judul_cerita : '') }}' required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Isi Cerita 3</label>
                                                    <textarea type="text" id="isi_cerita_3" name="isi_cerita_3" class="form-control" rows="5" placeholder="Contoh : 3 tahun lebih menjalin hubungan dan kami mempunyai visi misi yang sama untuk membawa hubungan ini ke jenjang yg lebih serius, dengan mempertemukan keluarga besar kami untuk menentukan tanggal pernikahan." required>{{ old("isi_cerita_3", isset($undangan->cerita[2]->isi_cerita) ? $undangan->cerita[2]->isi_cerita : '') }}</textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label>Waktu Cerita 3</label>
                                                    <input type="text" id="waktu_cerita_3" name="waktu_cerita_3" placeholder="Contoh : 2020 / Mei 2020 / 12 Mei 2020" class="form-control" value='{{ old("waktu_cerita_3", isset($undangan->cerita[2]->waktu_cerita) ? $undangan->cerita[2]->waktu_cerita : '') }}' required>
                                                </div>
                                                <div class="form-group">
                                                    <label>Upload Foto 3</label>
                                                    <div class="form-group">
                                                        <img data-src="{{ isset($undangan->cerita[2]->foto_cerita) ? asset('frontend/undangan/foto_cerita/'.$undangan->cerita[2]->foto_cerita) : asset('frontend/undangan/lovelove/images/default_img.jpg')  }}" class="lazyload" id="foto_cerita_3" width="70%"/>
                                                    </div>
                                                    <div class="custom-file">
                                                        <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                            <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_cerita_3" data-idfoto="foto_cerita_3" data-base64="base64_cerita_3" data-typefoto="foto_cerita">
                                                            <span class="file-custom">Pilih file...</span>
                                                        </label>
                                                    </div>
                                                    @if (isset($undangan->cerita[2]->id))
                                                        <a href="{{ route('delete_cp',['kode' => $undangan->kode, 'id' => $undangan->cerita[2]->id]) }}" class="btn btn-sm btn-danger mt-3 deleteCerita">Hapus</a>
                                                    @endif
                                                    <input type="hidden" name="id_cerita_3" value="{{ isset($undangan->cerita[2]->id) ? $undangan->cerita[2]->id : '' }}">
                                                    <input type="hidden" name="base64_cerita_3" id="base64_cerita_3">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xl-12 col-sm-6 m-t-10">
                                                <button type="submit" class="btn btn-space btn-primary">Simpan</button>
                                                @include('components.button_kembali', ['url' => route('riwayat_undangan')])
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @else
                        <p style="text-align: center; font-size: 16px;">Anda dapat mengubah data undangan setelah menyelesaikan pembayaran</p>
                    @endif
                    </div>
                    <div class="tab-pane fade" id="tiga-justify" role="tabpanel" aria-labelledby="tiga-tab-justify">
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                <div class="card bg-success">
                                    <div class="card-body">
                                        <h4 class="text-white" style="margin-bottom: 10px;">Tamu Hadir</h4>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1 text-white">{{ $tamu_hadir }}</h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                <div class="card bg-secondary">
                                    <div class="card-body">
                                        <h4 class="text-white" style="margin-bottom: 10px;">Tamu Tidak Hadir</h4>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1 text-white">{{ $tamu_tidak_hadir }}</h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                <div class="card bg-primary">
                                    <div class="card-body">
                                        <h4 class="text-white" style="margin-bottom: 10px;">Belum Yakin Hadir</h4>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1 text-white">{{ $tamu_belum_yakin }}</h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered" width="99%" id="table_ucapan">
                                <thead>
                                    <tr>
                                        <th class="colomnSize">No</th>
                                        <th>Nama Tamu</th>
                                        <th>Ucapan Tamu</th>
                                        <th class="colomnSize">Status Kehadiran</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade imagecrop" id="exampleModal" tabindex="-1" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body" style="padding-bottom: 0px;">
                <div class="form-group">
                    <div id="container-crop" style="height: 500px;">
                        <img id="image" src="" />
                        <div id="preview"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="idfoto"><input type="hidden" id="base64"><input type="hidden" id="typefoto">
                <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                <button type="button" class="btn btn-primary" id="crop">Crop</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js" integrity="sha512-6lplKUSl86rUVprDIjiW8DuOniNX8UDoRATqZSds/7t6zCQZfaCe3e5zcGaQwxa8Kpn5RTM9Fvl3X2lLV4grPQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="{{ asset('frontend/vendor/summernote/js/summernote-bs4.js') }}"></script>
<script src="{{ asset('frontend/libs/js/loadingSimpan.js') }}"></script>
<script type="text/javascript">
    countdown_bayar("{{ $waktu_expired }}", 'jam', 'menit', 'detik');
    function countdown_bayar(data, jam, menit, detik) {
        var timer = setInterval(function() {
            var end = new Date(data);
            var now = new Date();
            var status_pembayaran = "{{ $undangan->status_bayar }}";
            var distance = end - now;
            var distance1 = now - end;
            if(distance1 > 0 || status_pembayaran == "Lunas") {
                clearInterval(timer);
                return;
            }
            var hours = Math.floor(distance / 3600000);
            var minutes = Math.floor((distance % 3600000) / 60000);
            var seconds = Math.floor((distance % 60000) / 1000);
            document.getElementById(jam).innerHTML = hours + ' Jam';
            document.getElementById(menit).innerHTML = minutes + ' Menit';
            document.getElementById(detik).innerHTML = seconds + ' Detik';
        }, 1000);
    }

    $(document).ready(function(){
        function toggleForm(statusId, formId) {
            if ($("#" + statusId).is(':checked')) {
                $(formId).show();
            } else {
                $(formId).hide();
            }
        }
        toggleForm("status_bank_1", "#form_bank_1");
        toggleForm("status_bank_2", "#form_bank_2");
        toggleForm("status_musik", "#form_musik");
        toggleForm("status_link_youtube", "#form_link_youtube");
        toggleForm("status_slider", ".form_foto_slider");
        toggleForm("status_ig_pria", "#ig_pria");
        toggleForm("status_twitter_pria", "#twitter_pria");
        toggleForm("status_fb_pria", "#fb_pria");
        toggleForm("status_ig_wanita", "#ig_wanita");
        toggleForm("status_twitter_wanita", "#twitter_wanita");
        toggleForm("status_fb_wanita", "#fb_wanita");
    });

    function switchButton(value, key) {
        if ($('#'+value).is(':checked')) {
            $(key).show();
        } else {
            $(key).hide();
        }
    };

    function copyLink(element) {
        Swal.fire({
            position: 'center',
            icon: 'success',
            html: '<div style="font-size: 20px; font-weight: bold;">Link undangan berhasil disalin</div>',
            showConfirmButton: false,
            width: '30em',
            timer: 1500
        });
        var $input = $("<input>");
        $("body").append($input);
        $input.val($(element).text()).select();
        document.execCommand("copy");
        $input.remove();
    }

    $(function () {
        $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.fn.dataTable.ext.classes.sPageButton = 'btn btn-dark';
        var table = $('#table_ucapan').DataTable({
            language: {
                "infoFiltered": "",
                "zeroRecords": "Daftar tamu & ucapan masih kosong"
            },
            searchDelay: 500,
            processing: true,
            serverSide: true,
            ajax: "{{ route('detail_undangan', $undangan->kode) }}",
            columns: [
                { data: 'DT_RowIndex' },
                { data: 'nama_tamu', name: 'nama_tamu' },
                { data: 'ucapan', name: 'ucapan' },
                { data: 'kehadiran', name: 'kehadiran' },
            ],
            "bFilter": false,
            "bLengthChange": false,
            "bInfo": false,
            "aoColumnDefs": [
                { "bSortable": false, "aTargets": [0,2] },
                { "className": "text-center", "targets" : [0,3] },
            ],
            "aaSorting": [],
        });
    });

    var $modal = $('.imagecrop');
    var image = document.getElementById('image');
    var cropper;
    var cropperConfig = {
        foto_galeri: {
            checkOrientation: false,
            preview: '#preview',
            viewMode: 1,
        },
        foto_pengantin: {
            checkOrientation: false,
            preview: '#preview',
            viewMode: 1,
            aspectRatio: 1.2,
            width: 609,
            height: 505,
        },
        foto_slider: {
            checkOrientation: false,
            preview: '#preview',
            viewMode: 1,
            aspectRatio: "{{ $aspect_ratio }}",
            width: "{{ $width_slider }}",
            height: "{{ $height_slider }}",
        },
        foto_cerita: {
            checkOrientation: false,
            preview: '#preview',
            viewMode: 1,
            aspectRatio: 1.1796,
            width: 591,
            height: 501,
        },
    };
    $("body").on("change", ".imageUpload", function(e){
        $('#idfoto').val($(this).data('idfoto'));
        $('#base64').val($(this).data('base64'));
        $('#typefoto').val($(this).data('typefoto'));
        var files = e.target.files;
        var done = function(url) {
            image.src = url;
            $modal.modal('show');
        };
        var reader;
        var file;
        var url;
        if (files && files.length > 0) {
            file = files[0];
            if (FileReader) {
                reader = new FileReader();
                reader.onload = function(e) {
                    done(reader.result);
                };
                reader.readAsDataURL(file);
            } else if (URL) {
                done(URL.createObjectURL(file));
            }
        }
    });
    $modal.on('shown.bs.modal', function() {
        var typefoto = $('#typefoto').val();
        var config = cropperConfig[typefoto];
        cropper = new Cropper(image, {
            viewMode: config.viewMode,
            aspectRatio: config.aspectRatio,
            ready: function () {
                cropper.setCropBoxData({
                    width: config.width,
                    height: config.height,
                });
            },
        });
        $("body").on("click", "#crop", function() {
            canvas = cropper.getCroppedCanvas({
                maxWidth: 1200,
                maxHeight: 1200,
            });
            var idfoto = $('#idfoto').val();
            var base64 = $('#base64').val();
            var base64data = canvas.toDataURL('image/jpeg', 0.8);
            $('#'+base64).val(base64data);
            document.getElementById(idfoto).src = base64data;
            $modal.modal('hide');
        });
    }).on('hidden.bs.modal', function() {
        cropper.destroy();
        cropper = null;
    });

    $(function() {
        var tanggal_nikah = "{{ old('tanggal_nikah', $undangan->slider->tanggal_nikah) }}";
        $('#tanggal_nikah').datetimepicker({
            defaultDate: tanggal_nikah,
            minDate: new Date(moment()).setHours(0,0,0,0),
            format: 'YYYY-MM-DD HH:mm',
            orientation: 'bottom',
            icons: {
                time: "far fa-clock",
                date: "fa fa-calendar-alt",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down"
            }
        });
    });

    $(function() {
        var tanggal_acara_1 = "{{ old('tanggal_acara_1', $undangan->tempat[0]->tanggal_acara) }}";
        $('#tanggal_acara_1').datetimepicker({
            defaultDate: tanggal_acara_1,
            minDate: new Date(moment()).setHours(0,0,0,0),
            format: 'YYYY-MM-DD HH:mm',
            orientation: 'bottom',
            icons: {
                time: "far fa-clock",
                date: "fa fa-calendar-alt",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down"
            }
        });

        var tanggal_acara_2 = "{{ old('tanggal_acara_2', $undangan->tempat[1]->tanggal_acara) }}";
        $('#tanggal_acara_2').datetimepicker({
            defaultDate: tanggal_acara_2,
            minDate: new Date(moment()).setHours(0,0,0,0),
            format: 'YYYY-MM-DD HH:mm',
            orientation: 'bottom',
            icons: {
                time: "far fa-clock",
                date: "fa fa-calendar-alt",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down"
            }
        });
    });

    $(document).ready(function(){
        let link = "{{ url('undangan',$undangan->link) }}/";
        $('#link_tamu').val(link);
        $('#nama_tamu').on('keyup', function() {
            let nama_tamu = $('#nama_tamu').val().replace(/\s/g, '_');
            let link_tamu = link + nama_tamu;
            $('#link_tamu').val(link_tamu);
        });
    });

    $(document).ready(function(){
        $('#salin_link').click(function(){
            Swal.fire({
                position: 'center',
                icon: 'success',
                html: '<div style="font-size: 20px; font-weight: bold;">Link undangan berhasil disalin</div>',
                showConfirmButton: false,
                width: '30em',
                timer: 1500
            });
            var $input = $("<input>");
            $("body").append($input);
            $input.val($('#link_tamu').val()).select();
            document.execCommand("copy");
            $input.remove();
        });
    });

    $(document).ready(function() {
        $('#nama_tamu').on('keyup', function() {
            let nama_tamu = $('#nama_tamu').val().replace(/\s/g, '_');
            let url_undangan = "{{ url('undangan',$undangan->link) }}/" + nama_tamu + "/";

            let syari = "Assalamualaikum warahmatullahi wabaraktuh,\nTanpa mengurangi rasa hormat, perkenankan kami mengundang Bapak/Ibu/Saudara/i untuk menghadiri acara kami.\n\nInformasi lebih lengkap mengenai acara dapat dilihat pada tautan berikut :\n" + url_undangan + "\n\nMerupakan suatu kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/i berkenan untuk hadir dan memberikan doa restu.\nMohon maaf perihal undangan hanya di bagikan melalui pesan ini, terima kasih banyak atas perhatiannya.\n\nKami yang berbahagia,\n{!! $undangan->nama_pria.' dan '.$undangan->nama_wanita !!}";

            let formal = "Kepada Bapak/Ibu/Saudara/i yang kami hormati,\n\nMelalui pesan ini, kami mengundang Bapak/Ibu/Saudara/i untuk menghadiri pernikahan kami. Informasi lebih lengkap mengenai acara dapat dilihat pada tautan berikut :\n" + url_undangan + "\n\nKami sangat menghargai kehadiran Bapak/Ibu/Saudara/i di acara yang spesial ini dan kami berharap dapat merayakan momen bahagia ini bersama.\n\nAtas perhatian Bapak/Ibu/Saudara/i, kami ucapkan terima kasih.\nKami yang berbahagia,\n{!! $undangan->nama_pria.' dan '.$undangan->nama_wanita !!}";

            $("#kalimat_undangan").val(syari);
            $("#template_undangan").change(function() {
                if ($(this).val() == "formal") {
                    $("#kalimat_undangan").val(formal);
                } else if ($(this).val() == "syari") {
                    $("#kalimat_undangan").val(syari);
                }
            });
        });

        url_undangan = "{{ url('undangan',$undangan->link) }}/";

        let syari = "Assalamualaikum warahmatullahi wabaraktuh,\nTanpa mengurangi rasa hormat, perkenankan kami mengundang Bapak/Ibu/Saudara/i untuk menghadiri acara kami.\n\nInformasi lebih lengkap mengenai acara dapat dilihat pada tautan berikut :\n" + url_undangan + "\n\nMerupakan suatu kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/i berkenan untuk hadir dan memberikan doa restu.\nMohon maaf perihal undangan hanya di bagikan melalui pesan ini, terima kasih banyak atas perhatiannya.\n\nKami yang berbahagia,\n{!! $undangan->nama_pria.' dan '.$undangan->nama_wanita !!}";

        let formal = "Kepada Bapak/Ibu/Saudara/i yang kami hormati,\n\nMelalui pesan ini, kami mengundang Bapak/Ibu/Saudara/i untuk menghadiri pernikahan kami. Informasi lebih lengkap mengenai acara dapat dilihat pada tautan berikut :\n" + url_undangan + "\n\nKami sangat menghargai kehadiran Bapak/Ibu/Saudara/i di acara yang spesial ini dan kami berharap dapat merayakan momen bahagia ini bersama.\n\nAtas perhatian Bapak/Ibu/Saudara/i, kami ucapkan terima kasih.\nKami yang berbahagia,\n{!! $undangan->nama_pria.' dan '.$undangan->nama_wanita !!}";

        $("#kalimat_undangan").val(syari);
        $("#template_undangan").change(function() {
            if ($(this).val() == "formal") {
                $("#kalimat_undangan").val(formal);
            } else if ($(this).val() == "syari") {
                $("#kalimat_undangan").val(syari);
            }
        });

        $('#reset').click(function() {
            $("#kalimat_undangan").val(syari);
            $('#nama_tamu').val('');
            $('#whatsapp_tamu').val('');
            $('#link_tamu').val(url_undangan);
        });
    });

    $(document).ready(function(){
        $('#salin_undangan').click(function(){
            Swal.fire({
                position: 'center',
                icon: 'success',
                html: '<div style="font-size: 20px; font-weight: bold;">Undangan berhasil disalin</div>',
                showConfirmButton: false,
                width: '30em',
                timer: 1500
            });
            var $input = $("<textarea>");
            $("body").append($input);
            $input.val($('#kalimat_undangan').val()).select();
            document.execCommand("copy");
            $input.remove();
        });
    });

    $(document).ready(function() {
        $('#kirim_whatsapp').click(function() {
            var nomor_whatsapp = $('#whatsapp_tamu').val();
            nomor_whatsapp = nomor_whatsapp.replace(/[^0-9]/g, '');
            if (nomor_whatsapp.substring(0, 1) === '0') {
                nomor_whatsapp = '62' + nomor_whatsapp.substring(1);
            }
            var kalimat_undangan = $('#kalimat_undangan').val();
            kalimat_undangan = kalimat_undangan.replace(/\n/g, "%0A");
            var link_api_whatsapp = 'https://api.whatsapp.com/send?phone=' + nomor_whatsapp + '&text=' + kalimat_undangan;
            $(this).attr('href', link_api_whatsapp);
        });
    });

    $(document).ready(function() {
        $("#musik").on("change", function() {
            var selectedMusic = $(this).val();
            $("audio source").attr("src", "{{ asset('frontend/undangan/musik') }}/" + selectedMusic);
            $("audio")[0].load();
        });
    });

    $(document).ready(function(){
        function deleteData(deleteURL, successCallback) {
            Swal.fire({
                title: 'Apakah anda yakin',
                text: "Data akan dihapus",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Hapus Data!'
            }).then((e) => {
                if (e.value === true) {
                    $.ajax({
                        url: deleteURL,
                        type: 'DELETE',
                        headers: {
                        'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: successCallback,
                        error: function (data) {
                        console.log('Error:', data);
                        }
                    });
                } else {
                    return false;
                }
            });
        }

        $('.deleteGaleri').click(function(e){
            e.preventDefault();
            var deleteURL = $(this).attr('href');
            deleteData(deleteURL, function(data) {
                alertSuccess(data.message);
                location.reload();
            });
        });
        $('.deleteCerita').click(function(e){
            e.preventDefault();
            var deleteURL = $(this).attr('href');
            deleteData(deleteURL, function(data) {
                alertSuccess(data.message);
                location.reload();
            });
        });
    });

    $(document).ready(function() {
        $('#kalimat_pembuka').summernote({
            height: 100,
            toolbar: [
                ['font', ['bold', 'underline', 'italic']],
                ['view', ['help']],
            ],
            followingToolbar: false,
            disableDragAndDrop: true,
        });
    });

    function shareOnFacebook() {
        var link_tamu = document.getElementById("link_tamu").value;
        var url = "https://www.facebook.com/sharer/sharer.php?u=" + encodeURIComponent(link_tamu);
        window.open(url, "_blank", "width=600,height=500");
    }
    function shareOnTwitter() {
        var kalimat_undangan = document.getElementById("kalimat_undangan").value;
        var url = "https://twitter.com/intent/tweet?text=" + encodeURIComponent(kalimat_undangan);
        window.open(url, "_blank", "width=600,height=500");
    }
</script>
@endsection