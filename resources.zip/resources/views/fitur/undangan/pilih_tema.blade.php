@extends('layouts.app_template')
@section('body')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" integrity="sha512-cyzxRvewl+FOKTtpBzYjW6x6IAYUCZy3sGP40hn+DQkqeluGRCax7qztK2ImL64SA+C7kVWdLI6wvdlStawhyw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js" integrity="sha512-6lplKUSl86rUVprDIjiW8DuOniNX8UDoRATqZSds/7t6zCQZfaCe3e5zcGaQwxa8Kpn5RTM9Fvl3X2lLV4grPQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="alert alert-success" role="alert">
                <a href="{{ route('riwayat_undangan') }}" class="btn btn-rounded btn-success btn-sm">Lihat Undangan Anda</a>
            </div>
        </div>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="row">
                @foreach ($daftar_tema as $tema)
                <div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 col-12">
                    <div class="product-thumbnail">
                        <div class="product-img-head">
                            <div class="product-img">
                                <a href="{{ asset('frontend/images/paket/' . $tema->thumbnail) }}" data-lightbox="paket">
                                    <img data-src="{{ asset('frontend/images/paket/' . $tema->thumbnail) }}" alt="{{ $tema->thumbnail }}" class="img-fluid lazyload">
                                </a>
                            </div>
                        </div>
                        <div class="product-content" style="padding: 20px;">
                            <form action="{{ route('pilih_tema') }}" method="post" autocomplete="off">
                                @csrf
                                <div class="product-content-head">
                                    <h3 class="product-title" style="font-size: 18px; font-weight: bold; margin-bottom: 0px;">{{ $tema->nama_tema }}</h3>
                                </div>
                                <input type="hidden" id="id_tema" name="id_tema" value="{{ $tema->id }}" required="">
                                <div class="form-group d-flex justify-content-between">
                                    <a href="{{ route('preview_undangan', $tema->preview) }}" target="_blank" class="btn btn-block btn-success">Preview</a>
                                    <button type="submit" class="btn btn-block btn-primary" style="margin: 0px 0px 0px 5px;">Pilih Tema Ini</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @endforeach
                <div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 col-12">
                    <div class="product-thumbnail">
                        <div class="product-img-head">
                            <div class="product-img">
                                <a href="{{ asset('frontend/images/paket/coming_soon.jpg') }}" data-lightbox="paket">
                                    <img data-src="{{ asset('frontend/images/paket/coming_soon.jpg') }}" alt="coming_soon.jpg" class="img-fluid lazyload"></div>
                                </a>
                            <div class=""></div>
                        </div>
                        <div class="product-content" style="padding: 20px;">
                            <div class="product-content-head">
                                <h3 class="product-title" style="font-size: 18px; font-weight: bold; margin-bottom: 0px;">Coming Soon</h3>
                            </div>
                            <div class="form-group d-flex justify-content-between">
                                <button class="btn btn-block btn-success" disabled>Preview</button>
                                <button class="btn btn-block btn-primary" style="margin: 0px 0px 0px 5px;" disabled>Pilih Tema Ini</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection