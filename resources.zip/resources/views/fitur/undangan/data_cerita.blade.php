@extends('layouts.app_template')
@section('body')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" integrity="sha512-cyzxRvewl+FOKTtpBzYjW6x6IAYUCZy3sGP40hn+DQkqeluGRCax7qztK2ImL64SA+C7kVWdLI6wvdlStawhyw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form enctype="multipart/form-data" action="{{ route('data_cerita', $kode) }}" method="post" autocomplete="off" class="form_input">
                        @csrf
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group row pt-0">
                                    <label class="col-5 col-lg-4 col-form-label">Status Cerita</label>
                                    <div class="col-5 col-lg-4 pt-1">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_cerita" value="0">
                                            <input type="checkbox" value="1" name="status_cerita" id="status_cerita" onchange="switchButton('status_cerita', '#form_cerita')" checked><span>
                                            <label for="status_cerita"></label></span>
                                        </div>
                                    </div>
                                </div>
                                <div id="form_cerita">
                                    <div class="form-group">
                                        <label>Judul Cerita 1</label>
                                        <input type="text" id="judul_cerita_1" name="judul_cerita_1" placeholder="Contoh : Pertemuan pertama" class="form-control @error('judul_cerita_1') is-invalid @enderror" value="{{ old('judul_cerita_1') }}">
                                        @error('judul_cerita_1')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Isi Cerita 1</label>
                                        <textarea type="text" id="isi_cerita_1" name="isi_cerita_1" class="form-control @error('isi_cerita_1') is-invalid @enderror" rows="5" placeholder="Contoh : Pertemuan pertama kami berawal dari acara yang diselenggarakan kampus dan kami sebagai panitianya pada saat itu.">{{ old('isi_cerita_1') }}</textarea>
                                        @error('isi_cerita_1')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Waktu Cerita 1</label>
                                        <input type="text" id="waktu_cerita_1" name="waktu_cerita_1" placeholder="Contoh : 2020 / Mei 2020 / 12 Mei 2020" class="form-control @error('waktu_cerita_1') is-invalid @enderror" value="{{ old('waktu_cerita_1') }}">
                                        @error('waktu_cerita_1')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Upload Foto 1</label>
                                        <div class="form-group">
                                            <img src="{{ asset('frontend/undangan/lovelove/images/default_img.jpg') }}" id="foto_cerita_1" width="310px" height="260px"/>
                                        </div>
                                        <div class="custom-file">
                                            <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_cerita_1" data-idfoto="foto_cerita_1" data-base64="base64_cerita_1">
                                                <span class="file-custom">Pilih file...</span>
                                            </label>
                                        </div>
                                        <input type="hidden" name="base64_cerita_1" id="base64_cerita_1">
                                    </div>
                                    <hr>
                                    <div class="form-group">
                                        <label>Judul Cerita 2</label>
                                        <input type="text" id="judul_cerita_2" name="judul_cerita_2" placeholder="Contoh : Jadian" class="form-control @error('judul_cerita_2') is-invalid @enderror" value="{{ old('judul_cerita_2') }}">
                                        @error('judul_cerita_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Isi Cerita 2</label>
                                        <textarea type="text" id="isi_cerita_2" name="isi_cerita_2" class="form-control @error('isi_cerita_2') is-invalid @enderror" rows="5" placeholder="Contoh : Tidak lama setelah pertemuan pertama, hubungan kami semakin lebih dekat dan kami sering bertemu sampai akhirnya memutuskan untuk jadian.">{{ old('isi_cerita_2') }}</textarea>
                                        @error('isi_cerita_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Waktu Cerita 2</label>
                                        <input type="text" id="waktu_cerita_2" name="waktu_cerita_2" placeholder="Contoh : 2020 / Mei 2020 / 12 Mei 2020" class="form-control @error('waktu_cerita_2') is-invalid @enderror" value="{{ old('waktu_cerita_2') }}">
                                        @error('waktu_cerita_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Upload Foto 2</label>
                                        <div class="form-group">
                                            <img src="{{ asset('frontend/undangan/lovelove/images/default_img.jpg') }}" id="foto_cerita_2" width="310px" height="260px"/>
                                        </div>
                                        <div class="custom-file">
                                            <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_cerita_2" data-idfoto="foto_cerita_2" data-base64="base64_cerita_2">
                                                <span class="file-custom">Pilih file...</span>
                                            </label>
                                        </div>
                                        <input type="hidden" name="base64_cerita_2" id="base64_cerita_2">
                                    </div>
                                    <hr>
                                    <div class="form-group">
                                        <label>Judul Cerita 3</label>
                                        <input type="text" id="judul_cerita_3" name="judul_cerita_3" placeholder="Contoh : Lamaran" class="form-control @error('judul_cerita_3') is-invalid @enderror" value="{{ old('judul_cerita_3') }}">
                                        @error('judul_cerita_3')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Isi Cerita 3</label>
                                        <textarea type="text" id="isi_cerita_3" name="isi_cerita_3" class="form-control @error('isi_cerita_3') is-invalid @enderror" rows="5" placeholder="Contoh : 3 tahun lebih menjalin hubungan dan kami mempunyai visi misi yang sama untuk membawa hubungan ini ke jenjang yg lebih serius, dengan mempertemukan keluarga besar kami untuk menentukan tanggal pernikahan.">{{ old('isi_cerita_3') }}</textarea>
                                        @error('isi_cerita_3')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Waktu Cerita 3</label>
                                        <input type="text" id="waktu_cerita_3" name="waktu_cerita_3" placeholder="Contoh : 2020 / Mei 2020 / 12 Mei 2020" class="form-control @error('waktu_cerita_3') is-invalid @enderror" value="{{ old('waktu_cerita_3') }}">
                                        @error('waktu_cerita_3')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Upload Foto 3</label>
                                        <div class="form-group">
                                            <img src="{{ asset('frontend/undangan/lovelove/images/default_img.jpg') }}" id="foto_cerita_3" width="310px" height="260px"/>
                                        </div>
                                        <div class="custom-file">
                                            <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_cerita_3" data-idfoto="foto_cerita_3" data-base64="base64_cerita_3">
                                                <span class="file-custom">Pilih file...</span>
                                            </label>
                                        </div>
                                        <input type="hidden" name="base64_cerita_3" id="base64_cerita_3">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 m-t-10">
                                <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade imagecrop" id="exampleModal" tabindex="-1" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body" style="padding-bottom: 0px;">
                <div class="form-group">
                    <div id="container-crop" style="height: 500px;">
                        <img id="image" src="" />
                        <div id="preview"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="idfoto"><input type="hidden" id="base64">
                <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                <button type="button" class="btn btn-primary" id="crop">Crop</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js" integrity="sha512-6lplKUSl86rUVprDIjiW8DuOniNX8UDoRATqZSds/7t6zCQZfaCe3e5zcGaQwxa8Kpn5RTM9Fvl3X2lLV4grPQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="{{ asset('frontend/libs/js/loadingSimpan.js') }}"></script>
<script type="text/javascript">
    var $modal = $('.imagecrop');
    var image = document.getElementById('image');
    var cropper;
    $("body").on("change", ".imageUpload", function(e){
        var _idfoto = $(this).data('idfoto');
        var _base64 = $(this).data('base64');
        $('#idfoto').val(_idfoto);
        $('#base64').val(_base64);
        var files = e.target.files;
        var done = function(url) {
            image.src = url;
            $modal.modal('show');
        };
        var reader;
        var file;
        var url;
        if (files && files.length > 0) {
            file = files[0];
            if (FileReader) {
                reader = new FileReader();
                reader.onload = function(e) {
                    done(reader.result);
                };
                reader.readAsDataURL(file);
            } else if (URL) {
                done(URL.createObjectURL(file));
            }
        }
    });
    $modal.on('shown.bs.modal', function() {
        cropper = new Cropper(image, {
            checkOrientation: false,
            preview: '#preview',
            viewMode: 1,
            aspectRatio: 1.1796,
            ready: function () {
                cropper.setCropBoxData({
                    width: 591,
                    height: 501,
                });
            },
        });
        $("body").on("click", "#crop", function() {
            canvas = cropper.getCroppedCanvas({
                maxWidth: 1200,
                maxHeight: 1200,
            });
            var idfoto = $('#idfoto').val();
            var base64 = $('#base64').val();
            var base64data = canvas.toDataURL('image/jpeg', 0.8);
            $('#'+base64).val(base64data);
            document.getElementById(idfoto).src = base64data;
            $modal.modal('hide');
        });
    }).on('hidden.bs.modal', function() {
        cropper.destroy();
        cropper = null;
    });

    function switchButton(value, key) {
        if ($('#'+value).is(':checked')) {
            $(key).show();
        } else {
            $(key).hide();
        }
    };
</script>
@endsection