@extends('layouts.app_template')
@section('body')
<style>
    #radio-1 + label { background: #D4B0A5!important; }
    #radio-1:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-2 + label { background: #835845!important; }
    #radio-2:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-3 + label { background: #1e8267!important; }
    #radio-3:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-4 + label { background: #de5ca2!important; }
    #radio-4 + label:before { transform: scale(0); }
    #radio-4:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-5 + label { background: #d9ba91!important; }
    #radio-5 + label:before { transform: scale(0); }
    #radio-5:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-6 + label { background: #99337f!important; }
    #radio-6 + label:before { transform: scale(0); }
    #radio-6:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-7 + label { background: #18A7B5!important; }
    #radio-7 + label:before { transform: scale(0); }
    #radio-7:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-8 + label { background: #668c25!important; }
    #radio-8 + label:before { transform: scale(0); }
    #radio-8:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-9 + label { background: #ff8051!important; }
    #radio-9 + label:before { transform: scale(0); }
    #radio-9:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-10 + label { background: #dd6673!important; }
    #radio-10 + label:before { transform: scale(0); }
    #radio-10:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-11 + label { background: #d58675!important; }
    #radio-11 + label:before { transform: scale(0); }
    #radio-11:checked + label:before { transform: scale(1.5); transition: all .4s; }
    #radio-12 + label { background: #b19a56!important; }
    #radio-12 + label:before { transform: scale(0); }
    #radio-12:checked + label:before { transform: scale(1.5); transition: all .4s; }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" integrity="sha512-cyzxRvewl+FOKTtpBzYjW6x6IAYUCZy3sGP40hn+DQkqeluGRCax7qztK2ImL64SA+C7kVWdLI6wvdlStawhyw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form enctype="multipart/form-data" action="{{ route('data_pengantin') }}" method="post" autocomplete="off" class="form_input">
                        @csrf
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Foto Pria</label>
                                    <div class="form-group">
                                        <img src="{{ asset('frontend/undangan/lovelove/images/default_img.jpg') }}" id="foto_pria" width="310px" height="260px"/>
                                    </div>
                                    <div class="custom-file">
                                        <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                            <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_pria" data-idfoto="foto_pria" data-base64="base64_foto_pria" required>
                                            <span class="file-custom">Pilih file...</span>
                                        </label>
                                    </div>
                                    <input type="hidden" name="base64_foto_pria" id="base64_foto_pria">
                                </div>
                                <div class="form-group">
                                    <label>Nama Lengkap Pria</label>
                                    <input type="text" id="full_nama_pria" name="full_nama_pria" required="" placeholder="Contoh : Malik Haryanto Budiman" class="form-control @error('full_nama_pria') is-invalid @enderror" value="{{ old('full_nama_pria') }}">
                                    @error('full_nama_pria')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Nama Panggilan Pria</label>
                                    <input type="text" id="nama_pria" name="nama_pria" required="" placeholder="Contoh : Malik" class="form-control @error('nama_pria') is-invalid @enderror" value="{{ old('nama_pria') }}" onkeyup="linkUndangan()">
                                    @error('nama_pria')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Anak Keberapa?</label>
                                    <input type="text" id="anak_of_pria" name="anak_of_pria" required="" placeholder="Contoh : Putra ketiga dari" class="form-control @error('anak_of_pria') is-invalid @enderror" value="{{ old('anak_of_pria') }}">
                                    @error('anak_of_pria')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Nama Kedua Orang Tua Pria</label>
                                    <input type="text" id="ortu_pria" name="ortu_pria" required="" placeholder="Contoh : Bapak Kurnia Najmudin & Ibu Yani Mulyani" class="form-control @error('ortu_pria') is-invalid @enderror" value="{{ old('ortu_pria') }}">
                                    @error('ortu_pria')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Akun Instagram Pria</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_ig_pria" value="0">
                                            <input type="checkbox" value="1" name="status_ig_pria" id="status_ig_pria" onchange="switchButton('status_ig_pria', '#ig_pria')" checked><span>
                                            <label for="status_ig_pria"></label></span>
                                        </div>
                                    </div>
                                    <div class="input-group" id="ig_pria"><span class="input-group-prepend"><span class="input-group-text">www.instagram.com/</span></span>
                                        <input type="text" name="ig_pria" placeholder="Username" class="form-control @error('ig_pria') is-invalid @enderror" value="{{ old('ig_pria') }}">
                                        @error('ig_pria')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Akun Twitter Pria</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_twitter_pria" value="0">
                                            <input type="checkbox" value="1" name="status_twitter_pria" id="status_twitter_pria" onchange="switchButton('status_twitter_pria', '#twitter_pria')" checked><span>
                                            <label for="status_twitter_pria"></label></span>
                                        </div>
                                    </div>
                                    <div class="input-group" id="twitter_pria"><span class="input-group-prepend"><span class="input-group-text">www.twitter.com/</span></span>
                                        <input type="text" name="twitter_pria" placeholder="Username" class="form-control @error('twitter_pria') is-invalid @enderror" value="{{ old('twitter_pria') }}">
                                        @error('twitter_pria')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Akun Facebook Pria</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_fb_pria" value="0">
                                            <input type="checkbox" value="1" name="status_fb_pria" id="status_fb_pria" onchange="switchButton('status_fb_pria', '#fb_pria')" checked><span>
                                            <label for="status_fb_pria"></label></span>
                                        </div>
                                    </div>
                                    <div class="input-group" id="fb_pria"><span class="input-group-prepend"><span class="input-group-text">www.facebook.com/</span></span>
                                        <input type="text" name="fb_pria" placeholder="Username" class="form-control @error('fb_pria') is-invalid @enderror" value="{{ old('fb_pria') }}">
                                        @error('fb_pria')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Foto Wanita</label>
                                    <div class="form-group">
                                        <img src="{{ asset('frontend/undangan/lovelove/images/default_img.jpg') }}" id="foto_wanita" width="310px" height="260px"/>
                                    </div>
                                    <div class="custom-file">
                                        <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                            <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_wanita" data-idfoto="foto_wanita" data-base64="base64_foto_wanita" required>
                                            <span class="file-custom">Pilih file...</span>
                                        </label>
                                    </div>
                                    <input type="hidden" name="base64_foto_wanita" id="base64_foto_wanita">
                                </div>
                                <div class="form-group">
                                    <label>Nama Lengkap Wanita</label>
                                    <input type="text" id="full_nama_wanita" name="full_nama_wanita" required="" placeholder="Contoh : Belinda Wulandari Mayasari" class="form-control @error('full_nama_wanita') is-invalid @enderror" value="{{ old('full_nama_wanita') }}">
                                    @error('full_nama_wanita')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Nama Panggilan Wanita</label>
                                    <input type="text" id="nama_wanita" name="nama_wanita" required="" placeholder="Contoh : Belinda" class="form-control @error('nama_wanita') is-invalid @enderror" value="{{ old('nama_wanita') }}" onkeyup="linkUndangan()">
                                    @error('nama_wanita')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Anak Keberapa?</label>
                                    <input type="text" id="anak_of_wanita" name="anak_of_wanita" required="" placeholder="Contoh : Putri pertama dari" class="form-control @error('anak_of_wanita') is-invalid @enderror" value="{{ old('anak_of_wanita') }}">
                                    @error('anak_of_wanita')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Nama Kedua Orang Tua Wanita</label>
                                    <input type="text" id="ortu_wanita" name="ortu_wanita" required="" placeholder="Contoh : Bapak Hasim Hidayanto & Ibu Nadine Wastuti" class="form-control @error('ortu_wanita') is-invalid @enderror" value="{{ old('ortu_wanita') }}">
                                    @error('ortu_wanita')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Akun Instagram Wanita</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_ig_wanita" value="0">
                                            <input type="checkbox" value="1" name="status_ig_wanita" id="status_ig_wanita" onchange="switchButton('status_ig_wanita', '#ig_wanita')" checked><span>
                                            <label for="status_ig_wanita"></label></span>
                                        </div>
                                    </div>
                                    <div class="input-group" id="ig_wanita"><span class="input-group-prepend"><span class="input-group-text">www.instagram.com/</span></span>
                                        <input type="text" name="ig_wanita" placeholder="Username" class="form-control @error('ig_wanita') is-invalid @enderror" value="{{ old('ig_wanita') }}">
                                        @error('ig_wanita')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Akun Twitter Wanita</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_twitter_wanita" value="0">
                                            <input type="checkbox" value="1" name="status_twitter_wanita" id="status_twitter_wanita" onchange="switchButton('status_twitter_wanita', '#twitter_wanita')" checked><span>
                                            <label for="status_twitter_wanita"></label></span>
                                        </div>
                                    </div>
                                    <div class="input-group" id="twitter_wanita"><span class="input-group-prepend"><span class="input-group-text">www.twitter.com/</span></span>
                                        <input type="text" name="twitter_wanita" placeholder="Username" class="form-control @error('twitter_wanita') is-invalid @enderror" value="{{ old('twitter_wanita') }}">
                                        @error('twitter_wanita')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Akun Facebook Wanita</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_fb_wanita" value="0">
                                            <input type="checkbox" value="1" name="status_fb_wanita" id="status_fb_wanita" onchange="switchButton('status_fb_wanita', '#fb_wanita')" checked><span>
                                            <label for="status_fb_wanita"></label></span>
                                        </div>
                                    </div>
                                    <div class="input-group" id="fb_wanita"><span class="input-group-prepend"><span class="input-group-text">www.facebook.com/</span></span>
                                        <input type="text" name="fb_wanita" placeholder="Username" class="form-control @error('fb_wanita') is-invalid @enderror" value="{{ old('fb_wanita') }}">
                                        @error('fb_wanita')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Pilih Masa Aktif Undangan</label>
                                    <select class="form-control selectpicker @error('id_paket') is-invalid @enderror" name="id_paket" id="id_paket">
                                        @foreach ($daftar_paket as $dp)
                                            <option value="{{ $dp->id }}" @selected(old('id_paket') == $dp->id)>{{ convert_durasi($dp->durasi) }} : {{ format_rupiah($dp->harga) }}</option>
                                        @endforeach
                                    </select>
                                    @error('id_paket')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Link Undangan Digital</label>
                                    <div class="input-group"><span class="input-group-prepend"><span class="input-group-text">{{ request()->getHttpHost().'/undangan/' }}</span></span>
                                        <input type="text" id="link" name="link" placeholder="Contoh : malik-belinda" class="form-control @error('link') is-invalid @enderror" value="{{ old('link') }}" required>
                                        @error('link')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-12">
                                <div class="form-group">
                                    <label>Pilih Warna Teks Undangan</label>
                                    <div class="product-colors">
                                        <input type="radio" class="radio" id="radio-1" name="warna_undangan" value="color1" />
                                        <label for="radio-1"></label>
                                        <input type="radio" class="radio" id="radio-2" name="warna_undangan" value="color2" />
                                        <label for="radio-2"></label>
                                        <input type="radio" class="radio" id="radio-3" name="warna_undangan" value="color3" checked/>
                                        <label for="radio-3"></label>
                                        <input type="radio" class="radio" id="radio-4" name="warna_undangan" value="color4" />
                                        <label for="radio-4"></label>
                                        <input type="radio" class="radio" id="radio-5" name="warna_undangan" value="color5" />
                                        <label for="radio-5"></label>
                                        <input type="radio" class="radio" id="radio-6" name="warna_undangan" value="color6" />
                                        <label for="radio-6"></label>
                                        <input type="radio" class="radio" id="radio-7" name="warna_undangan" value="color7" />
                                        <label for="radio-7"></label>
                                        <input type="radio" class="radio" id="radio-8" name="warna_undangan" value="color8" />
                                        <label for="radio-8"></label>
                                        <input type="radio" class="radio" id="radio-9" name="warna_undangan" value="color9" />
                                        <label for="radio-9"></label>
                                        <input type="radio" class="radio" id="radio-10" name="warna_undangan" value="color10" />
                                        <label for="radio-10"></label>
                                        <input type="radio" class="radio" id="radio-11" name="warna_undangan" value="color11" />
                                        <label for="radio-11"></label>
                                        <input type="radio" class="radio" id="radio-12" name="warna_undangan" value="color12" />
                                        <label for="radio-12"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 m-t-10">
                                <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                                @include('components.button_kembali', ['url' => route('pilih_tema')])
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade imagecrop" id="exampleModal" tabindex="-1" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body" style="padding-bottom: 0px;">
                <div class="form-group">
                    <div id="container-crop" style="height: 500px;">
                        <img id="image" src="" />
                        <div id="preview"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="idfoto"><input type="hidden" id="base64">
                <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                <button type="button" class="btn btn-primary" id="crop">Crop</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js" integrity="sha512-6lplKUSl86rUVprDIjiW8DuOniNX8UDoRATqZSds/7t6zCQZfaCe3e5zcGaQwxa8Kpn5RTM9Fvl3X2lLV4grPQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="{{ asset('frontend/libs/js/loadingSimpan.js') }}"></script>
<script type="text/javascript">
    var $modal = $('.imagecrop');
    var image = document.getElementById('image');
    var cropper;
    $("body").on("change", ".imageUpload", function(e){
        var _idfoto = $(this).data('idfoto');
        var _base64 = $(this).data('base64');
        $('#idfoto').val(_idfoto);
        $('#base64').val(_base64);
        var files = e.target.files;
        var done = function(url) {
            image.src = url;
            $modal.modal('show');
        };
        var reader;
        var file;
        var url;
        if (files && files.length > 0) {
            file = files[0];
            if (FileReader) {
                reader = new FileReader();
                reader.onload = function(e) {
                    done(reader.result);
                };
                reader.readAsDataURL(file);
            } else if (URL) {
                done(URL.createObjectURL(file));
            }
        }
    });
    $modal.on('shown.bs.modal', function() {
        cropper = new Cropper(image, {
            checkOrientation: false,
            preview: '#preview',
            viewMode: 1,
            aspectRatio: 1.2,
            ready: function () {
                cropper.setCropBoxData({
                    width: 609,
                    height: 505,
                });
            },
        });
        $("body").on("click", "#crop", function() {
            canvas = cropper.getCroppedCanvas({
                maxWidth: 1200,
                maxHeight: 1200,
            });
            var idfoto = $('#idfoto').val();
            var base64 = $('#base64').val();
            var base64data = canvas.toDataURL('image/jpeg', 0.8);
            $('#'+base64).val(base64data);
            document.getElementById(idfoto).src = base64data;
            $modal.modal('hide');
        });
    }).on('hidden.bs.modal', function() {
        cropper.destroy();
        cropper = null;
    });

    function switchButton(value, key) {
        if ($('#'+value).is(':checked')) {
            $(key).show();
        } else {
            $(key).hide();
        }
    };

    function linkUndangan() {
        var nama_pria = $('#nama_pria').val();
        var nama_wanita = $('#nama_wanita').val();

        var strings = [nama_pria, nama_wanita];
        var str = strings.filter(e => e.length > 0).join('-');

        str = str.replace(/[`~!@#$%^&*()_\-+=\[\]{};:'"\\|\/,.<>?\s]/g, ' ').toLowerCase();
        str = str.replace(/^\s+|\s+$/gm, '');
        str = str.replace(/\s+/g, '-');
        $('#link').val(str);
    }
</script>
@endsection