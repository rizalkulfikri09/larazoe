@extends('layouts.app_template')
@section('body')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" integrity="sha512-cyzxRvewl+FOKTtpBzYjW6x6IAYUCZy3sGP40hn+DQkqeluGRCax7qztK2ImL64SA+C7kVWdLI6wvdlStawhyw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="{{ asset('frontend/vendor/summernote/css/summernote-bs4.css') }}">
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form enctype="multipart/form-data" action="{{ route('data_undangan', $kode) }}" method="post" autocomplete="off" class="form_input">
                        @csrf
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group" data-toggle="tooltip" data-placement="top" title="Digunakan untuk countdown">
                                    <label>Tanggal Dan Jam Pernikahan</label>
                                    <input placeholder="Contoh : 2022-12-15 21:00" type="text" name="tanggal_nikah" class="datetimepicker-input form-control @error('tanggal_nikah') is-invalid @enderror" id="tanggal_nikah" data-toggle="datetimepicker" data-target="#tanggal_nikah" required>
                                    @error('tanggal_nikah')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Kalimat Pembuka</label>
                                    <textarea type="text" id="kalimat_pembuka" name="kalimat_pembuka" class="form-control @error('kalimat_pembuka') is-invalid @enderror" rows="5" required>{{ old('kalimat_pembuka', "Assalamu'alaikum Warahmatullaahi Wabarakaatuh. Maha Suci Allah yang telah menciptakan makhluk-Nya berpasang-pasangan. Ya Allah semoga ridho-Mu tercurah mengiringi pernikahan kami.") }}</textarea>
                                    @error('kalimat_pembuka')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Status Video</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_link_youtube" value="0">
                                            <input type="checkbox" value="1" name="status_link_youtube" id="status_link_youtube" onchange="switchButton('status_link_youtube', '#form_link_youtube')" checked><span>
                                            <label for="status_link_youtube"></label></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group" id="form_link_youtube">
                                    <label>Link Video Dari Youtube</label>
                                    <input type="text" id="link_youtube" name="link_youtube" class="form-control @error('link_youtube') is-invalid @enderror" placeholder="Contoh : https://youtu.be/VBf4dH-qGh8" value="{{ old('link_youtube') }}">
                                    @error('link_youtube')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="mt-1">
                                        <a href="#" data-toggle="modal" data-target="#embed_youtube">Cara copy link video youtube</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Status Backsound</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_musik" value="0">
                                            <input type="checkbox" value="1" name="status_musik" id="status_musik" onchange="switchButton('status_musik', '#form_musik')" checked><span>
                                            <label for="status_musik"></label></span>
                                        </div>
                                    </div>
                                </div>
                                <div id="form_musik">
                                    <div class="form-group">
                                        <label>Pilih Backsound</label>
                                        <select class="form-control selectpicker" name="musik" id="musik">
                                            @foreach ($daftar_musik as $key => $musik)
                                                <option value="{{ $key }}">{{ $musik }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <audio controls preload="none">
                                            <source src="{{ asset('frontend/undangan/musik/musik_1.mp3') }}" type="audio/mpeg">
                                        </audio>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Nama Acara</label>
                                    <input type="text" id="nama_acara_1" name="nama_acara_1" placeholder="Contoh : Akad Nikah" class="form-control @error('nama_acara_1') is-invalid @enderror" value="{{ old('nama_acara_1') }}" required>
                                    @error('nama_acara_1')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Tanggal Acara</label>
                                    <input type="text" id="tanggal_acara_1" name="tanggal_acara_1" placeholder="Contoh : 2022-12-15 21:00" class="datetimepicker-input form-control @error('tanggal_acara_1') is-invalid @enderror" data-toggle="datetimepicker" data-target="#tanggal_acara_1" required>
                                    @error('tanggal_acara_1')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Tempat Acara</label>
                                    <input type="text" id="tempat_acara_1" name="tempat_acara_1" placeholder="Contoh : Hotel Grand Dafam Banjarbaru" class="form-control @error('tempat_acara_1') is-invalid @enderror" value="{{ old('tempat_acara_1') }}" required>
                                    @error('tempat_acara_1')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Alamat Acara</label>
                                    <textarea type="text" id="alamat_acara_1" name="alamat_acara_1" class="form-control @error('alamat_acara_1') is-invalid @enderror" rows="3" placeholder="Contoh : Q Mall, Jl. A. Yani No.km 36.8, Komet, Kec. Banjarbaru Utara, Kota Banjar Baru" required>{{ old('alamat_acara_1') }}</textarea>
                                    @error('alamat_acara_1')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label>Link Google Maps Acara</label>
                                    <textarea type="text" id="link_maps_1" name="link_maps_1" class="form-control @error('link_maps_1') is-invalid @enderror" rows="3" placeholder="Paste link google maps disini, contoh : https://goo.gl/maps/KnXQbcbrw6bprrjQA" required>{{ old('link_maps_1') }}</textarea>
                                    @error('link_maps_1')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="mt-1">
                                        <a href="#" data-toggle="modal" data-target="#embed_maps">Cara copy link google maps</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <div class="switch-button switch-button-success">
                                        <input type="hidden" name="status_acara_2" value="0">
                                        <input type="checkbox" value="1" name="status_acara_2" id="status_acara_2" onchange="switchButton('status_acara_2', '#form_acara_2')" checked><span>
                                        <label for="status_acara_2"></label></span>
                                    </div>
                                </div>
                                <div id="form_acara_2">
                                    <div class="form-group">
                                        <label>Nama Acara</label>
                                        <input type="text" id="nama_acara_2" name="nama_acara_2" placeholder="Contoh : Resepsi" class="form-control @error('nama_acara_2') is-invalid @enderror" value="{{ old('nama_acara_2') }}">
                                        @error('nama_acara_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Tanggal Acara</label>
                                        <input type="text" id="tanggal_acara_2" name="tanggal_acara_2" placeholder="Contoh : 2022-12-15 21:00" class="datetimepicker-input form-control @error('tanggal_acara_2') is-invalid @enderror" data-toggle="datetimepicker" data-target="#tanggal_acara_2" required>
                                        @error('tanggal_acara_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Tempat Acara</label>
                                        <input type="text" id="tempat_acara_2" name="tempat_acara_2" placeholder="Contoh : Hotel Grand Dafam Banjarbaru" class="form-control @error('tempat_acara_2') is-invalid @enderror" value="{{ old('tempat_acara_2') }}">
                                        @error('tempat_acara_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Alamat Acara</label>
                                        <textarea type="text" id="alamat_acara_2" name="alamat_acara_2" class="form-control @error('alamat_acara_2') is-invalid @enderror" rows="3" placeholder="Contoh : Q Mall, Jl. A. Yani No.km 36.8, Komet, Kec. Banjarbaru Utara, Kota Banjar Baru">{{ old('alamat_acara_2') }}</textarea>
                                        @error('alamat_acara_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Link Google Maps Acara</label>
                                        <textarea type="text" id="link_maps_2" name="link_maps_2" class="form-control @error('link_maps_2') is-invalid @enderror" rows="3" placeholder="Paste link google maps disini, contoh : https://goo.gl/maps/KnXQbcbrw6bprrjQA">{{ old('link_maps_2') }}</textarea>
                                        @error('link_maps_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Status Foto Slider</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_slider" value="0">
                                            <input type="checkbox" value="1" name="status_slider" id="status_slider" onchange="switchButton('status_slider', '.form_foto_slider')" checked><span>
                                            <label for="status_slider"></label></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form_foto_slider">
                                    <div class="form-group">
                                        <label>Title Foto 1</label>
                                        <input type="text" id="title_slider_1" name="title_slider_1" placeholder="Contoh : Love" class="form-control" value="{{ old('title_slider_1') }}" data-toggle="tooltip" data-placement="top" title="Kolom ini tidak wajib diisi, bisa dikosongkan">
                                    </div>
                                    <div class="form-group">
                                        <label>Foto Slider 1</label>
                                        <div class="form-group">
                                            <img src="{{ asset('frontend/undangan/lovelove/images/default_img.jpg') }}" id="foto_slider_1" width="60%"/>
                                        </div>
                                        <div class="custom-file">
                                            <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_slider_1" data-idfoto="foto_slider_1" data-base64="base64_slider_1">
                                                <span class="file-custom">Pilih file...</span>
                                            </label>
                                        </div>
                                        <input type="hidden" name="base64_slider_1" id="base64_slider_1">
                                    </div>
                                    <div class="form-group">
                                        <label>Title Foto 2</label>
                                        <input type="text" id="title_slider_2" name="title_slider_2" placeholder="Contoh : Happy" class="form-control" value="{{ old('title_slider_2') }}" data-toggle="tooltip" data-placement="top" title="Kolom ini tidak wajib diisi, bisa dikosongkan">
                                    </div>
                                    <div class="form-group">
                                        <label>Foto Slider 2</label>
                                        <div class="form-group">
                                            <img src="{{ asset('frontend/undangan/lovelove/images/default_img.jpg') }}" id="foto_slider_2" width="60%"/>
                                        </div>
                                        <div class="custom-file">
                                            <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_slider_2" data-idfoto="foto_slider_2" data-base64="base64_slider_2">
                                                <span class="file-custom">Pilih file...</span>
                                            </label>
                                        </div>
                                        <input type="hidden" name="base64_slider_2" id="base64_slider_2">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 form_foto_slider">
                                <div class="form-group">
                                    <label>Title Foto 3</label>
                                    <input type="text" id="title_slider_3" name="title_slider_3" placeholder="Contoh : Sweet" class="form-control" value="{{ old('title_slider_3') }}" data-toggle="tooltip" data-placement="top" title="Kolom ini tidak wajib diisi, bisa dikosongkan">
                                </div>
                                <div class="form-group">
                                    <label>Foto Slider 3</label>
                                    <div class="form-group">
                                        <img src="{{ asset('frontend/undangan/lovelove/images/default_img.jpg') }}" id="foto_slider_3" width="60%"/>
                                    </div>
                                    <div class="custom-file">
                                        <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                            <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_slider_3" data-idfoto="foto_slider_3" data-base64="base64_slider_3">
                                            <span class="file-custom">Pilih file...</span>
                                        </label>
                                    </div>
                                    <input type="hidden" name="base64_slider_3" id="base64_slider_3">
                                </div>
                                <div class="form-group">
                                    <label>Title Foto 4</label>
                                    <input type="text" id="title_slider_4" name="title_slider_4" placeholder="Contoh : Friendship" class="form-control" value="{{ old('title_slider_4') }}" data-toggle="tooltip" data-placement="top" title="Kolom ini tidak wajib diisi, bisa dikosongkan">
                                </div>
                                <div class="form-group">
                                    <label>Foto Slider 4</label>
                                    <div class="form-group">
                                        <img src="{{ asset('frontend/undangan/lovelove/images/default_img.jpg') }}" id="foto_slider_4" width="60%"/>
                                    </div>
                                    <div class="custom-file">
                                        <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                            <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_slider_4" data-idfoto="foto_slider_4" data-base64="base64_slider_4">
                                            <span class="file-custom">Pilih file...</span>
                                        </label>
                                    </div>
                                    <input type="hidden" name="base64_slider_4" id="base64_slider_4">
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Status Amplop Digital</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_bank_1" value="0">
                                            <input type="checkbox" value="1" name="status_bank_1" id="status_bank_1" onchange="switchButton('status_bank_1', '#form_bank_1')" checked><span>
                                            <label for="status_bank_1"></label></span>
                                        </div>
                                    </div>
                                </div>
                                <div id="form_bank_1">
                                    <div class="form-group">
                                        <label>Nama Bank 1</label>
                                        <input type="text" id="nama_bank_1" name="nama_bank_1" placeholder="Contoh : Bank BNI" class="form-control @error('nama_bank_1') is-invalid @enderror" value="{{ old('nama_bank_1') }}">
                                        @error('nama_bank_1')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Nomor Rekening 1</label>
                                        <input type="text" id="nomor_rekening_1" name="nomor_rekening_1" placeholder="Contoh : 1234567890" class="form-control @error('nomor_rekening_1') is-invalid @enderror" value="{{ old('nomor_rekening_1') }}">
                                        @error('nomor_rekening_1')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Pemilik Rekening 1</label>
                                        <input type="text" id="pemilik_rekening_1" name="pemilik_rekening_1" placeholder="Contoh : Malik Haryanto Budiman" class="form-control @error('pemilik_rekening_1') is-invalid @enderror" value="{{ old('pemilik_rekening_1') }}">
                                        @error('pemilik_rekening_1')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Status Amplop Digital</label>
                                    <div class="form-group">
                                        <div class="switch-button switch-button-success">
                                            <input type="hidden" name="status_bank_2" value="0">
                                            <input type="checkbox" value="1" name="status_bank_2" id="status_bank_2" onchange="switchButton('status_bank_2', '#form_bank_2')" checked><span>
                                            <label for="status_bank_2"></label></span>
                                        </div>
                                    </div>
                                </div>
                                <div id="form_bank_2">
                                    <div class="form-group">
                                        <label>Nama Bank 2</label>
                                        <input type="text" id="nama_bank_2" name="nama_bank_2" placeholder="Contoh : Bank BCA" class="form-control @error('nama_bank_2') is-invalid @enderror" value="{{ old('nama_bank_2') }}">
                                        @error('nama_bank_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Nomor Rekening 2</label>
                                        <input type="text" id="nomor_rekening_2" name="nomor_rekening_2" placeholder="Contoh : 1234567890" class="form-control @error('nomor_rekening_2') is-invalid @enderror" value="{{ old('nomor_rekening_2') }}">
                                        @error('nomor_rekening_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Pemilik Rekening 2</label>
                                        <input type="text" id="pemilik_rekening_2" name="pemilik_rekening_2" placeholder="Contoh : Malik Haryanto Budiman" class="form-control @error('pemilik_rekening_2') is-invalid @enderror" value="{{ old('pemilik_rekening_2') }}">
                                        @error('pemilik_rekening_2')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6 m-t-10">
                                <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade imagecrop" id="exampleModal" tabindex="-1" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body" style="padding-bottom: 0px;">
                <div class="form-group">
                    <div id="container-crop" style="height: 500px;">
                        <img id="image" src="" />
                        <div id="preview"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="idfoto"><input type="hidden" id="base64">
                <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                <button type="button" class="btn btn-primary" id="crop">Crop</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="embed_youtube" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cara copy link video youtube</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <div class="modal-body">
                <img src="{{ asset('frontend/undangan/lovelove/tutorial/cara_copy_youtube.gif') }}" class="img-fluid lazyload" alt="Cara Copy Link Google Maps">
                <a href="{{ asset('frontend/undangan/lovelove/tutorial/cara_copy_youtube.gif') }}" target="_blank">Lihat gambar lebih besar</a>
            </div>
            <div class="modal-footer">
                <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="embed_maps" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cara copy link google maps</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <div class="modal-body">
                <img src="{{ asset('frontend/undangan/lovelove/tutorial/cara_copy_maps.gif') }}" class="img-fluid lazyload" alt="Cara Copy Link Google Maps">
                <a href="{{ asset('frontend/undangan/lovelove/tutorial/cara_copy_maps.gif') }}" target="_blank">Lihat gambar lebih besar</a>
            </div>
            <div class="modal-footer">
                <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js" integrity="sha512-6lplKUSl86rUVprDIjiW8DuOniNX8UDoRATqZSds/7t6zCQZfaCe3e5zcGaQwxa8Kpn5RTM9Fvl3X2lLV4grPQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="{{ asset('frontend/vendor/summernote/js/summernote-bs4.js') }}"></script>
<script src="{{ asset('frontend/libs/js/loadingSimpan.js') }}"></script>
<script type="text/javascript">
    var $modal = $('.imagecrop');
    var image = document.getElementById('image');
    var cropper;
    $("body").on("change", ".imageUpload", function(e){
        var _idfoto = $(this).data('idfoto');
        var _base64 = $(this).data('base64');
        $('#idfoto').val(_idfoto);
        $('#base64').val(_base64);
        var files = e.target.files;
        var done = function(url) {
            image.src = url;
            $modal.modal('show');
        };
        var reader;
        var file;
        var url;
        if (files && files.length > 0) {
            file = files[0];
            if (FileReader) {
                reader = new FileReader();
                reader.onload = function(e) {
                    done(reader.result);
                };
                reader.readAsDataURL(file);
            } else if (URL) {
                done(URL.createObjectURL(file));
            }
        }
    });
    $modal.on('shown.bs.modal', function() {
        cropper = new Cropper(image, {
            checkOrientation: false,
            preview: '#preview',
            viewMode: 1,
            aspectRatio: {{ $aspect_ratio }},
            ready: function () {
                cropper.setCropBoxData({
                    width: {{ $width_slider }},
                    height: {{ $height_slider }},
                });
            },
        });
        $("body").on("click", "#crop", function() {
            canvas = cropper.getCroppedCanvas({
                maxWidth: 1200,
                maxHeight: 1200,
            });
            var idfoto = $('#idfoto').val();
            var base64 = $('#base64').val();
            var base64data = canvas.toDataURL('image/jpeg', 0.8);
            $('#'+base64).val(base64data);
            document.getElementById(idfoto).src = base64data;
            $modal.modal('hide');
        });
    }).on('hidden.bs.modal', function() {
        cropper.destroy();
        cropper = null;
    });

    $(function() {
        var tanggal_nikah = "{{ old('tanggal_nikah', '') }}";
        $('#tanggal_nikah').datetimepicker({
            defaultDate: tanggal_nikah,
            minDate: new Date(moment()).setHours(0,0,0,0),
            format: 'YYYY-MM-DD HH:mm',
            orientation: 'bottom',
            icons: {
                time: "far fa-clock",
                date: "fa fa-calendar-alt",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down"
            }
        });
        $('#tanggal_nikah').on('change.datetimepicker', function() {
            $('#tanggal_acara_1').val($(this).val());
            $('#tanggal_acara_2').val($(this).val());
        });
    });

    $(function() {
        var tanggal_acara_1 = "{{ old('tanggal_acara_1', '') }}";
        $('#tanggal_acara_1').datetimepicker({
            defaultDate: tanggal_acara_1,
            minDate: new Date(moment()).setHours(0,0,0,0),
            format: 'YYYY-MM-DD HH:mm',
            orientation: 'bottom',
            icons: {
                time: "far fa-clock",
                date: "fa fa-calendar-alt",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down"
            }
        });

        var tanggal_acara_2 = "{{ old('tanggal_acara_2', '') }}";
        $('#tanggal_acara_2').datetimepicker({
            defaultDate: tanggal_acara_2,
            minDate: new Date(moment()).setHours(0,0,0,0),
            format: 'YYYY-MM-DD HH:mm',
            orientation: 'bottom',
            icons: {
                time: "far fa-clock",
                date: "fa fa-calendar-alt",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down"
            }
        });
    });

    $(document).ready(function() {
        const elements = ['tempat_acara', 'alamat_acara', 'link_maps'];
        for (let i = 0; i < elements.length; i++) {
            const element = elements[i];
            $(`#${element}_1`).change(function() {
                $(`#${element}_2`).val($(this).val());
            });
        }
    });

    function switchButton(value, key) {
        if ($('#'+value).is(':checked')) {
            $(key).show();
        } else {
            $(key).hide();
        }
    };

    $(document).ready(function() {
        $("#musik").on("change", function() {
            var selectedMusic = $(this).val();
            $("audio source").attr("src", "{{ asset('frontend/undangan/musik') }}/" + selectedMusic);
            $("audio")[0].load();
        });
    });

    $(document).ready(function() {
        $('#kalimat_pembuka').summernote({
            height: 100,
            toolbar: [
                ['font', ['bold', 'underline', 'italic']],
                ['view', ['help']],
            ],
            followingToolbar: false,
            disableDragAndDrop: true,
        });
    });
</script>
@endsection