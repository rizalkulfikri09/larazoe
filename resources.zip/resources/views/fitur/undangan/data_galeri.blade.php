@extends('layouts.app_template')
@section('body')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" integrity="sha512-cyzxRvewl+FOKTtpBzYjW6x6IAYUCZy3sGP40hn+DQkqeluGRCax7qztK2ImL64SA+C7kVWdLI6wvdlStawhyw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<div class="ecommerce-widget">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="alert alert-warning" role="alert">
                Foto tidak wajib di isi, bisa dikosongkan semua atau upload beberapa.
            </div>
        </div>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            @include('components.alert')
            <div class="card">
                <div class="card-body">
                    <form enctype="multipart/form-data" action="{{ route('data_galeri', $kode) }}" method="post" autocomplete="off" class="form_input">
                        @csrf
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="form-group">
                                    <div class="row">
                                        @for ($i = 0; $i < 10; $i++)
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12 pb-4">
                                            <label>Foto {{ $i + 1 }}</label>
                                            <div class="form-group">
                                                <img src="{{ asset('frontend/undangan/lovelove/images/default_img.jpg') }}" id="foto_{{ $i + 1 }}" width="100%"/>
                                            </div>
                                            <div class="custom-file">
                                                <label class="file" data-toggle="tooltip" data-placement="top" title="Format foto jpg,jpeg,png dan ukuran maksimal 4 MB">
                                                    <input type="file" accept=".png, .jpg, .jpeg" class="custom-file-input imageUpload" name="foto_{{ $i + 1 }}" data-idfoto="foto_{{ $i + 1 }}" data-base64="base64_foto_{{ $i + 1 }}">
                                                    <span class="file-custom">Pilih file...</span>
                                                </label>
                                            </div>
                                            <input type="hidden" name="base64_foto_{{ $i + 1 }}" id="base64_foto_{{ $i + 1 }}">
                                        </div>
                                        @endfor
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-sm-6">
                                <button type="submit" class="btn btn-space btn-primary">Selanjutnya</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade imagecrop" id="exampleModal" tabindex="-1" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body" style="padding-bottom: 0px;">
                <div class="form-group">
                    <div id="container-crop" style="height: 500px;">
                        <img id="image" src="" />
                        <div id="preview"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="btn-group btn-group-toggle" data-toggle="buttons">
                    <label class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Ukuran Potrait">
                        <input type="radio" id="aspectRatio1" name="aspectRatio" value="0.6666666666666666">2:3
                    </label>
                    <label class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Ukuran Landscape">
                        <input type="radio" id="aspectRatio2" name="aspectRatio" value="1.3333333333333333">4:3
                    </label>
                    <label class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Ukuran Bebas">
                        <input type="radio" id="aspectRatio3" name="aspectRatio" value="NaN">Custom
                    </label>
                </div>
                <input type="hidden" id="idfoto"><input type="hidden" id="base64">
                <a href="#" class="btn btn-secondary" data-dismiss="modal">Keluar</a>
                <button type="button" class="btn btn-primary" id="crop">Crop</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js" integrity="sha512-6lplKUSl86rUVprDIjiW8DuOniNX8UDoRATqZSds/7t6zCQZfaCe3e5zcGaQwxa8Kpn5RTM9Fvl3X2lLV4grPQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="{{ asset('frontend/libs/js/loadingSimpan.js') }}"></script>
<script type="text/javascript">
    var $modal = $('.imagecrop');
    var image = document.getElementById('image');
    var cropper;
    $("body").on("change", ".imageUpload", function(e){
        $('#idfoto').val($(this).data('idfoto'));
        $('#base64').val($(this).data('base64'));
        var files = e.target.files;
        var done = function(url) {
            image.src = url;
            $modal.modal('show');
        };
        var reader;
        var file;
        var url;
        if (files && files.length > 0) {
            file = files[0];
            if (FileReader) {
                reader = new FileReader();
                reader.onload = function(e) {
                    done(reader.result);
                };
                reader.readAsDataURL(file);
            } else if (URL) {
                done(URL.createObjectURL(file));
            }
        }
    });
    $modal.on('shown.bs.modal', function() {
        cropper = new Cropper(image, {
            checkOrientation: false,
            preview: '#preview',
            viewMode: 1,
        });
        $(".btn-group input[name='aspectRatio']").on("change", function() {
            cropper.setAspectRatio(this.value);
        });
        $("body").on("click", "#crop", function() {
            canvas = cropper.getCroppedCanvas({
                maxWidth: 1200,
                maxHeight: 1200,
            });
            var idfoto = $('#idfoto').val();
            var base64 = $('#base64').val();
            var base64data = canvas.toDataURL('image/jpeg', 0.8);
            $('#'+base64).val(base64data);
            document.getElementById(idfoto).src = base64data;
            $modal.modal('hide');
            $(".btn-group-toggle label.active").removeClass("active");
        });
    }).on('hidden.bs.modal', function() {
        cropper.destroy();
        cropper = null;
    });
</script>
@endsection