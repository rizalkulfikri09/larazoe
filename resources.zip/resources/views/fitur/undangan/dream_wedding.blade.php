<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="{{ asset('frontend/images/favicon/'.$set_umum->value_4) }}">
    <title>{{ $undangan->nama_pria.' & '.$undangan->nama_wanita }}</title>
    <meta name="description" content="Pernikahan {{ $undangan->nama_pria.' & '.$undangan->nama_wanita.' '.Carbon::parse($tanggal_nikah)->translatedFormat('l, d F Y') }}">
    <meta name="keywords" content="undangan digital, undangan online, undangan nikah online, website undangan pernikahan">
    <meta property="og:locale" content="id_ID">
    <meta property="og:type" content="article">
    <meta property="og:title" content="Pernikahan {{ $undangan->nama_pria.' & '.$undangan->nama_wanita }}">
    <meta property="og:description" content="{{ Carbon::parse($tanggal_nikah)->translatedFormat('l, d F Y') }}">
    <meta property="og:url" content="{{ url('undangan',$undangan->link) }}/">
    <meta property="og:image" content="{{ $bg_image }}">
    <meta property="og:image:secure_url" content="{{ $bg_image }}">
    <meta property="og:image:width" content="500">
    <meta property="og:image:height" content="500">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:title" content="Pernikahan {{ $undangan->nama_pria.' & '.$undangan->nama_wanita }}">
    <meta property="twitter:description" content="{{ Carbon::parse($tanggal_nikah)->translatedFormat('l, d F Y') }}">
    <meta property="twitter:image" content="{{ $bg_image }}">
    <meta itemprop="name" content="Pernikahan {{ $undangan->nama_pria.' & '.$undangan->nama_wanita }}">
    <meta itemprop="description" content="{{ Carbon::parse($tanggal_nikah)->translatedFormat('l, d F Y') }}">
    <meta itemprop="image" content="{{ $bg_image }}">
    <link href="{{ asset('frontend/undangan/mylove/css/themify-icons.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/flaticon.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/owl.carousel.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/owl.theme.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/slick.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/slick-theme.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/swiper.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/nice-select.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/owl.transitions.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/jquery.fancybox.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/odometer-theme-default.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/sass/style.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/datatables/css/jquery.dataTables.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/mylove/css/template.css') }}" rel="stylesheet">
    <style>
        .wpo-video-section {
            background: url("{{ $bg_image }}") no-repeat center center;
        }
        .wpo-event-section:before,
        .wpo-event-section-s2:before {
            background: url("{{ asset('frontend/undangan/mylove/images/event/bg.jpg') }}") no-repeat center center;
        }
    </style>
</head>

<body class="{{ $undangan->warna_undangan }}">
    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <div class="preloader">
            <div class="vertical-centered-box">
                <div class="content">
                    <div class="loader-circle"></div>
                    <div class="loader-line-mask">
                        <div class="loader-line"></div>
                    </div>
                    <img src="{{ asset('frontend/undangan/mylove/images/preloader.png') }}" alt="">
                </div>
            </div>
        </div>
        <!-- end preloader -->
        <!-- Start header -->
        <header id="header">
            <div class="wpo-site-header">
                <nav class="navigation navbar navbar-expand-lg navbar-light" style="z-index: 99">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <div class="col-lg-3 col-md-3 col-3 d-lg-none dl-block">
                                <div class="mobail-menu">
                                    <button type="button" class="navbar-toggler open-btn">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar first-angle"></span>
                                        <span class="icon-bar middle-angle"></span>
                                        <span class="icon-bar last-angle"></span>
                                    </button>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-6 col-6">
                                <div class="navbar-header" style="text-align: center;">
                                    <a class="navbar-brand logo" href="" style="top: 0px;">{{ $undangan->nama_pria[0] }} <small>&</small> {{ $undangan->nama_wanita[0] }}</a>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-1 col-1">
                                <div id="navbar" class="collapse navbar-collapse navigation-holder">
                                    <button class="menu-close"><i class="ti-close"></i></button>
                                    <ul class="nav navbar-nav mb-2 mb-lg-0">
                                        <li><a href="#home">Beranda</a></li>
                                        <li><a href="#story">Cerita</a></li>
                                        <li><a href="#gallery">Galeri</a></li>
                                        <li><a href="#rsvp">Ucapan</a></li>
                                        <li><a href="#event">Tempat</a></li>
                                        <li><a href="#gift">Amplop</a></li>
                                    </ul>
                                </div><!-- end of nav-collapse -->
                            </div>
                        </div>
                    </div><!-- end of container -->
                </nav>
            </div>
        </header>
        <!-- end of header -->
        @if ($undangan->slider->status_slider)
        <!-- start of hero -->
        <section class="wpo-hero-slider wpo-hero-style-3">
            <div class="wedding-announcement">
                <div class="couple-text">
                    <h2 class="wow slideInUp" data-wow-duration="1s">{{ $undangan->nama_pria . ' & ' . $undangan->nama_wanita }}</h2>
                    <p class="wow slideInUp" data-wow-duration="1.8s">{{ Carbon::parse($tanggal_nikah)->translatedFormat('l, d F Y') }}</p>
                    <!-- start wpo-wedding-date -->
                    <div class="wpo-wedding-date wow slideInUp" data-wow-duration="2.1s">
                        <div class="clock-grids">
                            <div id="clock"></div>
                        </div>
                    </div>
                    <a href="{{ $google_calendar }}" target="_blank" class="btn btn-primary wow slideInUp mt-3" data-wow-duration="2.1s">Simpan Tanggal Acara</a>
                    <!-- end wpo-wedding-date -->
                </div>
            </div>
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_1) }}">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_2) }}">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_3) }}">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slide-inner slide-bg-image" data-background="{{ asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_4) }}">
                        </div>
                    </div>
                </div>
                <!-- end swiper-wrapper -->
                <!-- swipper controls -->
                <div class="swiper-pagination"></div>
                <div class="next-prev-btn">
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
            </div>
        </section>
        <!-- end of hero slider -->
        @endif
        <div class="container" id="home" style="padding-top: 40px; padding-bottom: 40px; text-align: center;">
            @if ($undangan->slider->status_slider == 0)
                <h1>{{ $undangan->nama_pria . ' & ' . $undangan->nama_wanita }}</h1>
                <p style="margin-bottom: 0px;">{{ Carbon::parse($tanggal_nikah)->translatedFormat('l, d F Y') }}</p>
            @endif
            <div class="wpo-section-title" style="margin-bottom: 10px;">
                <div class="section-title-icon">
                    <i class="fi flaticon-dove"></i>
                </div>
            </div>
            <div class="kalimat_pembuka wow fadeInUp" data-wow-duration="1200ms">{!! $undangan->slider->kalimat_pembuka !!}</div>
        </div>
        <!-- start couple-section -->
        <section class="couple-section section-padding" style="padding-top: 0px;">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col col-lg-11">
                        <div class="couple-area clearfix">
                            <div class="couple-item bride wow fadeInLeft" data-wow-duration="2s">
                                <div class="row align-items-center">
                                    <div class="col-lg-4">
                                        <div style="border: 10px solid #EEE;">
                                            <img src="{{ asset('frontend/undangan/foto_pengantin/'.$undangan->pengantin->foto_pria) }}" alt="foto pengantin">
                                        </div>
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="couple-text" style="padding-left: 20px;">
                                            <h3 style="line-height: 60px;">{{ $undangan->full_nama_pria }}</h3>
                                            <p style="margin-bottom: 0px;">{{ $undangan->pengantin->anak_of_pria }}</p>
                                            <p style="margin-bottom: 0px; font-weight: bold;">{{ $undangan->pengantin->ortu_pria }}</p>
                                            <div class="social">
                                                <ul>
                                                    @if (!empty($undangan->pengantin->ig_pria))<li><a href="https://www.instagram.com/{{ $undangan->pengantin->ig_pria }}" target="_blank"><i class="ti-instagram"></i></a></li>@endif
                                                    @if (!empty($undangan->pengantin->twitter_pria))<li><a href="https://www.twitter.com/{{ $undangan->pengantin->twitter_pria }}" target="_blank"><i class="ti-twitter-alt"></i></a></li>@endif
                                                    @if (!empty($undangan->pengantin->fb_pria))<li><a href="https://www.facebook.com/{{ $undangan->pengantin->fb_pria }}" target="_blank"><i class="ti-facebook"></i></a></li>@endif
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="couple-item groom wow fadeInRight" data-wow-duration="2s">
                                <div class="row align-items-center">
                                    <div class="col-lg-8 order-lg-1 order-2">
                                        <div class="couple-text" style="padding-right: 20px;">
                                            <h3 style="line-height: 60px;">{{ $undangan->full_nama_wanita }}</h3>
                                            <p style="margin-bottom: 0px;">{{ $undangan->pengantin->anak_of_wanita }}</p>
                                            <p style="margin-bottom: 0px; font-weight: bold;">{{ $undangan->pengantin->ortu_wanita }}</p>
                                            <div class="social">
                                                <ul>
                                                    @if (!empty($undangan->pengantin->ig_wanita))<li><a href="https://www.instagram.com/{{ $undangan->pengantin->ig_wanita }}" target="_blank"><i class="ti-instagram"></i></a></li>@endif
                                                    @if (!empty($undangan->pengantin->twitter_wanita))<li><a href="https://www.twitter.com/{{ $undangan->pengantin->twitter_wanita }}" target="_blank"><i class="ti-twitter-alt"></i></a></li>@endif
                                                    @if (!empty($undangan->pengantin->fb_wanita))<li><a href="https://www.facebook.com/{{ $undangan->pengantin->fb_wanita }}" target="_blank"><i class="ti-facebook"></i></a></li>@endif
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 order-lg-2 order-1">
                                        <div style="border: 10px solid #EEE;">
                                            <img src="{{ asset('frontend/undangan/foto_pengantin/'.$undangan->pengantin->foto_wanita) }}" alt="foto pengantin">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end couple-section -->

        @if (!empty($undangan->slider->link_youtube))
        <!-- start wpo-video-section -->
        <section class="wpo-video-section wow zoomIn" data-wow-duration="2s">
            <h2 class="hidden">some</h2>
            <a href="{{ $undangan->slider->link_youtube }}" class="video-btn" data-type="iframe"><i class="fi flaticon-play"></i></a>
        </section>
        <!-- end wpo-video-section-->
        @endif

        @if (count($undangan->cerita) > 0)
        <!-- start story-section -->
        <section class="story-section section-padding" id="story">
            <div class="container">
                <div class="row">
                    <div class="wpo-section-title">
                        <div class="section-title-icon">
                            <i class="fi flaticon-dove"></i>
                        </div>
                        <h2>Cerita Cinta</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="story-timeline">
                            <div class="row">
                                <div class="col offset-lg-6 col-lg-6 col-12 text-holder">
                                    <span class="heart">
                                        <i class="fi flaticon-balloon"></i>
                                    </span>
                                </div>
                            </div>
                            @foreach ($undangan->cerita as $cerita)
                            <div class="story-timeline-item s1">
                                <div class="row align-items-center">
                                    <div class="col col-lg-6 col-12">
                                        <div class="img-holder right-align-text wow fadeInLeftSlow" data-wow-duration="1500ms">
                                            <img src="{{ asset('frontend/undangan/foto_cerita/'.$cerita->foto_cerita) }}" alt class="img img-responsive">
                                        </div>
                                    </div>
                                    <div class="col col-lg-6 col-12">
                                        <div class="story-text left-align-text wow fadeInRightSlow" data-wow-duration="2000ms">
                                            <h3>{{ $cerita->judul_cerita }}</h3>
                                            <span class="date">{{ $cerita->waktu_cerita }}</span>
                                            <div class="line-shape">
                                                <div class="outer-ball">
                                                    <div class="inner-ball"></div>
                                                </div>
                                            </div>
                                            <p>{{ $cerita->isi_cerita }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
            <div class="shape-1">
                <div class="sticky-shape">
                    <img src="{{ asset('frontend/undangan/mylove/images/story/shape-1.png') }}" alt="">
                </div>  
            </div>
            <div class="shape-2">
                <div class="sticky-shape">
                    <img src="{{ asset('frontend/undangan/mylove/images/story/shape-2.png') }}" alt="">
                </div>
            </div>
        </section>
        <!-- end story-section -->
        @endif

        @if (count($undangan->galeri) > 0)
        <!-- start wpo-portfolio-section -->
        <section class="wpo-portfolio-section section-padding pt-0" id="gallery">
            <div class="container">
                <div class="row">
                    <div class="wpo-section-title">
                        <div class="section-title-icon">
                            <i class="fi flaticon-dove"></i>
                        </div>
                        <h2>Galeri Foto</h2>
                    </div>
                </div>
                <div class="sortable-gallery wow fadeInUp" data-wow-duration="2s">
                    <div class="gallery-filters"></div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="portfolio-grids gallery-container clearfix">
                                @foreach ($undangan->galeri as $galeri)
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/foto_galeri/'.$galeri->foto) }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/foto_galeri/'.$galeri->foto) }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- end container -->
        </section>
        <!-- end wpo-portfolio-section -->
        @endif

        <!-- start of wpo-contact-section -->
        <section class="wpo-contact-section section-padding" id="rsvp">
            <div class="container">
                <div class="wpo-contact-section-wrapper">
                    <div class="wpo-contact-form-area" style="padding: 130px 40px;">
                        <div class="wpo-section-title">
                            <div class="section-title-icon">
                                <i class="fi flaticon-dove"></i>
                            </div>
                            <h4>Berikan ucapan dan kehadiran anda</h4>
                        </div>
                        <div id="alert_message"></div>
                        <form id="ucapanForm" name="ucapanForm" autocomplete="off">
                            <div>
                                <input type="text" class="form-control" name="nama" id="nama" placeholder="Nama Anda" required>
                            </div>
                            <div>
                                <textarea class="form-control" name="ucapan" id="ucapan" placeholder="Ketik Ucapan & Doa" style="height: 80px;" required></textarea>
                            </div>
                            <div class="radio-buttons">
                                <p>
                                    <input type="radio" value="Hadir" id="ya" name="kehadiran" checked>
                                    <label for="ya">Ya, saya akan hadir</label>
                                </p>
                                <p>
                                    <input type="radio" value="Tidak Hadir" id="tidak" name="kehadiran">
                                    <label for="tidak">Maaf, saya tidak bisa hadir</label>
                                </p>
                                <p>
                                    <input type="radio" value="Belum Yakin" id="ragu" name="kehadiran">
                                    <label for="ragu">Saya belum yakin bisa hadir atau tidak</label>
                                </p>
                            </div>
                            <div class="submit-area">
                                <button type="submit" id="simpanBtn" value="create" class="btn btn-primary">Kirim</button>
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#ucapanModal">
                                    Lihat Semua Ucapan
                                </button>
                            </div>
                        </form>
                        <div class="border-style"></div>
                    </div>
                    <div class="vector-1">
                        <img src="{{ asset('frontend/undangan/mylove/images/rsvp/flower1.png') }}" alt="">
                    </div>
                    <div class="vector-2">
                        <img src="{{ asset('frontend/undangan/mylove/images/rsvp/flower2.png') }}" alt="">
                    </div>
                </div>
            </div>
            <div class="shape-1">
                <img src="{{ asset('frontend/undangan/mylove/images/rsvp/shape1.png') }}" alt="">
            </div>
            <div class="shape-2">
                <img src="{{ asset('frontend/undangan/mylove/images/rsvp/shape2.png') }}" alt="">
            </div>
        </section>
        <!-- end of wpo-contact-section -->

        <!-- start wpo-event-section -->
        <section class="wpo-event-section section-padding" id="event" style="padding-bottom: 0px;">
            <div class="container">
                <div class="row">
                    <div class="wpo-section-title-s2">
                        <div class="section-title-icon">
                            <i class="fi flaticon-dove"></i>
                        </div>
                        <h2>Waktu & Tempat Acara</h2>
                    </div>
                </div>
                <div class="wpo-event-wrap">
                    <div class="row justify-content-center">
                        <div class="col col-lg-4 col-md-6 col-12 wow fadeInLeft" data-wow-duration="2s">
                            <div class="wpo-event-item">
                                <div class="wpo-event-text">
                                    <h2>{{ $undangan->tempat[0]->nama_acara }}</h2>
                                    <ul>
                                        <li>{{ Carbon::parse($undangan->tempat[0]->tanggal_acara)->translatedFormat('l, d F Y \P\u\k\u\l H:i') }}</li>
                                        <li style="font-weight: bold;">{{ $undangan->tempat[0]->tempat_acara }}</li>
                                        <li>{{ $undangan->tempat[0]->alamat_acara }}</li>
                                        <li><a href="{{ $undangan->tempat[0]->link_maps }}" target="_blank" class="btn btn-primary text-white">Buka Maps</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        @if (!empty($undangan->tempat[1]->nama_acara))
                        <div class="col col-lg-4 col-md-6 col-12 wow fadeInRight" data-wow-duration="2s">
                            <div class="wpo-event-item">
                                <div class="wpo-event-text">
                                    <h2>{{ $undangan->tempat[1]->nama_acara }}</h2>
                                    <ul>
                                        <li>{{ Carbon::parse($undangan->tempat[1]->tanggal_acara)->translatedFormat('l, d F Y \P\u\k\u\l H:i') }}</li>
                                        <li style="font-weight: bold;">{{ $undangan->tempat[1]->tempat_acara }}</li>
                                        <li>{{ $undangan->tempat[1]->alamat_acara }}</li>
                                        <li><a href="{{ $undangan->tempat[1]->link_maps }}" target="_blank" class="btn btn-primary text-white">Buka Maps</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end wpo-event-section -->

        @if (!empty($undangan->tempat[0]->nama_bank))
        <!-- start wpo-pricing-section -->
        <section class="wpo-pricing-section section-padding" style="padding-top: 70px; padding-bottom: 40px;" id="gift">
            <div class="container">
                <div class="row">
                    <div class="wpo-section-title" style="margin-bottom: 30px;">
                        <div class="section-title-icon">
                            <i class="fi flaticon-dove"></i>
                        </div>
                        <h2>Amplop Digital</h2>
                    </div>
                </div>
                <div class="wpo-pricing-wrap wow zoomIn" data-wow-duration="2s">
                    <div class="row">
                        <div class="col col-lg-6 col-md-6 col-12" style="text-align: center;">
                            <div class="wpo-pricing-item">
                                <div class="wpo-pricing-top pb-1">
                                    <div class="wpo-pricing-text">
                                        <h3>{{ $undangan->tempat[0]->nama_bank }}</h3>
                                        <h2 style="font-size: 28px; font-weight: bold; padding-top: 10px;" id="bank_1">{{ $undangan->tempat[0]->nomor_rekening }}</h2>
                                        <h4 style="padding-top: 10px;">{{ $undangan->tempat[0]->pemilik_rekening }}</h4>
                                    </div>
                                </div>
                                <div class="shape"><img src="{{ asset('frontend/undangan/lovelove/images/pricing/p-shape.svg') }}" alt=""></div>
                                <div class="wpo-pricing-bottom py-3">
                                    <div class="wpo-pricing-bottom-text">
                                        <button onclick="copyNoRekening('#bank_1')" class="btn btn-primary mb-2">Salin Nomor Rekening</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @if (!empty($undangan->tempat[1]->nama_bank))
                        <div class="col col-lg-6 col-md-6 col-12" style="text-align: center;">
                            <div class="wpo-pricing-item">
                                <div class="wpo-pricing-top pb-1">
                                    <div class="wpo-pricing-text">
                                        <h3>{{ $undangan->tempat[1]->nama_bank }}</h3>
                                        <h2 style="font-size: 28px; font-weight: bold; padding-top: 10px;" id="bank_2">{{ $undangan->tempat[1]->nomor_rekening }}</h2>
                                        <h4 style="padding-top: 10px;">{{ $undangan->tempat[1]->pemilik_rekening }}</h4>
                                    </div>
                                </div>
                                <div class="shape"><img src="{{ asset('frontend/undangan/lovelove/images/pricing/p-shape.svg') }}" alt=""></div>
                                <div class="wpo-pricing-bottom py-3">
                                    <div class="wpo-pricing-bottom-text">
                                        <button onclick="copyNoRekening('#bank_2')" class="btn btn-primary mb-2">Salin Nomor Rekening</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </section>
        <!-- start wpo-pricing-section -->
        @endif

        <!-- start of wpo-site-footer-section -->
        <footer class="wpo-site-footer">
            <div class="wpo-lower-footer">
                <div class="container">
                    <div class="row">
                        <div class="col col-xs-12">
                            <p class="copyright"><a href="{{ url('/') }}">{{ $set_umum->value_3 }}. All Right Reserved.</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end of wpo-site-footer-section -->
    </div>
    <!-- end of page-wrapper -->

    <!-- Modal -->
    <div class="modal fade show" id="fullwedding" style="display: block">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="modal-body" style="padding: 0px;">
                    <!-- start of hero -->
                    <section class="static-hero-s4" style="height: 100vh;">
                        <div class="hero-container">
                            <div class="hero-inner" style="padding: 0px;">
                                <div class="container" style="padding-left: 0px; padding-right: 0px;">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-12">
                                            <div class="wpo-event-item" style="padding: 100px 0px;">
                                                <div class="wpo-event-text">
                                                    <h2>{{ $undangan->nama_pria.' & '.$undangan->nama_wanita }}</h2>
                                                    <p style="color: #06002E; font-size: 18px; margin-bottom: 0px; line-height: 24px;">Kepada yang terhormat Bapak/Ibu/Saudara/i :</p>
                                                    <p style="color: #06002E; font-size: 25px; font-weight: bold; margin: 10px 0px; line-height: 28px;">{{ $tamu }}</p>
                                                    <button class="btn btn-primary btn-lg mb-2" id="bukaUndangan">Buka Undangan</button>
                                                    <p style="color: #06002E; margin: 5px 0px; font-size: 18px; line-height: 20px;">Mohon maaf jika ada kesalahan penulisan nama dan gelar</p>
                                                </div>
                                                <div class="shape-1"><img src="{{ asset('frontend/undangan/mylove/images/slider/flower1.png') }}" alt=""></div>
                                                <div class="shape-2"><img src="{{ asset('frontend/undangan/mylove/images/slider/flower2.png') }}" alt=""></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- end of hero slider -->
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="ucapanModal" tabindex="-1" aria-labelledby="ucapanModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="ucapanModalLabel">Ucapan dari tamu undangan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-striped" width="100%" id="table_ucapan">
                            <thead>
                                <tr>
                                    <th>Nama Tamu</th>
                                    <th>Ucapan Tamu</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if (!empty($undangan->slider->musik))
        <button class="button-musik"><i class="fa fa-pause"></i></button>
        <audio id="musik" src="{{ asset('frontend/undangan/musik/' . $undangan->slider->musik) }}"></audio>
    @endif
    <!-- All JavaScript files
    ================================================== -->
    <script src="{{ asset('frontend/undangan/mylove/js/jquery.min.js') }}"></script>
    <script src="{{ asset('frontend/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('frontend/undangan/mylove/js/bootstrap.bundle.min.js') }}"></script>
    <!-- Plugins for this template -->
    <script src="{{ asset('frontend/undangan/mylove/js/modernizr.custom.js') }}"></script>
    <script src="{{ asset('frontend/undangan/mylove/js/jquery.dlmenu.js') }}"></script>
    <script src="{{ asset('frontend/undangan/mylove/js/jquery-plugin-collection.js') }}"></script>
    <!-- Custom script for this template -->
    <script src="{{ asset('frontend/libs/js/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('frontend/undangan/mylove/js/script.js') }}"></script>
    <script type="text/javascript">
        $('#clock').countdown("{{ $tanggal_nikah }}", function (event) {
            var $this = $(this).html(event.strftime(''
                + '<div class="box"><div><div class="time">%D</div> <span>Hari</span> </div></div>'
                + '<div class="box"><div><div class="time">%H</div> <span>Jam</span> </div></div>'
                + '<div class="box"><div><div class="time">%M</div> <span>Menit</span> </div></div>'
                + '<div class="box"><div><div class="time">%S</div> <span>Detik</span> </div></div>'));
        });

        $("#bukaUndangan").click(function () {
            $("#fullwedding").fadeToggle("slow");
            @if(!empty($undangan->slider->musik))
                $("#musik")[0].play();
                $("#musik").on("ended", function() {
                    this.currentTime = 0;
                    this.play();
                });
                $(".button-musik").click(function() {
                    if ($(this).find("i").hasClass("fa-play")) {
                        $("#musik")[0].play();
                        $(this).html('<i class="fa fa-pause"></i>');
                    } else {
                        $("#musik")[0].pause();
                        $(this).html('<i class="fa fa-play"></i>');
                    }
                });
            @endif
        });

        $(function () {
            $.ajaxSetup({
                headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.fn.dataTable.ext.classes.sPageButton = 'btn btn-dark';
            var table = $('#table_ucapan').DataTable({
                language: {
                    "infoFiltered": "",
                    "zeroRecords": "Daftar tamu & ucapan masih kosong",
                    "paginate": {
                        "previous": "<i class='ti-angle-left'>",
                        "next": "<i class='ti-angle-right'>",
                    }
                },
                processing: true,
                serverSide: true,
                ajax: "{{ route('data_ucapan', $undangan->kode) }}",
                columns: [
                    { data: 'nama_tamu', name: 'nama_tamu' },
                    { data: 'ucapan', name: 'ucapan' },
                ],
                "bFilter": false,
                "bLengthChange": false,
                "bInfo": false,
                "ordering": false,
                "aoColumnDefs": [
                    { "className": "text-center", "targets" : [0] },
                ],
                "aaSorting": [],
            });
            $('#simpanBtn').click(function (e) {
                e.preventDefault();
                $(this).prop('disabled', true).html('Proses kirim...');
                $.ajax({
                    data: $('#ucapanForm').serialize(),
                    url: "{{ route('ucapan_tamu', $undangan->kode) }}",
                    type: "POST",
                    dataType: 'json',
                    success: function (data) {
                        $('#ucapanForm').trigger("reset");
                        table.draw();
                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            html: '<div style="font-size: 20px; font-weight: bold;">'+ data.message +'</div>',
                            showConfirmButton: false,
                            timer: 1500
                        });
                    },
                    error: function (data) {
                        var errors = data.responseJSON.errors;
                        var errorMessage = '';
                        for (var key in errors) {
                            errorMessage += errors[key] + '<br>';
                        }
                        $('#alert_message').html('<div class="alert alert-danger" >'+ errorMessage +'</div>');
                    },
                    complete: function () {
                        $('#simpanBtn').prop('disabled', false).html('Kirim');
                    }
                });
            });
        });
    </script>
    <!-- =======================================================
    * Template Mylove: https://themeforest.net/item/mylove-wedding-html5-template/38484030
    * Image by: https://www.freepik.com/
    ======================================================== -->
</body>

</html>