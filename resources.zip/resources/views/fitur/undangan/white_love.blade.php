<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="{{ asset('frontend/images/favicon/'.$set_umum->value_4) }}">
    <title>{{ $undangan->nama_pria.' & '.$undangan->nama_wanita }}</title>
    <meta name="description" content="Pernikahan {{ $undangan->nama_pria.' & '.$undangan->nama_wanita.' '.Carbon::parse($tanggal_nikah)->translatedFormat('l, d F Y') }}">
    <meta name="keywords" content="undangan digital, undangan online, undangan nikah online, website undangan pernikahan">
    <meta property="og:locale" content="id_ID">
    <meta property="og:type" content="article">
    <meta property="og:title" content="Pernikahan {{ $undangan->nama_pria.' & '.$undangan->nama_wanita }}">
    <meta property="og:description" content="{{ Carbon::parse($tanggal_nikah)->translatedFormat('l, d F Y') }}">
    <meta property="og:url" content="{{ url('undangan',$undangan->link) }}/">
    <meta property="og:image" content="{{ $bg_image }}">
    <meta property="og:image:secure_url" content="{{ $bg_image }}">
    <meta property="og:image:width" content="500">
    <meta property="og:image:height" content="500">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:title" content="Pernikahan {{ $undangan->nama_pria.' & '.$undangan->nama_wanita }}">
    <meta property="twitter:description" content="{{ Carbon::parse($tanggal_nikah)->translatedFormat('l, d F Y') }}">
    <meta property="twitter:image" content="{{ $bg_image }}">
    <meta itemprop="name" content="Pernikahan {{ $undangan->nama_pria.' & '.$undangan->nama_wanita }}">
    <meta itemprop="description" content="{{ Carbon::parse($tanggal_nikah)->translatedFormat('l, d F Y') }}">
    <meta itemprop="image" content="{{ $bg_image }}">
    <link href="{{ asset('frontend/undangan/lovelove/css/themify-icons.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/flaticon.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/owl.carousel.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/owl.theme.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/slick.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/slick-theme.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/swiper.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/nice-select.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/owl.transitions.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/jquery.fancybox.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/odometer-theme-default.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/jquery-ui.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/sass/style.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/datatables/css/jquery.dataTables.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/undangan/lovelove/css/template.css') }}" rel="stylesheet">
</head>

<body class="{{ $undangan->warna_undangan }}">
    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <div class="preloader">
            <div class="vertical-centered-box">
                <div class="content">
                    <div class="loader-circle"></div>
                    <div class="loader-line-mask">
                        <div class="loader-line"></div>
                    </div>
                    <img src="{{ asset('frontend/undangan/lovelove/images/preloader.svg') }}" alt="">
                </div>
            </div>
        </div>
        <!-- end preloader -->

        <!-- Start header -->
        <header id="header">
            <div class="wpo-site-header wpo-header-style-1" id="sticky-header">
                <nav class="navigation navbar navbar-expand-lg navbar-light">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <div class="col-md-2 col-2 d-lg-none d-block">
                                <div class="mobail-menu">
                                    <button type="button" class="navbar-toggler open-btn">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar first-angle"></span>
                                        <span class="icon-bar middle-angle"></span>
                                        <span class="icon-bar last-angle"></span>
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-10 col-10 d-lg-none d-block">
                                <div class="navbar-header">
                                    <a class="navbar-brand mx-auto" href="#"><h3 style="margin: 14px 0px 0px; font-weight: bold; text-align: center;" id="inisial">
                                        <span class="shape-1"><img src="{{ asset('frontend/undangan/lovelove/images/slider/shape.png') }}" alt="" width="80"></span>
                                        {{ $undangan->nama_pria[0] . ' & ' . $undangan->nama_wanita[0] }}
                                        <span class="shape-2"><img src="{{ asset('frontend/undangan/lovelove/images/slider/shape2.png') }}" alt="" width="80"></span>
                                    </h3></a>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-1 col-1">
                                <div id="navbar" class="collapse navbar-collapse navigation-holder">
                                    <button class="menu-close"><i class="ti-close"></i></button>
                                    <ul class="nav navbar-nav mb-2 mb-lg-0">
                                        <li><a href="#home">Beranda</a></li>
                                        <li><a href="#story">Cerita</a></li>
                                        <li><a href="#gallery">Galeri</a></li>
                                        <li><a href="#rsvp">Ucapan</a></li>
                                        <li><a href="#event">Tempat</a></li>
                                        <li><a href="#gift">Amplop</a></li>
                                    </ul>
                                </div><!-- end of nav-collapse -->
                            </div>
                        </div>
                    </div><!-- end of container -->
                </nav>
            </div>
        </header>
        <!-- end of header -->

        @if ($undangan->slider->status_slider)
        <!-- start of hero -->
        <section class="wpo-hero-section">
            <div class="container-fluid">
                <div class="row">
                    <div class="wpo-hero-items owl-carousel">
                        <div class="wpo-hero-item">
                            <div class="wpo-hero-img">
                                <img src="{{ asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_1) }}" alt="foto slide 1">
                                <div class="wpo-hero-text">
                                    <h2>{{ $undangan->slider->title_slider_1 }}</h2>
                                </div>
                            </div>
                        </div>
                        <div class="wpo-hero-item">
                            <div class="wpo-hero-img">
                                <img src="{{ asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_2) }}" alt="foto slide 2">
                                <div class="wpo-hero-text">
                                    <h2>{{ $undangan->slider->title_slider_2 }}</h2>
                                </div>
                            </div>
                        </div>
                        <div class="wpo-hero-item">
                            <div class="wpo-hero-img">
                                <img src="{{ asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_3) }}" alt="foto slide 3">
                                <div class="wpo-hero-text">
                                    <h2>{{ $undangan->slider->title_slider_3 }}</h2>
                                </div>
                            </div>
                        </div>
                        <div class="wpo-hero-item">
                            <div class="wpo-hero-img">
                                <img src="{{ asset('frontend/undangan/foto_slider/'.$undangan->slider->foto_slider_4) }}" alt="foto slide 4">
                                <div class="wpo-hero-text">
                                    <h2>{{ $undangan->slider->title_slider_4 }}</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of hero slider -->
        @endif

        <!-- start wpo-wedding-date -->
        <section class="wpo-wedding-date section-padding pt-5" id="home">
            <div class="container" style="max-width: 1200px;">
                <h2 class="wow fadeInUp" data-wow-duration="1200ms" style="font-weight: bold;">
                    <span class="shape-1"><img src="{{ asset('frontend/undangan/lovelove/images/slider/shape.png') }}" alt="" width="200px"></span>
                    {{ $undangan->nama_pria . ' & ' . $undangan->nama_wanita }}
                    <span class="shape-2"><img src="{{ asset('frontend/undangan/lovelove/images/slider/shape2.png') }}" alt=""width="200px"></span>
                </h2>
                <p class="wow fadeInUp" data-wow-duration="1200ms" style="line-height: 28px; margin-top: 10px;">{!! $undangan->slider->kalimat_pembuka !!}</p>
                <div class="row wow fadeInUp pb-4" data-wow-duration="1400ms">
                    <div class="col col-xs-12">
                        <div class="clock-grids">
                            <div id="clock" style="font-weight: bold;"></div>
                        </div>
                    </div>
                </div>
                <a href="{{ $google_calendar }}" target="_blank" class="btn btn-primary wow zoomIn" data-wow-duration="1400ms">Simpan Tanggal Acara</a>
            </div> <!-- end container -->
        </section>
        <!-- end wpo-wedding-date -->

        <!-- start couple-section -->
        <section class="wpo-couple-section-s3 section-padding pb-3" id="couple">
            <div class="container">
                <div class="couple-area clearfix">
                    <div class="row align-items-center">
                        <div class="col col-md-5 col-12">
                            <div class="couple-item wow fadeInLeftSlow" data-wow-duration="1700ms">
                                <div class="couple-img">
                                    <img src="{{ asset('frontend/undangan/foto_pengantin/'.$undangan->pengantin->foto_pria) }}" alt="foto pengantin">
                                </div>
                                <div class="couple-text">
                                    <h3>{{ $undangan->full_nama_pria }}</h3>
                                    <b>{{ $undangan->pengantin->anak_of_pria }}</b>
                                    <p style="margin-bottom: 0px;">{{ $undangan->pengantin->ortu_pria }}</p>
                                    <div class="social">
                                        <ul>
                                            @if (!empty($undangan->pengantin->ig_pria))<li><a href="https://www.instagram.com/{{ $undangan->pengantin->ig_pria }}" target="_blank"><i class="ti-instagram"></i></a></li>@endif
                                            @if (!empty($undangan->pengantin->twitter_pria))<li><a href="https://www.twitter.com/{{ $undangan->pengantin->twitter_pria }}" target="_blank"><i class="ti-twitter-alt"></i></a></li>@endif
                                            @if (!empty($undangan->pengantin->fb_pria))<li><a href="https://www.facebook.com/{{ $undangan->pengantin->fb_pria }}" target="_blank"><i class="ti-facebook"></i></a></li>@endif
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-md-2 col-12">
                            <div class="middle-couple-shape wow fadeInUp" data-wow-duration="1200ms">
                                <div class="shape">
                                    <img src="{{ asset('frontend/undangan/lovelove/images/couple/shape.png') }}" alt="" width="100px">
                                </div>
                            </div>
                        </div>
                        <div class="col col-md-5 col-12">
                            <div class="couple-item wow fadeInRightSlow" data-wow-duration="1700ms">
                                <div class="couple-img">
                                    <img src="{{ asset('frontend/undangan/foto_pengantin/'.$undangan->pengantin->foto_wanita) }}" alt="foto pengantin">
                                </div>
                                <div class="couple-text">
                                    <h3>{{ $undangan->full_nama_wanita }}</h3>
                                    <b>{{ $undangan->pengantin->anak_of_wanita }}</b>
                                    <p style="margin-bottom: 0px;">{{ $undangan->pengantin->ortu_wanita }}</p>
                                    <div class="social">
                                        <ul>
                                            @if (!empty($undangan->pengantin->ig_wanita))<li><a href="https://www.instagram.com/{{ $undangan->pengantin->ig_wanita }}" target="_blank"><i class="ti-instagram"></i></a></li>@endif
                                            @if (!empty($undangan->pengantin->twitter_wanita))<li><a href="https://www.twitter.com/{{ $undangan->pengantin->twitter_wanita }}" target="_blank"><i class="ti-twitter-alt"></i></a></li>@endif
                                            @if (!empty($undangan->pengantin->fb_wanita))<li><a href="https://www.facebook.com/{{ $undangan->pengantin->fb_wanita }}" target="_blank"><i class="ti-facebook"></i></a></li>@endif
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end couple-section -->

        @if (!empty($undangan->slider->link_youtube))
        <!-- start wpo-video-section -->
        <section class="wpo-video-section-s2 pb-0 pt-5 section-padding">
            <h2 class="hidden">some</h2>
            <div class="container">
                <div class="video-wrap">
                    <img src="{{ $bg_image }}" alt="video">
                    <a href="{{ $undangan->slider->link_youtube }}" class="video-btn" data-type="iframe"><i class="fi flaticon-play"></i></a>
                </div>
            </div>
        </section>
        <!-- end wpo-video-section-->
        @endif

        @if (count($undangan->cerita) > 0)
        <!-- start wpo-story-section -->
        <section class="wpo-story-section-s3 section-padding pb-0" id="story" style="padding-top: 60px;">
            <div class="container">
                <div class="wpo-section-title">
                    <h2 class="wow fadeInUp" data-wow-duration="1200ms" style="margin-top: 0px;">Cerita Cinta</h2>
                </div>
                <div class="wpo-story-wrap">
                    @foreach ($undangan->cerita as $cerita)
                    <div class="wpo-story-item">
                        <div class="wpo-story-img-wrap wow zoomIn" data-wow-duration="1700ms">
                            <div class="wpo-story-img">
                                <img src="{{ asset('frontend/undangan/foto_cerita/'.$cerita->foto_cerita) }}" alt="foto cerita">
                            </div>
                        </div>
                        <div class="wpo-story-content wow fadeIn" data-wow-duration="1700ms">
                            <div class="wpo-story-content-inner">
                                <h2>{{ $cerita->judul_cerita }}</h2>
                                <span>{{ $cerita->waktu_cerita }}</span>
                                <p>{{ $cerita->isi_cerita }}</p>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end story-section -->
        @endif

        @if (count($undangan->galeri) > 0)
        <!-- start wpo-portfolio-section -->
        <section class="wpo-portfolio-section-s5 section-padding pb-0" id="gallery" style="padding-top: 60px;">
            <div class="container">
                <div class="wpo-section-title">
                    <h2 class="wow fadeInUp" data-wow-duration="1200ms" style="margin-top: 0px;">Galeri Foto</h2>
                </div>
                <div class="sortable-gallery wow zoomIn" data-wow-duration="1200ms">
                    <div class="gallery-filters"></div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="portfolio-grids gallery-container clearfix">
                                @foreach ($undangan->galeri as $galeri)
                                <div class="grid">
                                    <div class="img-holder">
                                        <a href="{{ asset('frontend/undangan/foto_galeri/'.$galeri->foto) }}" class="fancybox"
                                            data-fancybox-group="gall-1">
                                            <img src="{{ asset('frontend/undangan/foto_galeri/'.$galeri->foto) }}" alt class="img img-responsive">
                                            <div class="hover-content">
                                                <i class="ti-zoom-in"></i>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end wpo-portfolio-section -->
        @endif

        <!-- start of wpo-contact-section-s5 -->
        <section class="wpo-contact-section-s5 section-padding" id="rsvp">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col col-lg-12 col-md-12 col-12">
                        <div class="wpo-contact-section-wrapper wow slideInUp mx-auto" data-wow-duration="1200ms">
                            <div class="wpo-contact-section-inner">
                                <div class="wpo-contact-form-area" style="padding: 40px 10px">
                                    <div class="wpo-section-title">
                                        <div style="font-size: 18px; font-weight: bold;">Berikan ucapan dan kehadiran anda</div>
                                    </div>
                                    <div id="alert_message"></div>
                                    <form id="ucapanForm" name="ucapanForm" autocomplete="off">
                                        @csrf
                                        <div>
                                            <input type="text" class="form-control" name="nama" id="nama" placeholder="Nama Anda" required>
                                        </div>
                                        <div>
                                            <textarea class="form-control" name="ucapan" id="ucapan" placeholder="Ketik Ucapan & Doa" style="height: 80px;" required></textarea>
                                        </div>
                                        <div class="radio-buttons p-0">
                                            <p>
                                                <input type="radio" value="Hadir" id="ya" name="kehadiran" checked>
                                                <label for="ya">Ya, saya akan hadir</label>
                                            </p>
                                            <p>
                                                <input type="radio" value="Tidak Hadir" id="tidak" name="kehadiran">
                                                <label for="tidak">Maaf, saya tidak bisa hadir</label>
                                            </p>
                                            <p>
                                                <input type="radio" value="Belum Yakin" id="ragu" name="kehadiran">
                                                <label for="ragu">Saya belum yakin bisa hadir atau tidak</label>
                                            </p>
                                        </div>
                                        <div class="submit-area" style="margin-top: 20px;">
                                            <button type="submit" id="simpanBtn" value="create" class="btn btn-primary">Kirim</button>
                                            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#ucapanModal">
                                                Lihat Semua Ucapan
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-contact-section -->

        <!-- start wpo-event-section -->
        <section class="wpo-event-section section-padding pb-3" id="event" style="padding-top: 80px;">
            <div class="container">
                <div class="wpo-section-title">
                    <h2 class="wow fadeInUp" data-wow-duration="1200ms" style="margin-top: 0px;">Waktu & Tempat Acara</h2>
                </div>
                <div class="wpo-event-wrap wow slideInUp" data-wow-duration="1200ms">
                    <div class="row justify-content-center">
                        <div class="col col-lg-4 col-md-6 col-12">
                            <div class="wpo-event-item">
                                <div class="wpo-event-img">
                                    <img src="{{ asset('frontend/undangan/lovelove/images/event/wedding_1.jpg') }}" alt="wedding_1.jpg">
                                    <div class="title"><h2 style="font-weight: bold;">{{ $undangan->tempat[0]->nama_acara }}</h2></div>
                                </div>
                                <div class="wpo-event-text">
                                    <ul>
                                        <li>{{ Carbon::parse($undangan->tempat[0]->tanggal_acara)->translatedFormat('l, d F Y \P\u\k\u\l H:i') }}</li>
                                        <li style="font-weight: bold;">{{ $undangan->tempat[0]->tempat_acara }}</li>
                                        <li>{{ $undangan->tempat[0]->alamat_acara }}</li>
                                        <li><a href="{{ $undangan->tempat[0]->link_maps }}" target="_blank" class="btn btn-primary text-white">Buka Maps</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        @if (!empty($undangan->tempat[1]->nama_acara))
                        <div class="col col-lg-4 col-md-6 col-12">
                            <div class="wpo-event-item">
                                <div class="wpo-event-img">
                                    <img src="{{ asset('frontend/undangan/lovelove/images/event/wedding_2.jpg') }}" alt="wedding_2.jpg">
                                    <div class="title"><h2 style="font-weight: bold;">{{ $undangan->tempat[1]->nama_acara }}</h2></div>
                                </div>
                                <div class="wpo-event-text">
                                    <ul>
                                        <li>{{ Carbon::parse($undangan->tempat[1]->tanggal_acara)->translatedFormat('l, d F Y \P\u\k\u\l H:i') }}</li>
                                        <li style="font-weight: bold;">{{ $undangan->tempat[1]->tempat_acara }}</li>
                                        <li>{{ $undangan->tempat[1]->alamat_acara }}</li>
                                        <li><a href="{{ $undangan->tempat[1]->link_maps }}" target="_blank" class="btn btn-primary text-white">Buka Maps</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end wpo-event-section -->

        @if (!empty($undangan->tempat[0]->nama_bank))
        <!-- start wpo-pricing-section -->
        <section class="wpo-pricing-section section-padding pb-5" id="gift" style="padding-top: 80px;">
            <div class="container">
                <div class="wpo-section-title mb-4">
                    <h2 class="wow fadeInUp" data-wow-duration="1200ms" style="margin-top: 0px;">Amplop Digital</h2>
                </div>
                <div class="wpo-pricing-wrap pt-0 pb-5 wow zoomIn" data-wow-duration="1200ms">
                    <div class="row">
                        <div class="col col-lg-6 col-md-6 col-12">
                            <div class="wpo-pricing-item">
                                <div class="wpo-pricing-top pb-1">
                                    <div class="wpo-pricing-text">
                                        <h4 style="font-weight: bold; padding-top: 16px;">{{ $undangan->tempat[0]->nama_bank }}</h4>
                                        <h2 style="font-size: 28px;" id="bank_1">{{ $undangan->tempat[0]->nomor_rekening }}</h2>
                                        <h4 class="pt-3">{{ $undangan->tempat[0]->pemilik_rekening }}</h4>
                                    </div>
                                </div>
                                <div class="shape"><img src="{{ asset('frontend/undangan/lovelove/images/pricing/p-shape.svg') }}" alt=""></div>
                                <div class="wpo-pricing-bottom py-3">
                                    <div class="wpo-pricing-bottom-text">
                                        <button onclick="copyNoRekening('#bank_1')" class="btn btn-primary mb-2">Salin Nomor Rekening</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @if (!empty($undangan->tempat[1]->nama_bank))
                        <div class="col col-lg-6 col-md-6 col-12">
                            <div class="wpo-pricing-item">
                                <div class="wpo-pricing-top pb-1">
                                    <div class="wpo-pricing-text">
                                        <h4 style="font-weight: bold; padding-top: 16px;">{{ $undangan->tempat[1]->nama_bank }}</h4>
                                        <h2 style="font-size: 28px;" id="bank_2">{{ $undangan->tempat[1]->nomor_rekening }}</h2>
                                        <h4 class="pt-3">{{ $undangan->tempat[1]->pemilik_rekening }}</h4>
                                    </div>
                                </div>
                                <div class="shape"><img src="{{ asset('frontend/undangan/lovelove/images/pricing/p-shape.svg') }}" alt=""></div>
                                <div class="wpo-pricing-bottom py-3">
                                    <div class="wpo-pricing-bottom-text">
                                        <button onclick="copyNoRekening('#bank_2')" class="btn btn-primary mb-2">Salin Nomor Rekening</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </section>
        <!-- start wpo-pricing-section -->
        @endif

        <!-- wpo-site-footer start -->
        <div class="wpo-site-footer text-center" style="padding-top: 30px; padding-bottom: 30px;">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="copyright mt-0">
                            <p><a href="{{ url('/') }}">{{ $set_umum->value_3 }}. All Right Reserved.</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- wpo-site-footer end -->

    <!-- Modal -->
    <div class="modal fade show" id="fullwedding" style="display: block">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="modal-body" style="padding: 0px;">
                    <!-- start of hero -->
                    <section class="static-hero-s4" style="min-height: 650px;">
                        <div class="hero-container">
                            <div class="hero-inner" style="padding: 0px;">
                                <div class="container">
                                    <div class="row justify-content-center">
                                        <div class="col-lg-12">
                                            <div class="wpo-event-item" style="padding: 0px; height: 650px; margin-top: 40px;">
                                                <div class="wpo-event-text">
                                                    <h2 style="font-weight: bold;">{{ $undangan->nama_pria.' & '.$undangan->nama_wanita }}</h2>
                                                    <p style="font-size: 20px; margin-bottom: 10px; line-height: 20px;">Kepada yang terhormat Bapak/Ibu/Saudara/i :</p>
                                                    <p style="font-size: 25px; font-weight: bold; margin-bottom: 10px;">{{ $tamu }}</p>
                                                    <button class="btn btn-primary btn-lg mb-2" id="bukaUndangan">Buka Undangan</button>
                                                    <p style="margin-bottom: 0px; font-size: 18px; line-height: 20px;">Mohon maaf jika ada kesalahan penulisan nama dan gelar</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- end of hero slider -->
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="ucapanModal" tabindex="-1" aria-labelledby="ucapanModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="ucapanModalLabel">Ucapan dari tamu undangan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-striped" width="100%" id="table_ucapan">
                            <thead>
                                <tr>
                                    <th>Nama Tamu</th>
                                    <th>Ucapan Tamu</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if (!empty($undangan->slider->musik))
        <button class="button-musik"><i class="fa fa-pause"></i></button>
        <audio id="musik" src="{{ asset('frontend/undangan/musik/' . $undangan->slider->musik) }}"></audio>
    @endif
    <!-- All JavaScript files
    ================================================== -->
    <script src="{{ asset('frontend/undangan/lovelove/js/jquery.min.js') }}"></script>
    <!-- DataTables -->
    <script src="{{ asset('frontend/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('frontend/undangan/lovelove/js/bootstrap.bundle.min.js') }}"></script>
    <!-- Plugins for this template -->
    <script src="{{ asset('frontend/undangan/lovelove/js/modernizr.custom.js') }}"></script>
    <script src="{{ asset('frontend/undangan/lovelove/js/jquery.dlmenu.js') }}"></script>
    <script src="{{ asset('frontend/undangan/lovelove/js/jquery-plugin-collection.js') }}"></script>
    <!-- Custom script for this template -->
    <script src="{{ asset('frontend/libs/js/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('frontend/undangan/lovelove/js/script.js') }}"></script>
    <script type="text/javascript">
        $('#clock').countdown("{{ $tanggal_nikah }}", function (event) {
            var $this = $(this).html(event.strftime(''
                + '<div class="box"><div><div class="time">%D</div> <span>Hari</span> </div></div>'
                + '<div class="box"><div><div class="time">%H</div> <span>Jam</span> </div></div>'
                + '<div class="box"><div><div class="time">%M</div> <span>Menit</span> </div></div>'
                + '<div class="box"><div><div class="time">%S</div> <span>Detik</span> </div></div>'));
        });

        $("#bukaUndangan").click(function () {
            $("#fullwedding").fadeToggle("slow");
            @if(!empty($undangan->slider->musik))
                $("#musik")[0].play();
                $("#musik").on("ended", function() {
                    this.currentTime = 0;
                    this.play();
                });
                $(".button-musik").click(function() {
                    if ($(this).find("i").hasClass("fa-play")) {
                        $("#musik")[0].play();
                        $(this).html('<i class="fa fa-pause"></i>');
                    } else {
                        $("#musik")[0].pause();
                        $(this).html('<i class="fa fa-play"></i>');
                    }
                });
            @endif
        });

        $(function () {
            $.ajaxSetup({
                headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.fn.dataTable.ext.classes.sPageButton = 'btn btn-dark';
            var table = $('#table_ucapan').DataTable({
                language: {
                    "infoFiltered": "",
                    "zeroRecords": "Daftar tamu & ucapan masih kosong",
                    "paginate": {
                        "previous": "<i class='ti-angle-left'>",
                        "next": "<i class='ti-angle-right'>",
                    }
                },
                processing: true,
                serverSide: true,
                ajax: "{{ route('data_ucapan', $undangan->kode) }}",
                columns: [
                    { data: 'nama_tamu', name: 'nama_tamu' },
                    { data: 'ucapan', name: 'ucapan' },
                ],
                "bFilter": false,
                "bLengthChange": false,
                "bInfo": false,
                "ordering": false,
                "aoColumnDefs": [
                    { "className": "text-center", "targets" : [0] },
                ],
                "aaSorting": [],
            });
            $('#simpanBtn').click(function (e) {
                e.preventDefault();
                $(this).prop('disabled', true).html('Proses kirim...');
                $.ajax({
                    data: $('#ucapanForm').serialize(),
                    url: "{{ route('ucapan_tamu', $undangan->kode) }}",
                    type: "POST",
                    dataType: 'json',
                    success: function (data) {
                        $('#ucapanForm').trigger("reset");
                        table.draw();
                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            html: '<div style="font-size: 20px; font-weight: bold;">'+ data.message +'</div>',
                            showConfirmButton: false,
                            timer: 1500
                        });
                    },
                    error: function (data) {
                        var errors = data.responseJSON.errors;
                        var errorMessage = '';
                        for (var key in errors) {
                            errorMessage += errors[key] + '<br>';
                        }
                        $('#alert_message').html('<div class="alert alert-danger" >'+ errorMessage +'</div>');
                    },
                    complete: function () {
                        $('#simpanBtn').prop('disabled', false).html('Kirim');
                    }
                });
            });
        });
    </script>
    <!-- =======================================================
    * Template LoveLove: https://themeforest.net/item/lovelove-wedding-wedding-planner-html5-template/39643981
    * Image by: https://www.freepik.com/
    ======================================================== -->
</body>

</html>